 // TextureCoordinate.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;


public class TextureCoordinate extends SFNode {

	protected MFVec2f point = new MFVec2f(); // inits value is 0, 0

	public TextureCoordinate() {
		datatype = VRMLdatatype.TextureCoordinate;
	}

}//end class TextureCoordinate
