 // NavigationInfo.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 17, 2003

package d3d;


public class NavigationInfo {

	boolean created  = false; // if true, then a NavInfo node was in VRML file
	// and thus don't allow Dynamic-3D Creation tool applet parameters to override.
	float[] avatarSizeDefault = {.25f, .6f, .75f};
	private String[] typeDefault = { VRMLdatatype.string_WALK };

	/** <I>avatarSize</I> is not currently supported  */
	public MFFloat avatarSize = new MFFloat( avatarSizeDefault.length, avatarSizeDefault );
	public SFBool headlight = new SFBool( true );
	public SFFloat speed = new SFFloat( 1 );
	public MFString type = new MFString( typeDefault.length, typeDefault );
	/** <I>visibilityLimit</I> is not currently supported  */
	public SFFloat visibilityLimit = new SFFloat( 0 );

	public NavigationInfo() { } // not using the constructor

}//end class NavigationInfo
