 // WorldInfo.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 19, 2002

package d3d;


public class WorldInfo {

	public MFString info = new MFString();
	public SFString title = new SFString("");

	public WorldInfo() { }

}//end class WorldInfo
