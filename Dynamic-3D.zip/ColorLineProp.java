/*
ColorLineProp.java
Property of 3D-Online, All Rights Reserved, Copyright, 2003
April 14, 2003
*/

package d3d;


class ColorLineProp {

	 public float[] colorXdiff = new float[3];
	 public float[] colorYdiff = new float[3];
	 public float[] colorX = new float[3];

	public void SetUp (PolygonClass polygon) {
		int width = (int) (Math.ceil(polygon.vertex[1].x) - Math.ceil(polygon.vertex[0].x) ) + 1;
		int height = (int) ( Math.ceil(polygon.vertex[1].y) - Math.ceil(polygon.vertex[0].y) ) + 1;
		float[] colorDiff = new float[3];
		for (int i = 0; i < 3; i++) {
			colorDiff[i] = polygon.vertex[1].color[i] - polygon.vertex[0].color[i];
			// don't have to worry about divide by 0 since we added 1 above.
			colorXdiff[i] = colorDiff[i] / (width + height - 1);
			colorYdiff[i] = colorDiff[i] / height;
			colorX[i] = polygon.vertex[0].color[i];
		}

	}

	public void Step() {
		for (int i = 0; i < 3; i++) {
			colorX[i] += colorYdiff[i];
		}
	} // end step()

} // end class ColorLineProp