 // Dynamic3D.java
 // � 2002, 3D-Online, All Rights Reserved 
 // June 16, 2003

package d3d;


public class Dynamic3D {

	private final String timerString = "-timer";
	//private final int timerStringLength = timerString.length();
	private final String controlString = "control";
	//private final int controlStringLength = controlString.length();
	public static final String rotateString = "rotate";
	//private final int rotateStringLength = rotateString.length();
	private final String materialString = "material";
	//private final int materialStringLength = materialString.length();
	private final String reverseString = "_reverse";
	//private final int reverseStringLength = reverseString.length();
	private final String loopOnString = "_loopon";
	//private final int loopOnStringLength = loopOnString.length();
	private final String loopOffString = "_loopoff";
	//private final int loopOffStringLength = loopOffString.length();

	// appended to object names
	private final String touchSensorIndicatorString = "-TouchSensor";

	/* 3D Studio Max key words */ 
	final String PosInterpString = "-POS-INTERP";
	final int PosInterpStringLength = PosInterpString.length();
	final String RotInterpString = "-ROT-INTERP";
	final int RotInterpStringLength = RotInterpString.length();
	final String CoordInterpString = "-COORD-INTERP";
	final int CoordInterpStringLength = CoordInterpString.length();
	final String ScaleInterpString = "-SCALE-INTERP";
	final int ScaleInterpStringLength = ScaleInterpString.length();
	final String ScaleOrientationInterpString = "-SCALE-ORI-INTERP";
	final int ScaleOrientationInterpStringLength = ScaleOrientationInterpString.length();
	//final String exportedTimerName = "world-TIMER";  // Timer exported using Shout3D's exporter
	final float performance3DmodelTool = 1.0f; //adjusted for each 3D Modeling Tool

	private SFNode mainRoot = null;
	private Sensor mainSensorRoot = null;
	private Interpolator mainInterpolatorRoot = null;
   private Light mainLightsRoot = null;
	private Route mainRouteRoot = null;

	boolean reverse; //set true if reverse animation
	boolean enabledBegin; // set true if loopOn
	boolean loop; // set true for loopOn or loopOff



	private SFNode MatchRouteObjectName (String objectName, boolean testWithoutRotateString) {
		// check if in node list
		SFNode returnNode = null;
		String checkNodeName;
		//Note that Viewpoint is linked inside the mainRoot;
		SFNode checkNode = mainRoot.children;
		while (checkNode != null) {
			if (checkNode.name != null) {
				checkNodeName = checkNode.name;
				checkNodeName = checkNodeName.toLowerCase();
				if (objectName.equals(checkNodeName)) {
					returnNode = checkNode;
					break;
				}
				else if ( testWithoutRotateString ) {
					if ( checkNodeName.indexOf(rotateString) != -1) {
						checkNodeName = checkNodeName.substring(0, checkNodeName.indexOf(rotateString) );
						if (objectName.equals(checkNodeName)) {
							returnNode = checkNode;
							break;
						}
 				   }
				}
			}
			if (checkNode.children != null) {
				checkNode = checkNode.children;
			}
			else if (checkNode.next == null) {
				checkNode = checkNode.parent;
				// scale back up the later
				while ( (checkNode != mainRoot) && (checkNode.next == null) ) {
					checkNode = checkNode.parent;
				}
				checkNode = checkNode.next;
			} // end matchRoot.next == null, go to parent.next
			else {
				checkNode = checkNode.next;
			}
		} // end while loop
		return returnNode;
	}  // end MatchRouteObjectName



	private void GetRotateColorObjects () {
		// check if in node list
		String checkNodeName;
		//Note that Viewpoint is linked inside the mainRoot;
		SFNode checkNode = mainRoot.children;
		while (checkNode != null) {
			if (checkNode.name != null) {
				checkNodeName = checkNode.name;
				checkNodeName = checkNodeName.toLowerCase();

				if ( checkNodeName.indexOf(materialString) != -1) {
					String objName = checkNodeName.substring(0, checkNodeName.indexOf(materialString) );
					SFNode objToColor = MatchRouteObjectName (objName, true);
					if (objToColor != null) {
						// create the new touchSensor node, route it to the transform node
						TouchSensor newTouchSensor = new TouchSensor();
						newTouchSensor.next = mainSensorRoot.next;
						mainSensorRoot.next = newTouchSensor;
						newTouchSensor.name = checkNode.name + touchSensorIndicatorString;
						newTouchSensor.enabled.value = true;
						checkNode.touchSensor = newTouchSensor;

						// create the new dyanmic_Script node
						Dynamic3D_Script dynamic3D_Script = new Dynamic3D_Script();
						dynamic3D_Script.next = mainSensorRoot.next;
						mainSensorRoot.next = dynamic3D_Script;
						//dynamic3D_Script.name = transform.name + Dynamic3D_Script.dynamic3DIndicatorString;
						dynamic3D_Script.name = checkNode.name + Dynamic3D_Script.dynamic3DIndicatorString;
						dynamic3D_Script.scriptType = Dynamic3D_Script.materialChange;
						dynamic3D_Script.enabled.value = false;

						// add Route TouchSensor to Script
						Route routeTouchToScript = new Route();
						routeTouchToScript.fromObject = newTouchSensor;
						routeTouchToScript.toObject = dynamic3D_Script;
						RouteProperties fromTouchSensorProps = new RouteProperties();
						RouteProperties toScriptProps   = new RouteProperties();
						fromTouchSensorProps.isActiveProperty = true; // Dynamic-3D must be clicked on, not just mouse over
						toScriptProps.sfBool = true;
						routeTouchToScript.from = fromTouchSensorProps;
						routeTouchToScript.to   = toScriptProps;
						// add new route to the front of the list
						routeTouchToScript.nextRoute = mainRouteRoot.nextRoute;
						mainRouteRoot.nextRoute = routeTouchToScript;

						//Create the links to the Control Shape and Effect Shape nodes
						SFNode searchShapeNode = checkNode.children;
						while (searchShapeNode.datatype != VRMLdatatype.Shape) {
							searchShapeNode = searchShapeNode.children;
						}
						//controlAppearance
						//dynamic3D_Script.controlShape = (Shape) searchShapeNode;
						Shape controlShape = (Shape) searchShapeNode;
						dynamic3D_Script.controlAppearance = (Appearance) controlShape.appearance;
						dynamic3D_Script.effectNode = objToColor;

					} // end if ObjToColor != null
				} // end color string
				else if ( checkNodeName.indexOf(rotateString) != -1) {
					if ( checkNode.datatype == VRMLdatatype.Transform ) {

						//Add_Dynamic3DScript_ROUTEfromTransform(transform,
						//		routeScriptToTransform, dynamic3D_Script);
						Transform transform = (Transform) checkNode;
						// create the new dyanmic_Script node
						Dynamic3D_Script dynamic3D_Script = new Dynamic3D_Script();
						dynamic3D_Script.next = mainSensorRoot.next;
						mainSensorRoot.next = dynamic3D_Script;
						dynamic3D_Script.name = transform.name + Dynamic3D_Script.dynamic3DIndicatorString;
						dynamic3D_Script.scriptType = Dynamic3D_Script.rotate;
						dynamic3D_Script.enabled.value = false;

						// add Route Script to Transform
						Route routeScriptToTransform = new Route();
						routeScriptToTransform.fromObject = dynamic3D_Script;
						routeScriptToTransform.toObject = transform;
						RouteProperties fromScriptProps = new RouteProperties();
						RouteProperties toTransformProps   = new RouteProperties();
						fromScriptProps.sfBool = true; // Dynamic-3D must be clicked on, not just mouse over
						toTransformProps.sfRotation = transform.rotation.rotation;
						routeScriptToTransform.from = fromScriptProps;
						routeScriptToTransform.to   = toTransformProps;
						// add new route to the front of the list
						routeScriptToTransform.nextRoute = mainRouteRoot.nextRoute;
						mainRouteRoot.nextRoute = routeScriptToTransform;

						// create the new touchSensor node
						TouchSensor newTouchSensor = new TouchSensor();
						newTouchSensor.next = mainSensorRoot.next;
						mainSensorRoot.next = newTouchSensor;
						newTouchSensor.name = transform.name + touchSensorIndicatorString;
						newTouchSensor.enabled.value = true;
						transform.touchSensor = newTouchSensor;

						// add Route TouchSensor to Script
						Route routeTouchToScript = new Route();
						routeTouchToScript.fromObject = newTouchSensor;
						routeTouchToScript.toObject = dynamic3D_Script;
						//fromNode.touchSensor = newTouchSensor;
						//transform.touchSensor = newTouchSensor;
						RouteProperties fromTouchSensorProps = new RouteProperties();
						RouteProperties toScriptProps   = new RouteProperties();
						fromTouchSensorProps.isActiveProperty = true; // Dynamic-3D must be clicked on, not just mouse over
						toScriptProps.sfBool = true;
						routeTouchToScript.from = fromTouchSensorProps;
						routeTouchToScript.to   = toScriptProps;
						// add new route to the front of the list
						routeTouchToScript.nextRoute = mainRouteRoot.nextRoute;
						mainRouteRoot.nextRoute = routeTouchToScript;
					} // end if checkNode == Transform
				} // end if checkNode contains rotateString
			} // end if checkNode.name != null
			if (checkNode.children != null) {
				checkNode = checkNode.children;
			}
			else if (checkNode.next == null) {
				checkNode = checkNode.parent;
				// scale back up the later
				while ( (checkNode != mainRoot) && (checkNode.next == null) ) {
					checkNode = checkNode.parent;
				}
				checkNode = checkNode.next;
			} // end matchRoot.next == null, go to parent.next
			else {
				checkNode = checkNode.next;
			}
		} // end while loop
	}  // end GetRotateColorObjects




	private TouchSensor InsertTouchSensorAndScriptRoute (SFNode fromNode, TimeSensor toTimeSensor) {
		Sensor currentSensor = null;

		// Find the existing Dynamic3DScript and if not found, Create a new Dynamic_3D Script node
		String dynamic3D_ScriptName = fromNode.name + Dynamic3D_Script.dynamic3DIndicatorString; 
		currentSensor =  (Sensor) mainSensorRoot.next;
		while ( currentSensor != null ) {
			if (currentSensor.name.equals(dynamic3D_ScriptName) ) {
				break;
			}
			currentSensor = (Sensor) currentSensor.next;
		}
		Dynamic3D_Script dynamic3D_Script = null;
		if ( currentSensor != null ) {
			dynamic3D_Script = (Dynamic3D_Script) currentSensor;
		}
		else {
			dynamic3D_Script = new Dynamic3D_Script();
			dynamic3D_Script.next = mainSensorRoot.next;
			mainSensorRoot.next = dynamic3D_Script;
			dynamic3D_Script.name = dynamic3D_ScriptName;
			if (reverse) dynamic3D_Script.scriptType = Dynamic3D_Script.reverse;
			else if (loop) dynamic3D_Script.scriptType = Dynamic3D_Script.looping;
			else dynamic3D_Script.scriptType = Dynamic3D_Script.singleAnimation;
			dynamic3D_Script.enabled.value = enabledBegin;
			dynamic3D_Script.nextAnimation = true; // toggles for the reverse animations

			// add a Route: Script to Time Sensor
			Route routeScriptToTimer = new Route();
			routeScriptToTimer.fromObject = dynamic3D_Script;
			routeScriptToTimer.toObject = toTimeSensor;
			//toTimeSensor.loop = true;
			toTimeSensor.loop.setValue( loop );
			toTimeSensor.enabled = dynamic3D_Script.enabled;
			RouteProperties fromScriptProps = new RouteProperties();
			RouteProperties toNodeProps   = new RouteProperties();
			fromScriptProps.sfBool = true; // Dynamic-3D must be clicked on, not just mouse over
			toNodeProps.sfBool = true;
			routeScriptToTimer.from = fromScriptProps;
			routeScriptToTimer.to   = toNodeProps;
			// add new route to the front of the list
			routeScriptToTimer.nextRoute = mainRouteRoot.nextRoute;
			mainRouteRoot.nextRoute = routeScriptToTimer;
		}

		// find the existing TouchSensor and if not found, create new touch sensor
		String newTouchSensorName = fromNode.name + touchSensorIndicatorString;
		currentSensor = (Sensor) mainSensorRoot.next;
		while ( currentSensor != null ) {
			if (currentSensor.name.equals(newTouchSensorName) ) {
				break;
			}
			currentSensor = (Sensor) currentSensor.next;
		}
		TouchSensor newTouchSensor = null;
		if ( currentSensor != null ) {
			newTouchSensor = (TouchSensor) currentSensor;
		}
		else {
			newTouchSensor = new TouchSensor();
			newTouchSensor.next = mainSensorRoot.next;
			mainSensorRoot.next = newTouchSensor;
			newTouchSensor.name = newTouchSensorName;
			newTouchSensor.enabled.value = true;

			// add a Route: TouchSensor to Script Node
			Route routeTouchToScript = new Route();
			routeTouchToScript.fromObject = newTouchSensor;
			routeTouchToScript.toObject = dynamic3D_Script;
			fromNode.touchSensor = newTouchSensor;
			RouteProperties fromTouchSensorProps = new RouteProperties();
			RouteProperties toScriptProps   = new RouteProperties();
			fromTouchSensorProps.isActiveProperty = true; // Dynamic-3D must be clicked on, not just mouse over
			toScriptProps.sfBool = true;
			routeTouchToScript.from = fromTouchSensorProps;
			routeTouchToScript.to   = toScriptProps;
			// add new route to the front of the list
			routeTouchToScript.nextRoute = mainRouteRoot.nextRoute;
			mainRouteRoot.nextRoute = routeTouchToScript;
		}
		return newTouchSensor;
	} // end InsertTouchSensorRoute
	
	
	
	private void InsertReverseKeyFrame (SFNode transformNode, TimeSensor timerNode, Interpolator currInterpolator, TouchSensor newTouchSensor) {
		// inserts a reverse direction KeyFrame Interpolator, Timer and Route
		String reverseInterpolatorName = currInterpolator.name + Dynamic3D_Script.reverseIndicatorString;
		PositionInterpolator reversePositionInterpolator = null;
		OrientationInterpolator reverseOrientationInterpolator = null;

		if (currInterpolator.datatype == VRMLdatatype.PositionInterpolator) {
			PositionInterpolator currPositionInterpolator = (PositionInterpolator) currInterpolator;
			reversePositionInterpolator = new PositionInterpolator();
			reversePositionInterpolator.name = reverseInterpolatorName;
			reversePositionInterpolator.key.values = new float[currInterpolator.key.values.length];
			reversePositionInterpolator.keyValue = new MFVec3f ();
			reversePositionInterpolator.keyValue.vec3s = new float[currPositionInterpolator.keyValue.vec3s.length][3];
			for (int i = 0; i < currPositionInterpolator.keyValue.vec3s.length; i++) {
				for (int j = 0; j < 3; j++) {
					reversePositionInterpolator.keyValue.vec3s[i][j] =
						currPositionInterpolator.keyValue.vec3s[currPositionInterpolator.keyValue.vec3s.length - i - 1][j];
				}
			}
			for (int i = 0; i < currInterpolator.key.values.length; i++) {
				reversePositionInterpolator.key.values[i] =
					1 - currPositionInterpolator.key.values[currPositionInterpolator.key.values.length - i - 1];
			}
			reversePositionInterpolator.nextInterpolator = currPositionInterpolator.nextInterpolator;
			currPositionInterpolator.nextInterpolator = reversePositionInterpolator;
		} // Position

		else if (currInterpolator.datatype == VRMLdatatype.OrientationInterpolator) {
			OrientationInterpolator currOrientationInterpolator = (OrientationInterpolator) currInterpolator;
			reverseOrientationInterpolator = new OrientationInterpolator();
			reverseOrientationInterpolator.name = reverseInterpolatorName;
			reverseOrientationInterpolator.key.values = new float[currOrientationInterpolator.key.values.length];
			reverseOrientationInterpolator.keyValue = new MFRotation ();
			reverseOrientationInterpolator.keyValue.rotations = new float[currOrientationInterpolator.keyValue.rotations.length][4];

			for (int i = 0; i < currOrientationInterpolator.keyValue.rotations.length; i++) {
				for (int j = 0; j < 4; j++) {
					reverseOrientationInterpolator.keyValue.rotations[i][j] =
						currOrientationInterpolator.keyValue.rotations[currOrientationInterpolator.keyValue.rotations.length - i - 1][j];
				}
			}
			for (int i = 0; i < currInterpolator.key.values.length; i++) {
				reverseOrientationInterpolator.key.values[i] =
					1 - currOrientationInterpolator.key.values[currOrientationInterpolator.key.values.length - i - 1];
			}
			reverseOrientationInterpolator.nextInterpolator = currInterpolator.nextInterpolator;
			currInterpolator.nextInterpolator = reverseOrientationInterpolator;
		} // end OrientationInterpolator

		/**** end of reversing ******/


		// add a Route from Interpolator to Transform
		Route routeInterpolatorTransform = new Route();
		//routeInterpolatorTransform.fromObject = reverseInterpolator;
		routeInterpolatorTransform.toObject = transformNode;
		RouteProperties fromInterpolatorProps = new RouteProperties();
		RouteProperties toTransformProps   = new RouteProperties();
		Transform transform = (Transform) transformNode;
		if (currInterpolator.datatype == VRMLdatatype.PositionInterpolator) {
			fromInterpolatorProps.mfVec3f = reversePositionInterpolator.keyValue.vec3s;
			toTransformProps.sfVec3f = transform.translation.getValue();
			routeInterpolatorTransform.fromObject = reversePositionInterpolator;
		}
		else if (currInterpolator.datatype == VRMLdatatype.OrientationInterpolator) {
			fromInterpolatorProps.mfRotation = reverseOrientationInterpolator.keyValue.rotations;
			toTransformProps.sfRotation = transform.rotation.getValue();
			routeInterpolatorTransform.fromObject = reverseOrientationInterpolator;
		}
		routeInterpolatorTransform.from = fromInterpolatorProps;
		routeInterpolatorTransform.to = toTransformProps;
		// add new route to the front of the list
		routeInterpolatorTransform.nextRoute = mainRouteRoot.nextRoute;
		mainRouteRoot.nextRoute = routeInterpolatorTransform;


		// Add a new reverse timer, with similar values of the forward timer
		Sensor currentSensor = null;
		String reverseTimeSensorName = timerNode.name + Dynamic3D_Script.reverseIndicatorString; 
		currentSensor = (Sensor) mainSensorRoot.next;
		TimeSensor reverseTimeSensor = null;
		while ( currentSensor != null ) {
			if (currentSensor.name.equals(reverseTimeSensorName) ) {
				break;
			}
			currentSensor = (Sensor) currentSensor.next;
		}
		if ( currentSensor != null ) {
			reverseTimeSensor = (TimeSensor) currentSensor;
		}
		else {
			// reverseTimeSensor did not previously exist so add a new timesensor
			reverseTimeSensor = new TimeSensor();
			reverseTimeSensor.loop.setValue( false );
//reverseTimeSensor.stopTime.time = java.lang.Long.MAX_VALUE;
			reverseTimeSensor.enabled.value = false; // added on 08/17/04 to fix timer loop = false issue
			timerNode.loop.setValue( false );
			reverseTimeSensor.name = reverseTimeSensorName;
			reverseTimeSensor.cycleInterval = timerNode.cycleInterval;
			reverseTimeSensor.next = mainSensorRoot.next;
			mainSensorRoot.next = reverseTimeSensor;
		}

		// add a Route from TimeSensor to Interpolator
		Route routeTimerInterpolator = new Route();
		routeTimerInterpolator.fromObject = reverseTimeSensor;
		RouteProperties fromTimerProps = new RouteProperties();
		routeTimerInterpolator.from = fromTimerProps;
		RouteProperties toInterpolatorProps   = new RouteProperties();
		routeTimerInterpolator.to   = toInterpolatorProps;
		fromTimerProps.sfTime = timerNode.startTime.time;
		if (currInterpolator.datatype == VRMLdatatype.PositionInterpolator) {
			routeTimerInterpolator.toObject = reversePositionInterpolator;
			toInterpolatorProps.mfFloat = reversePositionInterpolator.key.values;
		}
		else {
			routeTimerInterpolator.toObject = reverseOrientationInterpolator;
			toInterpolatorProps.sfRotation = reverseOrientationInterpolator.key.values;
		}
		//toInterpolatorProps.mfFloat = reverseInterpolator.key.values;
		// add new route to the front of the list
		routeTimerInterpolator.nextRoute = mainRouteRoot.nextRoute;
		mainRouteRoot.nextRoute = routeTimerInterpolator;


		// Create the Dynamic_3D Script node
		String dynamic3D_Reverse_ScriptName = transformNode.name + Dynamic3D_Script.dynamic3DIndicatorString + Dynamic3D_Script.reverseIndicatorString; 
		currentSensor = (Sensor) mainSensorRoot.next;
		Dynamic3D_Script dynamic3D_Reverse_Script = null;
		while ( currentSensor != null ) {
			if (currentSensor.name.equals(dynamic3D_Reverse_ScriptName) ) {
				break;
			}
			currentSensor = (Sensor) currentSensor.next;
		}
		if ( currentSensor != null ) { // dynamic3D_reverse_Script already existed
			dynamic3D_Reverse_Script = (Dynamic3D_Script) currentSensor;
		}
		else { // add a new dynamic3D_reverse_Script
			//Dynamic3D_Script dynamic3D_Reverse_Script = new Dynamic3D_Script();
			dynamic3D_Reverse_Script = new Dynamic3D_Script();
			dynamic3D_Reverse_Script.name = dynamic3D_Reverse_ScriptName;
			dynamic3D_Reverse_Script.scriptType = Dynamic3D_Script.reverse;
			dynamic3D_Reverse_Script.enabled.value = false;
			dynamic3D_Reverse_Script.nextAnimation = false; // toggles for the reverse animations
			dynamic3D_Reverse_Script.next = mainSensorRoot.next;
			mainSensorRoot.next = dynamic3D_Reverse_Script;

			// Add Route from Script to TimeSensor
			Route routeScriptTimer = new Route();
			routeScriptTimer.fromObject = dynamic3D_Reverse_Script;
			routeScriptTimer.toObject = reverseTimeSensor;
			RouteProperties fromScriptProps = new RouteProperties();
			RouteProperties toTimerProps   = new RouteProperties();
			fromScriptProps.isActiveProperty = true; // Dynamic-3D must be clicked on, not just mouse over
			toTimerProps.sfBool = true;
			routeScriptTimer.from = fromScriptProps;
			routeScriptTimer.to   = toTimerProps;
			// add new route to the front of the list
			routeScriptTimer.nextRoute = mainRouteRoot.nextRoute;
			mainRouteRoot.nextRoute = routeScriptTimer;

			//add Route from existing TouchSensor to ScriptSensor
			Route routeTouchTimer = new Route();
			routeTouchTimer.fromObject = newTouchSensor;
			routeTouchTimer.toObject = dynamic3D_Reverse_Script;
			RouteProperties fromTouchProps = new RouteProperties();
			RouteProperties toScriptProps   = new RouteProperties();
			fromTouchProps.isActiveProperty = true; // Dynamic-3D must be clicked on, not just mouse over
			toScriptProps.sfBool = true;
			routeTouchTimer.from = fromTouchProps;
			routeTouchTimer.to   = toScriptProps;
			// add new route to the front of the list
			routeTouchTimer.nextRoute = mainRouteRoot.nextRoute;
			mainRouteRoot.nextRoute = routeTouchTimer;
		}
	} // end InsertReverseKeyFrame



	public void Parser() {
		String clickedObjectName = null;
		String interpObjectName  = null;
		String nonAppendObjectName  = null;
		String timerSensorString = null;
		reverse = false;
		enabledBegin = false;
		loop = false; // set true for loopOn or loopOff
		try {
			Interpolator currInterpolator = (Interpolator) mainInterpolatorRoot.next;
			while ( currInterpolator != null ) {
				nonAppendObjectName = null;
				clickedObjectName   = null;
				interpObjectName    = null;
	
				// Get the object refered to in the in the interpolator
				if ( currInterpolator.name.indexOf(PosInterpString) != -1) {
					interpObjectName = currInterpolator.name.substring(0, currInterpolator.name.indexOf(PosInterpString) );
				}
				else if ( currInterpolator.name.indexOf(RotInterpString) != -1) {
					interpObjectName = currInterpolator.name.substring(0, currInterpolator.name.indexOf(RotInterpString) );
				}
				else if ( currInterpolator.name.indexOf(CoordInterpString) != -1) {
					interpObjectName = currInterpolator.name.substring(0, currInterpolator.name.indexOf(CoordInterpString) );
				}
				else if ( currInterpolator.name.indexOf(ScaleInterpString) != -1) {
					interpObjectName = currInterpolator.name.substring(0, currInterpolator.name.indexOf(ScaleInterpString) );
				}
				else if ( currInterpolator.name.indexOf(ScaleOrientationInterpString) != -1) {
					interpObjectName = currInterpolator.name.substring(0, currInterpolator.name.indexOf(ScaleOrientationInterpString) );
				}
	
				if ( interpObjectName != null ) {
					interpObjectName = interpObjectName.toLowerCase();
		
					// Get the reverse, loopOn or loopOff command
					if (interpObjectName.indexOf(reverseString) != -1) {
						reverse = true;
						nonAppendObjectName = interpObjectName.substring(0, interpObjectName.indexOf(reverseString));
					}
					else if (interpObjectName.indexOf(loopOnString) != -1) {
						enabledBegin = true;
						loop = true;
						nonAppendObjectName = interpObjectName.substring(0, interpObjectName.indexOf(loopOnString));
					}
					else if (interpObjectName.indexOf(loopOffString) != -1) {
						loop = true;
						nonAppendObjectName = interpObjectName.substring(0, interpObjectName.indexOf(loopOffString));
					}
	
					// get the object that is clicked on
					if (interpObjectName.indexOf(controlString) != -1) {
						clickedObjectName = interpObjectName;
					}
					else {
						clickedObjectName = nonAppendObjectName + controlString;
					}
	
					if (clickedObjectName.indexOf(controlString) != -1) {
						// only parse and append if there is a 'control' string
						// Get the timer
						timerSensorString = interpObjectName + timerString;
						SFNode currTimerNode = (SFNode) mainSensorRoot.next;
						while ( currTimerNode != null ) {
							String timeNodeLC = new String(currTimerNode.name);
							timeNodeLC = timeNodeLC.toLowerCase();
							if ( timeNodeLC.equals(timerSensorString) ) {
								TimeSensor timeSensor = (TimeSensor) currTimerNode;
								SFNode clickTransformNode = MatchRouteObjectName (clickedObjectName, false);
								TouchSensor newTouchSensor = InsertTouchSensorAndScriptRoute (clickTransformNode, timeSensor); // insert the touch sensor
								if ( reverse ) {
									SFNode interpolatedTransformNode = MatchRouteObjectName (interpObjectName, false);
//timeSensor.stopTime.time = java.lang.Long.MAX_VALUE;
									InsertReverseKeyFrame(interpolatedTransformNode, timeSensor, currInterpolator, newTouchSensor);
								}
								break;
							}
							currTimerNode = (SFNode) currTimerNode.next;
						} // end while currTimerNode != null 
					} // end if controlString contained in name
				} // end if interpObjectName != null
	
				currInterpolator = (Interpolator) currInterpolator.next;
			} // end while currInterpolator != null
		} // end try
		catch (Exception e) { // error in Dyanmic-3D object name matching
			//System.out.println("Warning: Dynamic-3D parser:");
			//System.out.println("   Possible object - timer - interpolator name mismatch");
		} // end catch
		GetRotateColorObjects(); 

	} // end parser



	public Dynamic3D (Group root, Sensor sensorRoot, Interpolator interpolatorRoot,
							Light lightsRoot, Route routeRoot) {
		mainRoot = root;
		mainSensorRoot = sensorRoot;
		mainInterpolatorRoot = interpolatorRoot;
   	mainLightsRoot = lightsRoot;
   	mainRouteRoot = routeRoot;
	}

} // end class Dynamic3D
