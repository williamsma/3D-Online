// GraphicsEngineInit.java
// � 2002, 3D-Online, All Rights Reserved 
// Date: January 21, 2004

package d3d;


import java.applet.Applet;
import java.applet.AppletContext;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.net.MalformedURLException;
import java.net.URL;
import java.awt.Image;
import java.awt.Panel;
import java.awt.Label;
import java.awt.Font;


public class GraphicsEngineInit {
	final int topPanelHeightConst = 30;
	final int maxNonRegisteredWidth  = 320;
	final int maxNonRegisteredHeight = 270;

	int topPanelHeight = 0;
	Label label3DOnline = null;
	Dimension appDim = null;
	public Panel topPanel = null;
	public GraphicEngine graphicsEnginePanel = null;
	Applet applet = null;
	AppletContext appletContext = null;
	TopLabelMouseClicks labelMouseClicks = null;

	public int GetWidth() {
		return appDim.width;
	}


	private void SetLabel(String text1, String text2) {
		label3DOnline.setBackground(java.awt.Color.black);
		label3DOnline.setForeground(java.awt.Color.lightGray);
		if ( appDim.width < 240) {
			label3DOnline.setFont(new Font("Serif", Font.BOLD, 12));
			label3DOnline.setText(text1);
		}
		else if ( appDim.width < 320) {
			label3DOnline.setFont(new Font("Serif", Font.BOLD, 14));
			label3DOnline.setText(text1);
		}
		else if ( appDim.width < 400) {
			label3DOnline.setFont(new Font("Serif", Font.BOLD, 12));
			label3DOnline.setText(text1 + text2);
		}
		else {
			label3DOnline.setFont(new Font("Serif", Font.BOLD, 16));
			label3DOnline.setText(text1 + text2);
		}
		label3DOnline.setAlignment(Label.CENTER);
		label3DOnline.setBounds(0, 0, appDim.width, topPanelHeightConst);
	}


	public GraphicsEngineInit( Applet applet_, int[] pctComplete, AppletParameters appletParameters_) {
		applet = applet_;
		appletContext = applet.getAppletContext();
		pctComplete[0] = 20;
		applet.repaint();

		appDim = applet.getSize();

		AppletParameters appletParameters = appletParameters_;
		appletParameters.key *=2;
		appletParameters.key++;

		//registeredUser = appletParameters.GetRegistration();
		//appletParameters.SetRegistration();
//appletParameters.registeredUser = false;

		if ( !appletParameters.registeredUser ) {
			topPanelHeight = topPanelHeightConst;
	
			topPanel = new Panel();
			topPanel.setLayout(null);
			topPanel.setBounds(0, 0, appDim.width, topPanelHeightConst);
			topPanel.setBackground(java.awt.Color.black);
			topPanel.setCursor(java.awt.Cursor.getPredefinedCursor(java.awt.Cursor.HAND_CURSOR));
			applet.add(topPanel);

			label3DOnline = new Label();
			topPanel.add(label3DOnline);
			SetLabel("Dynamic-3D, 3D-Online", ", http://www.3D-Online.com");
	
			labelMouseClicks = new TopLabelMouseClicks();
			label3DOnline.addMouseListener(labelMouseClicks); // captures mouse clicks
		}
		// show the progress bar
		graphicsEnginePanel = new GraphicEngine();
		pctComplete[0] = 40;
		applet.repaint();
		graphicsEnginePanel.setLayout(null);
		int width = appDim.width;
		int height = appDim.height - topPanelHeight; 
		if ( !appletParameters.registeredUser ) {
			if (width  > maxNonRegisteredWidth ) width  = maxNonRegisteredWidth;
			if (height > maxNonRegisteredHeight) height = maxNonRegisteredHeight;
		}
		//graphicsEnginePanel.setBounds(0, topPanelHeight, appDim.width, (appDim.height - topPanelHeight) );
		graphicsEnginePanel.setBounds(0, topPanelHeight, width, height );

		//pctComplete[0] = 80;
		pctComplete[0] += 20;
		applet.repaint();
		graphicsEnginePanel.init(applet, appletParameters, topPanelHeight, pctComplete );
		//pctComplete[0] = 90;
		pctComplete[0] += 10;
		applet.repaint();
		applet.add(graphicsEnginePanel);
		graphicsEnginePanel.start();
		pctComplete[0] = 100;
		applet.repaint();
		//applet.repaint(); // need this  a second time to clear screen and check registration
	} // end GraphicsEngineInit.run

		public GraphicEngine GetGraphicEngine() {
			return graphicsEnginePanel;
		}

	
		/*
	public void stop() {
		//graphicsEnginePanel.stop();
		//super.stop(); // wasn't able to get this to compile
		//super.applet.stop();
		if (renderer != null); {
			renderer = null;
		}
	}
	*/
	public void destory() {
		graphicsEnginePanel.destroy();
	}

	class TopLabelMouseClicks extends java.awt.event.MouseAdapter {
		//public TopLabelMouseClicks() {}

		public void mousePressed(java.awt.event.MouseEvent event) {
			Object object = event.getSource();
			if (object == label3DOnline) {
				try {
					URL url = new URL ( applet.getCodeBase(), "http://www.3D-Online.com" );
					appletContext.showDocument(url, "_blank");
				}
				catch ( MalformedURLException e) {}
			}
		}
	}


} // end class GraphicsEngineInit
