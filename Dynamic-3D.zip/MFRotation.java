 // MFRotation.java
 // � 2002, 3D-Online, All Rights Reserved 
 // December 6, 2003

package d3d;

public class MFRotation {

	float[][] rotations = null;

	// constructor
	public MFRotation () {
	}
	public MFRotation ( int size, float[] rotations ) {
		this.setValue(size, rotations);
	}
	public MFRotation ( float[][] rotations ) {
		this.setValue(rotations);
	}

	// setValue
	public void setValue (float[][] rotations) {
		this.rotations = new float[rotations.length][4];
		for (int i = 0; i < rotations.length; i++ ) {
			for (int j = 0; j < 4; j++) {
				this.rotations[i][j] = rotations[i][j];
			}
		}
	}
	public void setValue (int size, float[] rotations ) {
  		int totalRotations = size/4;
		this.rotations = new float[totalRotations][4];
		for (int i = 0; i < totalRotations; i++ ) {
			for (int j = 0; j < 4; j++) {
				this.rotations[i][j] = rotations[i*4 + j];
			}
		}
	}

	// getValue
	public float[] get1Value(int index) {
		return this.rotations[index];
	}
	public float[][] getValue() {
		return this.rotations;
	}
	/** returns <I>rotations</I> separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < rotations.length; i++ ) {
			for (int j = 0; j < 4; j++) {
				returnString += (rotations[i][j] + " ");
			}
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFRotation
