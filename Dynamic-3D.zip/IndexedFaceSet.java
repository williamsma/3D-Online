 // IndexedFaceSet.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002

package d3d;


import java.util.Vector;


public class IndexedFaceSet extends IndexedSet {
	Normal normalPolygon = null; // normals for each polygon
	int[][] normalVertexIndex = null;									 
	int[] normalPolygonIndex = null;									 
	Vector normalStream = new Vector();
	Vector normalIndexStream = new Vector();

	//public SFNode normalVertex = null;
	public SFNode normal = null;
	/** <I>ccw</I> not supported, set to its default TRUE */
	public SFBool ccw = new SFBool( true );
	/** <I>convex</I> not supported, set to its default TRUE */
	public SFBool convex = new SFBool( true );
	public SFFloat creaseAngle = new SFFloat( .004f );  // works
	public SFBool normalPerVertex = new SFBool( true );
	/** <I>solid</I> not supported, set to its default TRUE */
	public SFBool solid = new SFBool( true );

	//public TextureCoordinate texCoord = null;
	public SFNode texCoord = null;
	public MFInt32 texCoordIndex = null; // constructed in LexicalAnalyzer


	// constructor
	public IndexedFaceSet () {
		datatype = VRMLdatatype.IndexedFaceSet;
	}

} // end class IndexedFaceSet
