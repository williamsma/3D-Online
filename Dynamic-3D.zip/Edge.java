/* Edge.java
Property of 3D-Online, All Rights Reserved, Copyright, 2002
*/

package d3d;


public class Edge {

	public int Height = 0;
	public int Y = 0;
	int X;
	int XStep;
	int Numerator;
	int Denominator;
	int ErrorTerm;


	public float OneOverZ; // 1/z and step
	private float OneOverZStep; // 1/z and step
	private float OneOverZStepExtra; // extra for int interpolation
	public float UOverZ; // u/z and step
	private float UOverZStep; // u/z and step
	private float UOverZStepExtra; // extra for int interpolation
	public float VOverZ; // v/z and step
	private float VOverZStep; // v/z and step
	private float VOverZStepExtra; // extra for int interpolation

	public float redOverZ;
	private float redOverZStep; // red/z and step
	private float redOverZStepExtra; // extra for int interpolation
	public float greenOverZ;
	private float greenOverZStep; // green/z and step
	private float greenOverZStepExtra; // extra for int interpolation
	public float blueOverZ;
	private float blueOverZStep; // blue/z and step
	private float blueOverZStepExtra; // extra for int interpolation
	

	//public int Step () {
	public void Step () {
		X += XStep;
		Y++;
		UOverZ += UOverZStep;
		VOverZ += VOverZStep;
		OneOverZ += OneOverZStep;
		redOverZ += redOverZStep;
		greenOverZ += greenOverZStep;
		blueOverZ += blueOverZStep;

		ErrorTerm += Numerator;
		if ( ErrorTerm >= Denominator ) {
			X++;
			ErrorTerm -= Denominator;
			UOverZ += UOverZStepExtra;
			VOverZ += VOverZStepExtra;
			OneOverZ += OneOverZStepExtra;
			redOverZ += redOverZStepExtra;
			greenOverZ += greenOverZStepExtra;
			blueOverZ += blueOverZStepExtra;
		}
		//return Height;
	} // end Step


	public Edge () { } // Constructor


	private void FloorDivMod_XStep_Numerator ( int num, int denom ) {
		XStep = 0;
		Numerator = 0;
		if ( denom != 0) {
			if ( num >= 0 ) {
				XStep = num / denom;
				Numerator = num % denom; 
			}
			else {
				// numerator < 0
				XStep = -(( -num ) / denom );
				Numerator = (-num) % denom;
				if ( Numerator != 0 ) {
					// there is a remainder
					XStep--;
					Numerator = denom - Numerator;
				}
			}
		}
	} // end FloorDivMod_XStep_Numerator



	private void FloorDivMod_X_ErrorTerm ( int num, int denom ) {
		XStep = 0;
		Numerator = 0;
		if ( denom != 0) {
			if ( num >= 0 ) {
				X = num / denom;
				ErrorTerm = num % denom; 
			}
			else {
				// numerator < 0
				X = -(( -num ) / denom );
				ErrorTerm = (-num) % denom;
				if ( ErrorTerm != 0 ) {
					// there is a remainder
					X--;
					ErrorTerm = denom - ErrorTerm;
				}
			}
		}
	} // end FloorDivMod_X_ErrorTerm 



	private int Ceil28_4 ( int value ) {
		int returnValue;
		int numerator = value - 1 + 16;
		if ( numerator >= 0 ) {
			returnValue = numerator / 16;
		}
		else {
			// deal with negative numberators correctly
			returnValue = -(( -numerator)/16);
			//returnValue -= ((-numerator) % 16) ? 1 : 0; // this is the C++ code
			if ( ((-numerator) % 16) == 0 ) returnValue--;
		}
		return returnValue;
	} // Ceil28_4

	
	private int FloatToFixed28_4(float value) { 
		return ((int) (value * 16)); // same as in Gradients
	} // end FloatToFixed28_4

	private float Fixed28_4ToFloat(int value) { 
		return (value / 16.0f); // same as in Gradients
	} // end Fixed28_4ToFloat


	public void EdgePolygon (PolygonClass polygonClass, Gradients gradients, int Top, int Bottom) {
		int yTop  = FloatToFixed28_4( polygonClass.vertex[Top].y );
		int yBttm = FloatToFixed28_4( polygonClass.vertex[Bottom].y );
		Y = Ceil28_4( yTop );
		int YEnd  = Ceil28_4( yBttm );
		Height = YEnd - Y;

		if ( Height > 0 ) {

			int dN = yBttm - yTop;
			int xTop  = FloatToFixed28_4( polygonClass.vertex[Top].x );
			int xBttm = FloatToFixed28_4( polygonClass.vertex[Bottom].x );
			int dM = xBttm - xTop;
			int InitialNumerator = dM*16*Y - dM*yTop + dN*xTop - 1 + dN*16;

			FloorDivMod_X_ErrorTerm ( InitialNumerator, dN*16 );

			FloorDivMod_XStep_Numerator( dM*16, dN*16 );
			Denominator = dN*16;		
	
			float YPrestep = Fixed28_4ToFloat( (Y * 16) - yTop );
			float XPrestep = Fixed28_4ToFloat( (X * 16) - xTop );

			OneOverZ = gradients.aOneOverZ[Top]
							+ XPrestep * gradients.dOneOverZdX
							+ YPrestep * gradients.dOneOverZdY;
			OneOverZStep = XStep * gradients.dOneOverZdX + gradients.dOneOverZdY;
			OneOverZStepExtra = gradients.dOneOverZdX;
	
			UOverZ = gradients.aUOverZ[Top]
							+ XPrestep * gradients.dUOverZdX
							+ YPrestep * gradients.dUOverZdY;
			UOverZStep = XStep * gradients.dUOverZdX + gradients.dUOverZdY;
			UOverZStepExtra = gradients.dUOverZdX;
	
			VOverZ = gradients.aVOverZ[Top]
							+ XPrestep * gradients.dVOverZdX
							+ YPrestep * gradients.dVOverZdY;
			VOverZStep = XStep * gradients.dVOverZdX + gradients.dVOverZdY;
			VOverZStepExtra = gradients.dVOverZdX;
	
			redOverZ = gradients.aRedOverZ[Top]
							+ XPrestep * gradients.dRedOverZdX
							+ YPrestep * gradients.dRedOverZdY;
			redOverZStep = XStep * gradients.dRedOverZdX + gradients.dRedOverZdY;
			redOverZStepExtra = gradients.dRedOverZdX;
	
			greenOverZ = gradients.aGreenOverZ[Top]
							+ XPrestep * gradients.dGreenOverZdX
							+ YPrestep * gradients.dGreenOverZdY;
			greenOverZStep = XStep * gradients.dGreenOverZdX + gradients.dGreenOverZdY;
			greenOverZStepExtra = gradients.dGreenOverZdX;
	
			blueOverZ = gradients.aBlueOverZ[Top]
							+ XPrestep * gradients.dBlueOverZdX
							+ YPrestep * gradients.dBlueOverZdY;
			blueOverZStep = XStep * gradients.dBlueOverZdX + gradients.dBlueOverZdY;
			blueOverZStepExtra = gradients.dBlueOverZdX;
		} // end Height > 0
	} // end EdgePolygon

} // end class Edge