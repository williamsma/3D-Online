 // PickRay.java
 // � 2004, 3D-Online, All Rights Reserved 
 // March 8, 2004

package d3d;


public class PickRay {

	final int totalPickedObjects = 1000;
	int pickedObjectsAppendList = 0; // current number of picked objects
	SFNode[] objectAppendList = new SFNode[totalPickedObjects]; // point to the shape node that was picked
	float[] distanceAppendList = new float[totalPickedObjects]; // distance from the camera to the picked polygon of the object

	/** List of all the nodes picked by a ray, in order of how they are rendered */
	public SFNode[] object = new SFNode[totalPickedObjects]; // point to the shape node that was picked
	/** Distance of the nodes picked by a ray, object[0], will have distance[0], etc. */
	public float[] distance = new float[totalPickedObjects]; // distance from the camera to the picked polygon of the object
	int pickedObjects = 0; // current number of picked objects

	// constructor
	//public PickRay() { } // not using

	public SFNode GetClosest() {
		SFNode closestNode = null;
		float closestPickDistance = java.lang.Float.NEGATIVE_INFINITY; 
		for (int i = 0; i < pickedObjects; i++) {
			if ( distance[i] > closestPickDistance) {
				closestPickDistance = distance[i];
				closestNode = object[i];
			}
		}
		return closestNode;
	} // end GetClosest

	public int TotalPickedObjects() {
		return pickedObjects;
	} // end TotalPickedObjects

} // end class PickRay
