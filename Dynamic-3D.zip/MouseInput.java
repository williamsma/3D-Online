 // MouseInput.java
 // � 2004, 3D-Online, All Rights Reserved 
 // March 5, 2004

package d3d;

public class MouseInput extends DeviceInput {

	public static final int DOWN	= 0; 
	public static final int DRAG	= 1; 
	public static final int MOVE	= 2; 
	public static final int UP		= 3; 

	/** indicates which type of input: DOWN, DRAG, MOVE, UP */
	public int which;
	/** indicates the x location of the mouse when the input was received */
	public int x;
	/** indicates the y location of the mouse when the input was received */
	public int y;

	// constructor
	public MouseInput () {}

} // end MouseInput
