// Clipping.java 
//  � 2003, 3D-Online, All Rights Reserved 
// Created May 6, 2003 

package d3d;

public class Clipping {

	static final int xIndex = 0;
	static final int yIndex = 1;
	static final int zIndex = 2;
	static final int maxIndexes = 3;
	static final int maxTextureCoordPts = 2;
	static final int OutOfBounds = (1 << 7);
	static final int OutOfBoundsMask = 127;

	static final int in	= 0;
	static final int out	= 1;
	// Note: line 0 connects vertices 0 to 1, line 1 connect vertices 1 to 2, and line 2 connects vertices 2 to 0

	private final int maxVertices = 3; // eventually, won't limit to only triangles
	private final int maxClippedVertices = maxVertices + WorldScreenCoordinates.totalClippingPlanes;
	public int totalVertices = 0;
	public float[][] vertexColor =  new float[maxClippedVertices][maxIndexes];
	public float[][] vertexTextureCoord = new float[maxClippedVertices][maxTextureCoordPts];
	public float[][] vertexPts = new float[maxClippedVertices][maxIndexes];

	private int[] vertexList = new int[maxClippedVertices];
	private int[] vertexStatus = new int[maxClippedVertices];
	private float[][] Start = new float[maxClippedVertices][maxIndexes];
	private float[][] FminusS = new float[maxClippedVertices][maxIndexes];
	private float[] tPt = new float[maxClippedVertices];
	int nextVertexSlot = 0; // next position for the next vertex

	WorldScreenCoordinates coordSys = null;
	Scanner scanner = null;
	ScanLine scanLine = null;

	int[] vertexCnt = new int[2];

	int nextVertex, newVertex, prevVertex;
	PolygonClass polygon = null;  // Can't do this till imageTexture and transparency values are passed as paramets.

/*
long scannerBeginMillisec = 0;
long scannerTotalMillisec = 0;
*/


	public Clipping(WorldScreenCoordinates _coordSys, Scanner _scanner, GraphicsDisplay display ) {
		coordSys = _coordSys;
		scanner = _scanner;
		polygon = new PolygonClass();
		scanLine = new ScanLine(display);
	} // end Constructor


	private void SetVertexInOut(int planeNumber) {
		for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
			float homoginizedVertexX = -vertexPts[ vertexList[vertexNumber] ][xIndex] / vertexPts[ vertexList[vertexNumber] ][zIndex];
			float homoginizedVertexY = -vertexPts[ vertexList[vertexNumber] ][yIndex] / vertexPts[ vertexList[vertexNumber] ][zIndex];
			if (planeNumber == WorldScreenCoordinates.leftClippingPlane) {
				if ( homoginizedVertexX <= -coordSys.xBoundary ) {
					vertexStatus[ vertexList[vertexNumber] ] = out;
				}
				else vertexStatus[ vertexList[vertexNumber] ] = in;
			} // end if plane = left
			else if (planeNumber == WorldScreenCoordinates.topClippingPlane) {
				if ( homoginizedVertexY >= coordSys.yBoundary ) {
					vertexStatus[ vertexList[vertexNumber] ] = out;
				}
				else vertexStatus[ vertexList[vertexNumber] ] = in;
			} // else if plane = top
			else if (planeNumber == WorldScreenCoordinates.rightClippingPlane) {
				if ( homoginizedVertexX >= coordSys.xBoundary ) {
					vertexStatus[ vertexList[vertexNumber] ] = out;
				}
				else vertexStatus[ vertexList[vertexNumber] ] = in;
			} // end if plane = right
			else if (planeNumber == WorldScreenCoordinates.bottomClippingPlane) {
				if ( homoginizedVertexY <=  -coordSys.yBoundary ) {
					vertexStatus[ vertexList[vertexNumber] ] = out;
				}
				else vertexStatus[ vertexList[vertexNumber] ] = in;
			} // end if plane is bottom
			else if (planeNumber == WorldScreenCoordinates.frontClippingPlane) {
				if ( vertexPts[ vertexList[vertexNumber] ][zIndex] >= WorldScreenCoordinates.frontClippingDistance) {
					vertexStatus[ vertexList[vertexNumber] ] = out;
				}
				else vertexStatus[ vertexList[vertexNumber] ] = in;
			} // end plane == frontClippingPlane
		} // end for ea. vertex
	} // end SetVertexInOut



	public int ClipBoundingBox() {
		int planesCrossed = 0;
		for (int i = 0; i < totalVertices; i++) {
			vertexList[i] = i;
		}
		for (int planeNumber = 0; planeNumber < WorldScreenCoordinates.totalClippingPlanes; planeNumber++) {
			SetVertexInOut(planeNumber);
			vertexCnt[out] = 0;
			for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
				if ( vertexStatus[ vertexList[vertexNumber] ] == out) vertexCnt[out]++;
			}
			if ( vertexCnt[out] == totalVertices ) { // plane out of bounds
				if ( (planesCrossed & OutOfBounds ) == 0) { // first plane to be out of bounds
					planesCrossed = OutOfBounds | (1 << planeNumber);
				}
				else { // add this plane as another fully out of bounds
					planesCrossed |= (1 << planeNumber);
				}
			}
			else if ( vertexCnt[out] != 0 ) {
				planesCrossed |= (1 << planeNumber);
			}
		} // check for each plane number
//System.out.println("Clipping, BoundingBox, planesCrossed = " + planesCrossed);
		return planesCrossed;
	} // end ClipBoundingBox



	private void SetLineEquations(int planeNumber) {

		float[] SminusX = new float[3];
		float	NdotSminusX;
		float	NdotFminusS;

		int startIndex = 0;
		int finishIndex = 1;
		for (int i = 0; i < totalVertices; i++) {
			for (int j = 0; j < maxIndexes; j++) {
				Start[ vertexList[startIndex] ][j] = vertexPts[ vertexList[startIndex] ][j];
				FminusS[ vertexList[startIndex] ][j] = vertexPts[ vertexList[finishIndex] ][j] - Start[ vertexList[startIndex] ][j];
			}
			startIndex  = (startIndex + 1) % totalVertices;
			finishIndex = (finishIndex + 1) % totalVertices;
		}


		for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
			// N . (P(t) - X) = 0;  . = dot
			// X is any pt on the clipping plane, which can be (0,0,0) for left, right top, bottom
			//    and X is (0,0,-1) for front plane and (0, 0, 1) for the back plane
			//
			// P(t) = S + (F - S)t where 0 <= t <= 1
			// N . (S + (F - S)t - X) = 0
			//  (N . (S - X)) + (N . (F - S)t)) = 0 
			for (int i = 0; i < 3; i++) {
				SminusX[i] = (Start[ vertexList[vertexNumber] ][i]) - WorldScreenCoordinates.Xclipping[planeNumber][i];
			}
			NdotSminusX = MathOps.DotProduct(WorldScreenCoordinates.clippingNormal[planeNumber], SminusX);
			NdotFminusS = MathOps.DotProduct(WorldScreenCoordinates.clippingNormal[planeNumber], FminusS[ vertexList[vertexNumber] ]);
			//t = -(N . (S - X) / N . (F - S)
			if ( NdotFminusS != 0) {
				tPt[ vertexList[vertexNumber] ] =  -NdotSminusX / NdotFminusS; // single values where to clip line, for each plane
			}
			else { // shares the same point
				tPt[ vertexList[vertexNumber] ] = 0;
			}
		} // end for each vertex
	} // end SetLineEquations



	private void SingleVertexOut() {  // after diagnosing problems, use this version
		int totalCurrentVertices = totalVertices;
//System.out.println("SingleVertexOut: totalVertices = " + totalVertices);
		for (int vertexNumber = 0; vertexNumber < totalCurrentVertices; vertexNumber++) {
			if ( vertexStatus[ vertexList[vertexNumber] ] == out) {
//System.out.println("   vertexList["+vertexNumber+"] = " + vertexList[vertexNumber] + " out");
				// shift all the higher numbered vertices to insert the new vertex 
				for (int i = totalVertices; i > vertexNumber; i--) {
					vertexList[i] = vertexList[i-1];
				}
				totalVertices++;
				prevVertex = ( vertexNumber+totalVertices-1)%totalVertices;
				newVertex = ( vertexNumber + 1 )%totalVertices;
				//newVertex = nextVertexSlot;
				nextVertex = ( newVertex + 1 )%totalVertices;
				//vertexList[ newVertex ] = totalVertices - 1;
				vertexList[ newVertex ] = nextVertexSlot;
				nextVertexSlot++; // next position for the next vertex
//System.out.println("   totalVertices = " + totalVertices + ", newVertex = " + newVertex + ", nextVertexSlot = " + nextVertexSlot);

				// insert the new vertex  first because the current vertex will be broken up and its values modified
				for (int i = 0; i < maxIndexes; i++ ) {
					vertexPts[ vertexList[newVertex] ][i] = vertexPts[ vertexList[vertexNumber] ][i] + 
						( FminusS[ vertexList[vertexNumber] ][i] * tPt[ vertexList[vertexNumber] ] );
				}
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					vertexColor[ vertexList[newVertex] ][colorIdx] =
						vertexColor[ vertexList[vertexNumber]][colorIdx] * (1 - tPt[ vertexList[vertexNumber] ]) +
						vertexColor[ vertexList[nextVertex] ][colorIdx] * tPt[ vertexList[vertexNumber] ];
				}
				vertexTextureCoord[ vertexList[newVertex] ][xIndex] =
						vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] * (1 - tPt[ vertexList[vertexNumber] ]) +
						vertexTextureCoord[ vertexList[nextVertex] ][xIndex]  * tPt[ vertexList[vertexNumber] ];
				vertexTextureCoord[ vertexList[newVertex] ][yIndex] =
						vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] * (1 - tPt[ vertexList[vertexNumber] ]) +
						vertexTextureCoord[ vertexList[nextVertex] ][yIndex]  * tPt[ vertexList[vertexNumber] ];

				// handle the original (existing) vertex
				for (int i = 0; i < maxIndexes; i++ ) {
					vertexPts[ vertexList[vertexNumber] ][i] = vertexPts[ vertexList[prevVertex] ][i] + 
						( FminusS[ vertexList[prevVertex] ][i] * tPt[ vertexList[prevVertex] ] );
				}
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					vertexColor[ vertexList[vertexNumber] ][colorIdx] =
						vertexColor[ vertexList[prevVertex] ][colorIdx] * (1 - tPt[ vertexList[prevVertex] ]) +
						vertexColor[ vertexList[vertexNumber] ][colorIdx]  * tPt[ vertexList[prevVertex] ];
				}
				vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] =
						vertexTextureCoord[ vertexList[prevVertex] ][xIndex] * (1 - tPt[ vertexList[prevVertex] ]) +
						vertexTextureCoord[ vertexList[vertexNumber] ][xIndex]  * tPt[ vertexList[prevVertex] ];
				vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] =
						vertexTextureCoord[ vertexList[prevVertex] ][yIndex] * (1 - tPt[ vertexList[prevVertex] ]) +
						vertexTextureCoord[ vertexList[vertexNumber] ][yIndex]  * tPt[ vertexList[prevVertex] ];
				break; // we found our 1 vertex, now get out of here
			} // end if this vertex is out
		} // end for ea. vertex
	} // end SingleVertexOut



	private void TwoVerticesOut() {
		for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
			if ( vertexStatus[ vertexList[vertexNumber] ] == out ) {
				prevVertex = (vertexNumber+totalVertices-1)%totalVertices;
				nextVertex = (vertexNumber+1)%totalVertices;
				if ( vertexStatus[ vertexList[prevVertex] ] == in ){
					for (int i = 0; i < maxIndexes; i++ ) {
						vertexPts[ vertexList[vertexNumber] ][i] = vertexPts[ vertexList[prevVertex] ][i] + 
							( FminusS[ vertexList[prevVertex] ][i] * tPt[ vertexList[prevVertex] ] );
					}
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						vertexColor[ vertexList[vertexNumber] ][colorIdx] =
							vertexColor[ vertexList[prevVertex] ][colorIdx] * (1 - tPt[ vertexList[prevVertex] ]) +
							vertexColor[ vertexList[vertexNumber] ][colorIdx] * tPt[ vertexList[prevVertex] ];
					}
					vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] =
							vertexTextureCoord[ vertexList[prevVertex] ][xIndex] * (1 - tPt[ vertexList[prevVertex] ]) +
							vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] * tPt[ vertexList[prevVertex] ];
					vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] =
							vertexTextureCoord[ vertexList[prevVertex] ][yIndex] * (1 - tPt[ vertexList[prevVertex] ]) +
							vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] * tPt[ vertexList[prevVertex] ];
				} // end if 1st vertex is out and 2nd vertex is in
				else if ( vertexStatus[ vertexList[nextVertex] ] == in ) {
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						vertexColor[ vertexList[vertexNumber] ][colorIdx] = 
							vertexColor[ vertexList[vertexNumber] ][colorIdx] * (1 - tPt[ vertexList[vertexNumber] ]) +
							vertexColor[ vertexList[nextVertex] ][colorIdx] * tPt[ vertexList[vertexNumber] ];
					}
					for (int i = 0; i < maxIndexes; i++ ) {
						vertexPts[ vertexList[vertexNumber] ][i] = vertexPts[ vertexList[vertexNumber] ][i] + 
							( FminusS[ vertexList[vertexNumber] ][i] * tPt[ vertexList[vertexNumber] ] );
					}
					vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] =
							vertexTextureCoord[ vertexList[vertexNumber] ][xIndex] * (1 - tPt[ vertexList[vertexNumber] ]) +
							vertexTextureCoord[ vertexList[nextVertex] ][xIndex] * tPt[ vertexList[vertexNumber] ];
					vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] =
							vertexTextureCoord[ vertexList[vertexNumber] ][yIndex] * (1 - tPt[ vertexList[vertexNumber] ]) +
							vertexTextureCoord[ vertexList[nextVertex] ][yIndex] * tPt[ vertexList[vertexNumber] ];
				} // end if 2nd vertex is out and 1st is in
			} // end if line formed by these two vertices cross clipping boundary
		} // end for loop checking ea. vertex to see who is in and who is out
	} // end TwoVerticesOut



	private void ThreeOrMoreVerticesOut(int planeNumber) {
		// remove vertices bewteen two outside vertices
		int firstDeletedVertex = -1;
		int totalVerticesToDelete = vertexCnt[out] - 2;
		for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
			if ( vertexStatus[ vertexList[vertexNumber] ] == in) {
				if ( vertexStatus[ vertexList[(vertexNumber + 1) % totalVertices ] ] == out) {
					firstDeletedVertex = (vertexNumber + 2) % totalVertices;
					break;
				}
			}
		}

		totalVertices -= totalVerticesToDelete;
		for (int i = firstDeletedVertex; i < totalVertices; i++ ) {
			vertexList[i] = vertexList[i+totalVerticesToDelete];
		}
		// update all the vertex info
		SetVertexInOut( planeNumber );
		TwoVerticesOut();
	} // end ThreeOrMoreVerticesOut



	public void ClipPolygon(PolygonClass polygonTemp, boolean renderBuffer1, int clippingPlanes) {
		polygon = polygonTemp;

		for (int i = 0; i < totalVertices; i++) {
			vertexList[i] = i;
			polygon.vertex[i].textureCoordUnclipped[xIndex] = vertexTextureCoord[i][xIndex];
			polygon.vertex[i].textureCoordUnclipped[yIndex] = vertexTextureCoord[i][yIndex];
		}
		boolean outOfBounds = false;
		nextVertexSlot = 3; // next position for the next vertex

//System.out.println("begin:");
//for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
//	System.out.println("   v["+vertexNumber+"]="+ vertexList[vertexNumber] + " (" + vertexPts[ vertexList[vertexNumber] ][xIndex] +
//							", " + vertexPts[ vertexList[vertexNumber] ][yIndex] + ", " + vertexPts[ vertexList[vertexNumber] ][zIndex] + ")");
//}
//System.out.println();

		// check for clipping
		for (int planeNumber = 0; planeNumber < WorldScreenCoordinates.totalClippingPlanes; planeNumber++) {

			//if ( (clippingPlanes & (1 << planeNumber)) != 0 ) { // may have an outofbounds for one front pane, not back plane and get error
			if ( clippingPlanes != 0 ) {
				SetVertexInOut(planeNumber);
				vertexCnt[out] = 0;
				vertexCnt[in]  = 0;
				for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
					if ( vertexStatus[ vertexList[vertexNumber] ] == out) vertexCnt[out]++;
					else vertexCnt[in]++;
				}
//System.out.println("planeNumber = " + planeNumber + ", vertexCnt[in] " + vertexCnt[in] + ", vertexCnt[out] = " + vertexCnt[out] );
				if ( vertexCnt[in] == 0 ) {
					outOfBounds = true;
					break;
				}
				else if ( vertexCnt[in] != totalVertices ) {
					SetLineEquations(planeNumber);
					if ( vertexCnt[out] == 1 ) SingleVertexOut();
					else if ( vertexCnt[out] == 2 ) TwoVerticesOut();
					else if ( vertexCnt[out] >= 3 ) ThreeOrMoreVerticesOut(planeNumber);
				} // end if all vertices are not in and thus require clipping
 		   } // end clip this plane
//for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
//	System.out.println("   v["+vertexNumber+"]="+ vertexList[vertexNumber] + " (" + vertexPts[ vertexList[vertexNumber] ][xIndex] +
//							", " + vertexPts[ vertexList[vertexNumber] ][yIndex] + ", " + vertexPts[ vertexList[vertexNumber] ][zIndex] + ")");
//}
//System.out.println();
		} //end for ea. plane
		if ( !outOfBounds ) {
			int[] vertexSet = {0, 1, 2};
			float w; 
			for (int polygonNumber = 0; polygonNumber < (totalVertices-2); polygonNumber++) {
				for (int vertexNumber = 0; vertexNumber < 3; vertexNumber++) {
					w = - vertexPts[ vertexList[ vertexSet[vertexNumber] ] ][zIndex] / coordSys.distance; 
					polygon.vertex[vertexNumber].x = coordSys.WorldToScreenX( vertexPts[ vertexList[ vertexSet[vertexNumber] ] ][xIndex] / w );
					polygon.vertex[vertexNumber].y = coordSys.WorldToScreenY( vertexPts[ vertexList[ vertexSet[vertexNumber] ] ][yIndex] / w );
					polygon.vertex[vertexNumber].z = vertexPts[ vertexList[ vertexSet[vertexNumber] ] ][zIndex];
					//if (polygon.imageTexture != null) {
					if (polygon.texture != null) {
						polygon.vertex[ vertexNumber ].textureCoord[xIndex] = vertexTextureCoord[ vertexList[ vertexSet[vertexNumber] ] ][xIndex];
						polygon.vertex[ vertexNumber ].textureCoord[yIndex] = vertexTextureCoord[ vertexList[ vertexSet[vertexNumber] ] ][yIndex];
					}
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						polygon.vertex[ vertexNumber ].color[colorIdx] = (int)(vertexColor[ vertexList[ vertexSet[vertexNumber] ] ][colorIdx] * 255);
					}
				}  // end for vertexNumber loop
//scannerBeginMillisec = System.currentTimeMillis();
				scanner.Convert(polygon, renderBuffer1);
//scannerTotalMillisec += (System.currentTimeMillis() - scannerBeginMillisec);
				vertexSet[1]++;
				vertexSet[2]++;
			} // end for polygonNumber loop
		} // !outOfBound
	} // end ClipPolygon



	public void ClipLine(boolean renderBuffer1, int clippingPlanes) {
		polygon.Reset();
		boolean outOfBounds = false;
		// check for clipping plane
		totalVertices = 2;
		for (int i = 0; i < totalVertices; i++) {
			vertexList[i] = i;
		}
		for (int planeNumber = 0; planeNumber < WorldScreenCoordinates.totalClippingPlanes; planeNumber++) {
			//if ( (clippingPlanes & (1 << planeNumber)) != 0 ) {	  //******** getting error using this line
				SetVertexInOut(planeNumber);
				vertexCnt[out] = 0;
				vertexCnt[in]  = 0;
				for (int vertexNumber = 0; vertexNumber < totalVertices; vertexNumber++) {
					if ( vertexStatus[ vertexNumber ] == out) vertexCnt[out]++;
					else vertexCnt[in]++;
				}
				if ( vertexCnt[in] == 0 ) {
					outOfBounds = true;
					break;
				}
				else if ( vertexCnt[in] != totalVertices ) {
					// one vertex needs clipping
					SetLineEquations(planeNumber);
					if ( vertexStatus[0] == in ) { // and thus vertexStatus[ vertexList[1] ] == out 
						for (int i = 0; i < maxIndexes; i++ ) {
							vertexPts[1][i] = vertexPts[0][i] + ( FminusS[0][i] * tPt[0] );
						}
						for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
							vertexColor[1][colorIdx] =
								vertexColor[0][colorIdx] * (1 - tPt[0]) + vertexColor[1][colorIdx] * tPt[0];
						}
					} // end if 1st vertex is out and 2nd vertex is in
					else { // vertexStatus[ vertexList[1] ] == in and thus vertexStatus[ vertexList[0] ] == out 
						for (int i = 0; i < maxIndexes; i++ ) {
							vertexPts[0][i] = vertexPts[0][i] + ( FminusS[0][i] * tPt[0] );
						}
						for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
							vertexColor[0][colorIdx] = 
								vertexColor[0][colorIdx] * (1 - tPt[0]) + vertexColor[1][colorIdx] * tPt[0];
						}
					} // end if 2nd vertex is out and 1st is in
				} // end if one vertex needs clipping 
			//} // end clip this plane
		} // end for each plane
		if ( !outOfBounds ) {
			float x0, x1, y0, y1, z0, z1, w0, w1; 
			z0 = vertexPts[0][zIndex]; 
			w0 = -z0 / coordSys.distance; 
			x0 = coordSys.WorldToScreenX( vertexPts[0][xIndex] / w0 ); 
			y0 = coordSys.WorldToScreenY( vertexPts[0][yIndex] / w0 ); 

			z1 = vertexPts[1][zIndex]; 
			w1 = -z1 / coordSys.distance; 
			x1 = coordSys.WorldToScreenX( vertexPts[1][xIndex] / w1 ); 
			y1 = coordSys.WorldToScreenY( vertexPts[1][yIndex] / w1 ); 

			if ( y0 < y1 ) {
				polygon.vertex[0].x = x0;
				polygon.vertex[0].y = y0;
				polygon.vertex[0].z = z0;
				polygon.vertex[1].x = x1;
				polygon.vertex[1].y = y1;
				polygon.vertex[1].z = z1;
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					polygon.vertex[0].color[colorIdx] = (int) (vertexColor[0][colorIdx] * 255);
					polygon.vertex[1].color[colorIdx] = (int) (vertexColor[1][colorIdx] * 255);
				}
			}
			else {
				polygon.vertex[1].x = x0;
				polygon.vertex[1].y = y0;
				polygon.vertex[1].z = z0;
				polygon.vertex[0].x = x1;
				polygon.vertex[0].y = y1;
				polygon.vertex[0].z = z1;
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					polygon.vertex[1].color[colorIdx] = (int) (vertexColor[0][colorIdx] * 255);
					polygon.vertex[0].color[colorIdx] = (int) (vertexColor[1][colorIdx] * 255);
				}
			}

			scanLine.ScanConvert(polygon, renderBuffer1);
		} // end if outOfBounds
	} // end ClipLine


} // end class Clipping