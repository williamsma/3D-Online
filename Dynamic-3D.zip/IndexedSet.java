 // IndexedSet.java
 // � 2004, 3D-Online, All Rights Reserved 
 // February 25, 2004
 // In memory of Alan Arinsberg, who took his life and was laid to rest on Feb. 23, 2004

package d3d;

/** superclass of common properties of IndexedFaceSet and IndexedLineSet */ 
public class IndexedSet extends SFNode {
	// used for common properties of IndexedFaceSet, IndexedLineSet

	//public Color color = null;
	public SFNode color = null;
	public MFInt32 colorIndex = null;
	public SFBool colorPerVertex = new SFBool( true );
	//public Coordinate coord = null;
	public SFNode coord = null;
	public MFInt32 coordIndex = null; // now init in LexAnalyzer

	// constructor
	public IndexedSet () {}

} // end IndexedSet 
