 // ColorInterpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // December 10, 2003

package d3d;


public class ColorInterpolator extends Interpolator {

	protected MFColor keyValue = null;

	public ColorInterpolator() {
		datatype = VRMLdatatype.ColorInterpolator;
	}

}//end class ColorInterpolator
