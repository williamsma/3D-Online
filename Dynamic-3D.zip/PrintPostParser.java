// PrintPostParser.java
// Used to be in Post Parser.java
// Just prints a list of objects: lights, 3D geometry and cameras
// � 2002, 3D-Online, All Rights Reserved 
// April 19, 2002
// Dedicated to Terry Nishimura who passed away in 2002 - first colleague at Xerox

package d3d;


public class PrintPostParser {

	public PrintPostParser (LexicalAnalyzer lexicalAnalyzer, Group root,
									Light lightsList, Viewpoint viewpointList, Route routeRoot,
									Sensor sensorRoot, NavigationInfo navigationInfo) {
		System.out.println();
		System.out.println("3D Scene");

		System.out.println("   Lights:");
		if ( navigationInfo.headlight.value ) 	System.out.println("      headlight");
		Light currentLight = lightsList.nextLight;
		while (currentLight != null) {
			System.out.print("      " + currentLight.name);
			if (currentLight.datatype == VRMLdatatype.DirectionalLight) System.out.print(" (Directional Light)");
			else if (currentLight.datatype == VRMLdatatype.PointLight) System.out.print(" (Point Light)");
			else if (currentLight.datatype == VRMLdatatype.SpotLight) System.out.print(" (Spot Light)");
			System.out.println();
			currentLight = currentLight.nextLight;
		}
		System.out.println();

		System.out.println("   Viewpoints:");
		viewpointList = viewpointList.nextViewpoint; // Get past the root
		while (viewpointList != null) {
			System.out.println("      " + viewpointList.name);
			viewpointList = viewpointList.nextViewpoint;
		}
		System.out.println();

		System.out.println("   Sensors/Timers:");
		Sensor sensorList = (Sensor) sensorRoot.next; // Get past the root
		TouchSensor touchSensor;
		while (sensorList != null) {
			System.out.print("      " + sensorList.name);
			try {
				touchSensor = (TouchSensor) sensorList;
				System.out.print(" *touchSensor");
				System.out.print("*");
			}
			catch (java.lang.Exception e) {
			}
			System.out.println();
			sensorList = (Sensor) sensorList.next;
		}
		System.out.println();

		System.out.println("   All Objects:");	
		SFNode currentNode = root;
		String indentAmt = "   ";
		String indent = "      ";
		while (currentNode != null) {
			System.out.print(indent + currentNode.name);	
			if (currentNode.touchSensor != null) System.out.print(" *touchSensor*");	
			System.out.println();	
			if ( currentNode.children != null ) {
				currentNode = currentNode.children;
				indent += indentAmt;
			}
			else if ( currentNode.next != null ) {
				currentNode = currentNode.next;
			}
			else {
				currentNode = currentNode.parent;
				indent = indent.substring(0, (indent.length() - indentAmt.length()));
				while ( (currentNode != root) && (currentNode.next == null) ) {
					currentNode = currentNode.parent;
					indent = indent.substring(0, (indent.length() - indentAmt.length()));
				}
				currentNode = currentNode.next;
			}
		} // end while loop
		System.out.println();

		System.out.println("   ROUTE's:");
		Route routeList = routeRoot.nextRoute;
		//Route childRoute = null;
		while (routeList != null) {
			System.out.print("      " + routeList.fromObject.name + ".");
			PrintRoutePropertyName (routeList.from);
			System.out.print(" TO " + routeList.toObject.name + ".");
			PrintRoutePropertyName (routeList.to);
			System.out.println();
			routeList = routeList.nextRoute;
		}
		System.out.println();

	} // end Constructor

	private void PrintRoutePropertyName (RouteProperties routeProperty) {
		if      (routeProperty.isActiveProperty) System.out.print("isActive");
		else if (routeProperty.isOverProperty) System.out.print("isOver");
		else if (routeProperty.touchTimeProperty) System.out.print("touchTime");
		else if (routeProperty.sfBool) System.out.print("SFBool");
		else if (routeProperty.mfFloat != null) System.out.print("MFFloat");
		else if (routeProperty.sfVec3f != null) System.out.print("SFVec3f");
		else if (routeProperty.mfVec3f != null) System.out.print("MFVec3f");
		else if (routeProperty.sfRotation != null) System.out.print("SFRotation");
		else if (routeProperty.mfRotation != null) System.out.print("MFRotation");
		else if (routeProperty.sfColor != null) System.out.print("SFColor");
		else if (routeProperty.mfColor != null) System.out.print("MFColor");
		else System.out.print("SFFloat/SFTime");
	} // end PrintRoutePropertyName


}  // end PrintPostParser
