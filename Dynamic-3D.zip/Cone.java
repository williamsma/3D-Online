 // Cone.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;

public class Cone extends IndexedFaceSet {

	public static final  boolean bottom = true;
	public static final  float bottomRadius = 1;
	public static final  float height = 2;
	public static final  boolean side = true;

	private float[][] conePoints = {
          {0, 1, 0}, {1, -1, 0}, {0.924f, -1, 0.383f}, {0.707f, -1, 0.707f},
			 {0.383f, -1, 0.924f}, {0, -1, 1}, {-0.383f, -1, 0.924f}, {-0.707f, -1, 0.707f}, 
			 {-0.924f, -1, 0.383f}, {-1, -1, 0}, {-0.924f, -1, -0.383f}, {-0.707f, -1, -0.707f},
			 {-0.383f, -1, -0.924f}, {0, -1, -1}, {0.383f, -1, -0.924f}, {0.707f, -1, -0.707f},
			 {0.924f, -1, -0.383f},  {0, -1, 0}
		};

	private int[] coordIndexSides  = {
		// sides			 
		0, 2, 1, -1, 0, 3, 2, -1, 0, 4, 3, -1, 0, 5, 4, -1, 0, 6, 5, -1, 0, 7, 6, -1, 0, 8, 7, -1, 0, 9, 8, -1,
		0, 10, 9, -1, 0, 11, 10, -1, 0, 12, 11, -1, 0, 13, 12, -1, 0, 14, 13, -1, 0, 15, 14, -1, 0, 16, 15, -1, 0, 1, 16, -1,
	};
	private int[] coordIndexBottom  = {
		//bottom	 
		17, 1, 2, -1, 17, 2, 3, -1, 17, 3, 4, -1, 17, 4, 5, -1, 17, 5, 6, -1, 17, 6, 7, -1, 17, 7, 8, -1, 17, 8, 9, -1,
		17, 9, 10, -1, 17, 10, 11, -1, 17, 11, 12, -1, 17, 12, 13, -1, 17, 13, 14, -1, 17, 14, 15, -1, 17, 15, 16, -1, 17, 16, 1, -1
	};
	private int[] coneCoordIndex = null;


	private void SetBottomRadius (float bottomRadius ) {
		// mulitply x and z value by bottomRadius, default is 1
		for (int i = 0; i < conePoints.length; i++) {
			this.conePoints[i][0] *= bottomRadius;
			this.conePoints[i][2] *= bottomRadius;
		}
	} // end SetBottomRadius

	private void SetHeight (float height ) {
		//this.height = height;
		//	//height /= 1;
		// mulitply y value by height, default is 2
		for (int i = 0; i < conePoints.length; i++) {
			this.conePoints[i][1] *= height/2;
		}
	} // end SetHeight

	// Constructors
	private void ConeConstructor (boolean bottomValue, boolean sideValue) {
		//coord = new Coordinate();
		this.coord = new Coordinate();
		Coordinate coord = (Coordinate) this.coord;
		coord.point.setValue(conePoints);

		if ( sideValue && bottomValue) {
			coneCoordIndex = new int[ coordIndexSides.length + coordIndexBottom.length ];
			for (int i = 0; i < coordIndexSides.length; i++) {
				coneCoordIndex[i] = coordIndexSides[i];
			}
			for (int i = 0; i < coordIndexBottom.length; i++) {
				coneCoordIndex[i + coordIndexSides.length] = coordIndexBottom[i];
			}
		}
		else if ( sideValue ) {
			coneCoordIndex = new int[ coordIndexSides.length ];
			for (int i = 0; i < coordIndexSides.length; i++) {
				coneCoordIndex[i] = coordIndexSides[i];
			}
		}
		else if ( bottomValue ) {
			coneCoordIndex = new int[ coordIndexBottom.length ];
			for (int i = 0; i < coordIndexBottom.length; i++) {
				coneCoordIndex[i] = coordIndexBottom[i];
			}
		}
		else  {
			coneCoordIndex = new int[ 0 ];
		}

		this.coordIndex = new MFInt32( coneCoordIndex.length, coneCoordIndex );
		this.creaseAngle.setValue(.5f);
	} // end ConeConstructor

	public Cone() {
		ConeConstructor(true, true);
	}

	public Cone(boolean bottomValue, float bottomRadius, float height, boolean sideValue ) {
		SetBottomRadius( bottomRadius );
		SetHeight ( height );
		ConeConstructor(bottomValue, sideValue);
	} // end Constructor

}//end class Cone
