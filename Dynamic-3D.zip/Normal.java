 // Normal.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;


/** All Normals are generated at initialization and not exposed for updates */

public class Normal extends SFNode {

	public MFVec3f vector = new MFVec3f();
	//public MFVec3f vector = null;
	//float[][] vector = null;
	float[][] transformedVector = null; // 3D point after object and camera transforms

	final int vectorDimensions = 3;

	public Normal() {
		datatype = VRMLdatatype.Normal;
	}

	/*
	void ConstructTransformedVectors() {
		this.transformedVector = new float[this.vector.vec3s.length][3];
	}

	public void setVectorSize(int numberVectors) {
		this.vector = new float[numberVectors][vectorDimensions];
	}
	public void setVectors(float[][] vector) {
		this.vector = new float[vector.length][3];
		for (int i = 0; i < vector.length; i++) {
 			this.vector[i][0] = vector[i][0];
			this.vector[i][1] = vector[i][1];
			this.vector[i][2] = vector[i][2];
		}
	}

	public void addVector ( float[] newVector ) {
		if (this.vector != null) {
			float[][] copyVectors = new float[this.vector.length][3];
			copyVectors = this.vector;
			this.vector = new float[copyVectors.length + 1][3];
			for (int i = 0; i < copyVectors.length; i++) {
				for(int j = 0; j < 3; j++) {
					this.vector[i][j] = copyVectors[i][j];
 		   	}
			}
		}
		else {
			this.vector = new float[1][3];
		}
		this.vector[this.vector.length-1][0] = newVector[0];
		this.vector[this.vector.length-1][1] = newVector[1];
		this.vector[this.vector.length-1][2] = newVector[2];
	}
	*/

}//end class Normal
