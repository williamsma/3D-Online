 // SFFloat.java
 // � 2002, 3D-Online, All Rights Reserved 
 // October 31, 2003

package d3d;

public class SFFloat {

	float f = 0;

	// constructor
	public SFFloat () {
		this.setValue ( 0 );
	}
	public SFFloat (float f) {
		this.setValue ( f );
	}

	// setValue
	public void setValue (float f ) {
		this.f = f;
	}

	// getValue
	public float getValue( ) {
		return this.f;
	}
	/** returns <I>f</I> as a string */
	public String toString( ) {
		String returnString = f + ""; // converts to a string
		return returnString;
	}

} // end SFFloat
