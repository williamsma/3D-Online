 // Box.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;


public class Box extends IndexedFaceSet {

	public static final float[] size = {2, 2, 2};

	private float[][] boxPoints = {
					{-1, -1, 1}, {1, -1, 1}, {-1, -1, -1}, {1, -1, -1},
					{-1,  1, 1}, {1,  1, 1}, {-1,  1, -1}, {1,  1, -1} };
	private int[] boxCoordIndex  = {
					// bottom
					0, 2, 3, -1, 3, 1, 0, -1, 
					// top
					4, 5, 7, -1, 7, 6, 4, -1,
					0, 1, 5, -1, 5, 4, 0, -1, 1, 3, 7, -1, 7, 5, 1, -1,
					3, 2, 6, -1, 6, 7, 3, -1, 2, 0, 4, -1, 4, 6, 2, -1
				};

	private void SetSize (float[] size ) {
		for (int i = 0; i < boxPoints.length; i++) {
			for (int j = 0; j < 3; j++) {
				this.boxPoints[i][j] *= (size[j]/2);
			}
		}
	} // end SetSize

	// Constructors
	private void  BoxConstructor() {
		//coord = new Coordinate();
		//this.coord = (Coordinate) coord;
		this.coord = new Coordinate();
		Coordinate coord = (Coordinate) this.coord;
		//this.coord.point.setValue(boxPoints);
		//this.coordIndex = new MFInt32( boxCoordIndex.length, boxCoordIndex );
		coord.point.setValue(boxPoints);
		coordIndex = new MFInt32( boxCoordIndex.length, boxCoordIndex );
	}
	public Box() {
		BoxConstructor();
	}
	public Box(float[] size) {
		SetSize(size);
		BoxConstructor();
	}

}//end class Box
