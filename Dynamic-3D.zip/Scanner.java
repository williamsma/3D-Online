// Scanner.java
// � 2002, 3D-Online, All Rights Reserved 
// Feb. 21, 2003
// based on CHecker TextureMapTriangle

package d3d;

import java.lang.ArrayIndexOutOfBoundsException;

public class Scanner {

	final int transparentPixel = 0;

	PolygonClass polygonClass = null;
	Gradients gradients = null;
	int Top, Middle, Bottom;
	int MiddleCompare, BottomCompare;
	Edge pLeft = null;
	Edge pRight = null;
	GraphicsDisplay pDestInfo = null;
	Edge TopToBottom = null;
	Edge TopToMiddle = null;
	Edge MiddleToBottom = null;

	// DrawScanLine variables
	int XStart;
	float XPrestep;
	int Width;

	float redOverZ;
	float greenOverZ;
	float blueOverZ;
	float Z;
	int pixelValue;
	int U = 0;
	int V = 0;
	int textureWidth, textureHeight, tmVal;
	//int UInt, VInt, totalPixels;


	// C.Hecker ver. IV variables
	final int AffineLength = 8;
	//final int AffineLength = 16;
	float ZRight;
	float DeltaZ;
	float ZLeft;
	float OneOverZLeft;
	float OneOverZRight;
	float dOneOverZdXAff;

	int DeltaU, DeltaV;
	float URight, VRight;
	float ULeft, VLeft;
	float UOverZLeft, VOverZLeft;
	float dUOverZdXAff, dVOverZdXAff;
	float UOverZRight, VOverZRight;

	int redFixed16_16, greenFixed16_16, blueFixed16_16;
	float redOverZLeft, greenOverZLeft, blueOverZLeft;
	float redRight, greenRight, blueRight;
	float redLeft, greenLeft, blueLeft;
	float dRedOverZdXAff, dGreenOverZdXAff, dBlueOverZdXAff;
	float redOverZRight, greenOverZRight, blueOverZRight;
	int DeltaRed, DeltaGreen, DeltaBlue;
	int Subdivisions, WidthModLength;


	private final int redMask   = 0x00ff0000;
	private final int greenMask = 0x0000ff00;
	private final int blueMask  = 0x000000ff;


	private int[] redMipmap    = null;
	private int[] greenMipmap  = null;
	private int[] blueMipmap   = null;
	private int[] alphaMipmap  = null;

	private int[] bufferRGB		= null;
	//private float[] zBuffer		= null;


/*
long edgeBeginMillisec = 0;
long edgeTotalMillisec = 0;
long gradientsBeginMillisec = 0;
long gradientsTotalMillisec = 0;
long drawScanLineBeginMillisec = 0;
long drawScanLineTotalMillisec = 0;
*/

	/* comment out for release */
	/*
	boolean firstTimeTextureError = true;
	private void ReportTextureError() {
		if (firstTimeTextureError) {
//			firstTimeTextureError = false;
			System.out.println("*** EXCEED BITMAP WIDTH ***");
			//System.out.println("   URight = ZRight * UOverZRight: " + URight + " = " + ZRight + " * " + UOverZRight);
			//System.out.println("   VRight = ZRight * VOverZRight: " + VRight + " = " + ZRight + " * " + VOverZRight);
			//System.out.println("   U = FloatToFixed16_16( ULeft ) + gradients.dUdXModifier; " + U + " = FloatToFixed16_16(" + ULeft + ") + " + gradients.dUdXModifier);
			System.out.println("   V = FloatToFixed16_16( VLeft ) + gradients.dVdXModifier; " + V + " = FloatToFixed16_16(" + VLeft + ") + " + gradients.dVdXModifier);
			System.out.println("   UInt = " + UInt + "; VInt = " + VInt);
			System.out.println("   tmVal = " + tmVal + "; textureWidth = " + textureWidth + ", totalPixels = " + totalPixels);
			//System.out.println("   DeltaU = FloatToFixed16_16( URight - ULeft ) / AffineLength; " + DeltaU + " = FloatToFixed16_16(" + URight + " - " + ULeft + ") / " + AffineLength);
			//System.out.println("   DeltaV = FloatToFixed16_16( VRight - VLeft ) / AffineLength; " + DeltaV + " = FloatToFixed16_16(" + VRight + " - " + VLeft + ") / " + AffineLength);
			//System.out.println("   DeltaZ = ( ZRight - ZLeft ) / AffineLength; " + DeltaZ + " = (" + ZRight + " - " + ZLeft + ") / " + AffineLength);
			System.out.println();
		}
   } // end ReportTextureError
	*/



	private void SetTopMiddleBottom() { 
		float Y0 = polygonClass.vertex[0].y;
		float Y1 = polygonClass.vertex[1].y;
		float Y2 = polygonClass.vertex[2].y;

		// sort vertices in y
		if ( Y0 < Y1 ) {
			if ( Y2 < Y0 ) {
				Top = 2; Middle = 0; Bottom = 1;
				MiddleCompare = 0; BottomCompare = 1;
			}
			else {
				Top = 0;
				if ( Y1 < Y2 ) {
					Middle = 1; Bottom = 2;
					MiddleCompare = 1; BottomCompare = 2;
				}
				else {
					Middle = 2; Bottom = 1;
					MiddleCompare = 2; BottomCompare = 1;
				}
			}
		}
		else {
			if ( Y2 < Y1 ) {
				Top = 2; Middle = 1; Bottom = 0;
				MiddleCompare = 1; BottomCompare = 0;
			}
			else {
				Top = 1;
				if ( Y0 < Y2 ) {
					Middle = 0; Bottom = 2;
					MiddleCompare = 3; BottomCompare = 2;
				}
				else {
					Middle = 2; Bottom = 0;
					MiddleCompare = 2; BottomCompare = 3;
				}
			}
		}
	}



	private static int FloatToFixed16_16( float Value ) { // private static inline's this code
		return (int)( Value * 65536 );
	}

	public void DrawScanLine(int height) {
		for (int heightCnt = 0; heightCnt < height; heightCnt++) {
			try {
	
				XStart = pLeft.X;
				Width = pRight.X - XStart;
		
				if ( Width > 0 ) {
	
					// set-up left values
					OneOverZLeft = pLeft.OneOverZ;
					UOverZLeft   = pLeft.UOverZ;
					VOverZLeft   = pLeft.VOverZ;
					redOverZLeft   = pLeft.redOverZ;
					greenOverZLeft = pLeft.greenOverZ;
					blueOverZLeft  = pLeft.blueOverZ;
		
					ZLeft = 1 / OneOverZLeft;
					//ZLeft = 1 / pLeft.OneOverZ;
					ULeft = ZLeft * UOverZLeft;
					VLeft = ZLeft * VOverZLeft;
					//ULeft = ZLeft * pLeft.UOverZ;
					//VLeft = ZLeft * pLeft.VOverZ;
					redLeft   = ZLeft * redOverZLeft;
					greenLeft = ZLeft * greenOverZLeft;
					blueLeft  = ZLeft * blueOverZLeft;
					//redLeft   = ZLeft * pLeft.redOverZ;
					//greenLeft = ZLeft * pLeft.greenOverZ;
					//blueLeft  = ZLeft * pLeft.blueOverZ;
	
					// set-up ZdX Affine values
					dOneOverZdXAff = gradients.dOneOverZdX * AffineLength;
					dUOverZdXAff   = gradients.dUOverZdX * AffineLength;
					dVOverZdXAff   = gradients.dVOverZdX * AffineLength;
					dRedOverZdXAff   = gradients.dRedOverZdX * AffineLength;
					dGreenOverZdXAff = gradients.dGreenOverZdX * AffineLength;
					dBlueOverZdXAff  = gradients.dBlueOverZdX * AffineLength;
		
					// set-up right values
					OneOverZRight = OneOverZLeft + dOneOverZdXAff;
					//OneOverZRight = pLeft.OneOverZ + dOneOverZdXAff;
					UOverZRight   = UOverZLeft + dUOverZdXAff;
					VOverZRight   = VOverZLeft + dVOverZdXAff;
					//UOverZRight   = pLeft.UOverZ + dUOverZdXAff;
					//VOverZRight   = pLeft.VOverZ + dVOverZdXAff;
					redOverZRight   = redOverZLeft + dRedOverZdXAff;
					greenOverZRight   = greenOverZLeft + dGreenOverZdXAff;
					blueOverZRight   = blueOverZLeft + dBlueOverZdXAff;
					//redOverZRight   = pLeft.redOverZ + dRedOverZdXAff;
					//greenOverZRight = pLeft.greenOverZ + dGreenOverZdXAff;
					//blueOverZRight  = pLeft.blueOverZ + dBlueOverZdXAff;
		
					pixelValue = (pLeft.Y * pDestInfo.width) + XStart;
		
					Subdivisions = Width / AffineLength;
					WidthModLength = Width % AffineLength;
					if ( WidthModLength == 0 ) {
						Subdivisions--;
						WidthModLength = AffineLength;
					}
	
					Z = ZLeft; 
					/***** Transparenct material, and no texture map *****/
					//if (  (polygonClass.transparency != 0) && (polygonClass.imageTexture == null) ) {
					if (  (polygonClass.transparencyMaterialValue != 0) && (polygonClass.texture == null) ) {
						while ( Subdivisions > 0 ) {
							Subdivisions--;
							ZRight = 1 / OneOverZRight;
							redRight = ZRight * redOverZRight;
							greenRight = ZRight * greenOverZRight;
							blueRight = ZRight * blueOverZRight;
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / AffineLength;
							DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / AffineLength;
							DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / AffineLength;
							DeltaZ = ( ZRight - ZLeft ) / AffineLength;
							for (int i = 0; i < AffineLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) {
									// Z buffer check, pixel in front of current objects
									if ( pDestInfo.transparencyZbuffer[pixelValue] > Z) {
										pDestInfo.transparencyRed[pixelValue]   = redFixed16_16 >> 16;
										pDestInfo.transparencyGreen[pixelValue] = greenFixed16_16 >> 16;
										pDestInfo.transparencyBlue[pixelValue]  = blueFixed16_16 >> 16;
										pDestInfo.transparencyValueBuffer[pixelValue] = this.polygonClass.transparencyMaterialValue;
										pDestInfo.transparencyZbuffer[pixelValue] = Z;
										pDestInfo.transparencyFlag[pixelValue] = true;
									} // pDestInfo.transparencyZbuffer[pixelValue] >= Z
									else if ( pDestInfo.transparencyZbuffer[pixelValue] == Z) {
										// two objects at exact same Z position
										pDestInfo.transparencyRed[pixelValue] =
													(int) ( (pDestInfo.transparencyRed[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (redFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyGreen[pixelValue] =
													(int) ( (pDestInfo.transparencyGreen[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (greenFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyBlue[pixelValue] =
													(int) ( (pDestInfo.transparencyBlue[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (blueFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyValueBuffer[pixelValue] *= this.polygonClass.transparencyMaterialValue;
									} // pDestInfo.transparencyZbuffer[pixelValue] == Z
								} // if pixel.X > buffer.Z
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								pixelValue++;
							} // end for i < AffineLength
	
							ZLeft = ZRight;
							redLeft   = redRight;
							greenLeft = greenRight;
							blueLeft  = blueRight;
							OneOverZRight += dOneOverZdXAff;
							redOverZRight   += dRedOverZdXAff;
							greenOverZRight += dGreenOverZdXAff;
							blueOverZRight  += dBlueOverZdXAff;
						} // end while subdivisions > 0
	
						if ( WidthModLength != 0 ) {
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							WidthModLength--;
							if ( WidthModLength > 0 ) { // don't divide by 0
								ZRight = 1 / (pRight.OneOverZ - gradients.dOneOverZdX);
								redRight   = ZRight * (pRight.redOverZ   - gradients.dRedOverZdX);
								greenRight = ZRight * (pRight.greenOverZ - gradients.dGreenOverZdX);
								blueRight  = ZRight * (pRight.blueOverZ  - gradients.dBlueOverZdX);
								DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / WidthModLength;
								DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / WidthModLength;
								DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / WidthModLength;
								DeltaZ = ( ZRight - ZLeft ) / WidthModLength;
							}
							for (int i = 0; i <= WidthModLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) {
									// Z buffer check, pixel in front of current objects
									if ( pDestInfo.transparencyZbuffer[pixelValue] > Z) {
										pDestInfo.transparencyRed[pixelValue]   = redFixed16_16 >> 16;
										pDestInfo.transparencyGreen[pixelValue] = greenFixed16_16 >> 16;
										pDestInfo.transparencyBlue[pixelValue]  = blueFixed16_16 >> 16;
										pDestInfo.transparencyValueBuffer[pixelValue] = this.polygonClass.transparencyMaterialValue;
										pDestInfo.transparencyZbuffer[pixelValue] = Z;
										pDestInfo.transparencyFlag[pixelValue] = true;
									} // pDestInfo.transparencyZbuffer[pixelValue] >= Z
									else if ( pDestInfo.transparencyZbuffer[pixelValue] == Z) {
										// two objects at exact same Z position
										pDestInfo.transparencyRed[pixelValue] =
													(int) ( (pDestInfo.transparencyRed[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (redFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyGreen[pixelValue] =
													(int) ( (pDestInfo.transparencyGreen[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (greenFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyBlue[pixelValue] =
													(int) ( (pDestInfo.transparencyBlue[pixelValue] * this.polygonClass.transparencyMaterialValue) +
															( (blueFixed16_16 >> 16) * ( 1 - this.polygonClass.transparencyMaterialValue)) );
										pDestInfo.transparencyValueBuffer[pixelValue] *= this.polygonClass.transparencyMaterialValue;
									} // pDestInfo.transparencyZbuffer[pixelValue] == Z
								} // if pixel.X > buffer.Z
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								pixelValue++;
							} // end for i < WidthModLength
	
						} // end WidthModLength
					}  // end transparent material, no texture map
	
	
					/***** Transparent Material, with texture map *****/
					else if ( polygonClass.transparencyMaterialValue != 0 ) {
						while ( Subdivisions > 0 ) {
							Subdivisions--;
							ZRight = 1 / OneOverZRight;
							URight = ZRight * UOverZRight;
							VRight = ZRight * VOverZRight;
							//U = FloatToFixed16_16( ULeft ) + gradients.dUdXModifier;
							//V = FloatToFixed16_16( VLeft ) + gradients.dVdXModifier;
U = FloatToFixed16_16( ULeft );
V = FloatToFixed16_16( VLeft );
							DeltaU = FloatToFixed16_16( URight - ULeft ) / AffineLength;
							DeltaV = FloatToFixed16_16( VRight - VLeft ) / AffineLength;
							DeltaZ = ( ZRight - ZLeft ) / AffineLength;
							redRight = ZRight * redOverZRight;
							greenRight = ZRight * greenOverZRight;
							blueRight = ZRight * blueOverZRight;
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / AffineLength;
							DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / AffineLength;
							DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / AffineLength;
							for (int i = 0; i < AffineLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) {
									// Z buffer check, pixel in front of current objects
									tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
									if( alphaMipmap[tmVal] != transparentPixel) {
										if ( pDestInfo.transparencyZbuffer[pixelValue] > Z) {
											//pDestInfo.transparencyRed[pixelValue]   = (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) );
											//pDestInfo.transparencyGreen[pixelValue] = (int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) );
											//pDestInfo.transparencyBlue[pixelValue]  = (int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) );
											pDestInfo.transparencyRed[pixelValue]   = 
												( (redMipmap[tmVal]   <= (redFixed16_16   >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) );
											pDestInfo.transparencyGreen[pixelValue] =
												( (greenMipmap[tmVal] <= (greenFixed16_16 >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) );
											pDestInfo.transparencyBlue[pixelValue]  =
												( (blueMipmap[tmVal]  <= (blueFixed16_16  >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.transparencyValueBuffer[pixelValue] = this.polygonClass.transparencyMaterialValue;
											pDestInfo.transparencyZbuffer[pixelValue] = Z;
											pDestInfo.transparencyFlag[pixelValue] = true;
										} // pDestInfo.transparencyZbuffer[pixelValue] >= Z
										else if ( pDestInfo.transparencyZbuffer[pixelValue] == Z) {
											// two objects at exact same Z position
											pDestInfo.transparencyRed[pixelValue] =
														(int) ( (pDestInfo.transparencyRed[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ))
																(  ( (redMipmap[tmVal]   <= (redFixed16_16   >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) )
															 * ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyGreen[pixelValue] =
														(int) ( (pDestInfo.transparencyGreen[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ))
																( ( (greenMipmap[tmVal] <= (greenFixed16_16 >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) )
															 * ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyBlue[pixelValue] =
														(int) ( (pDestInfo.transparencyBlue[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ))
																( ( (blueMipmap[tmVal]  <= (blueFixed16_16  >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) )
															 * ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyValueBuffer[pixelValue] *= this.polygonClass.transparencyMaterialValue;
										} // pDestInfo.transparencyZbuffer[pixelValue] == Z
									} // not an alpha pixel
								} // if pixel.X > buffer.Z
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								U += DeltaU;
								V += DeltaV;
								pixelValue++;
							} // end for i < AffineLength
	
							ZLeft = ZRight;
							ULeft = URight;
							VLeft = VRight;
							OneOverZRight += dOneOverZdXAff;
							UOverZRight   += dUOverZdXAff;
							VOverZRight   += dVOverZdXAff;
							redLeft   = redRight;
							greenLeft = greenRight;
							blueLeft  = blueRight;
							redOverZRight   += dRedOverZdXAff;
							greenOverZRight += dGreenOverZdXAff;
							blueOverZRight  += dBlueOverZdXAff;
						} // end while subdivisions > 0
	
						if ( WidthModLength != 0 ) {
							//U = FloatToFixed16_16( ULeft ) + gradients.dUdXModifier;
							//V = FloatToFixed16_16( VLeft ) + gradients.dVdXModifier;
U = FloatToFixed16_16( ULeft );
V = FloatToFixed16_16( VLeft );
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							WidthModLength--;
							if ( WidthModLength > 0 ) { // don't divide by 0
								ZRight = 1 / (pRight.OneOverZ - gradients.dOneOverZdX);
								URight = ZRight * (pRight.UOverZ - gradients.dUOverZdX);
								VRight = ZRight * (pRight.VOverZ - gradients.dVOverZdX);
								redRight   = ZRight * (pRight.redOverZ   - gradients.dRedOverZdX);
								greenRight = ZRight * (pRight.greenOverZ - gradients.dGreenOverZdX);
								blueRight  = ZRight * (pRight.blueOverZ  - gradients.dBlueOverZdX);
								DeltaU = FloatToFixed16_16( URight - ULeft ) / WidthModLength;
								DeltaV = FloatToFixed16_16( VRight - VLeft ) / WidthModLength;
								DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / WidthModLength;
								DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / WidthModLength;
								DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / WidthModLength;
								DeltaZ = ( ZRight - ZLeft ) / WidthModLength;
							}
							for (int i = 0; i <= WidthModLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) {
									// Z buffer check, pixel in front of current objects
									tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
									if( alphaMipmap[tmVal] != transparentPixel) {
										if ( pDestInfo.transparencyZbuffer[pixelValue] > Z) {
											//pDestInfo.transparencyRed[pixelValue]   = (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) );
											//pDestInfo.transparencyGreen[pixelValue] = (int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) );
											//pDestInfo.transparencyBlue[pixelValue]  = (int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) );
											pDestInfo.transparencyRed[pixelValue]   = 
												( (redMipmap[tmVal]   <= (redFixed16_16   >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) );
											pDestInfo.transparencyGreen[pixelValue] =
												( (greenMipmap[tmVal] <= (greenFixed16_16 >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) );
											pDestInfo.transparencyBlue[pixelValue]  =
												( (blueMipmap[tmVal]  <= (blueFixed16_16  >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.transparencyValueBuffer[pixelValue] = this.polygonClass.transparencyMaterialValue;
											pDestInfo.transparencyZbuffer[pixelValue] = Z;
											pDestInfo.transparencyFlag[pixelValue] = true;
										} // pDestInfo.transparencyZbuffer[pixelValue] >= Z
										else if ( pDestInfo.transparencyZbuffer[pixelValue] == Z) {
											// two objects at exact same Z position
											pDestInfo.transparencyRed[pixelValue] =
														(int) ( (pDestInfo.transparencyRed[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ))
																(  ( (redMipmap[tmVal]   <= (redFixed16_16   >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) )
																* ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyGreen[pixelValue] =
														(int) ( (pDestInfo.transparencyGreen[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ))
																( ( (greenMipmap[tmVal] <= (greenFixed16_16 >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) )
																* ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyBlue[pixelValue] =
														(int) ( (pDestInfo.transparencyBlue[pixelValue] * this.polygonClass.transparencyMaterialValue) +
																//( ((int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ))
																( ( (blueMipmap[tmVal]  <= (blueFixed16_16  >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) )
																* ( 1 - this.polygonClass.transparencyMaterialValue)) );
											pDestInfo.transparencyValueBuffer[pixelValue] *= this.polygonClass.transparencyMaterialValue;
										} // pDestInfo.transparencyZbuffer[pixelValue] == Z
									} // not an alpha pixel
								} // if pixel.X > buffer.Z
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								U += DeltaU;
								V += DeltaV;
								pixelValue++;
							} // end for i < WidthModLength
	
						} // end WidthModLength
					}  // end Transparenct material with texture map
	
	
					
					/***** Materials, no Texture Map *****/
					else if ( polygonClass.texture == null) {
						while ( Subdivisions > 0 ) {
							Subdivisions--;
							ZRight = 1 / OneOverZRight;
							redRight = ZRight * redOverZRight;
							greenRight = ZRight * greenOverZRight;
							blueRight = ZRight * blueOverZRight;
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / AffineLength;
							DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / AffineLength;
							DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / AffineLength;
							DeltaZ = ( ZRight - ZLeft ) / AffineLength;
							for (int i = 0; i < AffineLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) { // overwrite the Z buffer value
									bufferRGB[pixelValue]	=
										(0xff000000) | (redFixed16_16 & redMask) | ((greenFixed16_16 >> 16) << 8) | (blueFixed16_16 >> 16);
									pDestInfo.Zbuffer[pixelValue]	= Z;
								} // OK in z buffer
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								pixelValue++;
							} // end for (int i = 0; i < AffineLength; i++)
							ZLeft = ZRight;
							redLeft   = redRight;
							greenLeft = greenRight;
							blueLeft  = blueRight;
							OneOverZRight += dOneOverZdXAff;
							redOverZRight   += dRedOverZdXAff;
							greenOverZRight += dGreenOverZdXAff;
							blueOverZRight  += dBlueOverZdXAff;
						} // end while subdivisions > 0
	
						if ( WidthModLength != 0 ) {
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							WidthModLength--;
							if ( WidthModLength > 0 ) { // don't divide by 0
								ZRight = 1 / (pRight.OneOverZ - gradients.dOneOverZdX);
								redRight   = ZRight * (pRight.redOverZ   - gradients.dRedOverZdX);
								greenRight = ZRight * (pRight.greenOverZ - gradients.dGreenOverZdX);
								blueRight  = ZRight * (pRight.blueOverZ  - gradients.dBlueOverZdX);
								DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / WidthModLength;
								DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / WidthModLength;
								DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / WidthModLength;
								DeltaZ = ( ZRight - ZLeft ) / WidthModLength;
							}
							for (int i = 0; i <= WidthModLength; i++) {
								if (pDestInfo.Zbuffer[pixelValue] < Z ) {
									bufferRGB[pixelValue]	=
										(0xff000000) | (redFixed16_16 & redMask) | ((greenFixed16_16 >> 16) << 8) | (blueFixed16_16 >> 16);
									pDestInfo.Zbuffer[pixelValue] = Z;
								} // end if passes Z buffer test
								redFixed16_16   += DeltaRed;
								greenFixed16_16 += DeltaGreen;
								blueFixed16_16  += DeltaBlue;
								Z += DeltaZ;
								pixelValue++;
							} // end for i loop
						} // end WidthModLength
					}  // end Materials
	
		
	
					/***** Texture Map, no Material property *****/
					else if (!polygonClass.materialAttribute) { // a texture map
						while ( Subdivisions > 0 ) {
							Subdivisions--;
							ZRight = 1 / OneOverZRight;
							URight = ZRight * UOverZRight;
							VRight = ZRight * VOverZRight;
							//U = FloatToFixed16_16( ULeft ) + gradients.dUdXModifier;
							//V = FloatToFixed16_16( VLeft ) + gradients.dVdXModifier;
U = FloatToFixed16_16( ULeft );
V = FloatToFixed16_16( VLeft );
							DeltaU = FloatToFixed16_16( URight - ULeft ) / AffineLength;
							DeltaV = FloatToFixed16_16( VRight - VLeft ) / AffineLength;
							DeltaZ = ( ZRight - ZLeft ) / AffineLength;
	
							if ( polygonClass.transparentGIF) {
								/* Texture Map, No Materials, alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, alpha channel, tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
												pDestInfo.Zbuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for (int i = 0; i < AffineLength; i++)
								} // end no tiling
								else {
									/* Texture Map, Materials, alpha channel, no tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
												pDestInfo.Zbuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for (int i = 0; i < AffineLength; i++)
								} // no tiling
							} // potential transparent bits
							else { // remove alpha bit check
								/* Texture Map, No Materials, no alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, No alpha channel, tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
											pDestInfo.Zbuffer[pixelValue] = Z;
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for (int i = 0; i < AffineLength; i++)
								} // tiling
								else {
									/* Texture Map, Materials, No alpha channel, No tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
											pDestInfo.Zbuffer[pixelValue] = Z;
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for (int i = 0; i < AffineLength; i++)
								} // no tiling
							} // no transparent bits

							ZLeft = ZRight;
							ULeft = URight;
							VLeft = VRight;
							OneOverZRight += dOneOverZdXAff;
							UOverZRight   += dUOverZdXAff;
							VOverZRight   += dVOverZdXAff;
						} // end while subdivisions > 0
	
						// end of scanline
						if ( WidthModLength != 0 ) {
							//U = FloatToFixed16_16( ULeft ) + gradients.dUdXModifier;
							//V = FloatToFixed16_16( VLeft ) + gradients.dVdXModifier;
U = FloatToFixed16_16( ULeft );
V = FloatToFixed16_16( VLeft );
							WidthModLength--;
							if ( WidthModLength > 0 ) { // make sure we don't divide by 0
								ZRight = 1 / (pRight.OneOverZ - gradients.dOneOverZdX);
								URight = ZRight * (pRight.UOverZ - gradients.dUOverZdX);
								VRight = ZRight * (pRight.VOverZ - gradients.dVOverZdX);
								DeltaU = FloatToFixed16_16( URight - ULeft ) / WidthModLength;
								DeltaV = FloatToFixed16_16( VRight - VLeft ) / WidthModLength;
								DeltaZ = ( ZRight - ZLeft ) / WidthModLength;
							}
							if ( polygonClass.transparentGIF) {
								/* Texture Map, No Materials, alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, No alpha channel, tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
												pDestInfo.Zbuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for i loop
								} // tiling
								else {
									/* Texture Map, Materials, no alpha channel, no tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
												pDestInfo.Zbuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for i loop
								} // no tiling
							} // possible transparent bits to check
							else { // remove alpha bit check
								/* Texture Map, No Materials, No alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, No alpha channel, tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
											pDestInfo.Zbuffer[pixelValue] = Z;
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for i loop
								} // tiling
								else { // no tiling
									/* Texture Map, Materials, No alpha channel, no tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														(redMipmap[tmVal] << 16) |
														(greenMipmap[tmVal] << 8) |
														 blueMipmap[tmVal];
											pDestInfo.Zbuffer[pixelValue] = Z;
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
									} // end for i loop
								} // no tiling
							} // no transparent bits
						} // end WidthModLength > 0
					} // end Texture Map, no Material
	
						
					/***** Texture Map with Material property *****/
					else {
						while ( Subdivisions > 0 ) {
							Subdivisions--;
							ZRight = 1 / OneOverZRight;
							URight = ZRight * UOverZRight;
							VRight = ZRight * VOverZRight;
							U = FloatToFixed16_16( ULeft );
							V = FloatToFixed16_16( VLeft );
							DeltaU = FloatToFixed16_16( URight - ULeft ) / AffineLength;
							DeltaV = FloatToFixed16_16( VRight - VLeft ) / AffineLength;
							DeltaZ = ( ZRight - ZLeft ) / AffineLength;
							redRight = ZRight * redOverZRight;
							greenRight = ZRight * greenOverZRight;
							blueRight = ZRight * blueOverZRight;
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / AffineLength;
							DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / AffineLength;
							DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / AffineLength;
							if ( polygonClass.transparentGIF) {
								/* Texture Map, Materials, alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, alpha channel, tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if ( alphaMipmap[tmVal] != transparentPixel) {
												//int blueByte = 
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														//	( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//	( (int) Math.min( greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//	( (int) Math.min( blueMipmap[tmVal],  (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
												pDestInfo.Zbuffer[pixelValue] = Z;
												//zBuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for (int i = 0; i < AffineLength; i++)
								} // tiling
								else {
									/* Texture Map, Materials, alpha channel, no tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if ( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														//	( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//	( (int) Math.min( greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//	( (int) Math.min( blueMipmap[tmVal],  (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
												pDestInfo.Zbuffer[pixelValue] = Z;
												//zBuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for (int i = 0; i < AffineLength; i++)
								} // no tiling
							} // possible transparent bits
							else { // remove alpha bit check
								/* Texture Map, Materials, no alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, no alpha channel, tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
		
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														//	( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//	( (int) Math.min( greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//	( (int) Math.min( blueMipmap[tmVal],  (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.Zbuffer[pixelValue] = Z;
											//zBuffer[pixelValue] = Z;
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for (int i = 0; i < AffineLength; i++)
								} // tiling
								else { // no tiling
									/* Texture Map, Materials, no alpha channel, no tiling */
									for (int i = 0; i < AffineLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											// overwrite the Z buffer value
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											//blueMaterial = blueFixed16_16 >> 16;
											//blueBitMap   = blueMipmap[tmVal];
											bufferRGB[pixelValue]	=  
															(0xff000000) |
															//( Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
															( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
															//( (redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? (redMipmap[tmVal] << 16):(redFixed16_16 & redMask) ) |
															//( Math.min( greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
															( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
															//( (int) Math.min( blueMipmap[tmVal],  (blueFixed16_16 >> 16) ) );
															( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.Zbuffer[pixelValue] = Z;
											//zBuffer[pixelValue] = Z;
										} // OK in z buffer
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for (int i = 0; i < AffineLength; i++)
								} // no tiling
							} // no transparent bits

							ZLeft = ZRight;
							ULeft = URight;
							VLeft = VRight;
							OneOverZRight += dOneOverZdXAff;
							UOverZRight   += dUOverZdXAff;
							VOverZRight   += dVOverZdXAff;
							redLeft   = redRight;
							greenLeft = greenRight;
							blueLeft  = blueRight;
							redOverZRight   += dRedOverZdXAff;
							greenOverZRight += dGreenOverZdXAff;
							blueOverZRight  += dBlueOverZdXAff;
						} // end while subdivisions > 0
						// end of scanline
						if ( WidthModLength != 0 ) {
							U = FloatToFixed16_16( ULeft );
							V = FloatToFixed16_16( VLeft );
							redFixed16_16   = FloatToFixed16_16( redLeft   );
							greenFixed16_16 = FloatToFixed16_16( greenLeft );
							blueFixed16_16  = FloatToFixed16_16( blueLeft  );
							WidthModLength--;
							if ( WidthModLength > 0 ) { // prevent divides by 0
								ZRight = 1 / (pRight.OneOverZ - gradients.dOneOverZdX);
								URight = ZRight * (pRight.UOverZ - gradients.dUOverZdX);
								VRight = ZRight * (pRight.VOverZ - gradients.dVOverZdX);
								redRight   = ZRight * (pRight.redOverZ   - gradients.dRedOverZdX);
								greenRight = ZRight * (pRight.greenOverZ - gradients.dGreenOverZdX);
								blueRight  = ZRight * (pRight.blueOverZ  - gradients.dBlueOverZdX);
	
								DeltaU = FloatToFixed16_16( URight - ULeft ) / WidthModLength;
								DeltaV = FloatToFixed16_16( VRight - VLeft ) / WidthModLength;
								DeltaZ = ( ZRight - ZLeft ) / WidthModLength;
								DeltaRed   = FloatToFixed16_16( redRight   - redLeft   ) / WidthModLength;
								DeltaGreen = FloatToFixed16_16( greenRight - greenLeft ) / WidthModLength;
								DeltaBlue  = FloatToFixed16_16( blueRight  - blueLeft  ) / WidthModLength;
							}

							if ( polygonClass.transparentGIF) {
								/* Texture Map, Materials, alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, alpha channel, Tiled */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														//( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//( (int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//( (int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
												pDestInfo.Zbuffer[pixelValue] = Z;
												//zBuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for i loop
								} // end with alpha and tiling
								else {
									/* Texture Map, Materials, alpha channel, no Tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											//tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											if( alphaMipmap[tmVal] != transparentPixel) {
												bufferRGB[pixelValue]	=  
														(0xff000000) |
														//( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//( (int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//( (int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
												pDestInfo.Zbuffer[pixelValue] = Z;
												//zBuffer[pixelValue] = Z;
											} // if not a transparent bit
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for i loop
								} // end with alpha and no tiling
							} // potential transparent bits
							else { // remove alpha bit check
								/* Texture Map, Materials, no alpha channel */
								if (polygonClass.tiling) {
									/* Texture Map, Materials, no alpha channel, Tiled */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											tmVal = ((U >> 16) % textureWidth) + ( ((V >> 16) % textureHeight) * textureWidth);
											//tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														//( (int) Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//( (int) Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//( (int) Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.Zbuffer[pixelValue] = Z;
											//zBuffer[pixelValue] = Z;
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for i loop
								} // end texture map tiling with no alpha bytes
 							   else { // no tiling
									/* Texture Map, Materials, no alpha channel, No Tiling */
									for (int i = 0; i <= WidthModLength; i++) {
										if (pDestInfo.Zbuffer[pixelValue] < Z ) {
										//if (zBuffer[pixelValue] < Z ) {
											tmVal = (U >> 16) + ( (V >> 16) * textureWidth);
											bufferRGB[pixelValue]	=  
														(0xff000000) |
														//( Math.min(redMipmap[tmVal], (redFixed16_16 >> 16) ) << 16) |
														//( Math.min(greenMipmap[tmVal], (greenFixed16_16 >> 16) ) << 8) |
														//( Math.min(blueMipmap[tmVal], (blueFixed16_16 >> 16) ) );
														( ((redMipmap[tmVal]  <=  (redFixed16_16  >> 16) ) ? redMipmap[tmVal]:(redFixed16_16 >> 16) ) << 16 ) |
														( ((greenMipmap[tmVal]  <=  (greenFixed16_16  >> 16) ) ? greenMipmap[tmVal]:(greenFixed16_16 >> 16) ) << 8 ) |
														( (blueMipmap[tmVal] <=  (blueFixed16_16 >> 16) ) ? blueMipmap[tmVal]:(blueFixed16_16 >> 16) );
											pDestInfo.Zbuffer[pixelValue] = Z;
											//zBuffer[pixelValue] = Z;
										} // end if passes Z buffer test
										pixelValue++;
										U += DeltaU;
										V += DeltaV;
										Z += DeltaZ;
										redFixed16_16   += DeltaRed;
										greenFixed16_16 += DeltaGreen;
										blueFixed16_16  += DeltaBlue;
									} // end for i loop
								} // no tiling
							} // no transpatent bits
						} // end WidthModLength > 0
					} // end Texture Map with Material
	
				} // end if ( Width > 0 )
		   } // end try
			catch ( java.lang.ArrayIndexOutOfBoundsException e ) { 
				/* 
				//if ( firstTimeArrayOutOfBounds ) {
				//	firstTimeArrayOutOfBounds = false;
					//System.out.println("scanner: " + e);
					System.out.println( "(U >>16) = " + (U >> 16) + ", (V >> 16) = " + (V >> 16) + " * texture Width = " + textureWidth + ", tmVal = " + tmVal + ",  VLeft = " + VLeft);
					System.out.println( "   V = " + V + ", gradients.dVdXModifier = " + gradients.dVdXModifier + ", DeltaV = " + DeltaV );
					//System.out.println("   XStart, pLeft.Y = " + XStart + ", " + pLeft.Y + ", pDestInfo.width = " + pDestInfo.width);
					//System.out.println("   pixelValue = " + pixelValue + " >= pDestInfo.totalPixels = " + pDestInfo.totalPixels);
					System.out.println("textureWidth = " + textureWidth + ", textureHeight = " + textureHeight);	 
					System.out.println();
				//}
				/* */
			} // end catch
			pLeft.Step();
			pRight.Step();
		} // end for i = 0 to polygon-portion height
   } // end DrawScanLine


	public void MoveTransparencyPixelsToBuffer(boolean renderBuffer1_) {
		if ( renderBuffer1_ ) bufferRGB = pDestInfo.buffer1RGB;
		else bufferRGB = pDestInfo.buffer2RGB;
		float transparencyValueBuffer, oneMinusTransparencyValueBuffer;
		for (int i = 0; i < pDestInfo.totalPixels; i++) {
			if ( pDestInfo.transparencyFlag[i] ) {
				transparencyValueBuffer = pDestInfo.transparencyValueBuffer[i];
				oneMinusTransparencyValueBuffer = 1 - transparencyValueBuffer;
				bufferRGB[i]	= (0xff000000) |
						(   (int)(
										((bufferRGB[i] & redMask) >> 16)* transparencyValueBuffer + pDestInfo.transparencyRed[i] * oneMinusTransparencyValueBuffer
									 ) << 16) |
						(   (int)(
										((bufferRGB[i] & greenMask) >> 8)* transparencyValueBuffer + pDestInfo.transparencyGreen[i] * oneMinusTransparencyValueBuffer
									 ) << 8) |
						    (int)(
										(bufferRGB[i] & blueMask) * transparencyValueBuffer + pDestInfo.transparencyBlue[i] * oneMinusTransparencyValueBuffer
									 );
				/*
				bufferRGB[i]	= (0xff000000) |
						(   (int)(
										((bufferRGB[i] & redMask) >> 16)* pDestInfo.transparencyValueBuffer[i] + pDestInfo.transparencyRed[i] * ( 1 - pDestInfo.transparencyValueBuffer[i])
									 ) << 16) |
						(   (int)(
										((bufferRGB[i] & greenMask) >> 8)* pDestInfo.transparencyValueBuffer[i] + pDestInfo.transparencyGreen[i] * ( 1 - pDestInfo.transparencyValueBuffer[i])
									 ) << 8) |
						    (int)(
										(bufferRGB[i] & blueMask) * pDestInfo.transparencyValueBuffer[i] + pDestInfo.transparencyBlue[i] * ( 1 - pDestInfo.transparencyValueBuffer[i])
									 );
				*/
				pDestInfo.Zbuffer[i] = pDestInfo.transparencyZbuffer[i];
		   } // end if transparency bit set
   	} // end for i to totalPixels
   } // end MoveTransparencyPixelsToBuffer



  	public void Convert(PolygonClass polygonClass_, boolean renderBuffer1_) { 
//gradientsBeginMillisec = System.currentTimeMillis();
		this.polygonClass = polygonClass_;
		SetTopMiddleBottom(); // finds the vertex order
		if ( renderBuffer1_ ) bufferRGB = pDestInfo.buffer1RGB;
		else bufferRGB = pDestInfo.buffer2RGB;

		if ( polygonClass.texture != null) {
			if (polygonClass.texture.datatype == VRMLdatatype.ImageTexture ) {
				ImageTexture imageTexture = (ImageTexture) polygonClass.texture;
				if ( !imageTexture.loaded ) {
					textureWidth	= imageTexture.widthPreload;
					textureHeight	= imageTexture.heightPreload; 
					redMipmap		= imageTexture.colorPreload;
					greenMipmap		= imageTexture.colorPreload;
					blueMipmap		= imageTexture.colorPreload;
					alphaMipmap		= imageTexture.alphaPreload;
				}
				else {
					textureWidth	= imageTexture.width3x3;
					textureHeight	= imageTexture.height3x3; 
					redMipmap		= imageTexture.red3x3;
					greenMipmap		= imageTexture.green3x3;
					blueMipmap		= imageTexture.blue3x3;
					alphaMipmap		= imageTexture.alpha3x3;
				}
			} // end imageTexture
			else if (polygonClass.texture.datatype == VRMLdatatype.PixelTexture){
				PixelTexture pixelTexture = (PixelTexture) polygonClass.texture;
				textureWidth	= pixelTexture.image.width;
				textureHeight	= pixelTexture.image.height; 
				redMipmap		= pixelTexture.image.red;
				greenMipmap		= pixelTexture.image.green;
				blueMipmap		= pixelTexture.image.blue;
				alphaMipmap		= pixelTexture.image.alpha;
			}
		}
		else {
			textureWidth  = 0;
			textureHeight = 0;
		}
 //System.out.println("textureWidth = " + textureWidth + ", textureHeight = " + textureHeight);	 
		gradients.GradientsPolygon(polygonClass, textureWidth, textureHeight);
//gradientsTotalMillisec += (System.currentTimeMillis() - gradientsBeginMillisec);
//edgeBeginMillisec = System.currentTimeMillis();
		TopToBottom.EdgePolygon(polygonClass, gradients, Top, Bottom);
		TopToMiddle.EdgePolygon(polygonClass, gradients, Top, Middle);
		MiddleToBottom.EdgePolygon(polygonClass, gradients, Middle, Bottom);

		boolean MiddleIsLeft = true;

		if ( BottomCompare > MiddleCompare ) {
			pLeft = TopToMiddle;
			pRight = TopToBottom;
		}
		else {
			MiddleIsLeft = false;
			pLeft = TopToBottom;
			pRight = TopToMiddle;
		}
//edgeTotalMillisec += (System.currentTimeMillis() - edgeBeginMillisec);
//drawScanLineBeginMillisec = System.currentTimeMillis();
		DrawScanLine(TopToMiddle.Height);

		// lower portion of polygon
		if (MiddleIsLeft) { // switched for counter-clockwise
			pLeft = MiddleToBottom;
//System.out.println();
//System.out.println("pLeft = MiddleToBottom, pLeft.Height = " + pLeft.Height + ", MiddleToBottom.Height = " + MiddleToBottom.Height);
		}
		else { // switched for counter-clockwise
			pRight = MiddleToBottom;
		}
		DrawScanLine(MiddleToBottom.Height);
//drawScanLineTotalMillisec += (System.currentTimeMillis() - drawScanLineBeginMillisec);
	} // end Convert



	public Scanner(GraphicsDisplay display_) { 
		this.pDestInfo = display_;
		gradients = new Gradients();
		TopToBottom = new Edge();
		TopToMiddle = new Edge();
		MiddleToBottom = new Edge();
		//zBuffer = pDestInfo.Zbuffer;
	}

} // end class Scanner