 // CoordinateInterpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // December 10, 2003

package d3d;

/** CoordinateInterpolator re-calculates polygon and vertex normals upon each frame.&nbsp; Thus
it should be used wisely. */
public class CoordinateInterpolator extends Interpolator {

	protected MFVec3f keyValue = null;

	public CoordinateInterpolator() {
		datatype = VRMLdatatype.CoordinateInterpolator;
	}

}//end class CoordinateInterpolator
