 // Interpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 11, 2002

package d3d;


/** superclass of common properties of all interpolators */
public class Interpolator extends SFNode {

	Interpolator nextInterpolator = null;
	public MFFloat key = new MFFloat();

	public Interpolator() { }

}//end class Interpolator
