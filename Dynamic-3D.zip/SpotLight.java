 // SpotLight.java
 // � 2002, 3D-Online, All Rights Reserved 
 // February 11, 2004

package d3d;


public class SpotLight extends PointLight {

	public SFFloat beamWidth = new SFFloat( 1.570796f );
	public SFFloat cutOffAngle = new SFFloat( 0.785398f );
	public SFVec3f direction = new SFVec3f(0, 0, -1);

	// values added to assist the directionalLight
	float[] directionNormalized = {0, 0, -1}; // a normalized vector of the "direction"
	float[] lightDirectionTransformed = new float[3]; // light direction rotated
	Matrix3x3 directionMatrix = new Matrix3x3(); // multiplies all parent Transforms plus Viewpoint

	// values added to assist the SpotLight
	Matrix4x4 spotLightMatrix = new Matrix4x4(); // multiplies all parent Transforms plus Viewpoint

	// constructor
	public SpotLight () {
		datatype = VRMLdatatype.SpotLight;
	}

} // end class SpotLight
