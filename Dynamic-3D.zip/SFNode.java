 // Node.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 30, 2002

package d3d;


/** Node is superclass of all nodes */

public class SFNode {

	int datatype = VRMLdatatype.SFNode;
	public String name = null;
	/** <I>children</I> is a single link instead of an array connected to all
	its siblings through a linked-list using the <I>next</I> variable. */
	public SFNode next = null;
	//public Node sibling = null;
	/** <I>children</I> are a linked list connected by <I>next</I> till the last sibling and <I>prev</I> to the first sibling. */
	public SFNode prev = null;
	/** the parent of this node.  If this is a shape node, then parent is likely an Anchor,
		Billboard, Group, Transform. */
	public SFNode parent = null;
	//Node childFirst  = null;
	public SFNode children  = null;

	SFNode childLast   = null;
	/** parent contains a TouchSensor */
	public SFNode touchSensor = null; // the parent contains a touchSensor as a child
	int objectNumber = VRMLdatatype.NotInteractive;

	// constructor
	//public SFNode () { } // not using

	/** set the name of this node */
	public void setName(String name) {
		this.name = name;
	}

	/** returns the name of this node or null if no DEF name assigned */
	public String getName() {
		return this.name;
	}

	/** the datatype from the VRMLdatatype class */
	public int getDataType(){
		return this.datatype;
	} // end getRoot

} // end class SFNode
