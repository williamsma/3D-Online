 // MFString.java
 // � 2002, 3D-Online, All Rights Reserved 
 // November 21, 2003

package d3d;

public class MFString {

	String[] s = null;

	// constructor
	public MFString () {
	}
	public MFString (int size, String s[]) {
		this.s = new String[size];
		setValue( size, s );
	}

	// setValue
	public void setValue (int size, String s[] ) {
		if (this.s == null) this.s = new String[size];
		for (int i = 0; i < size; i++) {
			this.s[i] = s[i];
		}
	}

	// addValue
	public void addValue (String s) {
		if (this.s == null) {
			this.s = new String[1];
			this.s[0] = s;
		}
		else {
			String[] tempS = new String[this.s.length];
			for (int i = 0; i < tempS.length; i++) {
				tempS[i] = this.s[i];
			}
			this.s = new String[tempS.length + 1];
			for (int i = 0; i < tempS.length; i++) {
				this.s[i] = tempS[i];
			}
			this.s[this.s.length-1] = s;
		}
	}

	// getValue
	public String[] getValue( ) {
		return this.s;
	}
	public String get1Value(int index) {
		return this.s[index];
	}
	/** returns strings separated by semicolons */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < s.length; i++ ) {
			returnString += (s[i] + ";");
		}
		//returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space 
		return returnString;
	}

} // end MFString
