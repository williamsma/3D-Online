 // Viewpoint.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 12, 2002

package d3d;


public class Viewpoint extends SFNode {

	public SFString description = new SFString();
	/** <I>fieldOfView</I> must be between 0 and PI radians */
	public SFFloat fieldOfView = new SFFloat ( (float)(Math.PI/4) );
	/** <I>jump</I> is not supported, selectable through Dynamic-3D User Interface */
	public SFBool jump = new SFBool(true);
	public SFRotation orientation = new SFRotation(0, 0, 1, 0); // this is the default but set just in case
	public SFVec3f position = new SFVec3f(0, 0, 10);

	SFFloat fieldOfView_Original = new SFFloat ( (float)(Math.PI/4) );
	SFRotation orientation_Original = new SFRotation(0, 0, 1, 0); // this is the default but set just in case
	SFVec3f position_Original = new SFVec3f(0, 0, 10);

	/* <I>nextViewpoint</I> is a linked list to the next Viewpoint */
	//public Viewpoint nextViewpoint = null;
	Viewpoint nextViewpoint = null;
	Matrix4x4 matrix4x4 = new Matrix4x4();

	// constructor
	public Viewpoint () {
		datatype = VRMLdatatype.Viewpoint;
	}

	void setFieldOfView (float fov ) {
		if ( fov <= 0) {
			fov = (float) (Math.PI/180f);
		}
		else if ( fov >= Math.PI) {
			fov = (float) (179f*Math.PI/180f);
		}
		this.fieldOfView.setValue ( fov );
	} // end setFieldOfView

} // end Viewpoint
