 // Anchor.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 19, 2002

package d3d;


public class Anchor extends Group {

	//public SFString description = "";
	public SFString description = new SFString("");
	public MFString parameter = null;
	public MFString url = null;

	public Anchor () {
		datatype = VRMLdatatype.Anchor;
	}

} // end Anchor class
