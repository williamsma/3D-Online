 // PixelTexture.java
 // � 2004, 3D-Online, All Rights Reserved 
 // April 28, 2004

package d3d;


public class PixelTexture extends SFNode {

	public SFImage image = new SFImage();
	public SFBool repeatS = new SFBool( true );
	public SFBool repeatT = new SFBool( true );

	public PixelTexture() {
		datatype = VRMLdatatype.PixelTexture;
	}

}//end class PixelTexture
