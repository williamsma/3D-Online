 // SFVec2f.java
 // � 2003, 3D-Online, All Rights Reserved 
 // November 10, 2003

package d3d;

public class SFVec2f {

	float[] vec2s = new float[2];

	// constructor
	public SFVec2f () {
		this.setValue ( 0, 0 );
	}
	public SFVec2f (float x, float y) {
		this.setValue ( x,  y );
	}

	// setValue
	public void setValue (float[] vec2s ) {
		for (int i = 0; i < this.vec2s.length; i++) { this.vec2s[i] = vec2s[i]; };
	}
	public void setValue (float x, float y ) {
		this.vec2s[0] = x;
		this.vec2s[1] = y;
	}

	// getValue
	public float[] getValue( ) {
		return this.vec2s;
	}
	public float getX() {
		return this.vec2s[0];
	}
	public float getY() {
		return this.vec2s[1];
	}
	/** returns X and Y separated by space characters */
	public String toString( ) {
		String returnString = vec2s[0] + " " + vec2s[1];
		return returnString;
	}

} // end SFVec2f
