 // PositionInterpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // December 10, 2003

package d3d;


public class PositionInterpolator extends Interpolator {

	protected MFVec3f keyValue = null;

	public PositionInterpolator() {
		datatype = VRMLdatatype.PositionInterpolator;
	}

}//end class PositionInterpolator
