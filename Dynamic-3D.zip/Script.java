 // Script.java
 // � 2003, 3D-Online, All Rights Reserved 
 // June 19, 2003


package d3d;


public class Script extends Sensor {
	// extending Sensor provides an enabled varaible

	public boolean eventIn;
	public boolean eventOut;

	public Script() {
		datatype = VRMLdatatype.Script;
	}

}//end class Script
