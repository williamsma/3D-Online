// GraphicsEngineController.java
// � 2004, 3D-Online, All Rights Reserved 
package d3d;

import java.awt.Cursor;

public class GraphicsEngineController implements DeviceControllerAbstract {

	final String BridgeString = "Bridge";
	final String SlideString = "Slide";
	final String AddBridgeString = "Add" + BridgeString;
	final String AddSlideString = "Add" + SlideString;
	final String DetachString = "Detach";
	final String DeleteString = "Delete";
	final String GrassBackgroundString = "GrassBackground";

   GraphicEngine graphicEngine = null;
   PickRay pickRay = null;
	Transform Box1Transform = null;
	Transform Cone2Transform = null;
   float[] Box1Translation = new float[3];
   float[] Cone2Translation = new float[3];
   SFNode pickedObject = null;
   float[] pickedTranslation = new float[3];

	Transform pickedTransform = null;
	SFNode modifiableObject = null;
	int mouseDownX, mouseDownY;
   SFNode root = null;

	Cursor defaultCursor = null;
	Cursor handCursor = null;
	Cursor moveCursor = null;

	int bridgeCount = 0;
	int slideCount = 0;



	// constructor
	public GraphicsEngineController (GraphicEngine graphicEngine,
				Renderer renderer, RendererObserver rendererObserver) {
		renderer.addMouseObserver();
       this.graphicEngine = graphicEngine;
       pickRay = graphicEngine.getPickRay();
		defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);
		handCursor = new Cursor(Cursor.HAND_CURSOR);
		moveCursor = new Cursor(Cursor.MOVE_CURSOR);
	} // end Constructor



	public void initialize(){
   	root = graphicEngine.getRoot();
	} // initialize


	public void finalize(){}



	/** needs to be present if implementing DeviceControllerAbstract */
	public void onMouseInput(MouseInput mi){
      switch (mi.which) {
         case MouseInput.DOWN:
            if ( pickRay.TotalPickedObjects() != 0) {
               pickedObject = pickRay.GetClosest();
               if ( pickedObject.getDataType() == VRMLdatatype.Shape ) {
                  Shape shape = (Shape) pickedObject;
                  SFNode shapeParent = shape.parent;

                  if ( shapeParent.getDataType() == VRMLdatatype.Transform ) {
                     pickedTransform = (Transform) shapeParent;
							if ( pickedTransform.getName().equals( AddBridgeString ) ) {
								Transform transform = new Transform();
						      //transform.rotation.setValue(.866f, 0, .5f, .7f);
						      // add the transform to the scene graph
								String bridgeName = BridgeString + bridgeCount;
 							   bridgeCount++;
						      graphicEngine.AddNode( root, transform, bridgeName );
						
						      Material myMaterial = new Material();
						      myMaterial.diffuseColor.setValue(1, 1, 0);
						      Appearance myAppearance = new Appearance();
						      myAppearance.material = myMaterial;
						
						      Shape myShape = new Shape();
								float[] myBoxSize = {3, .3f, 1};
						      Box myBox = new Box( myBoxSize );
						      myShape.appearance = myAppearance;
						      myShape.geometry = myBox;
						      // add the shape
						      graphicEngine.AddNode( transform, myShape  );
								modifiableObject = transform;
							} // end adding bridge

							else if ( pickedTransform.getName().equals( AddSlideString ) ) {
								Transform transform = new Transform();
						      transform.rotation.setValue(1, 0, 0, 1.2f);
						      // add the transform to the scene graph
								String slideName = SlideString + slideCount;
 							   slideCount++;
						      graphicEngine.AddNode( root, transform, slideName );
						
						      Material myMaterial = new Material();
						      myMaterial.diffuseColor.setValue(0, 1, 1);
						      Appearance myAppearance = new Appearance();
						      myAppearance.material = myMaterial;
						
						      Shape myShape = new Shape();
						      Cylinder myCylinder = new Cylinder(true, 2, .5f, true, true);
						      myShape.appearance = myAppearance;
						      myShape.geometry = myCylinder;
						      // add the shape
						      graphicEngine.AddNode( transform, myShape  );
								modifiableObject = transform;
							}
							else if ( pickedTransform.getName().equals( DetachString ) ) {
								if (modifiableObject != null) {
							      modifiableObject = graphicEngine.DetachNode( modifiableObject );
							      graphicEngine.AddNode( root, modifiableObject );
								}
							}
							else if ( pickedTransform.getName().equals( DeleteString ) ) {
								if (modifiableObject != null) graphicEngine.DeleteNode( modifiableObject );
								modifiableObject = null;
								pickedTransform = null;
							}
							else  if ( !pickedTransform.getName().equals( GrassBackgroundString ) ) {
								mouseDownX = mi.x;
								mouseDownY = mi.y;
								modifiableObject = pickedTransform;
							   pickedTranslation = pickedTransform.translation.getValue();
								System.out.println("picked obj = " + modifiableObject.name);
							}
                  } // end shape.parent == Transform
						else pickedTransform = null;
               } // end picked object == Shape
            } // end picked objects != 0
				else pickedTransform = null;
         break;

         case MouseInput.UP:
 				pickedTransform = null;

			break;

         case MouseInput.DRAG:
				if (pickedTransform != null) {
					//System.out.println("mouse x, y = " + mi.x + ", " + mi.y);
					if ( 
							(!pickedTransform.getName().equals( AddBridgeString ) ) &&
							(!pickedTransform.getName().equals( AddSlideString ) ) &&
							(!pickedTransform.getName().equals( DetachString ) ) &&
							(!pickedTransform.getName().equals( DeleteString ) ) &&
							(!pickedTransform.getName().equals( GrassBackgroundString ) )
					) {
						float[] translation = new float[3];
						translation[0] = pickedTranslation[0] + ((float)(mi.x - mouseDownX))/36.f;
						translation[2] = pickedTranslation[2] + ((float)(mi.y - mouseDownY))/36.f;
						pickedTransform.translation.setValue( translation );
						mouseDownX = mi.x;
						mouseDownY = mi.y;
						//graphicEngine.applet.setCursor(moveCursor);
					}
				}
				//else graphicEngine.applet.setCursor(defaultCursor);
         break;

         case MouseInput.MOVE:
  				pickedTransform = null;

            if ( pickRay.TotalPickedObjects() != 0) {
               pickedObject = pickRay.GetClosest();
               if ( pickedObject.getDataType() == VRMLdatatype.Shape ) {
                  Shape shape = (Shape) pickedObject;
                  SFNode shapeParent = shape.parent;
                  if ( shapeParent.getDataType() == VRMLdatatype.Transform ) {
                     Transform mouseOverTransform = (Transform) shapeParent;
							if ( 
								( mouseOverTransform.getName().equals( AddBridgeString ) ) ||
								( mouseOverTransform.getName().equals( AddSlideString ) ) ||
								( mouseOverTransform.getName().equals( DetachString ) ) ||
								( mouseOverTransform.getName().equals( DeleteString ) )
							) {
								graphicEngine.applet.setCursor(handCursor);
							}
							else if ( mouseOverTransform.getName().equals( GrassBackgroundString ) ) {
								graphicEngine.applet.setCursor(defaultCursor);
							}
							else {
								graphicEngine.applet.setCursor(moveCursor);
								//modifiableObject = mouseOverTransform;
	//System.out.println("mouse Move, modifiableObject = " + modifiableObject.name );
							}
                  }
						//else pickedTransform = null;
               }
            }
				//else {
				//	graphicEngine.applet.setCursor(defaultCursor);
				//}
       break;
      } // end switch
		//if (objRemoved) System.out.println("objRemoved, end MouseInput");
	} // end 

} // end GraphicsEngineController class
