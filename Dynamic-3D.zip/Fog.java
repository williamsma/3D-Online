// Fog.java
// � 2004, 3D-Online, All Rights Reserved 
// February 26, 2004
 // In memory of Alan Arinsberg, who took his life and was laid to rest on Feb. 23, 2004

package d3d;


public class Fog extends SFNode {

	public SFColor color = new SFColor(1, 1, 1);
	public SFString fogType = new SFString("LINEAR");
	public SFFloat visibilityRange = new SFFloat(0);

	// constructor
	public Fog () {
		datatype = VRMLdatatype.Fog;
	}

} // end Fog class
