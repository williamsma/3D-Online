 // ScalarInterpolator.java
 // � 2004, 3D-Online, All Rights Reserved 
 // February 25, 2004

package d3d;


public class ScalarInterpolator extends Interpolator {

	public MFFloat keyValue = null;

	public ScalarInterpolator() {
		datatype = VRMLdatatype.ScalarInterpolator;
	}

}//end class ScalarInterpolator
