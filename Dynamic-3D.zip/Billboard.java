 // Billboard.java
 // � 2003, 3D-Online, All Rights Reserved 
 // March 20, 2003

package d3d;


public class Billboard extends Group {

	/** axisOfRotation only rotates around the Y-axis, thus this value should be left set */
	public SFVec3f axisOfRotation = new SFVec3f(0, 1, 0);

	Matrix3x3 rotationMatrix = new Matrix3x3();

	// constructor
	public Billboard () {
		datatype = VRMLdatatype.Billboard;
	}

} // end class Billbaord
