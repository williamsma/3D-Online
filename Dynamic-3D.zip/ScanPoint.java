/*
ScanPoint.java
Property of 3D-Online, All Rights Reserved, Copyright, 2003
May 2, 2004
*/

package d3d;


public class ScanPoint {

	GraphicsDisplay gd = null;
	WorldScreenCoordinates coordSys = null;
	float[] pointLocation = new float[3];
	float[] pointColor = new float[3];
	int[] pointColor255 = new int[3];
	private int[] bufferRGB		= null;

   public ScanPoint(WorldScreenCoordinates coordSys_, GraphicsDisplay display_ ) {
		gd = display_;
		coordSys = coordSys_;
	}

	public void DrawPoint( boolean renderBuffer1, int clippingPlanes) {
	// need to convert to a screen point

		float z = pointLocation[2]; 
		float w = -pointLocation[2] / coordSys.distance; 
		int x = (int) ( coordSys.WorldToScreenX( pointLocation[0] / w ) + .5f); 
		int y = (int) ( coordSys.WorldToScreenY( pointLocation[1] / w ) + .5f);
//System.out.print("DrawPt x " + x + ", y " + y);
		boolean clip = false;
		if (clippingPlanes != 0) {
			if ( (x < 0) || ( x >= coordSys.ScreenCoordMaxX) || (y < 0) || (y >= coordSys.ScreenCoordMaxY) ) {
				clip = true;
//System.out.print(" clip");
				}
		}
		if ( !clip ) {
			if ( renderBuffer1 ) bufferRGB = gd.buffer1RGB;
			else bufferRGB = gd.buffer2RGB;
			int pixelValue = y * gd.width + x;
			for (int i = 0; i < 3; i++)
				pointColor255[i] = (int) pointColor[i] * 255;
	
			//if ( renderBuffer1 ) {
				if (gd.Zbuffer[pixelValue] < z ) {
						bufferRGB[pixelValue]	=
							(0xff000000) | (pointColor255[0] << 16) | (pointColor255[1] << 8) | (pointColor255[2]);
						gd.Zbuffer[pixelValue] = z;
				}
			/*}
			else { // renderBuffer2
				if (gd.Zbuffer[pixelValue] < z ) {
						gd.buffer2RGB[pixelValue]	=
							(0xff000000) | (pointColor255[0] << 16) | (pointColor255[1] << 8) | (pointColor255[2]);
						gd.Zbuffer[pixelValue] = z;
				}
			}
		*/
		} // no clipping
//System.out.println();
	} // end DrawPoint


} // end class ScanPoint