/****************************
KeyFrameAnimator.java
February 27, 2003
Taken out of GenerateFrame
Property of 3D-Online, All Rights Reserved, Copyright, 2002

*****************************/

package d3d;

import java.lang.ArrayIndexOutOfBoundsException;


public class KeyFrameAnimator {

	final int badKey = -1;

	Route routeRoot = null;
	Route currentRoute = null;
	Sensor sensorRoot = null;
	TouchSensor clearTouchSensor = null;
	Route routeInterpTransform = null;
	GraphicEngine graphicsEnginePanel = null;

	int key;


   public KeyFrameAnimator(Route mainRouteRoot, Sensor mainSensorRoot, GraphicEngine graphicEnginePanel_) {
		routeRoot = mainRouteRoot;
		sensorRoot = mainSensorRoot;
		this.graphicsEnginePanel = graphicEnginePanel_;
  	} // end Constructor

	private int GetUpperKey(Interpolator currrentInterpolator, float fraction) {
		int key = 1;
		try {
			while ( currrentInterpolator.key.values[key] <= fraction) {
				key++;
				if (key >= currrentInterpolator.key.values.length) {
					key = currrentInterpolator.key.values.length - 1;
					break;
				}
			}
	   } // end try
		catch ( java.lang.ArrayIndexOutOfBoundsException e ) { 
			System.out.println("Error: KeyFrameAnimator.GetUpperKey = " + e);
			System.out.println("   key = " + key + ", fraction = " + fraction);
		}
		return key;
	} // end GetUpperKey

	private float GetPctComplete(Interpolator currrentInterpolator, float fraction, int key) {
		float pctComplete = 0;
		if (currrentInterpolator.key.values[key] != currrentInterpolator.key.values[key-1]) {
			pctComplete = (fraction - currrentInterpolator.key.values[key-1]) /
								(currrentInterpolator.key.values[key] - currrentInterpolator.key.values[key-1]);
		}
		return pctComplete;
	} // end GetPctComplete


	private void SetValuesFromScript(TouchSensor touchSensor) {
		Script scriptNode = (Script) currentRoute.fromObject;
		if ( touchSensor != null ) {
			// set the timer values
			if ( touchSensor.isActive ) {
				if (currentRoute.toObject.datatype == VRMLdatatype.TimeSensor) {
					TimeSensor timeSensor = (TimeSensor) currentRoute.toObject;
					timeSensor.enabled = scriptNode.enabled;
					if ( timeSensor.enabled.value ) {
						if ( timeSensor.loop.value ) {
							timeSensor.startTime.time = touchSensor.touchTime;
						}
						else { // NOT timeSensor.loop 
							timeSensor.startTime.time = touchSensor.touchTime;
							timeSensor.stopTime.time = timeSensor.startTime.time + (long)(timeSensor.cycleInterval.f * 1000);
						}
					} // end if timeSensor.enabled
					else {
						if ( timeSensor.loop.value ) {
							timeSensor.pauseTime = touchSensor.touchTime % (long)(timeSensor.cycleInterval.f * 1000);
						}
						else { // NOT timeSensor.loop
							timeSensor.pauseTime = 0;
 					   }
					} // end if timeSensor != enabled
				} // end if toObject == TimeSensor
				//else {
				//	//System.out.println("KeyUpdate.SetValuesFromScript currentRoute.toObject.datatype != VRMLdatatype.TimeSensor");
				//}
			} // end if touchSensor.isActive
		} // end if touchSensor != null
	} // end SetValuesFromScript


	private void TouchSensorEventOut(boolean isActiveOverValue, long touchSensorTouchTime) {
		if ( currentRoute.toObject.datatype == VRMLdatatype.TimeSensor ) {
			TimeSensor timeSensor = (TimeSensor) currentRoute.toObject; 
			timeSensor.enabled.value = isActiveOverValue;
		} // end if toObject == TimeSensor
		else if ( currentRoute.toObject.datatype == VRMLdatatype.Script ) {
			Script script = (Script) currentRoute.toObject; 
			if ( script.name.indexOf(Dynamic3D_Script.dynamic3DIndicatorString) != -1) {
				Dynamic3D_Script dynamic3D_Script = (Dynamic3D_Script) script;
				dynamic3D_Script.Execute_Script();
				dynamic3D_Script.startTime = touchSensorTouchTime;
			}
		} // end if toObject == Script
		else if ( 
			( currentRoute.toObject.datatype == VRMLdatatype.DirectionalLight ) ||
			( currentRoute.toObject.datatype == VRMLdatatype.PointLight ) ||
			( currentRoute.toObject.datatype == VRMLdatatype.SpotLight ) ) {
			currentRoute.to.sfBool = isActiveOverValue;
		} // end if toObject == Light
	} // end TouchSensorEventOut
	

	public void UpdateAnimations() {
		currentRoute = routeRoot.nextRoute;
		TouchSensor touchSensor = null;
		while ( currentRoute != null) {
			if (currentRoute.fromObject.datatype == VRMLdatatype.TouchSensor) {
				touchSensor = (TouchSensor) currentRoute.fromObject;
				if (touchSensor.enabled.value) {
					// Check if "ROUTE touchSensor.isActive TO" or "ROUTE touchSensor.isOver TO"
					if (currentRoute.from.isActiveProperty ) {
						if ( currentRoute.toObject.datatype == VRMLdatatype.DirectionalLight ) {
							Light light = (Light) currentRoute.toObject; 
							light.on.setValue( touchSensor.isActive );
						}
						else {
							if ( touchSensor.isActive ) {
								TouchSensorEventOut( touchSensor.isActive, touchSensor.touchTime );
								touchSensor.isActiveCleared = true; // indicate we acted on isActive so we can reset it false later
							}
						}
						/*
						if ( touchSensor.isActive ) {
							TouchSensorEventOut( touchSensor.isActive, touchSensor.touchTime );
							touchSensor.isActiveCleared = true; // indicate we acted on isActive so we can reset it false later
						}
						else { //touchSensor.isActive == false
							if ( currentRoute.toObject.datatype == VRMLdatatype.DirectionalLight ) {
								Light light = (Light) currentRoute.toObject; 
								light.on.setValue( touchSensor.isActive );
							} // end if toObject == Light
						}
						*/
					}
					else if (currentRoute.from.isOverProperty ) TouchSensorEventOut( touchSensor.isOver, touchSensor.touchTime );
					else if (currentRoute.from.touchTimeProperty ) {
						if ( currentRoute.toObject.datatype == VRMLdatatype.TimeSensor ) {
							TimeSensor timeSensor = (TimeSensor) currentRoute.toObject; 
							// assume only startTime and not stopTime is changed
							timeSensor.startTime.time = touchSensor.touchTime;
						} // end if toObject == TimeSensor
					} // if touchTimeProperty
				} // end timeSensor enabled
			} // end if touchSensor
			else if (currentRoute.fromObject.datatype == VRMLdatatype.Script) {
				SetValuesFromScript( touchSensor );
			} // end if Script
			else if (currentRoute.fromObject.datatype == VRMLdatatype.TimeSensor) {
				TimeSensor timeSensor = (TimeSensor) currentRoute.fromObject;
				if (timeSensor.enabled.value ) {
					long time = System.currentTimeMillis();
					if ( (!timeSensor.loop.value) && (time > timeSensor.stopTime.time) ) {
//System.out.println("(!timeSensor.loop.value) && (time > timeSensor.stopTime.time)");
//System.out.println("   timeSensor.loop.value = " + timeSensor.loop.value + ", timeSensor.enabled.value = " + timeSensor.enabled.value);
//System.out.println("   time = " + time + ", timeSensor.stopTime.time = " + timeSensor.stopTime.time);
						// fixes loop = FALSE error, had to modify Dynamic-3D code a bit too.
						if ( timeSensor.stopTime.time == 0 ) {
							timeSensor.startTime.time = time;
							timeSensor.stopTime.time = timeSensor.startTime.time + (long)(timeSensor.cycleInterval.f * 1000);
							//System.out.println("Reset stopTime = " + timeSensor.stopTime.time );
						}
						else timeSensor.enabled.value = false;
						//timeSensor.enabled.value = false;
					}
					else {
						//long fraction_changed = time % (long)(timeSensor.cycleInterval * 1000) ;
						long fraction_changed = (time - timeSensor.startTime.time + timeSensor.pauseTime) % (long)(timeSensor.cycleInterval.f * 1000) ;
						float fraction = (float) (fraction_changed / (1000 * timeSensor.cycleInterval.f) );
						Interpolator currToInterpolator = (Interpolator) currentRoute.toObject;
						key = GetUpperKey(currToInterpolator, fraction);
						if ( key != badKey) {
							float pctComplete = GetPctComplete(currToInterpolator, fraction, key);
							// Get second ROUTE that is From the Interpolator that matches the Timer TO the Interpolator
							routeInterpTransform = routeRoot.nextRoute;
							while ( routeInterpTransform != null ) {
								if ( routeInterpTransform.fromObject.name.equals(currentRoute.toObject.name ) ) {
									if (	currToInterpolator.datatype == VRMLdatatype.PositionInterpolator) {
										PositionInterpolator currToPositionInterpolator = (PositionInterpolator) currentRoute.toObject;
										for (int j = 0; j < 3; j++) {
											routeInterpTransform.to.sfVec3f[j] =
												(pctComplete *
												(currToPositionInterpolator.keyValue.vec3s[key][j] - currToPositionInterpolator.keyValue.vec3s[key-1][j])) +
												 currToPositionInterpolator.keyValue.vec3s[key-1][j];
										}
									} // end if PositionInterpolator
									else if (	currToInterpolator.datatype == VRMLdatatype.ColorInterpolator) {
										ColorInterpolator currToColorInterpolator = (ColorInterpolator) currentRoute.toObject;
										for (int j = 0; j < 3; j++) {
											routeInterpTransform.to.sfColor[j] =
												(pctComplete *
												(currToColorInterpolator.keyValue.colors[key][j] - currToColorInterpolator.keyValue.colors[key-1][j])) +
												 currToColorInterpolator.keyValue.colors[key-1][j];
										}
									} // end if ColorInterpolator
									else if (	currToInterpolator.datatype == VRMLdatatype.ScalarInterpolator) {
										ScalarInterpolator currToScalarInterpolator = (ScalarInterpolator) currentRoute.toObject;
										routeInterpTransform.to.sfFloat =
												(pctComplete *
												(currToScalarInterpolator.keyValue.values[key] - currToScalarInterpolator.keyValue.values[key-1])) +
												 currToScalarInterpolator.keyValue.values[key-1];

										//System.out.println("routeInterpTransform.toObject.datatype = " + routeInterpTransform.toObject.datatype );
										if ( routeInterpTransform.toObject.datatype == VRMLdatatype.Material ) { 
											Material material = (Material) routeInterpTransform.toObject;
											if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.materialTransparency )
												material.transparency.f = routeInterpTransform.to.sfFloat;
											else if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.materialShininess )
												material.shininess.f = routeInterpTransform.to.sfFloat;
											else if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.ambientIntensity )
												material.ambientIntensity.f = routeInterpTransform.to.sfFloat;
										} // end Material SFFloat
										else if ( routeInterpTransform.toObject.datatype == VRMLdatatype.TextureTransform ) {
											// rotation is the only SFFloat within TextureTransform
											TextureTransform textureTransform = (TextureTransform) routeInterpTransform.toObject;
											textureTransform.rotation.f = routeInterpTransform.to.sfFloat;	
										} // end TextureTransform SFFloat
										else if ( routeInterpTransform.toObject.datatype == VRMLdatatype.Viewpoint ) {
											// fieldOfView is the only SFFloat within Viewpoint
											Viewpoint viewpoint = (Viewpoint) routeInterpTransform.toObject;
											viewpoint.fieldOfView.f = routeInterpTransform.to.sfFloat;	
 											// must reset the view frustum to when changing field of view
											this.graphicsEnginePanel.coordSystem.SetViewFrustum(viewpoint.fieldOfView.f);
										} // end TextureTransform SFFloat
										if (	(routeInterpTransform.toObject.datatype == VRMLdatatype.DirectionalLight) ||
												(routeInterpTransform.toObject.datatype == VRMLdatatype.PointLight) ||
												(routeInterpTransform.toObject.datatype == VRMLdatatype.SpotLight) ) { 
											Light light = (Light) routeInterpTransform.toObject;
											if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.intensity )
												light.intensity.f = routeInterpTransform.to.sfFloat;
											else if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.ambientIntensity )
												light.ambientIntensity.f = routeInterpTransform.to.sfFloat;
											else { // PointLight or SpotLight value
												if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.lightRadius ) {
													// covers both PointLight and SpotLight
													PointLight pointLight = (PointLight) routeInterpTransform.toObject;
													pointLight.intensity.f = routeInterpTransform.to.sfFloat;
												}
												else { //SpotLight only
													SpotLight spotLight = (SpotLight) routeInterpTransform.toObject;
													if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.spotLightBeamWidth ) {
														spotLight.beamWidth.f = routeInterpTransform.to.sfFloat;
													}
													else if ( routeInterpTransform.to.sfFloatType == routeInterpTransform.to.spotLightCutOffAngle ) {
														spotLight.cutOffAngle.f = routeInterpTransform.to.sfFloat;
													}
												}
											}
										} // end Light SFFloat
									} // end if ScalarInterpolator
									else if (currToInterpolator.datatype == VRMLdatatype.OrientationInterpolator) {
										OrientationInterpolator currToOrientationInterpolator = (OrientationInterpolator) currentRoute.toObject;
										/*
										for (int j = 0; j < 4; j++) {
											routeInterpTransform.to.sfRotation[j] =
												(pctComplete * (currToOrientationInterpolator.keyValue.rotations[key][j] - currToOrientationInterpolator.keyValue.rotations[key-1][j])) +
												 currToOrientationInterpolator.keyValue.rotations[key-1][j];
										}
										*/
										float[] returnAxisAngle = SLERP(
											currToOrientationInterpolator.keyValue.rotations[key-1],
											currToOrientationInterpolator.keyValue.rotations[key], pctComplete);
										for (int j = 0; j < 4; j++) {
											routeInterpTransform.to.sfRotation[j] = returnAxisAngle[j];
										}
									} // end if OrientationInterpolator
									else if (currToInterpolator.datatype == VRMLdatatype.CoordinateInterpolator) {
										CoordinateInterpolator currToCoordinateInterpolator = (CoordinateInterpolator) currentRoute.toObject;
										//MFVec3f mfvec3f = routeInterpTransform.to.mfVec3f;
										int totalCoords =  routeInterpTransform.to.mfVec3f.length;
										for (int i = 0; i < routeInterpTransform.to.mfVec3f.length; i++) {
											for (int j = 0; j < 3; j++) {
												routeInterpTransform.to.mfVec3f[i][j] =
													(pctComplete *
													(currToCoordinateInterpolator.keyValue.vec3s[(key*totalCoords)+i][j] - currToCoordinateInterpolator.keyValue.vec3s[((key-1)*totalCoords)+i][j])) +
													 currToCoordinateInterpolator.keyValue.vec3s[((key-1)*totalCoords)+i][j];
											}
										}
										Shape shape = (Shape) routeInterpTransform.toObject.parent;
										this.graphicsEnginePanel.ResetNormals(shape);
									} // end CoordinateInterpolator
									else if (currToInterpolator.datatype == VRMLdatatype.NormalInterpolator) {
										NormalInterpolator currToNormalInterpolator = (NormalInterpolator) currentRoute.toObject;
										int totalVectors =  routeInterpTransform.to.mfVec3f.length;
										for (int i = 0; i < routeInterpTransform.to.mfVec3f.length; i++) {
											for (int j = 0; j < 3; j++) {
												routeInterpTransform.to.mfVec3f[i][j] =
													(pctComplete *
													(currToNormalInterpolator.keyValue.vec3s[(key*totalVectors)+i][j] - currToNormalInterpolator.keyValue.vec3s[((key-1)*totalVectors)+i][j])) +
													 currToNormalInterpolator.keyValue.vec3s[((key-1)*totalVectors)+i][j];
											}
										}
									} // end NormalInterpolator
								} // ROUTE TO Interpolator matches ROUTE from Interpolator
								routeInterpTransform = routeInterpTransform.nextRoute;
							} // end while ToRoute != null
						} // key != badKey
					} // timeSensor != loop and time <= stopTime;
				} // end if timeSensor.enabled
			} // end if fromObj == TimeSensor
			currentRoute = currentRoute.nextRoute;
		} // end while loop

		// clear the isActive values for TouchSensors
		Sensor currentSensor = (Sensor) sensorRoot.next; // Get past the root
		while (currentSensor != null) {
			try {
				clearTouchSensor = (TouchSensor) currentSensor;
				if ( clearTouchSensor.isActiveCleared ) {
					clearTouchSensor.isActive = false; 
					clearTouchSensor.isActiveCleared = false;
				}
			}
			catch (java.lang.Exception e) {
			}
			currentSensor = (Sensor) currentSensor.next;
		}
	} // end UpdateAnimations



	private float[] SLERP(float[] beginRotation, float[] destRotation, float pctTime) {
		float[] beginQuaternion = MathOps.AxisAngleToQuaternion( beginRotation );
		//float[] diffOrientation = new float[4];
		float[] destQuaternion = MathOps.AxisAngleToQuaternion( destRotation );

		float quaternionDotProduct = MathOps.DotProduct(beginQuaternion, destQuaternion);
		if ( quaternionDotProduct < 0) {
			for (int i = 0; i < destQuaternion.length; i++) { destQuaternion[i] = -destQuaternion[i]; }
			quaternionDotProduct = MathOps.DotProduct(beginQuaternion, destQuaternion);
		}
		float angleBetweenOrientations = (float) Math.acos(quaternionDotProduct);
		float sinTheta = (float) Math.sin(angleBetweenOrientations);

		float[] returnQuaternion = new float[4];
		// SLERP (t; q0, q1) = [ q0* sin(q*(1-t)) + q1* sin(q*t) ] / sin(q)
		if (sinTheta != 0) { // this function isn't called if sinTheta == 0
			float sinTheta_X_PctTime = ((float) Math.sin(sinTheta * pctTime)) / sinTheta;
			float sinTheta_X_OneMinusPctTime = ((float) Math.sin(sinTheta * (1 - pctTime)) )/sinTheta;
			for (int i = 0; i < returnQuaternion.length; i++) {
				returnQuaternion[i] = beginQuaternion[i] * sinTheta_X_OneMinusPctTime + destQuaternion[i] * sinTheta_X_PctTime;
			}
		}
		else {
			for (int i = 0; i < 4; i++) {
				returnQuaternion[i] = beginQuaternion[i];
			}
		}

		float[] returnAxisAngle = MathOps.QuaternionToAxisAngle( returnQuaternion );

		return returnAxisAngle;
	} // end SLERP


}//end class KeyFrameAnimator