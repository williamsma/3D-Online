 // ImageTexture.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 19, 2002

package d3d;


import java.awt.Image;
import java.awt.MediaTracker;
import java.applet.Applet;
import java.awt.image.PixelGrabber;
import java.awt.image.ImageObserver;

// for multii-tasking of downloading of images
import java.lang.Thread;
import java.lang.Runnable;
import java.lang.InterruptedException;


public class ImageTexture extends SFNode implements Runnable {

	final int transparent = 0;

	public MFString url = null;
	/** <I>repeatS</I> not currently implimented, set to true */
	public SFBool repeatS = new SFBool( true );
	/** <I>repeatT</I> not currently implimented, set to true */
	public SFBool repeatT = new SFBool( true );

	/* height of original texture map */
	int height;
	/* width of original texture map */
	int width;
	private int totalPixels = 0;
	private int[] pixels = null;
	// original bit map
	/* red channel of original texture map */
	int[] red    = null;
	/* green channel of original texture map */
	int[] green  = null;
	/* blue channel of original texture map */
	int[] blue   = null;
	/** alpha channel of original texture map */
	int[] alpha  = null;
	boolean transparentGIF = false; // set true if there is a transparent bit

	// mipmapping 
	int[] red3x3    = null;
	int[] green3x3  = null;
	int[] blue3x3   = null;
	int[] alpha3x3  = null;
	int   width3x3  = 0;
	int   height3x3 = 0;

	/*
	int[] red5x5    = null;
	int[] green5x5  = null;
	int[] blue5x5   = null;
	int[] alpha5x5  = null;
	int   width5x5  = 0;
	int   height5x5 = 0;
	private int[] red5x5copy    = null;
	private int[] green5x5copy  = null;
	private int[] blue5x5copy   = null;
	float invoke5x5mipmap = 0;

	int[] red7x7    = null;
	int[] green7x7  = null;
	int[] blue7x7   = null;
	int[] alpha7x7  = null;
	int   width7x7  = 0;
	int   height7x7 = 0;
	private int[] red7x7copy    = null;
	private int[] green7x7copy  = null;
	private int[] blue7x7copy   = null;
	float invoke7x7mipmap = 0;
	*/

	// temp buffer before image fully loaded 
	/** set false until texture map has downloaded */
	public boolean loaded = false;
	// dummy texture maps used until the read texture map has loaded
	int widthPreload  = 32; // arbitrary number
	int heightPreload = 32;
	int totalPixelsPreload = widthPreload * heightPreload;
	int[] colorPreload	= new int[totalPixelsPreload];
	int[] alphaPreload	= new int[totalPixelsPreload];

	//image-laoding variables
	Image image1 = null;
	MediaTracker tracker = null;
	Applet localApplet = null;

	// threading software
	private Thread thread;


	// constructor
	public ImageTexture () {
		datatype = VRMLdatatype.ImageTexture;

		// insert a dummy image while the texture maps are loading
		for (int i = 0; i < heightPreload; i++) {
			for (int j = 0; j < widthPreload; j++) {
				if ( (i==0) || (i == (heightPreload-1) ) ) colorPreload[i*widthPreload + j] = 0xCC;
				else if ( (j == 0) || (j == (widthPreload-1) ) ) colorPreload[i*widthPreload + j] = 0xCC;
				else colorPreload[i*widthPreload + j] = 0x33;
				alphaPreload[i*widthPreload + j] = 0xff000000;
			} // end for j loop
		} // end for i loop
	} // end ImageTexture constructor


	public int getWidth() {
	    return this.width;
	}

	public int getHeight() {
	    return this.height;
	}


	
	private void HalfMipmap (
			int[] redSrc, int[] greenSrc, int[] blueSrc, int[] alphaSrc,
			int srcWidth, int srcHeight,
			int[] redDest, int[] greenDest, int[] blueDest, int[] alphaDest,
			int destWidth, int destHeight) {

		for (int i = 0; i < destHeight; i++) {
			for (int j = 0; j < destWidth; j++) {
				redDest[i*destWidth + j]	= redSrc[(i*srcWidth*2) + (j*2)];
				greenDest[i*destWidth + j]	= greenSrc[(i*srcWidth*2) + (j*2)];
				blueDest[i*destWidth + j]	= blueSrc[(i*srcWidth*2) + (j*2)];
				alphaDest[i*destWidth + j]	= alphaSrc[(i*srcWidth*2) + (j*2)];
			}
		}
	} // end HalfMipmap



	private void CreateMipmap (
			int[] redSrc, int[] greenSrc, int[] blueSrc,
			int[] redDest, int[] greenDest, int[] blueDest,
		 	int[] alphaMap,
			int mipmapWidth, int mipmapHeight) {

		int minI, maxI, minJ, maxJ;
		final int span = 2;
		int pixelWeight;
		int totalPixelWeight;

		for (int i = 0; i < mipmapHeight; i++) {
			minI = (int)Math.max(i-1, 0);
			maxI = (int)Math.min(i+1, mipmapHeight-1);
			for (int j = 0; j < mipmapWidth; j++) {
				minJ = (int)Math.max(j-1, 0);
				maxJ = (int)Math.min(j+1, mipmapWidth-1);
				redDest[i*mipmapWidth + j] = 0;
				greenDest[i*mipmapWidth + j] = 0;
				blueDest[i*mipmapWidth + j] = 0;
				totalPixelWeight = 0;
				for (int iOffset = minI; iOffset <= maxI; iOffset++) {
					for (int jOffset = minJ; jOffset <= maxJ; jOffset++) {
						if ( alphaMap[i * mipmapWidth + j] != transparent) {
							pixelWeight = (span - Math.abs(iOffset-i)) * (span - Math.abs(jOffset-j));
							redDest[i * mipmapWidth + j]	+= redSrc[iOffset*mipmapWidth + jOffset] * pixelWeight;
							greenDest[i * mipmapWidth + j]	+= greenSrc[iOffset*mipmapWidth + jOffset] * pixelWeight;
							blueDest[i * mipmapWidth + j]	+= blueSrc[iOffset*mipmapWidth + jOffset] * pixelWeight;
							totalPixelWeight += pixelWeight;
						}
					} // end for jOffset loop
				} // end for iOffset loop
				if (totalPixelWeight != 0) {
					redDest[i*mipmapWidth + j] /= totalPixelWeight;
					greenDest[i*mipmapWidth + j] /= totalPixelWeight;
					blueDest[i*mipmapWidth + j] /= totalPixelWeight;
				}
			} // end for j loop
		} // end for i loop
	} // end create multiple mip maps


	private void SetImage(Image image1) {
		this.width  = image1.getWidth(localApplet);
		this.height = image1.getHeight(localApplet);
		totalPixels = width * height;
		this.pixels = new int[totalPixels];
		PixelGrabber pg = new PixelGrabber(image1, 0, 0, width, height, pixels, 0, width);
		try {
			pg.grabPixels();
		}
		catch (InterruptedException e){
			System.out.println("Image Texture.SetImage: grabPixels Error: " + e);
		};
		this.red   = new int[totalPixels];
		this.green = new int[totalPixels];
		this.blue  = new int[totalPixels];
		this.alpha = new int[totalPixels];

		this.red3x3   = new int[totalPixels];
		this.green3x3 = new int[totalPixels];
		this.blue3x3  = new int[totalPixels];
		this.alpha3x3 = new int[totalPixels];
		width3x3  = width;
		height3x3 = height;

		for (int i = 0; i < height; i++) {
			for (int j = 0; j < width; j++) {
				this.red[i*width + j]   = (this.pixels[i*width + j] & 0x00ff0000) >> 16;
				this.green[i*width + j] = (this.pixels[i*width + j] & 0x0000ff00) >> 8;
				this.blue[i*width + j]  =  this.pixels[i*width + j] & 0x000000ff;
				this.alpha[i*width + j] =  this.pixels[i*width + j] >> 24;
				if ( this.alpha[i*width + j] == transparent) transparentGIF = true; // set true if there is a transparent bit
			}
		}

//if (transparentGIF) {
//	System.out.println();
//	System.out.println("ImageTexture " + this.url.get1Value(0) + " transparent");
//	System.out.println();
//}

		try { System.arraycopy( alpha, 0, alpha3x3, 0, totalPixels ); }
		catch (Exception e) {};
		CreateMipmap(red, green, blue, red3x3, green3x3, blue3x3, alpha3x3, width3x3, height3x3);

		/*
		// create 5x5 bit map (reduction of 3x3
		width5x5  = (width3x3 + 1) >> 1;
		height5x5 = (height3x3 + 1) >> 1;
		red5x5   = new int[width5x5 * height5x5];
		green5x5 = new int[width5x5 * height5x5];
		blue5x5  = new int[width5x5 * height5x5];
		alpha5x5 = new int[width5x5 * height5x5];
		red5x5copy   = new int[width5x5 * height5x5];
		green5x5copy = new int[width5x5 * height5x5];
		blue5x5copy  = new int[width5x5 * height5x5];
		invoke5x5mipmap = (height5x5 + width5x5)*.36f; // just a logical guess, version 2.8 set to .38f

		HalfMipmap(red3x3, green3x3, blue3x3, alpha3x3, width3x3, height3x3,
						red5x5copy, green5x5copy, blue5x5copy, alpha5x5, width5x5, height5x5);
		CreateMipmap(red5x5copy, green5x5copy, blue5x5copy, red5x5, green5x5, blue5x5, alpha5x5, width5x5, height5x5);


		// create 7x7 bit map (reduction of 5x5
		width7x7  = (width5x5 + 1) >> 1;
		height7x7 = (height5x5 + 1) >> 1;
		red7x7   = new int[width7x7 * height7x7];
		green7x7 = new int[width7x7 * height7x7];
		blue7x7  = new int[width7x7 * height7x7];
		alpha7x7 = new int[width7x7 * height7x7];
		red7x7copy   = new int[width7x7 * height7x7];
		green7x7copy = new int[width7x7 * height7x7];
		blue7x7copy  = new int[width7x7 * height7x7];
		invoke7x7mipmap = (height7x7 + width7x7)*.36f; // just a logical guess, version 2.8 set to .38f

		HalfMipmap(red5x5, green5x5, blue5x5, alpha5x5, width5x5, height5x5,
						red7x7copy, green7x7copy, blue7x7copy, alpha7x7, width7x7, height7x7);
		CreateMipmap(red7x7copy, green7x7copy, blue7x7copy, red7x7, green7x7, blue7x7, alpha7x7, width7x7, height7x7);
		*/


		/* 
		for (int i = 0; i < this.red3x3.length; i++) {
			this.red3x3[i] = this.red3x3[i] << 16;
		}
		for (int i = 0; i < this.red5x5.length; i++) {
			this.red5x5[i] = this.red5x5[i] << 16;
		}
		for (int i = 0; i < this.red7x7.length; i++) {
			this.red7x7[i] = this.red7x7[i] << 16;
		}
		/* */
	} // end setImage

	/** Once the ImageTexture's url property is set, <I>retrieveImage</I> must be called to retrieve the image via multi-tasking.  Highest <I>priority</I> is 0.  suggested value is 1 */
	public void retrieveImage (Applet applet, int priority) {
		this.localApplet = applet;
		tracker = new MediaTracker(localApplet);
		image1 = localApplet.getImage(localApplet.getCodeBase(), this.url.get1Value(0) );
		tracker.addImage(image1, priority);
		try {
			//tracker.waitForID(0);
			tracker.waitForID(1);

			loaded = false;
		}
		catch (InterruptedException e){
			System.out.println("Image Texture.setURL: tracker Error: " + e);
		}
		thread = new Thread(this);
		thread.start();
	} // end retrieveImage

	/** Should only be called by the <I>retrieveImage</I> function to download images in a seperate thread */
	public void run() {
		try {
			while ( tracker.statusAll(true) != MediaTracker.COMPLETE ) {
				thread.sleep(500);
			}
		}
		catch (InterruptedException e) {
			System.out.println("Image Texture.run Error: " + e);
		}
		finally {
			SetImage(image1);
			loaded = true;
			System.out.println("Loaded " + this.url.get1Value(0));
	
		}
	} // end thread run

} // end class ImageTexture
