 // SFString.java
 // � 2002, 3D-Online, All Rights Reserved 
 // October 31, 2003

package d3d;

public class SFString {

	String s = null;

	// constructor
	public SFString () {
	}
	public SFString (String s) {
		this.setValue ( s );
	}

	// setValue
	public void setValue (String s ) {
		this.s = s;
	}

	// getValue
	public String getValue( ) {
		return this.s;
	}
	/** This overrides a method in Object */
	public String toString( ) {
		return s;
	}

} // end SFString
