// LexicalAnalyzerNDB.java
// � 2002, 3D-Online, All Rights Reserved 
// Date: March 30, 2002

package d3d;


import java.io.InputStream;
import java.io.StreamTokenizer;
import java.applet.Applet;
import java.util.Stack;


public class LexicalAnalyzerNDB {

	final char leftBraceChar    = '{'; // ascii 123
	final char rightBraceChar   = '}'; // ascii 125
	final char leftBracketChar  = '['; // ascii  91
	final char rightBracketChar = ']'; // ascii  93
	final char underscoreChar   = '_'; // ascii  95 (I think)
	final char doubleQuoteChar  = '"'; // ascii  34

	SFNode root = null;
	SFNode currentNode = null;

	Transform currentTransform											= null;
	Anchor currentAnchor													= null;
	Appearance currentAppearance										= null;
	AppletParameters appletParameters								= null;
	Background background												= null;
	Billboard currentBillboard											= null;
	Color currentColor													= null;
	ColorInterpolator currentColorInterpolator					= null;
	Coordinate currentCoordinate										= null;
	DirectionalLight currentDirectionalLight						= null;
	Fog currentFog															= null;
	Group currentGroup													= null;
	Shape currentShape													= null;
	Light currentLight 	                    						= null;
	Material currentMaterial											= null;
	SFNode /*imageTexture*/ imageTextureRoot							= null;
	//ImageTexture currentImageTexture									= null;
	//ImageTexture currImageTextureLink								= null;
	IndexedLineSet currentIndexedLineSet							= null;
	IndexedFaceSet currentIndexedFaceSet							= null;
	Interpolator interpolatorRoot										= null;
	Interpolator interpolatorLink										= null;
	TextureCoordinate currentTextureCoordinate					= null;
	NavigationInfo navigationInfo										= null;
	//Normal currentNormal													= null;
	OrientationInterpolator currentOrientationInterpolator	= null;
	PixelTexture currentPixelTexture									= null;
	PointLight currentPointLight										= null;
	PointSet currentPointSet											= null;
	PositionInterpolator currentPositionInterpolator			= null;
	CoordinateInterpolator currentCoordinateInterpolator		= null;
	NormalInterpolator currentNormalInterpolator					= null;
	Route routeRoot														= null;
	Route routeLast														= null;
	ScalarInterpolator currentScalarInterpolator					= null;
	Sensor sensorRoot														= null;
	Sensor sensorLink														= null;
	SpotLight currentSpotLight											= null;
	TextureTransform currentTextureTransform						= null;
	TimeSensor currentTimeSensor										= null;
	TouchSensor currentTouchSensor									= null;
	Viewpoint viewpointLink												= null;
	Viewpoint viewpointRoot												= null;
	Viewpoint currentViewpoint											= null;
	WorldInfo worldInfo													= null;

	SFNode DEFnameNode						= null; // for a linked list of named nodes for USE/DEF nodes
	SFNode currentDEFnameNode				= null; // for a linked list of named nodes for USE/DEF nodes
	
	int state = VRMLdatatype.SFNode;
	Applet localApplet = null; // passed to ImageTexture
	Parser parser = null;
	Stack stateStack = null;
	Shape shapeLink = null;

	StreamTokenizer st = null;
	int tokenType;
	String token = null;

	String textureMapFolder = null;
	String imageTextureDEFName = null; // a bit of a cludge but had to split up creation of ImageTexture node and keep name around
	final int floatFileLimit = 15000; // taken from VRML 2.0 Reference Manual book, pg 365, MColor value
	final int intFileLimit = 20000; // from MFInt32 file limit, pg 365 above too
	float[] tempFloatBuffer = new float[floatFileLimit*3];
	int[] tempIntBuffer = new int[intFileLimit];
	int tempBufferIndex = 0;

	/* following are for the debug version */
	/*
	final String indentAmt = "   ";
	String indent = "";
	final int maxValsPerLine = 4;
	int valsPerLine = 0; // for list of Coordinate values so line isn't too long
	private void FormatError(String errorMssg) {
		System.out.println("Format Error: " + errorMssg);
	}
	private void Write(char ch) {
		System.out.print(ch);
	}
	private void Write(String string) {
		System.out.print(string);
	}
	private void WriteLine() {
		System.out.println();
	}
	private void WriteLine(char ch) {
		Write(ch);
		WriteLine();
	}
	private void WriteLine(String string) {
		Write(string);
		WriteLine();
	}
	*/
	/* end section for debug version */

	public int GetToken() {
		try {
			tokenType = st.nextToken();
		}
		catch (Exception e) {
			//FormatError(e.toString());
		}
		return tokenType;
	}


	private void PushStack(int stateValue) {
		Integer stateInteger = new Integer(stateValue);
		stateStack.push( stateInteger );
	}

	private int PopStack() {
		Integer stateInteger = new Integer(stateStack.pop().toString());
		return stateInteger.intValue();
	}



	public Route VerifyRoute () {
		Route newRoute = new Route();
		String objName, propertyName;
		SFNode matchRoot = null;
		boolean propertyFound;

		//Write(indent + VRMLdatatype.string_ROUTE + " ");
		// Get the 'fromObject.property' values
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			objName = token.substring(0, token.indexOf('.') );
			matchRoot = newRoute.MatchRouteObjectName(objName);
			if (matchRoot != null) {
				newRoute.fromObject = matchRoot;
				RouteProperties fromProperties = new RouteProperties();
				newRoute.from = fromProperties;

				propertyName = token.substring((token.indexOf('.') + 1), token.length() );
				propertyFound = newRoute.MatchRoutePropertyName (matchRoot, propertyName, newRoute.from);
			}
			//else FormatError("'" + objName + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE);
		}
		//else FormatError("Missing word in " + VRMLdatatype.string_ROUTE);

		// Get the 'TO' in the ROUTE
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			//if (token.equals(VRMLdatatype.string_TO) ) {
			//	Write(token + " ");
			//}
			//else FormatError("Missing '" + VRMLdatatype.string_TO + "' in " + VRMLdatatype.string_ROUTE);
		}
		//else FormatError("Missing '" + VRMLdatatype.string_TO + "'in " + VRMLdatatype.string_ROUTE);

		// Get the 'toObject.property' values
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			objName = token.substring(0, token.indexOf('.') );
			matchRoot = newRoute.MatchRouteObjectName(objName);
			if (matchRoot != null) {
				newRoute.toObject = matchRoot;
				RouteProperties toProperties = new RouteProperties();
				newRoute.to = toProperties;
				propertyName = token.substring((token.indexOf('.') + 1), token.length() );
				propertyFound = newRoute.MatchRoutePropertyName (matchRoot, propertyName, newRoute.to);
			}
			//else FormatError("'" + objName + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE);
		}
		//else FormatError("Missing word in " + VRMLdatatype.string_ROUTE);
		//WriteLine();
		return newRoute;
	} // end VerifyRoute


	public void CreateRoute () {
		Route newRoute = VerifyRoute();
		if (newRoute != null) {
			// Add to the link list
			routeLast.nextRoute = newRoute;
			routeLast = newRoute;
		}
	} // end CreateRoute

	private boolean CheckBoolean() {
		boolean returnBool = true; 
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String booleanValue = st.sval;
			if ( booleanValue.equals(VRMLdatatype.string_TRUE) ) 
				returnBool = true;
			else if ( booleanValue.equals(VRMLdatatype.string_FALSE) ) 
				returnBool = false;
			//else FormatError("Missing " +  VRMLdatatype.string_TRUE + " or " + VRMLdatatype.string_FALSE + " value ");
		}
		//else FormatError("Missing " +  VRMLdatatype.string_TRUE + " or " + VRMLdatatype.string_FALSE + " value ");
		//WriteLine(" " + returnBool);
		return returnBool; 
	}

	
	private boolean CheckChar(char validateChar) {
		boolean charCk = false;
		tokenType = GetToken();
		char ch = (char) tokenType;
		if (ch == validateChar) charCk = true;
		//Write(ch);
		return charCk;
	}


	private byte[] ParseByteString(String byteString, int bytesPerString) {
		byte[] returnByte = new byte[bytesPerString];
		//Write( byteString ); // intValue0 should be "0"
		byteString = byteString.toLowerCase();

		byte[] byteArray = byteString.getBytes();
		// first char is an "x"
		for (int byteNum = 0; byteNum < bytesPerString; byteNum++) {
			int byteValue = 0;
			for (int i = 0; i < 2; i++) {
				Byte aByte = new Byte(byteArray[(byteNum*2) + i + 1]); // first byte is "x"
				int intVal = aByte.intValue();
				if ( intVal <= 57 ) intVal -= 48; // numbers 0 thru 9
				else if (intVal >= 97) intVal -= 87; // letters a thru f
				byteValue = (byteValue << 4) + intVal;
			}
			returnByte[byteNum] = (byte) byteValue;
		}
		return returnByte;
	}

	private byte[] GetByte(int bytesPerString) {
	//private void GetByte() {
		byte[] returnByte = new byte[bytesPerString];
		tokenType = GetToken();
		// handle "0x00, oxFF ..." or "0 255 ..."
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			// either decimal number or Hex number beginning with "0"
			int intValue0 = (int) st.nval;
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_NUMBER) {
				// decimal value, gray 0 - 255, not hex value
				//Write( " " + intValue0 );
				st.pushBack(); 
				returnByte[0] = (byte) intValue0;
			}
			else { // hex begin with 0, either 0xHexHex for gray, 0xRGB (3 values) or 0xRGBA (4 values
				//Write(" " + intValue0 ); // intValue0 should be "0"
				returnByte = ParseByteString(st.sval, bytesPerString);
			}
		}
		else { // Hex number beginning with x
			//Write(" ");
			returnByte = ParseByteString(st.sval, bytesPerString);
		}
		return returnByte;
	} // end GetByte


	private int GetIntegerNumber() {
		int returnNumber = (int) st.nval;
		//Write(" " + returnNumber);
		return returnNumber;
	} // end GetIntegerNumber


	private float GetFloatNumber() {
		// Gets a number and checks for exponential data.
		float returnNumber = (float) st.nval;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String str = st.sval;
  			if (str.length() == 1) {
				if (str.equals("e")) {
					// positive exponential value
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_NUMBER) {
						int exp = (int) st.nval;
						returnNumber *= Math.pow(10, exp);
					}
					else st.pushBack(); // no exponential value, push value back on stack
				}
				else st.pushBack(); // no exponential value, push value back on stack
			}
			else if (str.substring(0,2).equals("e-")) {
				// have an large negative exponential value, set value to 0
				returnNumber = 0;
			}
			/*
			else if (str.substring(0,2).equals("e+")) {
				// have an large positive exponential value, set value to 0
				System.out.println();
				System.out.println(" the current value is : " + st.sval + ", str = " + str);
				System.out.println();
				
				returnNumber = 0;
			}
			*/
			else st.pushBack(); // no exponential value, push value back on stack
		}
		else st.pushBack();
		//Write(" " + returnNumber);
		return returnNumber;
	} // end GetFloatNumber


	private float[] GetFloatValues(int quantity) {
		float[] returnFloat = new float[quantity];
		for (int i = 0; i < returnFloat.length; i++) {
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_NUMBER) {
				returnFloat[i] = GetFloatNumber();
			}
			//else FormatError("Missing numeric values");
		}
		return returnFloat;
	} // end GetFloatValues


	private float GetSingleFloat() {
		float returnFloat = 0;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			returnFloat = GetFloatNumber();
		}
		//else FormatError("Missing numeric values");
		return returnFloat;
	} // end GetSingleFloat


	private long GetTimeValue() {
		long returnTime = 0; // long value for time
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			returnTime = (long) st.nval;
			//Write(" " + returnTime);
		}
		//else FormatError("Missing time value");
		return returnTime;
	} // end GetTimeValue


	public void AddChild (SFNode parentNode, SFNode childNode) {
		childNode.prev = parentNode.childLast;
		childNode.parent = parentNode;
		if (parentNode.childLast != null ) parentNode.childLast.next = childNode;
		if (parentNode.children == null ) parentNode.children = childNode;
		parentNode.childLast = childNode;
	} // end AddChild


	private String GetNodeName () {
		String nodeName = null;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			nodeName = st.sval;
			//Write(indent + VRMLdatatype.string_DEF + " " + nodeName + " ");
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
			}
			//else FormatError("Name not following " + VRMLdatatype.string_DEF);
		}
		//else FormatError("Name '" + token + "' following " + VRMLdatatype.string_DEF + " improper");
		return nodeName;
	} // end GetNodeName


	private void SetNodeName (SFNode node, String name) {
		node.setName(name);
		// Add the node to the linked list
		if (name != null) {
			SFNode newNameNode = new SFNode();
			newNameNode.setName(name);
			newNameNode.children = node;
			currentDEFnameNode.next = newNameNode;
			currentDEFnameNode = newNameNode;
		}
	} // end SetNodeName


	private void GotUSEtoken () {
		SFNode foundNode = null;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String useName = st.sval;
			//WriteLine(" " + VRMLdatatype.string_USE + " " + useName + " ");

			SFNode checkNode = DEFnameNode.next;
			while ( checkNode != null ) {
				if ( useName.equals(checkNode.children.name) ) {
					foundNode = checkNode.children;
					switch (state) {
						case VRMLdatatype.Shape:
							if ( (foundNode.datatype == VRMLdatatype.IndexedFaceSet) ||
									(foundNode.datatype == VRMLdatatype.IndexedLineSet) || (foundNode.datatype == VRMLdatatype.PointSet)) {
								//currentShape.geometry = (IndexedSet)foundNode;
								currentShape.geometry = foundNode;
							}
							/*
							if (foundNode.datatype == VRMLdatatype.IndexedFaceSet) {
								//currentShape.indexedFaceSet = (IndexedFaceSet)foundNode;
								currentShape.geometry = (IndexedSet)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.IndexedLineSet) {
								//currentShape.indexedLineSet = (IndexedLineSet)foundNode;
								currentShape.geometry = (IndexedSet)foundNode;
							}
							*/
							else if (foundNode.datatype == VRMLdatatype.Appearance) {
								currentShape.appearance = (Appearance)foundNode;
							}
							//else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_Shape);
						break; // end case Shape
						case VRMLdatatype.Appearance:
							if (foundNode.datatype == VRMLdatatype.Material) {
								currentAppearance.material = (Material)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.TextureTransform ) {
								currentAppearance.textureTransform = (TextureTransform)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.ImageTexture ) {
								currentAppearance.texture = (ImageTexture)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.PixelTexture ) {
								currentAppearance.texture = (PixelTexture)foundNode;
							}
							//else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_Appearance);
						break; // end case Appearance
						case VRMLdatatype.IndexedFaceSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentIndexedFaceSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentIndexedFaceSet.coord = (Coordinate)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.TextureCoordinate) {
								currentIndexedFaceSet.texCoord = (TextureCoordinate)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Normal) {
								currentIndexedFaceSet.normal = (Normal)foundNode;
							}
							//else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_IndexedFaceSet);
						break; // end case IndexedFaceSet
						case VRMLdatatype.IndexedLineSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentIndexedLineSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentIndexedLineSet.coord = (Coordinate)foundNode;
							}
							//else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_IndexedLineSet);
						break; // end case IndexedLineSet
						case VRMLdatatype.PointSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentPointSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentPointSet.coord = (Coordinate)foundNode;
							}
							//else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_PointSet);
						break; // end case IndexedLineSet
						default:
							//FormatError("No '" + VRMLdatatype.string_DEF + " " + useName + "' matching '" + VRMLdatatype.string_USE + " " + useName+ "'");
						break; // end default
					} // end switch on state
					checkNode = null; // gets me out of the loop
				}
				else {
					checkNode = checkNode.next;
					//if (checkNode == null) FormatError("No '" + VRMLdatatype.string_DEF + " " + useName + "' matching '" + VRMLdatatype.string_USE + " " + useName+ "'");
				}
			}
		}
		//else FormatError("'" + token + "' following " + VRMLdatatype.string_USE + " not a word");
	} // end GotUSEtoken



	private int NodeParser(Parser parser) {
		tokenType = GetToken();
		String nodeName = null;
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			nodeName = null;

			if (token.equals(VRMLdatatype.string_DEF) ) {
				nodeName = GetNodeName();
			}

			switch (state) {

				/********* Node, children *********/
				case VRMLdatatype.SFNode:
				case VRMLdatatype.children:
					if ( token.equals(VRMLdatatype.string_Transform) ) { 
						//if (nodeName == null) {
						//	Write(indent);
						//}
						//Write(VRMLdatatype.string_Transform + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Transform;
							currentTransform = new Transform();
							SetNodeName (currentTransform, nodeName);
							AddChild (currentNode, currentTransform);
							currentNode = currentTransform;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Transform);
					} // else if token = Transform

					else if ( token.equals(VRMLdatatype.string_Shape) ) { 
						//if (nodeName == null) {
						//	Write(indent);
						//}
						//Write(VRMLdatatype.string_Shape); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Shape;
							currentShape = new Shape();
							SetNodeName (currentShape, nodeName);
							AddChild (currentNode, currentShape);  // Node in case Shape is alone or attached to Transform, Group, Billboard, etc.
							shapeLink.nextShape = currentShape; // used to quickly find shapes in the mouse rollovers, interactivity.
							shapeLink = currentShape;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Shape);
					} // else if token = Shape

					else if ( token.equals(VRMLdatatype.string_Viewpoint) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_Viewpoint + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Viewpoint;
							currentViewpoint = new Viewpoint();
							SetNodeName (currentViewpoint, nodeName);
							AddChild (currentNode, currentViewpoint);
							viewpointLink.nextViewpoint = currentViewpoint;
							viewpointLink = currentViewpoint;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Viewpoint);
					} // else if token = Viewpoint

					else if ( token.equals(VRMLdatatype.string_DirectionalLight) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_DirectionalLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.DirectionalLight;
							currentDirectionalLight = new DirectionalLight();
							SetNodeName (currentDirectionalLight, nodeName);
							AddChild (currentNode, currentDirectionalLight);
							currentLight.nextLight = currentDirectionalLight;
							currentLight = currentDirectionalLight;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_DirectionalLight);
					} // else if token = DirectionalLight

					else if ( token.equals(VRMLdatatype.string_PointLight) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_PointLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.PointLight;
							currentPointLight = new PointLight();
							SetNodeName (currentPointLight, nodeName);
							AddChild (currentNode, currentPointLight);
							currentLight.nextLight = currentPointLight;
							currentLight = currentPointLight;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PointLight);
					} // else if token = PointLight

					else if ( token.equals(VRMLdatatype.string_SpotLight) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_SpotLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.SpotLight;
							currentSpotLight = new SpotLight();
							SetNodeName (currentSpotLight, nodeName);
							AddChild (currentNode, currentSpotLight);
							currentLight.nextLight = currentSpotLight;
							currentLight = currentSpotLight;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_SpotLight);
					} // else if token = SpotLight

					else if ( token.equals(VRMLdatatype.string_TimeSensor) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_TimeSensor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.TimeSensor;
							currentTimeSensor = new TimeSensor();
							SetNodeName (currentTimeSensor, nodeName);
							sensorLink.next = currentTimeSensor;
							currentTimeSensor.prev = sensorLink; 
							sensorLink = currentTimeSensor;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TimeSensor);
					} // else if token = TimeSensor

					else if ( token.equals(VRMLdatatype.string_OrientationInterpolator) ) { 
						//Write(VRMLdatatype.string_OrientationInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.OrientationInterpolator;
							currentOrientationInterpolator = new OrientationInterpolator();
							SetNodeName(currentOrientationInterpolator, nodeName);
							interpolatorLink.next = currentOrientationInterpolator;
							currentOrientationInterpolator.prev = interpolatorLink;
							interpolatorLink = currentOrientationInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_OrientationInterpolator);
					} // else if token = OrientationInterpolator

					else if ( token.equals(VRMLdatatype.string_PositionInterpolator) ) { 
						//Write(VRMLdatatype.string_PositionInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.PositionInterpolator;
							currentPositionInterpolator = new PositionInterpolator();
							SetNodeName(currentPositionInterpolator, nodeName);
							interpolatorLink.next = currentPositionInterpolator;
							currentPositionInterpolator.prev = interpolatorLink;
							interpolatorLink = currentPositionInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PositionInterpolator);
					} // else if token = PositionInterpolator

					else if ( token.equals(VRMLdatatype.string_CoordinateInterpolator) ) { 
						//Write(VRMLdatatype.string_CoordinateInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.CoordinateInterpolator;
							currentCoordinateInterpolator = new CoordinateInterpolator();
							SetNodeName(currentCoordinateInterpolator, nodeName);
							interpolatorLink.next = currentCoordinateInterpolator;
							currentCoordinateInterpolator.prev = interpolatorLink;
							interpolatorLink = currentCoordinateInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_CoordinateInterpolator);
					} // else if token = CoordinateInterpolator

					else if ( token.equals(VRMLdatatype.string_ColorInterpolator) ) { 
						//Write(VRMLdatatype.string_ColorInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.ColorInterpolator;
							currentColorInterpolator = new ColorInterpolator();
							SetNodeName(currentColorInterpolator, nodeName);
							interpolatorLink.next = currentColorInterpolator;
							currentColorInterpolator.prev = interpolatorLink;
							interpolatorLink = currentColorInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ColorInterpolator);
					} // else if token = ColorInterpolator

					else if ( token.equals(VRMLdatatype.string_ScalarInterpolator) ) { 
						//Write(VRMLdatatype.string_ScalarInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.ScalarInterpolator;
							currentScalarInterpolator = new ScalarInterpolator();
							SetNodeName(currentScalarInterpolator, nodeName);
							interpolatorLink.next = currentScalarInterpolator;
							currentScalarInterpolator.prev = interpolatorLink;
							interpolatorLink = currentScalarInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ScalarInterpolator);
					} // else if token = ScalarInterpolator

					else if ( token.equals(VRMLdatatype.string_NormalInterpolator) ) { 
						//Write(VRMLdatatype.string_NormalInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.NormalInterpolator;
							currentNormalInterpolator = new NormalInterpolator();
							SetNodeName(currentNormalInterpolator, nodeName);
							interpolatorLink.next = currentNormalInterpolator;
							currentNormalInterpolator.prev = interpolatorLink;
							interpolatorLink = currentNormalInterpolator;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_NormalInterpolator);
					} // else if token = NormalInterpolator


					else if ( token.equals(VRMLdatatype.string_ROUTE) ) { 
						CreateRoute();
					} // else if token = ROUTE

					else if ( token.equals(VRMLdatatype.string_TouchSensor) ) { 
						//if (nodeName == null) Write(indent);
						//Write (VRMLdatatype.string_TouchSensor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.TouchSensor;
							currentTouchSensor = new TouchSensor();
							SetNodeName(currentTouchSensor, nodeName);
							sensorLink.next = currentTouchSensor;
							currentTouchSensor.prev = sensorLink; 
							sensorLink = currentTouchSensor;
							currentNode.touchSensor = currentTouchSensor;
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TouchSensor);
					} // else if token = TouchSensor

					else if ( token.equals(VRMLdatatype.string_Anchor) ) { 
						//Write(VRMLdatatype.string_Anchor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Anchor;
							currentAnchor = new Anchor();
							SetNodeName(currentAnchor, nodeName);
							currentAnchor.matrix4x4.setIdentityMatrix(); //set just as a precaution
							AddChild (currentNode, currentAnchor);
							currentNode = currentAnchor;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Anchor);
					} // else if token = Anchor

					else if ( token.equals(VRMLdatatype.string_Billboard) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_Billboard + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Billboard;
							currentBillboard = new Billboard();
							//currentBillboard.matrix4x4.setIdentityMatrix();  // set in FrameGen
							SetNodeName(currentBillboard, nodeName);
							AddChild (currentNode, currentBillboard);
							currentNode = currentBillboard;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Billboard);
					} // else if token = Billboard

					else if ( token.equals(VRMLdatatype.string_Group) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_Group + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Group;
							currentGroup = new Group();
							currentGroup.matrix4x4.setIdentityMatrix(); //set here as a pre-caution
							SetNodeName(currentGroup, nodeName);
							AddChild (currentNode, currentGroup);
							currentNode = currentGroup;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Group);
					} // else if token = Group

					else if ( token.equals(VRMLdatatype.string_Background) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_Background + " "); indent += indentAmt;
						background.created  = true; // override applet parameters values, use NavInfo values
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Background;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Background);
					} // else if token = Background

					else if ( token.equals(VRMLdatatype.string_NavigationInfo) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_NavigationInfo + " "); indent += indentAmt;
						navigationInfo.created  = true; // override applet parameters values, use NavInfo values
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.NavigationInfo;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_NavigationInfo);
					} // else if token = NavigationInfo

					else if ( token.equals(VRMLdatatype.string_WorldInfo) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_WorldInfo + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.WorldInfo;
							worldInfo = new WorldInfo();
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_WorldInfo);
					} // else if token = WorldInfo

					else if ( token.equals(VRMLdatatype.string_Fog) ) { 
						//if (nodeName == null) Write(indent);
						//Write(VRMLdatatype.string_Fog + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							//Write(indent + "; not currently supported ");
							PushStack( state );
							state = VRMLdatatype.Fog;
							currentFog = new Fog();
							//SetNodeName(currentFog, nodeName);
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Fog);
					} // else if token = Fog

					//else FormatError("node: '" + token + "' misplaced, not currently implemented or illegal.");
				break; // end case Node or children



				/********* TimeSensor *********/
				case VRMLdatatype.TimeSensor:
					if ( token.equals(VRMLdatatype.string_cycleInterval) ) { 
						//Write(indent + VRMLdatatype.string_cycleInterval);
						currentTimeSensor.cycleInterval.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_loop) ) { 
						//Write(indent + VRMLdatatype.string_loop);
						currentTimeSensor.loop.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_enabled) ) { 
						//Write(indent + VRMLdatatype.string_enabled);
						currentTimeSensor.enabled.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_startTime) ) { 
						//Write(indent + VRMLdatatype.string_startTime);
						currentTimeSensor.startTime.setValue( GetTimeValue() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_stopTime) ) { 
						//Write(indent + VRMLdatatype.string_stopTime);
						currentTimeSensor.stopTime.setValue( GetTimeValue() );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TimeSensor);
				break; // end case TimeSensor


				/********* TouchSensor *********/
				case VRMLdatatype.TouchSensor:
					if ( token.equals(VRMLdatatype.string_enabled) ) { 
						//Write(indent + VRMLdatatype.string_enabled);
						currentTouchSensor.enabled.setValue( CheckBoolean() );
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TouchSensor);
				break; // end case TouchSensor


				/********* Viewpoint *********/
				case VRMLdatatype.Viewpoint:
					if ( token.equals(VRMLdatatype.string_position) ) { 
						//Write(indent + VRMLdatatype.string_position);
						currentViewpoint.position.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_orientation) ) { 
						//Write(indent + VRMLdatatype.string_orientation);
						currentViewpoint.orientation.setValue( GetFloatValues(4) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_fieldOfView) ) { 
						//Write(indent + VRMLdatatype.string_fieldOfView);
						currentViewpoint.setFieldOfView( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_jump) ) { 
						//Write(indent + VRMLdatatype.string_jump);
						currentViewpoint.jump.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_description) ) { 
						//Write(indent + VRMLdatatype.string_description + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							token = st.sval;
							currentViewpoint.description.setValue( token );
							//WriteLine(doubleQuoteChar + token + doubleQuoteChar);
						}
						//else FormatError(" in " + VRMLdatatype.string_Viewpoint + " " + VRMLdatatype.string_description + " node");
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Viewpoint);
				break; // end case Viewpoint


				/********* DirectionalLight *********/
				case VRMLdatatype.DirectionalLight:
					if ( token.equals(VRMLdatatype.string_direction) ) { 
						//Write(indent + VRMLdatatype.string_direction);
						currentDirectionalLight.direction.setValue( GetFloatValues(3) );
						currentDirectionalLight.directionNormalized = MathOps.NormalizeVector( currentDirectionalLight.direction.getValue() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color);
						currentDirectionalLight.color.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) { 
						//Write(indent + VRMLdatatype.string_intensity);
						currentDirectionalLight.intensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) { 
						//Write(indent + VRMLdatatype.string_ambientIntensity);
						currentDirectionalLight.ambientIntensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) { 
						//Write(indent + VRMLdatatype.string_on);
						currentDirectionalLight.on.setValue( CheckBoolean() );
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_DirectionalLight);
				break; // end case DirectionalLight



				/********* PointLight *********/
				case VRMLdatatype.PointLight:
					if ( token.equals(VRMLdatatype.string_location) ) { 
						//Write(indent + VRMLdatatype.string_location);
						currentPointLight.location.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_attenuation) ) { 
						//Write(indent + VRMLdatatype.string_attenuation);
						currentPointLight.attenuation.setValue( GetFloatValues(3) );
						if (
							(currentPointLight.attenuation.vec3s[0] == 0) &&
							(currentPointLight.attenuation.vec3s[1] == 0) &&
							(currentPointLight.attenuation.vec3s[2] == 0) )
								currentPointLight.attenuation.vec3s[0] = 1; // VRML rule
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color);
						currentPointLight.color.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) { 
						//Write(indent + VRMLdatatype.string_intensity);
						currentPointLight.intensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) { 
						//Write(indent + VRMLdatatype.string_ambientIntensity);
						currentPointLight.ambientIntensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) { 
						//Write(indent + VRMLdatatype.string_on);
						currentPointLight.on.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_radius) ) { 
						//Write(indent + VRMLdatatype.string_radius);
						currentPointLight.radius.setValue( GetSingleFloat() );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PointLight);
				break; // end case PointLight



				/********* SpotLight *********/
				case VRMLdatatype.SpotLight:
					if ( token.equals(VRMLdatatype.string_location) ) { 
						//Write(indent + VRMLdatatype.string_location);
						currentSpotLight.location.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_direction) ) { 
						//Write(indent + VRMLdatatype.string_direction);
						currentSpotLight.direction.setValue( GetFloatValues(3) );
						currentSpotLight.directionNormalized = MathOps.NormalizeVector( currentSpotLight.direction.getValue() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_attenuation) ) { 
						//Write(indent + VRMLdatatype.string_attenuation);
						currentSpotLight.attenuation.setValue( GetFloatValues(3) );
						if (
							(currentSpotLight.attenuation.vec3s[0] == 0) &&
							(currentSpotLight.attenuation.vec3s[1] == 0) &&
							(currentSpotLight.attenuation.vec3s[2] == 0) )
								currentSpotLight.attenuation.vec3s[0] = 1; // VRML rule
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color);
						currentSpotLight.color.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) { 
						//Write(indent + VRMLdatatype.string_intensity);
						currentSpotLight.intensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) { 
						//Write(indent + VRMLdatatype.string_ambientIntensity);
						currentSpotLight.ambientIntensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) { 
						//Write(indent + VRMLdatatype.string_on);
						currentSpotLight.on.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_radius) ) { 
						//Write(indent + VRMLdatatype.string_radius);
						currentSpotLight.radius.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_beamWidth) ) { 
						//Write(indent + VRMLdatatype.string_beamWidth);
						currentSpotLight.beamWidth.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_cutOffAngle) ) { 
						//Write(indent + VRMLdatatype.string_cutOffAngle);
						currentSpotLight.cutOffAngle.setValue( GetSingleFloat() );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_SpotLight);
				break; // end case SpotLight



				/********* Transform *********/
				case VRMLdatatype.Transform:
					if ( token.equals(VRMLdatatype.string_children) ) { 
						//Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Transform);
					}
					else if ( token.equals(VRMLdatatype.string_translation) ) { 
						//Write(indent + VRMLdatatype.string_translation);
						currentTransform.translation.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_rotation) ) { 
						//Write(indent + VRMLdatatype.string_rotation);
						currentTransform.rotation.setValue( GetFloatValues(4) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_center) ) { 
						//Write(indent + VRMLdatatype.string_center);
						currentTransform.center.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scale) ) { 
						//Write(indent + VRMLdatatype.string_scale);
						currentTransform.scale.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scaleOrientation) ) { 
						//Write(indent + VRMLdatatype.string_scaleOrientation);
						currentTransform.scaleOrientation.setValue( GetFloatValues(4) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) { 
						//Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentTransform.bboxCenter.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) { 
						//Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentTransform.bboxSize.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ROUTE) ) { 
						CreateRoute();
					} // else if token = ROUTE
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Transform);
				break; // end case Transform



				/********* Shape *********/
				case VRMLdatatype.Shape:
					if ( token.equals(VRMLdatatype.string_appearance) ) { 
						//Write(indent + VRMLdatatype.string_appearance  + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Appearance) ) { 
									//Write(VRMLdatatype.string_Appearance  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Appearance;
										currentAppearance	= new Appearance();
										SetNodeName(currentAppearance, nodeName);
										currentShape.appearance = currentAppearance;
										//WriteLine();
									}												   
									//else FormatError("Missing '{' following " + VRMLdatatype.string_Appearance);
								} // end if token == Appearance
								//else FormatError("Missing '" + VRMLdatatype.string_Appearance + "' following " + VRMLdatatype.string_appearance);
							} // end if token != USE
						} // end if token == word
						//else FormatError("Missing word token following " + VRMLdatatype.string_appearance);
					} // end Shape.appearance

					else if ( token.equals(VRMLdatatype.string_geometry) ) { 
						//Write(indent + VRMLdatatype.string_geometry   + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								//Write( token + " ");
								if ( token.equals(VRMLdatatype.string_IndexedFaceSet) ) { 
									if ( CheckChar(leftBraceChar) ) {
										//indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.IndexedFaceSet;
										currentIndexedFaceSet = new IndexedFaceSet();
										if ( appletParameters.creaseAngleDefault ) {
											currentIndexedFaceSet.creaseAngle.setValue( appletParameters.creaseAngle );
										}
										SetNodeName(currentIndexedFaceSet, nodeName);
										//currentShape.indexedFaceSet = currentIndexedFaceSet;
										currentShape.geometry = currentIndexedFaceSet;
										//currentIndexedFaceSet.normal = new Normal(); // done here cause some IFS have a normal and others may not
										//Normal normal = (Normal) currentIndexedFaceSet.normal;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_IndexedFaceSet);
								} // end geometry.IndexedFaceSet

								else if ( token.equals(VRMLdatatype.string_IndexedLineSet) ) { 
									if ( CheckChar(leftBraceChar) ) {
										//indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.IndexedLineSet;
										currentIndexedLineSet	= new IndexedLineSet();
										SetNodeName(currentIndexedLineSet, nodeName);
										currentShape.geometry = currentIndexedLineSet;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_IndexedLineSet);
								} // end geometry.IndexedLineSet

								else if ( token.equals(VRMLdatatype.string_PointSet) ) { 
									if ( CheckChar(leftBraceChar) ) {
										//indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.PointSet;
										currentPointSet	= new PointSet();
										SetNodeName(currentPointSet, nodeName);
										currentShape.geometry = currentPointSet;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PointSet);
								} // end geometry.PointSet
								else if ( token.equals(VRMLdatatype.string_Box) ) { 
									float[] size = Box.size;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_size) ) { size = GetFloatValues(Box.size.length); }
												//else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Box);
												tokenType = GetToken();
											}
											//else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Box);
										} while (tokenType != rightBraceChar);
										//WriteLine(rightBraceChar);
										Box box	= new Box(size);
										SetNodeName(box, nodeName);
										currentShape.geometry = box;
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Box);
								} // end Box

								else if ( token.equals(VRMLdatatype.string_Cone) ) { 
									boolean bottom = Cone.bottom;
									float bottomRadius = Cone.bottomRadius;
									float height = Cone.height;
									boolean side   = Cone.side;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_bottom) ) { bottom = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_bottomRadius) ) { bottomRadius = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_height) ) { height = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_side) ) { side = CheckBoolean(); }
												//else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cone);
												tokenType = GetToken();
											}
											//else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Cone);
										} while (tokenType != rightBraceChar);
										//WriteLine(rightBraceChar);
										Cone cone = new Cone(bottom, bottomRadius, height, side);
										SetNodeName(cone, nodeName);
										currentShape.geometry = cone;
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Cone);
								} // end Cone

								else if ( token.equals(VRMLdatatype.string_Cylinder) ) { 
									boolean bottom = Cylinder.bottom;
									float height = Cylinder.height;
									float radius = Cylinder.radius;
									boolean side   = Cylinder.side;
									boolean top   = Cylinder.top;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_bottom) ) { bottom = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_height) ) { height = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_radius) ) { radius = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_side) ) { side = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_top) ) { top = CheckBoolean(); }
												//else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cylinder);
												tokenType = GetToken();
											}
											//else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Cylinder);
										} while (tokenType != rightBraceChar);
										//WriteLine(rightBraceChar);
										Cylinder cylinder	= new Cylinder(bottom, height, radius, side, top);
										SetNodeName(cylinder, nodeName);
										currentShape.geometry = cylinder;
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Cylinder);
								} // end Cylinder

								else if ( token.equals(VRMLdatatype.string_Sphere) ) { 
									float radius = Sphere.radius;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_radius) ) { radius = GetSingleFloat(); }
												//else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Sphere);
												tokenType = GetToken();
											}
											//else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Sphere);
										} while (tokenType != rightBraceChar);
										//WriteLine(rightBraceChar);
										Sphere sphere	= new Sphere(radius);
										SetNodeName(sphere, nodeName);
										currentShape.geometry = sphere;
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Sphere);
								} // end geometry.Sphere
								//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_geometry);
							} // end word != USE
						} // end if word token follows geometry
						//else FormatError("word must follow " + VRMLdatatype.string_geometry);
					} // end Shape.geometry
				break; // end case Shape



				/********* Appearance *********/
				case VRMLdatatype.Appearance:
					if ( token.equals(VRMLdatatype.string_material) ) { 
						//Write( indent + VRMLdatatype.string_material  + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Material) ) { 
									//Write(VRMLdatatype.string_Material  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Material;
										currentMaterial = new Material();
										SetNodeName(currentMaterial, nodeName);
										currentAppearance.material = currentMaterial;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Material);
								} // end if token == material
								//else FormatError("Missing '" + VRMLdatatype.string_Material + "' following " + VRMLdatatype.string_material);
							} // end token != USE
						} // end if token == word
						//else FormatError("Missing word token following " + VRMLdatatype.string_material);
					} // end if Appearance.material
					else if ( token.equals(VRMLdatatype.string_texture) ) { 
						//Write(indent + VRMLdatatype.string_texture + " " );
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								imageTextureDEFName = null; // save this name when I actually load the ImageName
								if (token.equals(VRMLdatatype.string_DEF) ) {
									//nodeName = GetNodeName();
									imageTextureDEFName = GetNodeName();
								}
								if ( token.equals(VRMLdatatype.string_ImageTexture) ) { 
									//Write(VRMLdatatype.string_ImageTexture  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.ImageTexture;
										//currentImageTexture	= new ImageTexture(localApplet);
										//SetNodeName(currentImageTexture, nodeName);
										//currentAppearance.texture = currentImageTexture;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ImageTexture);
								}
								else if ( token.equals(VRMLdatatype.string_PixelTexture) ) { 
									//Write(VRMLdatatype.string_PixelTexture  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.PixelTexture;
										currentPixelTexture	= new PixelTexture();
										SetNodeName(currentPixelTexture, nodeName);
										currentAppearance.texture = currentPixelTexture;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PixelTexture);
								}
								//else FormatError("Missing texture type following " + VRMLdatatype.string_texture);
							} // end token != USE
						}  // end if token == word
						//else FormatError("Missing word token following " + VRMLdatatype.string_texture);
					} // end Appearance.texture
					else if ( token.equals(VRMLdatatype.string_textureTransform) ) { 
						//Write(indent + VRMLdatatype.string_textureTransform + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_TextureTransform) ) { 
									//Write(VRMLdatatype.string_TextureTransform  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.TextureTransform;
										currentTextureTransform	= new TextureTransform();
										SetNodeName(currentTextureTransform, nodeName);
										currentAppearance.textureTransform = currentTextureTransform;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TextureTransform);
								} // end if token == material
								//else FormatError("Missing '" + VRMLdatatype.string_Material + "' following " + VRMLdatatype.string_textureTransform);
							} // end token != USE
						} // end if token == word
						//else FormatError("Missing word token following " + VRMLdatatype.string_textureTransform);
					} //end Appearance.textureTransform
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Appearance);
				break; // end case Appearance



				/********* Material *********/
				case VRMLdatatype.Material:
					if ( token.equals(VRMLdatatype.string_diffuseColor) ) { 
						//Write(indent + VRMLdatatype.string_diffuseColor + " ");
						currentMaterial.diffuseColor.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_emissiveColor) ) { 
						//Write(indent + VRMLdatatype.string_emissiveColor );
						currentMaterial.emissiveColor.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_specularColor) ) { 
						//Write(indent + VRMLdatatype.string_specularColor );
						currentMaterial.specularColor.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_transparency) ) { 
						//Write(indent + VRMLdatatype.string_transparency );
						currentMaterial.transparency.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) { 
						//Write(indent + VRMLdatatype.string_ambientIntensity );
						currentMaterial.ambientIntensity.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_shininess) ) { 
						//Write(indent + VRMLdatatype.string_shininess );
						currentMaterial.shininess.setValue( GetSingleFloat() );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Material);
				break; // end case Material



				/********* TextureTransform *********/
				case VRMLdatatype.TextureTransform:
					if ( token.equals(VRMLdatatype.string_center) ) { 
						//Write(indent + VRMLdatatype.string_center);
						currentTextureTransform.center.setValue( GetFloatValues(2) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_rotation) ) { 
						//Write(indent + VRMLdatatype.string_rotation);
						currentTextureTransform.rotation.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scale) ) { 
						//Write(indent + VRMLdatatype.string_scale);
						currentTextureTransform.scale.setValue( GetFloatValues(2) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_translation) ) { 
						//Write(indent + VRMLdatatype.string_translation);
						currentTextureTransform.translation.setValue( GetFloatValues(2) );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TextureTransform);
				break; // end case TextureTransform



				/********* IndexedLineSet *********/
				case VRMLdatatype.IndexedLineSet:
					if ( token.equals(VRMLdatatype.string_coord) ) { 
						//Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) { 
									//Write(VRMLdatatype.string_Coordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentIndexedLineSet.coord = currentCoordinate;
										currentCoordinate.parent = currentShape; // this is a cludge so interpolated coordinates can call ResetNormals(shape)
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								//else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						//else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end IndexedLineSet.coord

					else if ( token.equals(VRMLdatatype.string_coordIndex) ) { 
						//Write(indent + VRMLdatatype.string_coordIndex );
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentIndexedLineSet.coordIndex = new MFInt32();
							if (tempIntBuffer[tempBufferIndex-1] != -1) { // insure we end with -1
								tempIntBuffer[tempBufferIndex] = -1;
								tempBufferIndex++;
							}
							currentIndexedLineSet.coordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_coordIndex);
					} // end IndexedLineSet.coordIndex

					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) { 
									//Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentIndexedLineSet.color = currentColor;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // else if token == Color
								//else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end else if token != USE
						} // end if token == world
						//else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end IndexedLineSet.color

					else if ( token.equals(VRMLdatatype.string_colorIndex) ) { 
						//Write(indent + VRMLdatatype.string_colorIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentIndexedLineSet.colorIndex = new MFInt32();
							currentIndexedLineSet.colorIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_colorIndex);
					} // end currentIndexedLineSet.colorIndex

					else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) { 
						//Write(indent + VRMLdatatype.string_colorPerVertex + " ");
						currentIndexedLineSet.colorPerVertex.setValue( CheckBoolean() );
					} // end currentIndexedLineSet.colorPerVertex
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_IndexedLineSet);
				break; // end case IndexedLineSet



				/********* IndexedFaceSet *********/
				case VRMLdatatype.IndexedFaceSet:
					if ( token.equals(VRMLdatatype.string_coord) ) { 
						//Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) { 
									//Write(VRMLdatatype.string_Coordinate  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentIndexedFaceSet.coord = currentCoordinate;
										currentCoordinate.parent = currentShape; // this is a cludge so interpolated coordinates can call ResetNormals(shape)
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								//else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						//else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end IndexedFaceSet.coord

					else if ( token.equals(VRMLdatatype.string_coordIndex) ) { 
						//Write(indent + VRMLdatatype.string_coordIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							/******* ASSUMES FOR THE MOMENT THAT WE GET ONLY TRIANGLES **********/
							//valsPerLine = 0;
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									//if (tempIntBuffer[tempBufferIndex] == -1) valsPerLine++;
									//if (valsPerLine > maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentIndexedFaceSet.coordIndex = new MFInt32();
							if (tempIntBuffer[tempBufferIndex-1] != -1) { // insure we end with -1
								tempIntBuffer[tempBufferIndex] = -1;
								tempBufferIndex++;
							}
							currentIndexedFaceSet.coordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_coordIndex);
					}  // end IndexedFaceSet.coordIndex

					/* Need to Rewrite Normal */
					else if ( token.equals(VRMLdatatype.string_normal) ) { 
						//Write(indent + VRMLdatatype.string_normal + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_DEF) ) {
								nodeName = GetNodeName();
							}
							if ( token.equals(VRMLdatatype.string_Normal) ) { 
								//Write(VRMLdatatype.string_Normal  + " "); indent += indentAmt;
								if ( CheckChar(leftBraceChar) ) {
									PushStack( state );
									state = VRMLdatatype.Normal;
									currentIndexedFaceSet.normal = new Normal(); // done here cause some IFS have a normal and others may not
									SetNodeName (currentIndexedFaceSet.normal, nodeName);
									//WriteLine();
								}
								//else FormatError("Missing '{' following " + VRMLdatatype.string_Normal);
							}
							//else FormatError("Missing '" + VRMLdatatype.string_Normal + "' following " + VRMLdatatype.string_normal);
						}
						//else FormatError("Non-word token following " + VRMLdatatype.string_normal);
					} // end IndexedFaceSet.normal

					else if ( token.equals(VRMLdatatype.string_normalIndex) ) { 
						//Write(indent + VRMLdatatype.string_normalIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									currentIndexedFaceSet.normalIndexStream.addElement( (Object) new Integer ( GetIntegerNumber() ) );
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							/******* ASSUMES FOR THE MOMENT THAT WE GET ONLY TRIANGLES **********/
							Integer il = new Integer( currentIndexedFaceSet.normalIndexStream.elementAt(currentIndexedFaceSet.normalIndexStream.size()-1).toString() );
							if (il.intValue() != -1) { // insure we end with -1
								currentIndexedFaceSet.normalIndexStream.addElement( (Object) new Integer ( -1 ) );
							}
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_normalIndex);
					} // end IndexedFaceSet.normalIndex

					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) { 
									//Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentIndexedFaceSet.color = currentColor;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // if token == Color
								//else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end if !USE
						} // end if a word
						//else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end IndexedFaceSet.color

					else if ( token.equals(VRMLdatatype.string_colorIndex) ) { 
						//Write(indent + VRMLdatatype.string_colorIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentIndexedFaceSet.colorIndex = new MFInt32();
							currentIndexedFaceSet.colorIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_colorIndex);
					} // end IndexedFaceSet.colorIndex

					else if ( token.equals(VRMLdatatype.string_texCoord) ) { 
						//Write(indent + VRMLdatatype.string_texCoord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_TextureCoordinate) ) { 
									//Write(VRMLdatatype.string_TextureCoordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.TextureCoordinate;
										currentTextureCoordinate = new TextureCoordinate();
										SetNodeName (currentTextureCoordinate, nodeName);
										currentIndexedFaceSet.texCoord = currentTextureCoordinate;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TextureCoordinate);
								}
								//else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_texCoord);
							} // end word != USE
						} // end got a word
						//else FormatError("Non-word token following " + VRMLdatatype.string_texCoord);
					} // end IndexedFaceSet.texCoord

					else if ( token.equals(VRMLdatatype.string_texCoordIndex) ) { 
						//Write(indent + VRMLdatatype.string_texCoordIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							//valsPerLine = 0;
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									//if (tempIntBuffer[tempBufferIndex] == -1) {
									//	Write(",");
									//	valsPerLine++;
									//}
									//if (valsPerLine > maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentIndexedFaceSet.texCoordIndex = new MFInt32( );
							currentIndexedFaceSet.texCoordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_texCoordIndex);
					}  // end IndexedFaceSet.texCoordIndex

					else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) { 
						//Write(indent + VRMLdatatype.string_colorPerVertex + " ");
						currentIndexedFaceSet.colorPerVertex.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_normalPerVertex) ) { 
						//Write(indent + VRMLdatatype.string_normalPerVertex + " ");
						currentIndexedFaceSet.normalPerVertex.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_ccw) ) { 
						//Write(indent + VRMLdatatype.string_ccw  + " ");
						currentIndexedFaceSet.ccw.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_solid) ) { 
						//Write(indent + VRMLdatatype.string_solid  + " ");
						currentIndexedFaceSet.solid.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_creaseAngle) ) { 
						//Write(indent + VRMLdatatype.string_creaseAngle );
						float creaseAngle = GetSingleFloat();
						if ( appletParameters.creaseAngleDefault ) {
							//Write(" - using default of " + appletParameters.creaseAngle);
						}
						else currentIndexedFaceSet.creaseAngle.setValue( creaseAngle );
						//currentIndexedFaceSet.creaseAngle.setValue( GetSingleFloat() );
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_IndexedFaceSet);
				break; // end case IndexedFaceSet



				/********* PointSet *********/
				case VRMLdatatype.PointSet:
					if ( token.equals(VRMLdatatype.string_coord) ) { 
						//Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) { 
									//Write(VRMLdatatype.string_Coordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentPointSet.coord = currentCoordinate;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								//else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						//else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end PointSet.coord

					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) { 
									//Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentPointSet.color = currentColor;
										//WriteLine();
									}
									//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // else if token == Color
								//else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end else if token != USE
						} // end if token == world
						//else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end PointSet.color

					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PointSet);
				break; // end case PointSet


				/********* Coordinate *********/
				case VRMLdatatype.Coordinate:
					if ( token.equals(VRMLdatatype.string_point) ) { 
						//Write(indent + VRMLdatatype.string_point + " ");
						if ( CheckChar(leftBracketChar) ) {
							//valsPerLine = 0;
							tempBufferIndex = 0;
							// had to get this before do while loop cause tokenType set in GetFloatNumber
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									//Write(",");
									//if (valsPerLine >= maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentCoordinate.point.setValue(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_point);
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Coordinate);
				break; // end case Coordinate


				/********* Normal *********/
				case VRMLdatatype.Normal:
					if ( token.equals(VRMLdatatype.string_vector) ) { 
						//Write(indent + VRMLdatatype.string_vector + " ");
						if ( CheckChar(leftBracketChar) ) {
							float[] newVector = new float[3];
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									currentIndexedFaceSet.normalStream.addElement( (Object) new Float ( GetFloatNumber() ) );
									//Write(" ");
								}
								tokenType = GetToken();
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							Normal normal = (Normal) currentIndexedFaceSet.normal;
							normal.vector.vec3s = new float[currentIndexedFaceSet.normalStream.size()/3][3]; // makes vec3s not null for ROUTE properties	
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_vector);
					} // end if 'vector'not following Normal
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Normal);
				break; // end case Normal


				/********* Color *********/
				case VRMLdatatype.Color:
					if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									//Write(",");
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentColor.color.setValue(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_color);
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Color);
				break; // end case Color


				/********* PositionInterpolator, ColorInterpolator, CoordinateInterpolator, NormalInterpolator *********/
				case VRMLdatatype.PositionInterpolator:
				case VRMLdatatype.ColorInterpolator:
				case VRMLdatatype.CoordinateInterpolator:
				case VRMLdatatype.NormalInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) { 
						//Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							//valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									//Write(",");
									//if (valsPerLine >= maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							if (state == VRMLdatatype.PositionInterpolator) {
								currentPositionInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.ColorInterpolator) {
								currentColorInterpolator.keyValue = new MFColor(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.CoordinateInterpolator) {
								currentCoordinateInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.NormalInterpolator) {
								currentNormalInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) { 
						//Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							//valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									//Write(",");
									//if ( valsPerLine > (maxValsPerLine*2) ) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							if (state == VRMLdatatype.PositionInterpolator) {
								currentPositionInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.ColorInterpolator) {
								currentColorInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.CoordinateInterpolator) {
								currentCoordinateInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.NormalInterpolator) {
								currentNormalInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key);
					} // end if key
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Interpolator);
				break; // end case ColorInterpolator, PositionInterpolator

				/********* OrientationInterpolator - for Transform.rotation and Viewpoint.orientation *********/
				case VRMLdatatype.OrientationInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) { 
						//Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							//valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;

									//Write(",");
									//if (valsPerLine >= maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentOrientationInterpolator.keyValue = new MFRotation(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue + " inside " + VRMLdatatype.string_OrientationInterpolator);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) { 
						//Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							//valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									//Write(",");
									//if ( valsPerLine > (maxValsPerLine*2) ) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentOrientationInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key + " inside " + VRMLdatatype.string_OrientationInterpolator);
					} // end if key
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_OrientationInterpolator);
				break; // end case OrientationInterpolator

				/********* ScalarInterpolator, used for MFFloats typically *********/
				case VRMLdatatype.ScalarInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) { 
						//Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							//valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;

									//Write(",");
									//if ( valsPerLine > (maxValsPerLine*2) ) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentScalarInterpolator.keyValue = new MFFloat(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue + " inside " + VRMLdatatype.string_ScalarInterpolator);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) { 
						//Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							//valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									//Write(",");
									//if ( valsPerLine > (maxValsPerLine*2) ) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentScalarInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key + " inside " + VRMLdatatype.string_ScalarInterpolator);
					} // end if key
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ScalarInterpolator);
				break; // end case ScalarInterpolator



				/********* ImageTexture *********/
				case VRMLdatatype.ImageTexture:
					if ( token.equals(VRMLdatatype.string_url) ) { 
						//Write(indent + VRMLdatatype.string_url + " ");
						String[] urlString = new String[1];
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							token = st.sval;
							urlString[0] = textureMapFolder + token;
							//urlString[0] = urlString[0].toLowerCase();
						}
						//else FormatError("Missing doublequote following " + VRMLdatatype.string_url + " in " + VRMLdatatype.string_ImageTexture);
						// check for a repeated image
						SFNode currNodeLink	= imageTextureRoot.next;
						while (currNodeLink != null) {
							ImageTexture currImageTextureLink = (ImageTexture) currNodeLink;
							if ( currImageTextureLink.url.get1Value(0).equals(urlString[0]) ) {
								currentAppearance.texture = currImageTextureLink;
								break;
							}
							currNodeLink = currNodeLink.next;
						}
						if ( currNodeLink == null) {
							// add new Image Texture
							//ImageTexture currentImageTexture	= new ImageTexture(localApplet);
							ImageTexture currentImageTexture	= new ImageTexture();
							SetNodeName(currentImageTexture, imageTextureDEFName); // new var used to save nodeName 
							currentAppearance.texture = currentImageTexture;
							currentImageTexture.url = new MFString( 1, urlString );
							//currentImageTexture.retrieveImage( );
							currentImageTexture.retrieveImage(localApplet, 1);
							// insert new ImageTexture into linked list
							currentImageTexture.next = imageTextureRoot.next;
							imageTextureRoot.next = currentImageTexture;
						}
						//WriteLine(doubleQuoteChar + token + doubleQuoteChar);
					} // end getting url
					else if ( token.equals(VRMLdatatype.string_repeatS) ) { 
						//Write(indent + VRMLdatatype.string_repeatS );
						//currentImageTexture.repeatS.setValue( CheckBoolean() ); // valied currentImageTexture may not be avail
						CheckBoolean();
						//WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatS + " not currently supported ");
					}
					else if ( token.equals(VRMLdatatype.string_repeatT) ) { 
						//Write(indent + VRMLdatatype.string_repeatT );
						//currentImageTexture.repeatT.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						CheckBoolean();
						//WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatT + " not currently supported ");
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ImageTexture);
				break; // end case ImageTexture



				/********* PixelTexture *********/
				case VRMLdatatype.PixelTexture:
					if ( token.equals(VRMLdatatype.string_image) ) { 
						//Write(indent + VRMLdatatype.string_image + " ");

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.width  = GetIntegerNumber();
						//else FormatError("Missing width value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.height = GetIntegerNumber();
						//else FormatError("Missing height value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.components = GetIntegerNumber();
						//else FormatError("Missing components value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						currentPixelTexture.image.pixels = new byte[currentPixelTexture.image.width * currentPixelTexture.image.height * currentPixelTexture.image.components];
						// flip the pixel texture according to spec.
						int widthIndex = currentPixelTexture.image.width - 1;
						int heightIndex = currentPixelTexture.image.height - 1;
						for (int i = 0; i < currentPixelTexture.image.width; i++) {
							for (int j = 0; j < currentPixelTexture.image.height; j++) {
								byte[] returnBytes = GetByte(currentPixelTexture.image.components);
								for (int byteNum = 0; byteNum < returnBytes.length; byteNum++) {
									//currentPixelTexture.image.pixels[(currentPixelTexture.image.height*(widthIndex - i))+j+byteNum] = returnBytes[byteNum];
									currentPixelTexture.image.pixels[
										(i + ((heightIndex-j)*currentPixelTexture.image.height))*currentPixelTexture.image.components + byteNum] =
										returnBytes[byteNum];
								}
							}
						}
						currentPixelTexture.image.SetRGBA();
						//WriteLine();
					} // end getting image
					else if ( token.equals(VRMLdatatype.string_repeatS) ) { 
						//Write(indent + VRMLdatatype.string_repeatS );
						currentPixelTexture.repeatS.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						//WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatS + " not currently supported ");
					}
					else if ( token.equals(VRMLdatatype.string_repeatT) ) { 
						//Write(indent + VRMLdatatype.string_repeatT );
						currentPixelTexture.repeatT.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						//WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatT + " not currently supported ");
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PixelTexture);
				break; // end case PixelTexture



				/********* TextureCoordinate *********/
				case VRMLdatatype.TextureCoordinate:
					if ( token.equals(VRMLdatatype.string_point) ) { 
						//Write(indent + VRMLdatatype.string_point + " ");
						if ( CheckChar(leftBracketChar) ) {
							//valsPerLine = 0;
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									//Write(",");
									//if (valsPerLine >= maxValsPerLine) {
									//	WriteLine();
 									//	valsPerLine = 0;
									//	Write(indent + indentAmt);
								   //}
									//else valsPerLine++;
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//WriteLine(rightBracketChar);
							currentTextureCoordinate.point.setValue(tempBufferIndex, tempFloatBuffer);
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_point);
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TextureCoordinate);
				break; // end case TextureCoordinate



				/********* Anchor *********/
				case VRMLdatatype.Anchor:
					if ( token.equals(VRMLdatatype.string_children) ) { 
						//Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar +"' following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Anchor);
					} // end if children
					else if ( token.equals(VRMLdatatype.string_description) ) { 
						//Write(indent + VRMLdatatype.string_description + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							//token = st.sval;
							currentAnchor.description = new SFString( st.sval );
							//WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						//else FormatError("Missing doublequote following " + VRMLdatatype.string_description + " in " + VRMLdatatype.string_Anchor);
					} // end if description
					else if ( token.equals(VRMLdatatype.string_parameter) ) { 
						//Write(indent + VRMLdatatype.string_parameter + " ");
						tokenType = GetToken();
						boolean bracket = false;
						if ( tokenType == leftBracketChar ) {
							tokenType = GetToken();
							bracket = true;
							//Write(leftBracketChar);
						}
						if ( tokenType == doubleQuoteChar ){
							//token = st.sval;
							String[] parameterString = {st.sval };
							currentAnchor.parameter = new MFString(1, parameterString );
							//Write(doubleQuoteChar + parameterString[0] + doubleQuoteChar);
						}
						//else FormatError("Missing double quote/left bracket following " + VRMLdatatype.string_parameter + " in " + VRMLdatatype.string_Anchor);
						if ( bracket ) {
							tokenType = GetToken();
							//Write(rightBracketChar);
						}
						//WriteLine();
					} // end if parameter
					else if ( token.equals(VRMLdatatype.string_url) ) { 
						//Write(indent + VRMLdatatype.string_url + " ");
						tokenType = GetToken();
						boolean bracket = false;
						if ( tokenType == leftBracketChar ) {
							tokenType = GetToken();
							bracket = true;
							//Write(leftBracketChar);
						}
						if ( tokenType == doubleQuoteChar ){
							//token = st.sval;
							String[] urlString = {st.sval };
							currentAnchor.url = new MFString(1, urlString );
							//Write(doubleQuoteChar + urlString[0] + doubleQuoteChar);
						}
						//else FormatError("Missing double quote following " + VRMLdatatype.string_url + " in " + VRMLdatatype.string_Anchor);
						if ( bracket ) {
							tokenType = GetToken();
							//Write(rightBracketChar);
						}
						//WriteLine();
					} // end if url
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) { 
						//Write(indent + VRMLdatatype.string_bboxCenter + " ");
						//currentAnchor.setBboxCenter( GetFloatValues(3) );
						currentAnchor.bboxCenter.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) { 
						//Write(indent + VRMLdatatype.string_bboxSize + " ");
						//currentAnchor.setBboxSize( GetFloatValues(3) );
						currentAnchor.bboxSize.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Anchor);
				break; // end case Anchor


				/********* Billboard *********/
				case VRMLdatatype.Billboard:
					if ( token.equals(VRMLdatatype.string_children) ) { 
						//Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Billboard);
					}
					else if ( token.equals(VRMLdatatype.string_axisOfRotation) ) { 
						//Write(indent + VRMLdatatype.string_axisOfRotation);
						currentBillboard.axisOfRotation.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) { 
						//Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentBillboard.bboxCenter.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) { 
						//Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentBillboard.bboxSize.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Billboard);
				break; // end case Billboard



				/********* Group *********/
				case VRMLdatatype.Group:
					if ( token.equals(VRMLdatatype.string_children) ) { 
						//Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Group);
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) { 
						//Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentGroup.bboxCenter.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) { 
						//Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentGroup.bboxSize.setValue( GetFloatValues(3) );
						//Write("; not currently supported ");
						//WriteLine();
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Group);
				break; // end case Group


				/********* WorldInfo *********/
				case VRMLdatatype.WorldInfo:
					if ( token.equals(VRMLdatatype.string_title) ) { 
						//Write(indent + VRMLdatatype.string_title + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							worldInfo.title.setValue( st.sval );
							//WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						//else FormatError("Missing doublequote following " + VRMLdatatype.string_title + " in " + VRMLdatatype.string_WorldInfo);
					}
					else if ( token.equals(VRMLdatatype.string_info) ) { 
						//Write(indent + VRMLdatatype.string_info + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							//WriteLine(leftBracketChar);
							tokenType = GetToken();
							while (tokenType != rightBracketChar) {
								worldInfo.info.addValue( st.sval );
								//WriteLine(indent + indentAmt + doubleQuoteChar + st.sval + doubleQuoteChar);
								tokenType = GetToken();
							} 
							//WriteLine(indent + rightBracketChar);
						}
						else if (tokenType == doubleQuoteChar) {
							// no brackets but a single string
							worldInfo.info.addValue( st.sval );
							//WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						//else FormatError("Missing character following " + VRMLdatatype.string_info + " in " + VRMLdatatype.string_WorldInfo);
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_WorldInfo);
				break; // end case WorldInfo


				/********* Background *********/
				case VRMLdatatype.Background:
					if ( token.equals(VRMLdatatype.string_skyColor) ) { 
						//Write(indent + VRMLdatatype.string_skyColor + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							//Write(leftBracketChar);
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									//Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//Write(rightBracketChar);
							background.skyColor.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else {
							//background.setSkyColor( GetFloatValues(3) );
							tempFloatBuffer[0] = GetFloatNumber();
							tempFloatBuffer[1] = GetSingleFloat();
							tempFloatBuffer[2] = GetSingleFloat();
							background.skyColor.setValue( 3, tempFloatBuffer );
						}
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_groundColor) ) { 
						//Write(indent + VRMLdatatype.string_groundColor + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							//Write(leftBracketChar);
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									tempFloatBuffer[0] = GetSingleFloat();
									tempFloatBuffer[0] = GetSingleFloat();
									//Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//Write(rightBracketChar);
							//Write("; not currently supported ");
							//background.groundColor.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else {
							tempFloatBuffer[0] = GetFloatNumber();
							tempFloatBuffer[1] = GetSingleFloat();
							tempFloatBuffer[2] = GetSingleFloat();
							//Write("; not currently supported ");
							//background.groundColor.setValue( 3, tempFloatBuffer );
						}
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_skyAngle) ) {
						//Write(indent + VRMLdatatype.string_skyAngle + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									//Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//Write(rightBracketChar);
							//Write("; not currently supported");
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_skyAngle + " in " + VRMLdatatype.string_Background);
 				   }
					else if ( token.equals(VRMLdatatype.string_groundAngle) ) {
						//Write(indent + VRMLdatatype.string_groundAngle + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									//Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							//Write(rightBracketChar);
							//Write("; not currently supported ");
							//WriteLine();
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_skyAngle + " in " + VRMLdatatype.string_Background);
 				   }
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Background);
				break; // end case Background


				/********* Fog *********/
				case VRMLdatatype.Fog:
					if ( token.equals(VRMLdatatype.string_visibilityRange) ) { 
						//Write(indent + VRMLdatatype.string_visibilityRange);
						currentFog.visibilityRange.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) { 
						//Write(indent + VRMLdatatype.string_color);
						currentFog.color.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_fogType) ) {
						//Write(indent + VRMLdatatype.string_fogType + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							if ( st.sval.equals(VRMLdatatype.string_LINEAR) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								currentFog.fogType.setValue( VRMLdatatype.string_LINEAR );
								//WriteLine();
							}
							else if ( st.sval.equals(VRMLdatatype.string_EXPONENTIAL) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								currentFog.fogType.setValue( VRMLdatatype.string_EXPONENTIAL );
								//WriteLine();
							}
	 						//else FormatError(st.sval + "invalid following " + VRMLdatatype.string_fogType + " in " + VRMLdatatype.string_Fog);
						}
 						//else FormatError("Missing " + doubleQuoteChar + " following " + VRMLdatatype.string_fogType + " in " + VRMLdatatype.string_Fog);
					}
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Fog);
				break; // end case Fog


				/********* NavigationInfo *********/
				case VRMLdatatype.NavigationInfo:
					if ( token.equals(VRMLdatatype.string_headlight) ) { 
						//Write(indent + VRMLdatatype.string_headlight );
						navigationInfo.headlight.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_speed) ) { 
						//Write(indent + VRMLdatatype.string_speed );
						navigationInfo.speed.setValue( GetSingleFloat() );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_avatarSize) ) { 
						//Write(indent + VRMLdatatype.string_avatarSize + " ");
						if ( CheckChar(leftBracketChar) ) {
							navigationInfo.avatarSize.setValue(3, GetFloatValues(3) );
							//Write("; not currently supported ");
							if ( !CheckChar(rightBracketChar) ) {
								//FormatError("Missing '" + rightBracketChar + "' following " + VRMLdatatype.string_avatarSize + " in " + VRMLdatatype.string_NavigationInfo);
							}
						}
						//else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_avatarSize + " in " + VRMLdatatype.string_NavigationInfo);
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_type) ) {
						//Write(indent + VRMLdatatype.string_type + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							//String stringType = (String) st.sval;
							if ( st.sval.equals(VRMLdatatype.string_WALK) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								appletParameters.walkthrough = true;
								//WriteLine();
							}
							else if ( st.sval.equals(VRMLdatatype.string_EXAMINE) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								appletParameters.walkthrough = true;
								//WriteLine();
							}
							else if ( st.sval.equals(VRMLdatatype.string_FLY) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								appletParameters.walkthrough = true;
								//WriteLine();
							}
							else if ( st.sval.equals(VRMLdatatype.string_NONE) ) {
								//Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								appletParameters.walkthrough = false;
								//WriteLine();
							}
	 						//else FormatError(st.sval + "invalid following " + VRMLdatatype.string_type + " in " + VRMLdatatype.string_NavigationInfo);
						}
 						//else FormatError("Missing " + doubleQuoteChar + " following " + VRMLdatatype.string_type + " in " + VRMLdatatype.string_NavigationInfo);
				   }
					else if ( token.equals(VRMLdatatype.string_visibilityLimit) ) {
						//Write(indent + VRMLdatatype.string_visibilityLimit );
						navigationInfo.visibilityLimit.setValue( GetSingleFloat() );
						//Write("; not currently supported ");
						//WriteLine();
 				   }
					//else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_NavigationInfo);
				break; // end case NavigationInfo


				/********* default *********/
				default:
					//FormatError("node '" + token + "' misplaced, not currently implemented or illegal");
				break; // end default
			} // end switch on state
		} // end if (tokenType == StreamTokenizer.TT_WORD)


		else if ( tokenType == rightBraceChar) { // '}'
			//if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
			//WriteLine(indent + rightBraceChar);
			switch (state) {
				case VRMLdatatype.Appearance:
					currentAppearance = null;
					state =  PopStack();
				break;
				case VRMLdatatype.Material:
					currentMaterial = null;
					state =  PopStack();
				break;
				case VRMLdatatype.Shape:
					currentShape = null;
					state = PopStack();
				break;
				case VRMLdatatype.Transform:
					state = PopStack();
					currentNode = currentTransform.parent;
					if ( currentNode.datatype == VRMLdatatype.Transform) {
						currentTransform = (Transform) currentNode;
					}
					else { currentTransform = null; }
				break;
				case VRMLdatatype.Viewpoint:
					currentViewpoint = null;
					state = PopStack();
				break;
				case VRMLdatatype.Coordinate:
					currentCoordinate = null;
					state = PopStack();
				break;
				case VRMLdatatype.IndexedFaceSet:
					currentIndexedFaceSet = null;
					state = PopStack();
				break;
				case VRMLdatatype.IndexedLineSet:
					currentIndexedLineSet = null;
					state =  PopStack();
				break;
				case VRMLdatatype.PointSet:
					currentPointSet = null;
					state =  PopStack();
				break;
				case VRMLdatatype.TextureTransform:
					currentTextureTransform = null;
					state =  PopStack();
				break;
				case VRMLdatatype.TextureCoordinate:
					currentTextureCoordinate = null;
					state = PopStack();
				break;
				case VRMLdatatype.ImageTexture:
					//currentImageTexture = null;
					state = PopStack();
				break;
				case VRMLdatatype.PixelTexture:
					currentPixelTexture = null;
					state = PopStack();
				break;
				case VRMLdatatype.Color:
					currentColor = null;
					state = PopStack();
				break;
				case VRMLdatatype.TimeSensor:
					currentTimeSensor = null;
					state = PopStack();
				break;
				case VRMLdatatype.TouchSensor:
					currentTouchSensor = null;
					state = PopStack();
				break;
				case VRMLdatatype.DirectionalLight:
					currentDirectionalLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.PointLight:
					currentPointLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.SpotLight:
					currentSpotLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.ColorInterpolator:
					currentColorInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.PositionInterpolator:
					currentPositionInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.CoordinateInterpolator:
					currentCoordinateInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.OrientationInterpolator:
					currentOrientationInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.ScalarInterpolator:
					currentScalarInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.NormalInterpolator:
					currentNormalInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.Anchor:
					state = PopStack();
					currentNode = currentAnchor.parent;
					if ( currentNode.datatype == VRMLdatatype.Anchor) {
						currentAnchor = (Anchor) currentNode;
					}
					else { currentAnchor = null; }
				break;
				case VRMLdatatype.Billboard:
					state = PopStack();
					currentNode = currentBillboard.parent;
					if ( currentNode.datatype == VRMLdatatype.Billboard) {
						currentBillboard = (Billboard) currentNode;
					}
					else { currentBillboard = null; }
				break;
				case VRMLdatatype.Group:
					state = PopStack();
					currentNode = currentGroup.parent;
					if ( currentNode.datatype == VRMLdatatype.Group) {
						currentGroup = (Group) currentNode;
					}
					else { currentGroup = null; }
				break;
				case VRMLdatatype.SFNode:
				case VRMLdatatype.ROOT:
					//FormatError("'" + rightBraceChar + "' for unspecified Node.");
				break;
				case VRMLdatatype.Background:
				case VRMLdatatype.Fog:
				case VRMLdatatype.NavigationInfo:
				case VRMLdatatype.WorldInfo:
					state = PopStack();
				break;
				case VRMLdatatype.Normal:
					//currentNormal = null;
					state = PopStack();
				break;
				/*
				case VRMLdatatype.NavigationInfo:
					state = PopStack();
				break;
				case VRMLdatatype.WorldInfo:
					state = PopStack();
				break;
				*/
				default:
					//FormatError("'" + rightBraceChar + "' for undefined node.");
				break;
			} // end switch on state for '}'
		} // end if ( tokenType == rightBraceChar)

		else if ( tokenType == rightBracketChar) { // ']'
			//if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
			//WriteLine(indent + rightBracketChar);
			switch (state) {
				case VRMLdatatype.children:
					state = PopStack();
				break;
				default:
					//FormatError("'" + rightBracketChar + "' (right bracket) for undefined node.");
				break;
			} // end switch on state
		} // else if token == right Brace

		//else if (tokenType == StreamTokenizer.TT_NUMBER) {
		//	FormatError("unexpected number: " + GetFloatNumber() );
		//}
		return tokenType;
	} // end NodeParser function


	public void ReadStream(InputStream vrmlInputStream, String _textureMapFolder) {
		this.textureMapFolder = _textureMapFolder;
		st = parser.GetStreamTokenizer (vrmlInputStream);
		do {
			tokenType = NodeParser(parser);
		} while (tokenType != StreamTokenizer.TT_EOF);
	} // end ReadStream


	public LexicalAnalyzerNDB(Applet applet,
				//Node mainRoot, Light mainLightsRoot,
				Group mainRoot, Light mainLightsRoot,
				Viewpoint mainViewpointRoot, Sensor mainSensorRoot,
				Interpolator mainInterpolatorRoot, Route mainRouteRoot, Shape shapeRoot,
				Background background_, NavigationInfo navigationInfo_,
				AppletParameters appletParameters_) {

		stateStack  = new Stack();
		parser = new Parser();

		localApplet = applet;

		mainRoot.setName("ROOT");
 		root = mainRoot;
		currentNode = mainRoot;

		mainLightsRoot.setName("LIGHTSroot");
		currentLight = mainLightsRoot;

		mainViewpointRoot.setName("VIEWPOINTroot");
		viewpointRoot = mainViewpointRoot;
		viewpointLink = mainViewpointRoot;

		mainSensorRoot.setName("SENSORroot");
		sensorRoot = mainSensorRoot;
		sensorLink = mainSensorRoot;

		mainInterpolatorRoot.setName("INTERPOLATORroot");
		interpolatorRoot = mainInterpolatorRoot;
		interpolatorLink = mainInterpolatorRoot;

		routeRoot = mainRouteRoot;
		routeLast = mainRouteRoot;
		shapeLink = shapeRoot;

		imageTextureRoot = new SFNode();

		background		= background_;
		navigationInfo	= navigationInfo_;

		DEFnameNode = new SFNode(); // for a linked list of named nodes for USE/DEF nodes
		//DEFnameNode.setName("DEFnameNodeRoot");
		currentDEFnameNode = DEFnameNode; // for a linked list of named nodes for USE/DEF nodes

		appletParameters = appletParameters_;

	} // LexicalAnalyzer Constructor

} // end class Lexical Analyser
