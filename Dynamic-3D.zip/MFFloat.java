 // MFFloat.java
 // � 2002, 3D-Online, All Rights Reserved 
 // November 29, 2003

package d3d;

public class MFFloat {

	float[] values = null;

	// constructor
	public MFFloat () {
	}
	public MFFloat (int size, float values[] ) {
		this.setValue( size, values );
	}

	// setValue
	public void setValue ( int size, float values[] ) {
		this.values = new float[size];
		for (int i = 0; i < size; i++ ) {
			this.values[i] = values[i];
		}
	}

	// getValue
	public float[] getValue( ) {
		return this.values;
	}
	public float get1Value(int index) {
		return this.values[index];
	}
	/** returns <I>values</I> separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < values.length; i++ ) {
			returnString += (values[i] + " ");
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFFloat
