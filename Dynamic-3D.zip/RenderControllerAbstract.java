// RenderControllerAbstract.java
// � 2004, 3D-Online, All Rights Reserved 
// March 2, 2004

package d3d;


public abstract interface RenderControllerAbstract {

	public abstract void PreRender();

} // end RenderControllerAbstract class
