 // WorldScreenCoordinates.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 14, 2002

package d3d;

import java.awt.Dimension;

public class WorldScreenCoordinates {

	static final int frontClippingPlane		= 0;
	static final int leftClippingPlane		= 1;
	static final int topClippingPlane		= 2;
	static final int rightClippingPlane		= 3;
	static final int bottomClippingPlane	= 4;
	static final int totalClippingPlanes	= 5;


	static final float WorldCoordMaxX = 1.33f;
	static final float WorldCoordMinX = -WorldCoordMaxX;
	static final float WorldCoordMaxY = 1;
	static final float WorldCoordMinY = -WorldCoordMaxY;
	static final float WorldCoordWidth = WorldCoordMaxX -  WorldCoordMinX ;
	static final float WorldCoordHeight = WorldCoordMaxY -  WorldCoordMinY;


	static final float frontClippingDistance = -0.1f;
	static final float[][] Xclipping = { {0, 0, frontClippingDistance}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0}, {0, 0, 0} };
	private final float[] cameraCoord = {0, 0, 0}; 


	int ScreenCoordMaxX;
	int ScreenCoordMaxY;
	private int ScreenCoordMinX;
	private int ScreenCoordMinY;
	private int ScreenCoordWidth;
	private int ScreenCoordHeight;
	private int ScreenCoordWidthCenter;
	private int ScreenCoordHeightCenter;
	private float ScreenWorldRatioWidth;
	private float ScreenWorldRatioHeight;
	private float WorldScreenRatioWidth;
	private float WorldScreenRatioHeight;

	static float[][] clippingNormal = new float[totalClippingPlanes][3]; 

	float distance = (float)(1 / Math.tan(Math.PI/8f) ); // default 22.5 degrees.
	float xBoundary = WorldCoordMaxX / distance;
	float yBoundary = WorldCoordMaxY / distance;



	private float[] GetClippingNormal(float[] vertex0, float[] vertex1, float[] vertex2) {
		// Create the clipping region normals
		float[] vector1 = new float[3]; 			
		float[] vector2 = new float[3]; 
		float[] clippingPlaneNormal  = new float[3];	
		for (int i = 0; i <  3; i++) {
			vector1[i] = vertex1[i] - vertex0[i];
			vector2[i] = vertex2[i] - vertex1[i];
		} // end for loop
		clippingPlaneNormal = MathOps.CrossProduct( vector1, vector2 );
		clippingPlaneNormal = MathOps.NormalizeVector( clippingPlaneNormal );
		return clippingPlaneNormal;
	} // end GetClippingNormal

	// anytime there is a change to the fieldOfView, this must be called
	/** Given a fieldOfView in radians, sets the distance and clipping planes.<BR>distance = 1 / Math.tan(fieldOfView/2)*/
	public void SetViewFrustum (float fieldOfView ) {
		distance = (float)(1 / Math.tan(fieldOfView/2.0f) ); // default 22.5 degrees, which is 45/2.
		xBoundary = WorldCoordMaxX / distance;
		yBoundary = WorldCoordMaxY / distance;

		float[] upperLeft   = {WorldCoordMinX, WorldCoordMaxY, -distance}; 
		float[] lowerLeft   = {WorldCoordMinX, WorldCoordMinY, -distance}; 
		float[] upperRight  = {WorldCoordMaxX, WorldCoordMaxY, -distance}; 
		float[] lowerRight  = {WorldCoordMaxX, WorldCoordMinY, -distance}; 

		clippingNormal[leftClippingPlane] = GetClippingNormal(cameraCoord, upperLeft, lowerLeft);
		clippingNormal[rightClippingPlane] = GetClippingNormal(cameraCoord, lowerRight, upperRight); 
		clippingNormal[topClippingPlane] = GetClippingNormal(cameraCoord, upperRight, upperLeft); 
		clippingNormal[bottomClippingPlane] = GetClippingNormal(cameraCoord, lowerLeft, lowerRight); 
	} // end SetViewFrustum


	// constructor
	public WorldScreenCoordinates (int width, int height) {
		ScreenCoordMinX = 0;
		ScreenCoordMinY = 0;
		ScreenCoordMaxX = width;
		ScreenCoordMaxY = height;
		ScreenCoordWidth  = (ScreenCoordMaxX - 1) << 1;
		ScreenCoordHeight = (ScreenCoordMaxY - 1) << 1;
		ScreenCoordWidthCenter = ScreenCoordWidth >> 1;
		ScreenCoordHeightCenter = ScreenCoordHeight >> 1;

		ScreenWorldRatioWidth = ScreenCoordWidth / WorldCoordWidth;
		ScreenWorldRatioHeight = ScreenCoordHeight / WorldCoordHeight;
		WorldScreenRatioWidth = 1 / ScreenWorldRatioWidth;
		WorldScreenRatioHeight = 1 / ScreenWorldRatioHeight;

		/* Front clipping plane normals and cameraCoord don't change with new vewipoints */
		clippingNormal[frontClippingPlane][0] = 0;
		clippingNormal[frontClippingPlane][1] = 0; 
		clippingNormal[frontClippingPlane][2] = 1; 

	} // end Constructor

	/** Given a world's X coordinate , return the screen's X coordinate */
	public float WorldToScreenX(float worldCoord) {
		return ( (  ( ScreenWorldRatioWidth * worldCoord ) + ScreenCoordWidthCenter) / 2.0f );
	}

	/** Given a world's Y coordinate , return the screen'x Y coordinate */
	public float WorldToScreenY(float worldCoord) {
		return ( ( ( -ScreenWorldRatioHeight * worldCoord ) + ScreenCoordHeightCenter) / 2.0f );
	}

	// used for mouse clicking
	/** Given a screen's X coordinate , return the world's X coordinate */
	public float ScreenToWorldX(int screenCoord) {
		return ( ( (screenCoord << 1) - ScreenCoordWidthCenter) * WorldScreenRatioWidth );
	}

	/** Given a screen's Y coordinate , return the world's Y coordinate */
	public float ScreenToWorldY(int screenCoord) {
		return ( ( (screenCoord << 1) - ScreenCoordHeightCenter) * -WorldScreenRatioHeight );
	}

} // end class WorldScreenCoordinates