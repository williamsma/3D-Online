 // MFInt32.java
 // � 2003, 3D-Online, All Rights Reserved 
 // November 7, 2003

package d3d;

public class MFInt32 {

	int[] values = null;

	// constructor
	public MFInt32 () {
	}
	public MFInt32 (int size, int values[] ) {
		this.setValue( size, values );
	}
	public MFInt32 (int values[] ) {
		this.setValue( values );
	}

	// setValue
	public void setValue (int size, int values[] ) {
		this.values = new int[size];
		for (int i = 0; i < size; i++ ) {
			this.values[i] = values[i];
		}
	}
	public void setValue (int values[]) {
		setValue(values.length, values );
	}

	// getValue
	public int[] getValue( ) {
		return this.values;
	}
	public int get1Value(int index) {
		return this.values[index];
	}
	/** returns <I>values</I> separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < values.length; i++ ) {
			returnString += (values[i] + " ");
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFInt32
