 // IndexedLineSet.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002

package d3d;


public class IndexedLineSet extends IndexedSet {
	// all values contained in IndexedSet

	// constructor
	public IndexedLineSet () {
		datatype = VRMLdatatype.IndexedLineSet;
	}

} // end class IndexedLineSet
