/*
ScanLine.java
Property of 3D-Online, All Rights Reserved, Copyright, 2003
April 15, 2003
*/

package d3d;


public class ScanLine {

	int scanCurY;
	GraphicsDisplay gd = null;

	public boolean renderBuffer1;
	ColorLineProp colorLine  = null;
	LineProp leftLine  = null;
	LineProp rightLine = null;

   public ScanLine(GraphicsDisplay display) {
		gd = display;
		colorLine  = new ColorLineProp();
		leftLine  = new LineProp();
		rightLine = new LineProp();
	}

	private void ScanInit(PolygonClass polygon) {
		leftLine.SetUp(polygon);
		rightLine.SetUp(polygon);
		colorLine.SetUp(polygon);

		if ( polygon.vertex[0].x <= polygon.vertex[1].x) {
			rightLine.Step();
		}
		else {
			leftLine.Step();
			colorLine.Step();
		}
		scanCurY = (int)polygon.vertex[0].y;
	}

	private void GenScanDraw(){
		float red   = colorLine.colorX[Vertex.redIndex];
		float green = colorLine.colorX[Vertex.greenIndex];
		float blue  = colorLine.colorX[Vertex.blueIndex];
		float Z     = leftLine.zPos;
		int color;
		int yPos = scanCurY*gd.width;
		int rightPos = (int)Math.min( (gd.width-1), Math.ceil(rightLine.xPos) );
		if ( renderBuffer1 ) {
			for (int i = (int)Math.ceil(leftLine.xPos); i <= rightPos; i++) {
				if (gd.Zbuffer[i + yPos] < Z ) {
					gd.buffer1RGB[i + yPos]	=
						(0xff000000) | (((int)red) << 16) | (((int)green) << 8) | ((int) blue);
					gd.Zbuffer[i + yPos]  	  = Z;
				}
				red   += colorLine.colorXdiff[Vertex.redIndex];
				green += colorLine.colorXdiff[Vertex.greenIndex];
				blue  += colorLine.colorXdiff[Vertex.blueIndex];
				Z += leftLine.zDiffXDir;
			}
		}
		else { // renderBuffer2
			for (int i = (int)Math.ceil(leftLine.xPos); i <= rightPos; i++) {
				if (gd.Zbuffer[i + yPos] < Z ) {
					gd.buffer2RGB[i + yPos]	=
						(0xff000000) | (((int)red) << 16) | (((int)green) << 8) | ((int) blue);
					gd.Zbuffer[i + yPos]  	  = Z;
				}
				red   += colorLine.colorXdiff[Vertex.redIndex];
				green += colorLine.colorXdiff[Vertex.greenIndex];
				blue  += colorLine.colorXdiff[Vertex.blueIndex];
				Z += leftLine.zDiffXDir;
			}
		}
	}


	private void VerticalStepLine() {
		scanCurY++;
		colorLine.Step();
		leftLine.Step();
		rightLine.Step();
	}

	public void ScanConvert(PolygonClass polygon, boolean renderBuffer1_) {
		this.renderBuffer1 = renderBuffer1_;
		ScanInit(polygon);

		int height = (int) Math.abs( Math.ceil(polygon.vertex[0].y) - Math.ceil(polygon.vertex[1].y));
		for (int i = 0; i <= height; i++) {
			GenScanDraw(); // Does the actual writing
			VerticalStepLine();
		}
 	} // end ScanConvert

} // end class ScanLine