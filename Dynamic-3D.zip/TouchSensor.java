 // TouchSensor.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 20, 2002

package d3d;


public class TouchSensor extends Sensor {

	/** true when clicked on an interactive object */
	public boolean isActive = false;
	/** true when over an interactive object */
	public boolean isOver = false;
	/** time an object is clicked on */
	public long touchTime = 0;
	// set true when we act on isActive and can set it back to false later
	boolean isActiveCleared = false;

	public TouchSensor() {
		datatype = VRMLdatatype.TouchSensor;
	}

}//end class TouchSensor
