 // Cylinder.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;


public class Cylinder extends IndexedFaceSet {

	public static final boolean bottom = true;
	public static final  float height = 2;
	public static final  float radius = 1;
	public static final  boolean side = true;
	public static final  boolean top = true;

	private float[][] cylinderPoints = {
		//bottom
		{0, -1, 0},
		{1, -1, 0}, {0.924f, -1, -0.383f}, {0.707f, -1, -0.707f}, {0.383f, -1, -0.924f}, 
		{0, -1, -1}, {-0.383f, -1, -0.924f}, {-0.707f, -1, -0.707f}, {-0.924f, -1, -0.383f}, 
		{-1, -1, 0}, {-0.924f, -1, 0.383f}, {-0.707f, -1, 0.707f}, {-0.383f, -1, 0.924f}, 
		{0, -1, 1}, {0.383f, -1, 0.924f}, {0.707f, -1, 0.707f}, {0.924f, -1, 0.383f},
		//top 
		{1, 1, 0}, {0.924f, 1, -0.383f}, {0.707f, 1, -0.707f}, {0.383f, 1, -0.924f}, 
		{0, 1, -1}, {-0.383f, 1, -0.924f}, {-0.707f, 1, -0.707f}, {-0.924f, 1, -0.383f}, 
		{-1, 1, 0}, {-0.924f, 1, 0.383f}, {-0.707f, 1, 0.707f}, {-0.383f, 1, 0.924f}, 
		{0, 1, 1}, {0.383f, 1, 0.924f}, {0.707f, 1, 0.707f}, {0.924f, 1, 0.383f}, 
		{0, 1, 0}
		};

	private int[] coordIndexBottom  = {
		0, 2, 1, -1, 0, 3, 2, -1, 0, 4, 3, -1, 0, 5, 4, -1,
		0, 6, 5, -1, 0, 7, 6, -1, 0, 8, 7, -1, 0, 9, 8, -1,
		0, 10, 9, -1, 0, 11, 10, -1, 0, 12, 11, -1, 0, 13, 12, -1,
		0, 14, 13, -1, 0, 15, 14, -1, 0, 16, 15, -1, 0, 1, 16, -1
	};
	private int[] coordIndexSides  = {
		1, 18, 17, -1, 1, 2, 18, -1, 2, 19, 18, -1, 2, 3, 19, -1,
		3, 20, 19, -1, 3, 4, 20, -1, 4, 21, 20, -1, 4, 5, 21, -1,
		5, 22, 21, -1, 5, 6, 22, -1, 6, 23, 22, -1, 6, 7, 23, -1,
		7, 24, 23, -1, 7, 8, 24, -1, 8, 25, 24, -1, 8, 9, 25, -1,
		9, 26, 25, -1, 9, 10, 26, -1, 10, 27, 26, -1, 10, 11, 27, -1,
		11, 28, 27, -1, 11, 12, 28, -1, 12, 29, 28, -1, 12, 13, 29, -1,
		13, 30, 29, -1, 13, 14, 30, -1, 14, 31, 30, -1, 14, 15, 31, -1,
		15, 32, 31, -1, 15, 16, 32, -1, 16, 17, 32, -1, 16, 1, 17, -1
	};
	private int[] coordIndexTop  = {
		33, 17, 18, -1, 33, 18, 19, -1, 33, 19, 20, -1, 33, 20, 21, -1,
		33, 21, 22, -1, 33, 22, 23, -1, 33, 23, 24, -1, 33, 24, 25, -1,
		33, 25, 26, -1, 33, 26, 27, -1, 33, 27, 28, -1, 33, 28, 29, -1,
		33, 29, 30, -1, 33, 30, 31, -1, 33, 31, 32, -1, 33, 32, 17, -1
	};
	private int[] cylinderCoordIndex = null;




	private void SetRadius (float radius ) {
		// mulitply x and z value by bottomRadius, default is 1
		for (int i = 0; i < this.cylinderPoints.length; i++) {
			this.cylinderPoints[i][0] *= radius;
			this.cylinderPoints[i][2] *= radius;
		}
	} // end SetRadius

	private void SetHeight (float height ) {
		//height /= 1;
		// mulitply y value by height, default is 2
		for (int i = 0; i < this.cylinderPoints.length; i++) {
			this.cylinderPoints[i][1] *= height/2;
		}
	} // end SetHeight

	// Constructors
	private void CylinderConstructor(boolean bottomValue, boolean sideValue, boolean topValue) {
		//coord = new Coordinate();
		this.coord = new Coordinate();
		Coordinate coord = (Coordinate) this.coord;
		coord.point.setValue(cylinderPoints);

		int totalCoordIndex = 0;
		if (bottomValue) {
			totalCoordIndex = coordIndexBottom.length;
		}
		if (sideValue) {
			totalCoordIndex += coordIndexSides.length;
		}
		if (topValue) {
			totalCoordIndex += coordIndexTop.length;
		}
		cylinderCoordIndex = new int[totalCoordIndex];

		totalCoordIndex = 0;
		if (bottomValue) {
			for (int i = 0; i < coordIndexBottom.length; i++) {
				cylinderCoordIndex[i] = coordIndexBottom[i];
			}
			totalCoordIndex = coordIndexBottom.length;
		}
		if (sideValue) {
			for (int i = 0; i < coordIndexSides.length; i++) {
				cylinderCoordIndex[i + totalCoordIndex] = coordIndexSides[i];
			}
			totalCoordIndex += coordIndexSides.length;
		}
		if (topValue) {
			for (int i = 0; i < coordIndexTop.length; i++) {
				cylinderCoordIndex[i + totalCoordIndex] = coordIndexTop[i];
			}
			totalCoordIndex += coordIndexTop.length;
		}
		this.coordIndex = new MFInt32(cylinderCoordIndex.length, cylinderCoordIndex);
		this.creaseAngle.setValue(.5f);
	} // end CylinderConstructor

	public Cylinder() {
		CylinderConstructor(true, true, true);
	}

	public Cylinder(boolean bottomValue, float height, float radius, boolean sideValue, boolean topValue) {
		SetRadius(radius);
		SetHeight(height);
		CylinderConstructor(bottomValue, sideValue, topValue);
	} // end Constructor

}//end class Cylinder
