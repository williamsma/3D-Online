 // SFBool.java
 // � 2003, 3D-Online, All Rights Reserved 
 // October 31, 2003

package d3d;

public class SFBool {

	boolean value;

	// constructor
	public SFBool () {
	}
	public SFBool (boolean bool) {
		this.setValue ( bool );
	}

	// setValue
	public void setValue (boolean bool ) {
		this.value = bool;
	}

	// getValue
	public boolean getValue( ) {
		return this.value;
	}
	/** returns boolean value as a string */
	public String toString( ) {
		String returnString = value + "";
		return returnString;
	}

} // end SFString
