// GraphicsEngineControllerAbstract.java
// � 2004, 3D-Online, All Rights Reserved 
// March 1, 2004
 // In memory of Alan Arinsberg, who took his life and was laid to rest on Feb. 23, 2004

package d3d;


public abstract interface GraphicsEngineControllerAbstract {

	// constructor
	//public GraphicsEngineControllerAbstract () {}

	public abstract void customInitialize();
	public abstract void finalize();

} // end GraphicsEngineControllerAbstract class
