 // Transform.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 29, 2002

package d3d;



public class Transform extends Group {

	public SFVec3f center = new SFVec3f();  // init value is 0,0,0
	public SFRotation rotation = new SFRotation(0, 0, 1, 0);
	public SFVec3f scale = new SFVec3f(1, 1, 1);
	public SFRotation scaleOrientation = new SFRotation(0, 0, 1, 0);
	public SFVec3f translation = new SFVec3f(); // init value is 0,0,0

	Matrix3x3 rotationMatrix = new Matrix3x3();

	// constructor
	public Transform () {
		datatype = VRMLdatatype.Transform;
	}

}
