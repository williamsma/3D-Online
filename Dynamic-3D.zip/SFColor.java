 // SFColor.java
 // � 2003, 3D-Online, All Rights Reserved 
 // October 31, 2003

package d3d;

public class SFColor {

	float[] color = new float[3];

	// constructor
	public SFColor () {
	}
	public SFColor (float red, float green, float blue) {
		this.setValue ( red,  green,  blue );
	}

	// setValue
	public void setValue (float[] colors ) {
		for (int i = 0; i < colors.length; i++) { this.color[i] = colors[i]; };
	}
	public void setValue (float red, float green, float blue) {
		this.color[0] = red;
		this.color[1] = green;
		this.color[2] = blue;
	}

	// getValue
	public float[] getValue( ) {
		return this.color;
	}
	public float getRed() {
		return this.color[0];
	}
	public float getGreen() {
		return this.color[1];
	}
	public float getBlue() {
		return this.color[2];
	}
	/** returns <I>red</I>, <I>green</I> and <I>blue</I> separated by space characters */
	public String toString( ) {
		String returnString = color[0] + " " + color[1] + " " + color[2];
		return returnString;
	}
} // end SFColor
