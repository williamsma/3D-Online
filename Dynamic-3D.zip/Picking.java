/* Picking.java
* - created September 24, 2003
Property of 3D-Online, All Rights Reserved, Copyright, 2003
*/

package d3d;
import java.lang.Integer;

public class Picking {

	static final int xIndex = 0;
	static final int yIndex = 1;
	static final int zIndex = 2;
	static final float NoIntersection = java.lang.Float.NEGATIVE_INFINITY;

	WorldScreenCoordinates coordSys;
	float worldXpos = java.lang.Float.POSITIVE_INFINITY;
	float worldYpos = java.lang.Float.POSITIVE_INFINITY;

	final int totalVertices = 3;
	public float[][] vertex = new float[3][3];

//int xxx = 0;
	public Picking(WorldScreenCoordinates coordSys_) {
		coordSys = coordSys_;
   } // end Constructor


	public void SetMousePos(int mouseXpos, int mouseYpos) {
		worldXpos = coordSys.ScreenToWorldX( mouseXpos );
		worldYpos = coordSys.ScreenToWorldY( mouseYpos );
	} // end SetMousePos


	public boolean BoundingBoxPicked( Coordinate coordinate ) {
		boolean returnPicked = false;
		// ray-box intersection, pg. 23, "Realistic Ray Tracing"
		float dx = worldXpos; // save x and y so we don't get mouse movement
		float dy = worldYpos;
		float dz = coordSys.distance;
		float xMin, xMax, yMin, yMax, zMin, zMax;
		float t0, t1;
		if (dx > 0) {
			xMin = coordinate.min[MathOps.xIndex] / dx;
			xMax = coordinate.max[MathOps.xIndex] / dx;
		}
		else if (dx < 0){
			xMin = coordinate.max[MathOps.xIndex] / dx;
			xMax = coordinate.min[MathOps.xIndex] / dx;
		}
		else {
			xMin = coordinate.max[MathOps.xIndex];
			xMax = coordinate.min[MathOps.xIndex];
		}

		if (dy > 0) {
			yMin = coordinate.min[MathOps.yIndex] / dy;
			yMax = coordinate.max[MathOps.yIndex] / dy;
		}
		else if (dy < 0){
			yMin = coordinate.max[MathOps.yIndex] / dy;
			yMax = coordinate.min[MathOps.yIndex] / dy;
		}
		else {
			yMin = coordinate.max[MathOps.yIndex];
			yMax = coordinate.min[MathOps.yIndex];
		}

		if ( -dz > 0) {
			zMin = coordinate.min[MathOps.zIndex] / -dz;
			zMax = coordinate.max[MathOps.zIndex] / -dz;
		}
		else {
			zMin = coordinate.max[MathOps.zIndex] / -dz;
			zMax = coordinate.min[MathOps.zIndex] / -dz;
		}

		if (xMin > yMin) t0 = xMin;
		else t0 = yMin;
		if (zMin > t0) t0 = zMin;

		if (xMax < yMax) t1 = xMax;
		else t1 = yMax;
		if (zMax < t1) t1 = zMax;
		/*
if (t0 == t1) {
	System.out.println("t0 == t1");
	returnPicked = true;
}
*/
		if (t0 <= t1) returnPicked = true;
		//if (t0 < t1) returnPicked = true;
		return returnPicked;
	} // end BoundingBoxPicked


	//public float PolygonPicked( PolygonClass polygonClass ) {
	public float PolygonPicked( ) {
		// based on equations from "Realistic Ray Tracing, Peter Shirley, pg. 28 equation
		float a, b, c, d, e, f, j, k, l; // inputs
		float M, Beta, Gamma, t; // ending values
		t = NoIntersection;

		/*

		| ax - bx	ax - cx	dx	|		| Beta  |		| ax - Ox |
		| ay - by	ay - cy	dy	|	*	| Gamma |	=	| ay - Oy |
		| az - bz	az - cz	dz	|		|   t   |		| az - Oz |

		(Ox, Oy, Oz) = origin at (0, 0, 0)
		dx = screenXpos
		dy = screenYpos
		dz = distance

		|    a		   d		g	|		| Beta  |		| j |
		|    b		   e		h	|	*	| Gamma |	=	| k |
		|    c		   f		i	|		|   t   |		| l |

		*/

		a = vertex[0][xIndex] - vertex[1][xIndex];
		b = vertex[0][yIndex] - vertex[1][yIndex];
		c = vertex[0][zIndex] - vertex[1][zIndex];

		d = vertex[0][xIndex] - vertex[2][xIndex];
		e = vertex[0][yIndex] - vertex[2][yIndex];
		f = vertex[0][zIndex] - vertex[2][zIndex];

		/*
		a = polygon.vertex[0].x - polygon.vertex[1].x;
		b = polygon.vertex[0].y - polygon.vertex[1].y;
		c = polygon.vertex[0].z - polygon.vertex[1].z;

		d = polygon.vertex[0].x - polygon.vertex[2].x;
		e = polygon.vertex[0].y - polygon.vertex[2].y;
		f = polygon.vertex[0].z - polygon.vertex[2].z;
		*/


		//g = worldXpos
		//h = worldYpos
		//i = -coordSys.distance
		j = vertex[0][xIndex];
		k = vertex[0][yIndex];
		l = vertex[0][zIndex];

		float eiMINUShf, gfMINUSdi, dhMINUSeg; // used in M and beta so we do it once
		eiMINUShf = (e * (-coordSys.distance)) - (worldYpos * f); 
		gfMINUSdi = (worldXpos * f) - (d * (-coordSys.distance) );
		dhMINUSeg = (d * worldYpos) - (e * worldXpos);

		M = a * eiMINUShf + b * gfMINUSdi + c * dhMINUSeg; 
		Beta = (j * eiMINUShf + k * gfMINUSdi + l * dhMINUSeg) / M; 

		float akMINUSjb, jcMINUSal, blMINUSkc; // used in Gamma and t so we do it once
		akMINUSjb = a*k - j*b;
		jcMINUSal = j*c - a*l;
		blMINUSkc = b*l - k*c;
		Gamma = ( (-coordSys.distance) * akMINUSjb + worldYpos * jcMINUSal + worldXpos * blMINUSkc ) / M;
		if ( (Beta + Gamma < 1) && (Beta > 0) && (Gamma > 0) ) {
			t = ( f * akMINUSjb + e * jcMINUSal + d * blMINUSkc ) / M;
		}
		return t;
	} // end PolygonPicked



} // end class Picking