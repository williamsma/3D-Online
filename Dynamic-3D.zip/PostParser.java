// PostParser.java
// Formerly Parser2.java
// � 2002, 3D-Online, All Rights Reserved 
// April 19, 2002
// Inspects all the nodes and generates Normals, missing Viewpoint, etc.
// Dedicated to Terry Nishimura who passed away in 2002 - first colleague at Xerox

package d3d;

import java.lang.Math;

public class PostParser {

	final int xIndex = 0;
	final int yIndex = 1;
	final int zIndex = 2;
	final int notSet = -1; // used to create vertex normals

	int objectNumber = 0;


	//private void CreatePolygonNormals (Shape shape) {
	private void CreatePolygonNormals (IndexedFaceSet indexedFaceSet) {
		float[] vector1 = new float[3]; 			
		float[] vector2 = new float[3]; 
		float[] polygonNormal  = new float[3];	
 		/*** assumes triangles and coordIndex vertex sets ends with -1, as in {0, 1, 2, -1, 0, 3, 2 -1} ***********/
		//for (int i = 0; i <  shape.indexedFaceSet.coordIndex.values.length/4; i++) {
		Coordinate coord = (Coordinate) indexedFaceSet.coord;
		for (int i = 0; i <  (indexedFaceSet.coordIndex.values.length/4); i++) {
			for (int k = 0; k < 3; k++) {
				vector1[k] = coord.point.vec3s[ indexedFaceSet.coordIndex.values[i*4 + 1]][k] -
					coord.point.vec3s[ indexedFaceSet.coordIndex.values[i*4] ][k];
				vector2[k] = coord.point.vec3s[ indexedFaceSet.coordIndex.values[i*4 +2]][k] -
					coord.point.vec3s[ indexedFaceSet.coordIndex.values[i*4 + 1]][k];
			}
			polygonNormal =  MathOps.CrossProduct(vector1, vector2);
			indexedFaceSet.normalPolygon.vector.vec3s[i] =  MathOps.NormalizeVector(polygonNormal);
		} // end for i = 0; i < totalPolygons
		for (int i = 0; i < indexedFaceSet.normalPolygonIndex.length; i++) {
			indexedFaceSet.normalPolygonIndex[i] = i;
		}
	} // end CreatePolygonNormals


	//private void CreateVertexNormals (Shape shape) {
	private void CreateVertexNormals (IndexedFaceSet indexedFaceSet) {
		Coordinate coord = (Coordinate) indexedFaceSet.coord;
		indexedFaceSet.normalVertexIndex = new int[(indexedFaceSet.coordIndex.values.length/4)][3];	
		for (int i = 0; i < indexedFaceSet.normalVertexIndex.length; i++) {
			for (int j = 0; j < 3; j++) {
				indexedFaceSet.normalVertexIndex[i][j] = notSet;
			}
		}

		int vertexNumber = 0;
		int[][] normalVertexIndexes = new int[(indexedFaceSet.coordIndex.values.length/4)][3];
		for (int i = 0; i < normalVertexIndexes.length; i++) {
			for (int j = 0; j < 3; j++) {
				normalVertexIndexes[i][j] = notSet;
			}
		}
		float[] matchingVertex = new float[3];

		for (int i = 0; i < (indexedFaceSet.coordIndex.values.length/4); i++) {
			for (int j = 0; j < 3; j++) {
				for (int k = 0; k < 3; k++) {
					matchingVertex[k] = coord.point.vec3s[indexedFaceSet.coordIndex.values[i*4 + j]][k];
				}

				for (int m = 0; m < (indexedFaceSet.coordIndex.values.length/4); m++) {
					for (int n = 0; n < 3; n++) {
						if (	(matchingVertex[0] == coord.point.vec3s[indexedFaceSet.coordIndex.values[m*4 + n]][0]) &&				
								(matchingVertex[1] == coord.point.vec3s[indexedFaceSet.coordIndex.values[m*4 + n]][1]) &&				
								(matchingVertex[2] == coord.point.vec3s[indexedFaceSet.coordIndex.values[m*4 + n]][2]) ) {
							float creaseAngle =	indexedFaceSet.normalPolygon.vector.vec3s[i][0] * indexedFaceSet.normalPolygon.vector.vec3s[m][0] +
														indexedFaceSet.normalPolygon.vector.vec3s[i][1] * indexedFaceSet.normalPolygon.vector.vec3s[m][1] +
														indexedFaceSet.normalPolygon.vector.vec3s[i][2] * indexedFaceSet.normalPolygon.vector.vec3s[m][2];
							//if (creaseAngle > (float) Math.cos(shape.indexedFaceSet.creaseAngle.value) ) {
							//if (creaseAngle >= (float) Math.cos(shape.indexedFaceSet.creaseAngle.value) ) {
							if (creaseAngle >= (float) Math.cos(indexedFaceSet.creaseAngle.f) ) {
								if ( (normalVertexIndexes[m][n] == notSet) && (normalVertexIndexes[i][j] == notSet) ) {
									normalVertexIndexes[i][j] = vertexNumber;
									normalVertexIndexes[m][n] = vertexNumber;
									vertexNumber++;
								}
								else if (normalVertexIndexes[m][n] != notSet) {
									normalVertexIndexes[i][j] = normalVertexIndexes[m][n];
								}
								else if (normalVertexIndexes[i][j] != notSet) {
									normalVertexIndexes[m][n] = normalVertexIndexes[i][j];
								}
							} // end if (creaseAngle > shape.indexedFaceSet.creaseAngleRadians)
						} // end if common vertex
					}  // end for n loop
				}  // end for m loop
			} // end for j loop
		}  //  end for i loop

		// Compute Vertex normal
		// 1) Add all polygon normals sharing a vertex
		//indexedFaceSet.normalVertex.vector = new float[vertexNumber][3];
		//indexedFaceSet.normalVertex.vector.vec3s = new float[vertexNumber][3];
		Normal normalVertex = (Normal) indexedFaceSet.normal;
		normalVertex.vector.vec3s = new float[vertexNumber][3];

		int vnCounter = 0;
		float[] cummulativePolygonNormals = new float[3];
		for (int vn = 0; vn < vertexNumber; vn++) {
			for (int i = 0; i < 3; i++) {
				cummulativePolygonNormals[i] = 0;
			}
			for (int i = 0; i < (indexedFaceSet.coordIndex.values.length/4); i++) {
				for (int j = 0; j < 3; j++) {
					if ( normalVertexIndexes[i][j] == vn) {
						for (int k = 0; k < 3; k++) {
							cummulativePolygonNormals[k] += indexedFaceSet.normalPolygon.vector.vec3s[i][k];
						}
						vnCounter++;
					}
				}
			}

			// Get the normal average, and Normalize
			for (int i = 0; i < 3; i++) {
				cummulativePolygonNormals[i] /= vnCounter;
			}
			//indexedFaceSet.normalVertex.vector.vec3s[vn] =  MathOps.NormalizeVector(cummulativePolygonNormals);
			normalVertex.vector.vec3s[vn] =  MathOps.NormalizeVector(cummulativePolygonNormals);
			vnCounter = 0;
		}

		for (int m = 0; m < (indexedFaceSet.coordIndex.values.length/4); m++) {
			for (int n = 0; n < 3; n++) {
				indexedFaceSet.normalVertexIndex[m][n] = normalVertexIndexes[m][n];
			}
		}
	} // CreateVertexNormals



	private void CreateBoundingBox (Shape shape) {
		float[] maxBBoxSize = { java.lang.Float.NEGATIVE_INFINITY, java.lang.Float.NEGATIVE_INFINITY, java.lang.Float.NEGATIVE_INFINITY };
		float[] minBBoxSize = { java.lang.Float.POSITIVE_INFINITY, java.lang.Float.POSITIVE_INFINITY, java.lang.Float.POSITIVE_INFINITY };
		//Coordinate coordinate = shape.geometry.coord;
		Coordinate coordinate = null;
		//IndexedSet indexedSet = (IndexedSet) shape.geometry;
		//coordinate = indexedSet.coord;
		if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
			IndexedSet indexedSet = (IndexedSet) shape.geometry;
			coordinate = (Coordinate) indexedSet.coord;
		}
		else if (shape.geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) shape.geometry;
			//coordinate = pointSet.coord;
			coordinate = (Coordinate) pointSet.coord;
		}
		if (coordinate != null) {
			for (int i = 0; i < coordinate.point.vec3s.length; i++) {
				for (int j = 0; j < 3; j++) {
					if ( maxBBoxSize[j] < coordinate.point.vec3s[i][j] ) {
						maxBBoxSize[j] = coordinate.point.vec3s[i][j];
					}
					if ( minBBoxSize[j] > coordinate.point.vec3s[i][j] ) {
						minBBoxSize[j] = coordinate.point.vec3s[i][j];
					}
				}
			} // end for i < coord.point.vec3s
			for (int j = 0; j < 3; j++) {
				coordinate.bboxCenter[j] = (maxBBoxSize[j] + minBBoxSize[j]) / 2;
				coordinate.bboxSize[j] = maxBBoxSize[j] - coordinate.bboxCenter[j];
			}
		} // end coordinate != null
		// set up vertices for bounding box
		for (int i = 0; i < coordinate.bboxVertices.length; i++) {
			for (int j = 0; j < 3; j++) {
				if (i < 4) { // front vertices
					coordinate.bboxVertices[i][MathOps.zIndex] = coordinate.bboxSize[MathOps.zIndex] + coordinate.bboxCenter[MathOps.zIndex];
				}
				else { // back vertices
					coordinate.bboxVertices[i][MathOps.zIndex] = -coordinate.bboxSize[MathOps.zIndex] + coordinate.bboxCenter[MathOps.zIndex];
				}
				if ( (i == 0) || (i == 1) || (i == 4) || (i == 5) ) {  // left vertices
					coordinate.bboxVertices[i][MathOps.xIndex] = -coordinate.bboxSize[MathOps.xIndex] + coordinate.bboxCenter[MathOps.xIndex];
				}
				else { // right vertices
					coordinate.bboxVertices[i][MathOps.xIndex] = coordinate.bboxSize[MathOps.xIndex] + coordinate.bboxCenter[MathOps.xIndex];
				}
				if ( ((i >> 1) << 1) == i) { // top vertices
					coordinate.bboxVertices[i][MathOps.yIndex] = coordinate.bboxSize[MathOps.yIndex] + coordinate.bboxCenter[MathOps.yIndex];
				}
				else { // bottom vertices
					coordinate.bboxVertices[i][MathOps.yIndex] = -coordinate.bboxSize[MathOps.yIndex] + coordinate.bboxCenter[MathOps.yIndex];
				}
			}
			//System.out.println("         " + i + " (" + coordinate.bboxVertices[i][MathOps.xIndex] + " " + coordinate.bboxVertices[i][MathOps.yIndex] + " " + coordinate.bboxVertices[i][MathOps.zIndex] + ")" );
		}
	} // end Creation of Bounding Box



	public void CreateNormals_BoundingBox (Shape shape) {
		// create the Vertex and Polygon normals
		if (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) {
			IndexedFaceSet indexedFaceSet = (IndexedFaceSet) shape.geometry;

			Normal normalPolygon = new Normal();
			indexedFaceSet.normalPolygon = normalPolygon;
			indexedFaceSet.normalPolygonIndex = new int[(indexedFaceSet.coordIndex.values.length/4)];	
			//normalPolygon.setVectorSize( (indexedFaceSet.coordIndex.values.length/4) );	
			normalPolygon.vector = new MFVec3f();	
			normalPolygon.vector.vec3s = new float[indexedFaceSet.coordIndex.values.length/4][3];	
			CreatePolygonNormals ( indexedFaceSet );
			//Normal normal = null;
			if (indexedFaceSet.normal == null) { // be sure not to set new normal in case of CoordInterpolator
				indexedFaceSet.normal = new Normal();	// normal not previously created								 
			}
			Normal normal = (Normal) indexedFaceSet.normal;									 
			if ( indexedFaceSet.normalStream.size() == 0) {
				if ( indexedFaceSet.normalPerVertex.value ) {
					CreateVertexNormals ( indexedFaceSet );
				}
				else { // vertex normals same as polygon normals
//System.out.println("need to implement normalPerVertex = false");
					normal.vector.vec3s = new float[normalPolygon.vector.vec3s.length*3][3];	
					for ( int i = 0; i < normalPolygon.vector.vec3s.length; i++) {
						for (int k = 0; k < 3; k++) {
//System.out.print("normal.vector.vec3s["+((i*3)+k)+"] = ");
							for (int j = 0; j < 3; j++) {
								normal.vector.vec3s[(i*3)+k][j] = normalPolygon.vector.vec3s[i][j];
//System.out.print(normal.vector.vec3s[(i*3)+k][j] + ", ");
							}
//System.out.println();
						}
					}
					indexedFaceSet.normalVertexIndex = new int[normal.vector.vec3s.length/3][3];	
//System.out.println("indexedFaceSet.normalVertexIndex.length = " + indexedFaceSet.normalVertexIndex.length);	
					for ( int i = 0; i < indexedFaceSet.normalVertexIndex.length; i++) {
						//for (int k = 0; k < 3; k++) {
							for (int j = 0; j < 3; j++) {
								//indexedFaceSet.normalVertexIndex[(i*3)+k][j] = i;
								indexedFaceSet.normalVertexIndex[i][j] = (i*3) + j;
//System.out.println("      indexedFaceSet.normalVertexIndex["+i+"]["+j+"] = " + indexedFaceSet.normalVertexIndex[i][j] );
							}
						//}
					}
				} // end normalPerVertex == false
			} // normals not included in VRML/X3D file
			else { // vertex normals and possibly normalindexes supplied by file
				//normal = (Normal) indexedFaceSet.normal; // Normal already created in Lex Analyzer									 
				Float fl;
				for ( int i = 0; i < normal.vector.vec3s.length; i++) {
					for (int j = 0; j < 3; j++) {
						fl = new Float( indexedFaceSet.normalStream.elementAt((i*3)+j).toString() );
						normal.vector.vec3s[i][j] = fl.floatValue();
					}
				}
				// set the normals indexes
				if ( indexedFaceSet.normalPerVertex.value ) {
					if (indexedFaceSet.normalIndexStream.size() == 0) {
						// vertex normals not supplied, use coordindex values
						indexedFaceSet.normalVertexIndex = new int[indexedFaceSet.coordIndex.values.length/4][3];	
						for ( int i = 0; i < indexedFaceSet.normalVertexIndex.length; i++) {
							for (int j = 0; j < 3; j++) {
								indexedFaceSet.normalVertexIndex[i][j] = indexedFaceSet.coordIndex.values[i*4 + j];
							}
						}
					} // end normalIndex == 0
					else { // use the normalIndex that came with the VRML/X3D file
						indexedFaceSet.normalVertexIndex = new int[indexedFaceSet.normalIndexStream.size()][3];	
						Integer il;
						for ( int i = 0; i < (indexedFaceSet.normalVertexIndex.length/4); i++) {
							for (int j = 0; j < 3; j++) {
								il = new Integer( indexedFaceSet.normalIndexStream.elementAt( (i*4)+j).toString() );
								if (il.intValue() != -1) {
									indexedFaceSet.normalVertexIndex[i][j] = il.intValue();
								}
							}
						}
					}  // end normalIndex != 0
				} // normalPerVertex == true
				else { // normalPerVertex == false
					if (indexedFaceSet.normalIndexStream.size() == 0) {
						// no NormalIndex, just count up 0, 1, 2, 3 ...
						indexedFaceSet.normalVertexIndex = new int[normal.vector.vec3s.length][3];	
						for ( int i = 0; i < indexedFaceSet.normalVertexIndex.length; i++) {
							for (int j = 0; j < 3; j++) {
								indexedFaceSet.normalVertexIndex[i][j] = i;
//System.out.println("indexedFaceSet.normalVertexIndex["+i+"]["+j+"] = " + indexedFaceSet.normalVertexIndex[i][j] );
							}
						}
					}  // end normalIndex == 0
					else { // use the normalIndex that came with the VRML/X3D file
						// each vertex will have the polygon normal
						Integer il;
						int normalIndexTotal = indexedFaceSet.normalIndexStream.size();
						il = new Integer( indexedFaceSet.normalIndexStream.elementAt(normalIndexTotal-1).toString() );
						if (il.intValue() == -1) normalIndexTotal--;
						indexedFaceSet.normalVertexIndex = new int[normalIndexTotal][3];	
						for ( int i = 0; i < indexedFaceSet.normalVertexIndex.length; i++) {
							il = new Integer( indexedFaceSet.normalIndexStream.elementAt(i).toString() );
							for (int j = 0; j < 3; j++) {
								indexedFaceSet.normalVertexIndex[i][j] = il.intValue();
//System.out.println("indexedFaceSet.normalVertexIndex["+i+"]["+j+"] = " + indexedFaceSet.normalVertexIndex[i][j] );
							}
						}
					}   // end normalIndex != 0
				}  // normalPerVertex == false
			} // end Normals provided
			//normalVertex.ConstructTransformedVectors(); 
			normal.transformedVector = new float[normal.vector.vec3s.length][3]; 
			//if (normalPolygon.transformedVector == null) normalPolygon.ConstructTransformedVectors(); 
			if (normalPolygon.transformedVector == null) normalPolygon.transformedVector = new float[normalPolygon.vector.vec3s.length][3]; 
		} // end if (shape.geometry == indexedFaceSet)

		CreateBoundingBox( shape );

		Coordinate coordinate = null;
		if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
			IndexedSet indexedSet = (IndexedSet) shape.geometry;
			coordinate = (Coordinate) indexedSet.coord;
		}
		else if (shape.geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) shape.geometry;
			coordinate = (Coordinate) pointSet.coord;
		}
		if ( coordinate.transformedPoint == null) coordinate.ConstructTransformedPoints();
	} // end CreateNormals_BoundingBox



	// constructor
	//public PostParser (Group root, Background background, GraphicsDisplay display) {
	//public PostParser (SFNode root, Background background, GraphicsDisplay display) {
	public PostParser (Group root, Background background, GraphicsDisplay display) {
		root.matrix4x4.setIdentityMatrix();
		// set the background based on parameters or the Background VRML node
		int[] bg = {255, 255, 255};
		for (int i = 0; i < 3; i++) {
			bg[i] = Math.min(bg[i], (int)Math.abs(background.skyColor.colors[0][i]*255) );
		}
		display.InitializeBackground( bg );
	}

	public void SceneGraph_CreateNormalsBoundingBox (SFNode root) {
		/*
		root.matrix4x4.setIdentityMatrix();
		// set the background based on parameters or the Background VRML node
		int[] bg = {255, 255, 255};
		for (int i = 0; i < 3; i++) {
			bg[i] = Math.min(bg[i], (int)Math.abs(background.skyColor.colors[0][i]*255) );
		}
		display.InitializeBackground( bg );
		*/

		//SFNode currentNode = root;
		SFNode currentNode = root.children;
		//while (currentNode != null) {
		while (currentNode != root) {
			if ( (currentNode.touchSensor == null) && (currentNode.parent != null) ){
				currentNode.touchSensor = currentNode.parent.touchSensor;
				currentNode.objectNumber = currentNode.parent.objectNumber;
			}
			else if (currentNode.touchSensor !=  null) {
				currentNode.objectNumber = objectNumber;
				objectNumber++;
			}
			if (currentNode.datatype == VRMLdatatype.Anchor) {
				currentNode.touchSensor = currentNode;
				currentNode.objectNumber = objectNumber;
				objectNumber++;
			} // end if node == Anchor
			else if (currentNode.datatype == VRMLdatatype.Shape) {
				Shape shape = (Shape) currentNode;
				/*
				Coordinate coordinate = null;
				if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
					IndexedSet indexedSet = (IndexedSet) shape.geometry;
					coordinate = (Coordinate) indexedSet.coord;
				}
				else if (shape.geometry.datatype == VRMLdatatype.PointSet) {
					PointSet pointSet = (PointSet) shape.geometry;
					coordinate = (Coordinate) pointSet.coord;
				}
				*/
				CreateNormals_BoundingBox ( shape );
				/*
				coordinate.ConstructTransformedPoints(); 
				*/
				//CreateNormals_BoundingBox ( shape );
			} // end currentNode == Shape

			// Get next node
			if (currentNode.children != null) {
				currentNode = currentNode.children;
			}
			else if (currentNode.next == null) {
				currentNode = currentNode.parent;
				while ( (currentNode != root) && (currentNode.next == null) ) {
					currentNode = currentNode.parent;
				}
				//currentNode = currentNode.next;
				if ( currentNode != root) currentNode = currentNode.next;
			} // end currentNode.next == null, go to parent.next
			else {
				currentNode = currentNode.next;
			}
		} // end while loop
	} //end Constructor

}  // end PostParser
