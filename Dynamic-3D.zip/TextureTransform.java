 // TextureTransform.java
 // � 2003, 3D-Online, All Rights Reserved 
 // November 10, 2003

package d3d;

public class TextureTransform extends SFNode {

	public SFVec2f center = new SFVec2f(0, 0);
	public SFFloat rotation = new SFFloat(0);
	public SFVec2f scale = new SFVec2f(1, 1);
	public SFVec2f translation = new SFVec2f(0, 0);

	// constructor
	public TextureTransform () {
		datatype = VRMLdatatype.TextureTransform;
	}


} // end TextureTransform

