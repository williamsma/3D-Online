/*	
	Company:		3D-Online.com
	Class:		Matrix4x4.java
	Date:			February 9, 2002
	Description:	Class functions for constructing and manipulating a 4 x 4 matrix
	(C) Copyright 3D-Online.com - 2001 - All rights reserved
*/

package d3d;


public class Matrix4x4 {

	float[][] values = {	{0, 0, 0, 0},
								{0, 0, 0, 0},
								{0, 0, 0, 0},
								{0, 0, 0, 0} };
	float[] quaternion = { 0,1,0,0 };

	// Constructor
	public Matrix4x4() { }



	/** Sets identity matrix for a 4 x 4 matrice */
	public void setIdentityMatrix() {
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				if ( i == j ) this.values[i][j] = 1;
				else this.values[i][j] = 0;
			}
		}
	} // end setIdentityMatrix

	/* 
	public void writeMatrix() {
 		//System.out.println("   print Matrix:");
		for (int i=0; i < 4; i++) {
			System.out.print("       ");
			for (int j=0; j < 4; j++) {
				System.out.print(this.values[i][j] + " ");
			}
	 		System.out.println();
		}
 		System.out.println();
	}
	/* */



	/** Calls <I>MathOps.AxisAngleToQuaternion</I>, saves value in Matrix4x4's quaternion value */
	public void convertAxisAngleToQuaternion(float[] axisAngle ) {
		this.quaternion = MathOps.AxisAngleToQuaternion( axisAngle ); 
	}


	/** Converts Matrix4x4.quaternion to Matrix4x4.matrix*/
	public void convertQuaternionToMatrix() {
		double[] sqr = new double[quaternion.length];
		for (int i = 0; i < quaternion.length; i++) {
			sqr[i] = Math.pow(this.quaternion[i], 2);
		}
		double xw = this.quaternion[ MathOps.quatXidx ] * this.quaternion[ MathOps.quatWidx ];
		double xy = this.quaternion[ MathOps.quatXidx ] * this.quaternion[ MathOps.quatYidx ];
		double xz = this.quaternion[ MathOps.quatXidx ] * this.quaternion[ MathOps.quatZidx ];
		double yw = this.quaternion[ MathOps.quatYidx ] * this.quaternion[ MathOps.quatWidx ];
		double yz = this.quaternion[ MathOps.quatYidx ] * this.quaternion[ MathOps.quatZidx ];
		double zw = this.quaternion[ MathOps.quatZidx ] * this.quaternion[ MathOps.quatWidx ];

		this.values[0][0] = (float) (1 - 2 * (sqr[MathOps.quatYidx] + sqr[MathOps.quatZidx]) ); 
		this.values[0][1] = (float) (2 * ( xy - zw ) ); 
		this.values[0][2] = (float) (2 * ( xz + yw ) ); 

		this.values[1][0] = (float) (2 * ( xy + zw ) ); 
		this.values[1][1] = (float) (1 - 2 * ( sqr[MathOps.quatXidx] + sqr[MathOps.quatZidx] ) ); 
		this.values[1][2] = (float) (2 * ( yz - xw ) ); 

		this.values[2][0] = (float) (2 * ( xz - yw ) ); 
		this.values[2][1] = (float) (2 * ( yz + xw ) ); 
		this.values[2][2] = (float) (1 - 2 * ( sqr[MathOps.quatXidx] + sqr[MathOps.quatYidx] ) );
 
		//writeMatrix();
	} // end convertQuaternionToMatrix


	/** Sets this matrix's right column to the translation value.<BR>
	&nbsp;&nbsp;&nbsp; m(0,3) = translation(0)<BR>
	&nbsp;&nbsp;&nbsp; m(1,3) = translation(1)<BR>
	&nbsp;&nbsp;&nbsp; m(2,3) = translation(2)
	*/
	public void setTranslationMatrix(float[] translation) {
		for (int i=0; i < 3; i++) {
			this.values[i][3] = translation[i];
		}
	} // end setTranslationMatrix



	/** Sets this matrix's diagonal to the scale value.<BR>
	&nbsp;&nbsp;&nbsp; m(0,0) = scale(0)<BR>
	&nbsp;&nbsp;&nbsp; m(1,1) = scale(1)<BR>
	&nbsp;&nbsp;&nbsp; m(2,2) = scale(2)
	*/
	public void setScaleMatrix(float[] scale) {
		for (int i=0; i < 3; i++) {
			this.values[i][i] = scale[i];
		}
	} // end setScaleMatrix



	/** Multiplies 4x4 matrices: this.matrix = this.matrix * matrix2 */
	public void multiplyThisby4x4( float[][] matrix2 ) {
		float[][] tempMatrix = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0} };
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				for (int k=0; k < 4; k++) {
					tempMatrix[i][j] += this.values[i][k] * matrix2[k][j];
				}
			}
		}
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				this.values[i][j] = tempMatrix[i][j];
			}
		}
	} // end multiplyThisby4x4

	/* Multiplies 4x4 matrices: this.matrix = this.matrix * matrix2<BR>Optimized to exclude the last rows of each matrix since they are zero'd out, matrix[4][4]=1*/
	/*public void multiplyThisby4x4Optimized( float[][] matrix2 ) {
		float[][] tempMatrix = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,1} };
		// upper left 3x3 matrix multiplication
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				for (int k=0; k < 3; k++) {
					tempMatrix[i][j] += this.values[i][k] * matrix2[k][j];
				}
			}
		}
		// right column of 2nd matrix
		for (int i=0; i < 3; i++) {
			for (int k=0; k < 4; k++) {
				tempMatrix[i][3] += this.values[i][k] * matrix2[k][3];
			}
		}
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				this.values[i][j] = tempMatrix[i][j];
			}
		}
	} // end multiplyThisby4x4
	*/


	/** Multiplies 4x4 matrices: this.matrix = matrix1 *  this.matrix */
	public void multiply4x4byThis( float[][] matrix1 ) {
		float[][] tempMatrix = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0} };
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				for (int k=0; k < 4; k++) {
					tempMatrix[i][j] += matrix1[i][k] * this.values[k][j];
				}
			}
		}
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				this.values[i][j] = tempMatrix[i][j];
			}
		}
		//writeMatrix();
	} // end multiply4x4byThis



	/**  Inverts the 4x4 Matrix by flipping the 3x3 (rotation) portion and negates the translation values in the right column
	*/
	public void InvertMatrix ( ) {
		// used by the Viewpoint Matrix
		float[][] tempMatrix = { {0,0,0,0}, {0,0,0,0}, {0,0,0,0}, {0,0,0,0} };
		// First the 3 x 3 matrix for rotations
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				tempMatrix[j][i] = this.values[i][j];
			}
		}
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				this.values[i][j] = tempMatrix[i][j];
			}
		}
		// now negate the translation
		for (int i = 0; i < 3; i++) {
			this.values[i][3] = -this.values[i][3];
		}
	} // end InvertMatrix

	
	/** Multiplies 4x4 matrix by 1 x 4 array: array1x4 = this.matrix * array1x4 */
	public void multiply4x4byArray( float[] array1x4 ) {
		float[] tempMatrix = {0,0,0,0};
		for (int i=0; i < 4; i++) {
			for (int j=0; j < 4; j++) {
				tempMatrix[i] += this.values[i][j] * array1x4[j];
			}
		}
		for (int i=0; i < 4; i++) {
			array1x4[i] = tempMatrix[i];
		}
	}


	/** Multiplies 4x4 matrix by array, optimized by multiplying the first 3 columns and 3 rows of the matrix by the array. The array can be any dimension 3 or greater.  Returns a 4 dimensional array, the last value = 1. */
	public float[] multiply4x4byArrayOptimized( float[] array1x ) {
		float[] returnArray = {0,0,0,1};
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				returnArray[i] += this.values[i][j] * array1x[j];
			}
			returnArray[i] += this.values[i][3]; //  matrixArray[3] = 1 so no need for multiply;
		}
		return returnArray;
	}

	/** returns the 4x4 Matrix */
	public float[][] GetMatrix( ) {
		return this.values;
	}

} // end Matrix4x4 class

