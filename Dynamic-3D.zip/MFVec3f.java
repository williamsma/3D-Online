 // MFVec3f.java
 // � 2003, 3D-Online, All Rights Reserved 
 // November 7, 2003

package d3d;

public class MFVec3f {

	float[][] vec3s = null;

	// constructor
	public MFVec3f () {
	}
	public MFVec3f ( int size, float[] vec3s ) {
		this.setValue(size, vec3s);
	}
	public MFVec3f ( float[][] vec3s ) {
		this.setValue(vec3s);
	}

	// setValue
	public void setValue (float[][] vec3s) {
		this.vec3s = new float[vec3s.length][3];
		for (int i = 0; i < vec3s.length; i++ ) {
			for (int j = 0; j < 3; j++) {
				this.vec3s[i][j] = vec3s[i][j];
			}
		}
	}
	/** <i>size</I> is the total items in the vec3s array.  Double dimention array will be [size/3][3] */
	public void setValue (int size, float[] vec3s ) {
  		int totalVec3s = size/3;
		this.vec3s = new float[totalVec3s][3];
		for (int i = 0; i < totalVec3s; i++ ) {
			for (int j = 0; j < 3; j++) {
				this.vec3s[i][j] = vec3s[i*3 + j];
			}
		}
	}

	// getValue
	public float[] get1Value(int index) {
		float[] returnValue = new float[3];
		for (int i = 0; i < 3; i++) {
			returnValue[i] = this.vec3s[index][i];
		}
		return returnValue;
	}
	public float[][] getValue() {
		return this.vec3s;
	}
	/** returns x, y, z triplets separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < vec3s.length; i++ ) {
				returnString += (vec3s[i][0] + " " + vec3s[i][1] + " "+ vec3s[i][2] + " ");
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFVec3f
