// GraphicsEngineController.java
// � 2004, 3D-Online, All Rights Reserved 
package d3d;


public class GraphicsEngineController implements DeviceControllerAbstract {


	// constructor
	public GraphicsEngineController (GraphicEngine graphicEngine,
				Renderer renderer, RendererObserver rendererObserver) {
		renderer.addMouseObserver();
	} // end Constructor

	public void initialize(){}
	public void finalize(){}
	/** needs to be present if implementing DeviceControllerAbstract */
	public void onMouseInput(MouseInput mi){}

} // end GraphicsEngineController class
