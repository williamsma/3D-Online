 // Appearance.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002

package d3d;


public class Appearance extends SFNode {

	public SFNode texture = null;
	public SFNode material = null;
	public SFNode textureTransform = null;

	// constructor
	public Appearance () {
		datatype = VRMLdatatype.Appearance;
	}

} // end Appearance
