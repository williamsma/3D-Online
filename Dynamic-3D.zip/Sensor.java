 // Sensor.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 10, 2002

package d3d;


/** superclass of common properties of all sensors */
public class Sensor extends SFNode {

	public SFBool enabled = new SFBool(true);

	public Sensor() { }

}//end class Sensor
