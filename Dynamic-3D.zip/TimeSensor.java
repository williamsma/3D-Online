 // TimeSensor.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 10, 2002

package d3d;


public class TimeSensor extends Sensor {

	public SFFloat cycleInterval = new SFFloat( 1 );
	public SFBool loop = new SFBool( false );
	public SFTime startTime = new SFTime(0);
	public SFTime stopTime = new SFTime(0);
	public float fraction_changed = 0;
	// if loop=false, then check when stopTime > currentTime 
	// the time left when the TimeSensor stopped */
	long pauseTime = 0;

	public TimeSensor() {
		datatype = VRMLdatatype.TimeSensor;
	}

}//end class TimeSensor
