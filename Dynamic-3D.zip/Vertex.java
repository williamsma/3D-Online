/* Vertex.java
* - created July 23, 1996
* previously Vector, but that conflicted with java.util.Vector
changed April 23, 2002
*/

package d3d;


public class Vertex {

	static final int vertices = 3; // currently only doing triangles
	static final int redIndex   = 0;
	static final int greenIndex = 1;
	static final int blueIndex  = 2;

	public float x, y, z; // for z buffering
	float[] vertexNormal = new float[3];

	int[] color = new int[3]; // red, green, blue

	float[] textureCoord = new float[2];
	float[] textureCoordUnclipped = new float[2];

	public void Z(float z) {
		this.z = z;
	}

	public void set (float x, float y, float z) {
		this.x = x;
		this.y = y;
		this.z = z;
	}

	public void setColor (int red, int green, int blue) {
		this.color[redIndex]   = red;
		this.color[greenIndex] = green;
		this.color[blueIndex]  = blue;
	}

	public void setTextureCoord (float xCoord, float yCoord) {
		this.textureCoord[0] = xCoord;
		this.textureCoord[1] = yCoord;
		this.textureCoordUnclipped[0] = xCoord;
		this.textureCoordUnclipped[1] = yCoord;
	}

} // end class Vertex