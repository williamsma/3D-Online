 // Material.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002
				  
package d3d;


public class Material extends SFNode {

	public SFFloat ambientIntensity = new SFFloat(0.2f);
	public SFColor diffuseColor = new SFColor(0.8f, 0.8f, 0.8f);
	public SFColor emissiveColor = new SFColor(0, 0, 0);
	public SFFloat shininess = new SFFloat(0.2f);
	public SFColor specularColor = new SFColor(0, 0, 0);
	public SFFloat transparency = new SFFloat(0);

	// constructor
	public Material () {
		datatype = VRMLdatatype.Material;
	}

}
