/*	
	Company:		3D-Online.com
	Class:		Matrix3x3.java
	Date:			January 5, 2004
	Description:	Class functions for constructing and manipulating a 4 x 4 matrix
	(C) Copyright 3D-Online.com - 2001, 2004 - All rights reserved
*/

package d3d;

/** 3 x 3 matrices used for rotation transformations, such as in Normals or
	direction vector in directionalLight and SpotLight.
*/
public class Matrix3x3 {

	float[][] matrix = {	{1, 0, 0},
								{0, 1, 0},
								{0, 0, 1} };

	// Constructor
	public Matrix3x3() { }

	/** Sets identity matrix for this 3 x 3 matrix */
	public void setIdentityMatrix() {
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				if ( i == j ) this.matrix[i][j] = 1;
				else this.matrix[i][j] = 0;
			}
		}
	}


	/** Copies the upper left 3 rows and 3 columns from a matrix4x4 into this 3x3 matrix */
	public void Copy4x4To3x3matrix( float[][] matrix4x4) {
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				this.matrix[i][j] = matrix4x4[i][j];
			}
		}
	} // end function Copy4x4To3x3matrix



	/** Multiplies two 3x3 matrices: this.matrix = this.matrix * matrix2 */
	public void multiplyThisby3x3( float[][] matrix2 ) {
		float[][] tempMatrix = { {0,0,0}, {0,0,0}, {0,0,0} };
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				for (int k=0; k < 3; k++) {
					tempMatrix[i][j] += this.matrix[i][k] * matrix2[k][j];
				}
			}
		}
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				this.matrix[i][j] = tempMatrix[i][j];
			}
		}
	}


	/** Multiplies two 3x3 matrices: this.matrix = matrix1 * this.matrix */
	public void multiply3x3byThis( float[][] matrix1 ) {
		float[][] tempMatrix = { {0,0,0}, {0,0,0}, {0,0,0} };
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				for (int k=0; k < 3; k++) {
					tempMatrix[i][j] += matrix1[i][k] * this.matrix[k][j];
				}
			}
		}
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				this.matrix[i][j] = tempMatrix[i][j];
			}
		}
	}


	/** Multiplies 3x3 matrix by 1 x 3 array: array1x3 = this.matrix * array1x3 */
	public void multiply3x3byArray( float[] array1x3 ) {
		float[] tempArray1x3 = {0,0,0};
		for (int i=0; i < 3; i++) {
			for (int j=0; j < 3; j++) {
				tempArray1x3[i] += this.matrix[i][j] * array1x3[j];
			}
		}
		for (int i=0; i < 3; i++) {
			array1x3[i] = tempArray1x3[i];
		}
	}



	/** returns the 3x3 Matrix */
	public float[][] GetMatrix( ) {
		return this.matrix;
	}

} // end Matrix3x3 class

