 // PointLight.java
 // � 2002, 3D-Online, All Rights Reserved 
 // February 10, 2004
 // Dedicted to my Mother, who is in her final days.  Appropriately, she too is my pointlight

package d3d;


public class PointLight extends Light {

	public SFVec3f attenuation = new SFVec3f(1, 0, 0);
	public SFVec3f location = new SFVec3f(0, 0, 0);
	public SFFloat radius = new SFFloat( 100 );

	// 4 value array cause we rotate and transform
	float[] lightLocationTransformed = {0, 0, 0, 1};
	Matrix4x4 matrix4x4 = new Matrix4x4();

	// constructor
	public PointLight () {
		datatype = VRMLdatatype.PointLight;
	}

} // end class PointLight
