 // RouteProperties.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 14, 2002

package d3d;


public class RouteProperties {

	// value for SFFloat - w/o pointers, have to set each one
		// materials
			final int materialTransparency = 1;
			final int materialShininess = 2;
		// lights + materials
			final int ambientIntensity = 3; // for Directional, Point and Spot Light and Material
			final int intensity = 4; // for Directional, Point and Spot Light and Sound
			final int lightRadius = 5;  // for point and spot light
			final int spotLightBeamWidth = 6;
			final int spotLightCutOffAngle = 7;
		// texture maps
			final int textureTransformRotation = 8;
		// viewpoint
			final int viewpointFieldOfView = 9;
		// Misc. fog, LOD
			final int fogVisibilityRange = 10;
			final int lodRange = 11; // Level-Of-Detail range



	// will contain both the from and to values
	boolean isActiveProperty = false;	// pts to TouchSensor.isActive property in ROUTE
	boolean isOverProperty  = false;		// pts to TouchSensor.isOver property in ROUTE
	boolean touchTimeProperty  = false;		// pts to TouchSensor.touchTime property in ROUTE




	double sfTime = 0;			// pts to time variables
	boolean sfBool = false;			// pts to DirectionalLight on, TouchSensor.enabled
	float sfFloat = java.lang.Float.NEGATIVE_INFINITY;
											// pts to TimeSensor.time
	float[] mfFloat = null;			// for ColorInterpolator.key, PositionInterpolator.key, OrientationInterpolator.key
	float[] sfVec3f = null;			// for Translation.transform, Viewpoint.position and Color too
	float[][] mfVec3f = null;		// for PositionInterpolator key_value
	float[] sfColor = null;			// for Translation.transform, Viewpoint.position and Color too
	float[][] mfColor = null;		// for ColorInterpolator key_value
	float[] sfRotation = null;		// for Translation.rotation, Viewpoint.orientation
	float[][] mfRotation = null;	// for  OrientationInterpolator key_value

	int sfFloatType = 0; // set to one of the final (const) values above

	//float[] sfFloatPtr = new float[1]; // used for ScalarInterpolator
	//public RouteProperties() {}  // don't seem to need the constructor

}//end class RouteProperties