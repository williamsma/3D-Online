 // Coordinate.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002

package d3d;


public class Coordinate extends SFNode {

	private final int wIndex = 3;

	public MFVec3f point = new MFVec3f();
	float[][] transformedPoint = null; // 3D point after object and camera transforms
	float[] bboxCenter	= new float[3];
	float[] bboxSize		= new float[3];
	float[][] bboxVertices = new float[8][3];
	float[][] transformBBoxVertices = new float[8][4];
	float[] min = new float[3]; // used for bounding box test of picking and clipping
	float[] max = new float[3]; // used for bounding box test of picking and clipping

	public Coordinate() { //Constructor
		datatype = VRMLdatatype.Coordinate;
	}

	void ConstructTransformedPoints() {
		// this is 4 values because we do matrix math and the 4th value = 1
		this.transformedPoint = new float[this.point.vec3s.length][4];
		for (int i = 0; i < this.point.vec3s.length; i++) {
			this.transformedPoint[i][wIndex] = 1;
		}
		for (int i = 0; i < this.transformBBoxVertices.length; i++) {
			this.transformBBoxVertices[i][wIndex] = 1;
		}
	}

}//end class Coordinate
