 // DeviceInput.java
 // � 2004, 3D-Online, All Rights Reserved 
 // March 5, 2004

package d3d;

/** superclass of common values of all devices */ 
public class DeviceInput {

	public long timeStamp; // 64-bit signed integer

	// constructor
	public DeviceInput () {}



} // end DeviceInput
