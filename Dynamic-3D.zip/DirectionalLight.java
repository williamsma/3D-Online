 // DirectionalLight.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 2, 2002

package d3d;


public class DirectionalLight extends Light {

	public SFVec3f direction = new SFVec3f(0, 0, -1);

	// values added to assist the directionalLight
	float[] directionNormalized = {0, 0, -1}; // a normalized vector of the "direction"
	float[] lightDirectionTransformed = new float[3]; // light direction rotated
	Matrix3x3 directionMatrix = new Matrix3x3(); // multiplies all parent Transforms plus Viewpoint


	// constructor
	public DirectionalLight () {
		datatype = VRMLdatatype.DirectionalLight;
	}

} // end class DirectionalLight
