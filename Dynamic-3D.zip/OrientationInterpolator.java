 // OrientationInterpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // December 9, 2003

package d3d;


public class OrientationInterpolator extends Interpolator {

	protected MFRotation keyValue = null;

	public OrientationInterpolator() {
		datatype = VRMLdatatype.OrientationInterpolator;
	}

}//end class OrientationInterpolator
