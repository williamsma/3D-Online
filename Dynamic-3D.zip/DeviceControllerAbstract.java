// DeviceControllerAbstract.java
// � 2004, 3D-Online, All Rights Reserved 
// March 5, 2004

package d3d;


public abstract interface DeviceControllerAbstract {

	public abstract void onMouseInput(MouseInput mi);

} // end DeviceControllerAbstract class
