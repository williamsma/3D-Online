 // MFColor.java
 // � 2003, 3D-Online, All Rights Reserved 
 // October 31, 2003

package d3d;

public class MFColor {

	float[][] colors = null;

	// constructor
	public MFColor () {
	}
	public MFColor (float colors[]) {
		this.setValue ( colors );
	}
	public MFColor (int size, float colors[]) {
		this.setValue ( size, colors );
	}
	public MFColor (float colors[][]) {
		this.setValue ( colors );
	}

	// setValue
	/** newColors is a single-dimension array with <I>newColors.length</I>/3 total colors*/
	public void setValue (float[] colors ) {
		this.setValue ( colors.length, colors );
	}
	/** newColors is a single-dimension array with <I>size</I>/3 total colors*/
	public void setValue (int size, float[] colors ) {
  		int totalColors = size/3;
		this.colors = new float[totalColors][3];
		for (int i = 0; i < totalColors; i++ ) {
			for (int j = 0; j < 3; j++) {
				this.colors[i][j] = colors[i*3 + j];
			}
		}
	}
	/** newColors is a double-dimension array with <I>newColors.length</I> total colors*/
	public void setValue(float[][] colors ) {
		this.colors = new float[colors.length][3];
		for (int i = 0; i < colors.length; i++ ) {
			for (int j = 0; j < 3; j++) {
				this.colors[i][j] = colors[i][j];
			}
		}
	}

	// getValue
	public float[][] getValue( ) {
		return this.colors;
	}
	public float[] get1Value(int index) {
		float[] returnValue = new float[3];
		for (int i = 0; i < 3; i++) {
			returnValue[i] = this.colors[index][i];
		}
		//return this.colors[index];
		return returnValue;
	}
	/** returns <I>colors</I> sets in repeating <I>red</I>, <I>green</I>, <I>blue</I> order  separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < colors.length; i++ ) {
			for (int j = 0; j < 3; j++) {
				returnString += (colors[i][j] + " ");
			}
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFColor
