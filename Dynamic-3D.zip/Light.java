 // Light.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 2, 2002

package d3d;

/** superclass of common properties of all lights: DirectionalLight, PointLight and SpotLight */

public class Light extends SFNode {

	// VRML defined variables
	public SFFloat ambientIntensity = new SFFloat(0);
	public SFColor color = new SFColor(1, 1, 1);
	public SFFloat intensity = new SFFloat(1);
	public SFBool on = new SFBool(true);

	// light variables for faster rendering
	float[] computedColor = {1, 1, 1}; // = color * intensity
	Light nextLight = null;

	// constructor
	public Light () {}

} // end class Light
