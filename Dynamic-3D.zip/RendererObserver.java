// RendererObserver.java
// � 2004, 3D-Online, All Rights Reserved 
// February 24, 2004
// dedicated to Alan Arinsberg on the day of his funeral

package d3d;

import java.util.Observer;
import java.util.Observable;


public class RendererObserver implements Observer {

	private Renderer ro = null;
	private GraphicsEngineController graphicsEngineController = null;
	private Object[] renderControlObjects = null;

	// constructor
	public RendererObserver (Renderer ro) {
		this.ro = ro;
	}

	public void init(GraphicsEngineController graphicsEngineController, Object[] renderControlObjects) {
		this.graphicsEngineController = graphicsEngineController;
		this.renderControlObjects = renderControlObjects;
	}

	public void update(Observable obs, Object obj) {
		if (obs == ro) {
			if (obj == renderControlObjects[0] ) {
				graphicsEngineController.PreRender();
			}
			//else  System.out.println("Rend.Obsrv obj NULL");
		}
	}

} // end RendererObserver
