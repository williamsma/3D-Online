 // MFVec2f.java
 // � 2003, 3D-Online, All Rights Reserved 
 // November 7, 2003

package d3d;

public class MFVec2f {

	float[][] vec2s = null;

	// constructor
	public MFVec2f () {
	}
	public MFVec2f (float[][] vec2s) {
		this.setValue(vec2s);
	}
	public MFVec2f (int size, float[] vec2s) {
		this.setValue(size, vec2s);
	}

	// setValue
	public void setValue (float[][] vec2s) {
		this.vec2s = new float[vec2s.length][2];
		for (int i = 0; i < vec2s.length; i++ ) {
			for (int j = 0; j < 2; j++) {
				this.vec2s[i][j] = vec2s[i][j];
			}
		}
	}
	/** <i>size</I> is the total items in the vec2s array.  Double dimension array will be [size/2][2] */
	public void setValue (int size, float[] vec2s ) {
  		int totalVec2s = size/2;
		this.vec2s = new float[totalVec2s][2];
		for (int i = 0; i < totalVec2s; i++ ) {
			for (int j = 0; j < 2; j++) {
				this.vec2s[i][j] = vec2s[i*2 + j];
			}
		}
	}

	// getValue
	public float[] get1Value(int index) {
		float[] returnValue = new float[2];
		for (int i = 0; i < 2; i++) {
			returnValue[i] = this.vec2s[index][i];
		}
		return returnValue;
	}
	public float[][] getValue() {
		return this.vec2s;
	}
	/** returns x, y pairs separated by space characters */
	public String toString() {
		String returnString = "";
		for (int i = 0; i < vec2s.length; i++ ) {
				returnString += (vec2s[i][0] + " " + vec2s[i][1] + " ");
		}
		if (returnString.length() >= 1) returnString = returnString.substring(0, (returnString.length()-1) ); // get rid of last space character
		return returnString;
	}

} // end MFVec2f
