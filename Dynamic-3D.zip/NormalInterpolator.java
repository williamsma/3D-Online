 // NormalInterpolator.java
 // � 2002, 3D-Online, All Rights Reserved 
 // May 8, 2004

package d3d;


public class NormalInterpolator extends Interpolator {

	protected MFVec3f keyValue = null;

	public NormalInterpolator() {
		datatype = VRMLdatatype.NormalInterpolator;
	}

}//end class NormalInterpolator
