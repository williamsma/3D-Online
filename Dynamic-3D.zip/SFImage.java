 // SFImage.java
 // � 2004, 3D-Online, All Rights Reserved 
 // OApril 28, 2004

package d3d;

public class SFImage {

	int width = 0;
	int height = 0;
	int components = 0;
	byte[] pixels = null;

	int[] red    = null;
	int[] green  = null;
	int[] blue   = null;
	int[] alpha  = null;
	boolean transparentByte = false;



	// returns the 2's complement if byte is negative
	private int ConvertByteToInt(byte byteValue){
		int returnInt = 0;
		if ( byteValue >= 0) returnInt = byteValue;
		else { // get 2's complement
			returnInt = byteValue + 1;
			returnInt = (-returnInt ^ 255);
		}
		return returnInt;
	}


	void SetRGBA() {
		red   = new int[pixels.length/components];
		green = new int[pixels.length/components];
		blue  = new int[pixels.length/components];
		alpha = new int[pixels.length/components];
		if (components == 1) {// gray scale
			for (int i = 0; i < pixels.length; i++) {
				red[i]   = ConvertByteToInt(pixels[i]);
				green[i] = red[i];
				blue[i]  = red[i];
				alpha[i] = 0;
			}
		}
		else if (components == 2) {// gray scale + alpha
			for (int i = 0; i < (pixels.length/2); i++) {
				red[i]   = ConvertByteToInt(pixels[i*2]);
				green[i] = red[i];
				blue[i]  = red[i];
				alpha[i] = ConvertByteToInt(pixels[(i*2)+1]);
				if (alpha[i] == 0) transparentByte = true;
				else alpha[i] = 255; // currently only implement opaque or transparent bits, no partials
			}
		}
		else if (components == 3) {// RGB
			for (int i = 0; i < (pixels.length/3); i++) {
				red[i]   = ConvertByteToInt(pixels[(i*3)]);
				green[i] = ConvertByteToInt(pixels[(i*3)+1]);
				blue[i]  = ConvertByteToInt(pixels[(i*3)+2]);
				alpha[i] = 0;
			}
		}
		else if (components == 4) {// RGBA
			for (int i = 0; i < (pixels.length/4); i++) {
				red[i]   = ConvertByteToInt(pixels[(i*4)]);
				green[i] = ConvertByteToInt(pixels[(i*4)+1]);
				blue[i]  = ConvertByteToInt(pixels[(i*4)+2]);
				alpha[i] = ConvertByteToInt(pixels[(i*4)+3]);
				if (alpha[i] == 0) transparentByte = true;
				else alpha[i] = 255; // currently only implement opaque or transparent bits, no partials
			}
		}
		else System.out.println("Error: SFImage: incorrect number of components"); 
	} // end SetRGBA


	// constructor
	public SFImage () {}
	public SFImage (int width, int height, int components, byte[] pixels) {
		setValue( width, height, components, pixels);
	}

	// setValue
	public void setValue (int width, int height, int components, byte[] pixels) {
		this.width      = width;
		this.height     = height;
		this.components = components;
		this.pixels = new byte[pixels.length];
		for (int i = 0; i < pixels.length; i++)
			this.pixels[i] = pixels[i];
		SetRGBA();
	}

	// getValue
	public int getWidth( ) {
		return this.width;
	}
	public int getHeight( ) {
		return this.height;
	}
	public int getComponents( ) {
		return this.components;
	}
	public byte[] getPixels( ) {
		byte returnByte[] = new byte[this.pixels.length];
		for (int i = 0; i < this.pixels.length; i++)
			returnByte[i] = this.pixels[i];
		return returnByte;
	}

	/** returns width, height, components and pixels array separated by space characters */
	public String toString( ) {
		String returnString = this.width + " " + this.height + " " + this.components;
		for (int i = 0; i < this.pixels.length; i++)
			returnString += " " + this.pixels[i];
		return returnString;
	}

} // end SFImage
