/* Polygon.java - created July 23, 1996 
	PolygonClass.java, renamed from "Polygon" which is a java class
*/

package d3d;


public class PolygonClass {

	final int totalVertices = 3;
	//final int transparentPixelValue = 0;

	//ImageTexture imageTexture = null;
	SFNode texture = null; // pts to ImageTexture
	float transparencyMaterialValue = 0; // a value between 0 and 1 from Shape.appearance.material
	boolean transparentGIF = false; // set by texture.transparentGIF
	Vertex[] vertex = null;
	int objectNumber;
	boolean materialAttribute = false;

	// textureTransform values needed for Gradients
	public float textureCoordinateScaleX = 1;
	public float textureCoordinateScaleY = 1;
	public float textureCoordinateTranslationX = 0;
	public float textureCoordinateTranslationY = 0;
	public float textureCoordinateCenterX = 0;
	public float textureCoordinateCenterY = 0;
	public float textureCoordinateRotation = 0;
	boolean tiling; // set if a polygon has tiling for effecientcy

	public PolygonClass() {
		vertex = new Vertex[totalVertices];
		for (int i=0; i < vertex.length; i++) { // Java's way of creating an array of objects
			vertex[i] = new Vertex();
		}
		Reset();
	} // end Constructor

	public void Reset() {
		//imageTexture = null;
		texture = null;
		transparencyMaterialValue = 0;
		transparentGIF = false;
		materialAttribute = false;
		textureCoordinateScaleX = 1;
		textureCoordinateScaleY = 1;
		textureCoordinateTranslationX = 0;
		textureCoordinateTranslationY = 0;
		textureCoordinateCenterX = 0;
		textureCoordinateCenterY = 0;
		textureCoordinateRotation = 0;
} // end Reset

} // end class PolygonClass