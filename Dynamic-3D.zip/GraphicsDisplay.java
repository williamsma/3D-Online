// GraphicsDisplay.java
// � 2002, 3D-Online, All Rights Reserved 
// Date: April 9, 2002

package d3d;


public class GraphicsDisplay {

	static final int redIndex		= 0;
	static final int greenIndex	= 1;
	static final int blueIndex		= 2;

	public float Zbuffer[]		= null;
	public int buffer1RGB[]	= null;
	public int buffer2RGB[]	= null;

	//private float ZbufferCopy[]	= null;
	private int bufferRGBCopy[]	= null;  // public so the GrpahicsEngine can set borders similar colors

	// transparency buffers, taken from CG Principles & Practice, pg. 755
	public float transparencyValueBuffer[]	= null; // 0 <= value <= 1, from material transparency value
	public int transparencyRed[]				= null;	// RGB value of polygon
	public int transparencyGreen[]			= null;
	public int transparencyBlue[]				= null;
	public boolean transparencyFlag[]		= null;
	//private boolean transparencyFlagCopy[]	= null; // used for fast copy into buffer
	public float transparencyZbuffer[]		= null;  // pixel's Z value
	//public float transparencyZbufferCopy[]	= null; // used for fast copy into buffer

	public int width, height;
	public int totalPixels = 0;

	public GraphicsDisplay(int width, int height) { 
		this.width = width;
		this.height = height + 1; // maybe an extra scanline here
		totalPixels =  this.width * this.height;

		Zbuffer      = new float[totalPixels];
		buffer1RGB = new int[totalPixels];
		buffer2RGB  = new int[totalPixels];

		//ZbufferCopy     = new float[totalPixels];
		bufferRGBCopy	= new int[totalPixels];

		// transparency buffers, taken from CG Principles & Practice, pg. 755
		transparencyValueBuffer = new float[totalPixels]; // 0 <= value <= 1, from material transparency value
		transparencyRed         = new int[totalPixels];
		transparencyGreen       = new int[totalPixels];
		transparencyBlue        = new int[totalPixels];
		transparencyZbuffer     = new float[totalPixels];
		//transparencyZbufferCopy = new float[totalPixels];
		transparencyFlag        = new boolean[totalPixels];
		//transparencyFlagCopy    = new boolean[totalPixels];

		/*
		// initialize copy and use copyarray later for speed
		for (int i = 0; i < totalPixels; i++) {
			ZbufferCopy[i] = java.lang.Float.NEGATIVE_INFINITY;
			transparencyFlagCopy[i]    = false;
			transparencyZbufferCopy[i] = java.lang.Float.MIN_VALUE;
		}
		*/
		int[] bgColor = {0, 0, 0};
		InitializeBackground(bgColor);
	} // end Constructor

	public void InitializeBackground(int[] bg) {
		// initialize copy and use copyarray later for speed
		int bgByte = (0xFF000000) | (bg[redIndex] << 16) | (bg[greenIndex] << 8) | bg[blueIndex];
		for (int i = 0; i < totalPixels; i++) {
			this.bufferRGBCopy[i]	= bgByte | 0xFF000000 ;
		}
	} // end InitializeBackground

	public void ClearBuffer1() {
		System.arraycopy( bufferRGBCopy, 0, buffer1RGB, 0, totalPixels);
		//try { System.arraycopy( bufferRGBCopy, 0, buffer1RGB, 0, totalPixels); }
		//catch (Exception e) { System.out.println("Error: array copy: " + e.toString()); }
	} // end ClearBuffer1

	public void ClearBuffer2() {
		System.arraycopy( bufferRGBCopy, 0, buffer2RGB, 0, totalPixels);
		//try { System.arraycopy( bufferRGBCopy, 0, buffer2RGB, 0, totalPixels); }
		//catch (Exception e) { System.out.println("Error: array copy: " + e.toString()); }
	} // end ClearBuffer2

	public void Clear() {
		ClearBuffer1();
		ClearBuffer2();
	} // end Clear both Buffers

	public void ClearZbuffer() {
		//System.arraycopy( ZbufferCopy, 0, Zbuffer, 0, totalPixels);
		//try { System.arraycopy( ZbufferCopy, 0, Zbuffer, 0, totalPixels); }
		//catch (Exception e) { System.out.println("Error: array copy: " + e.toString()); }
		for (int i = 0; i < totalPixels; i++) {
			Zbuffer[i] = java.lang.Float.NEGATIVE_INFINITY;
		}
	} // end ClearZ and Material Buffers

	public void ClearTransparencyBuffer() {
		/*
		try { System.arraycopy( transparencyFlagCopy, 0, transparencyFlag, 0, totalPixels); }
		catch (Exception e) { }
		//catch (Exception e) { System.out.println("Error: array copy: " + e.toString()); }
		try { System.arraycopy( transparencyZbufferCopy, 0, transparencyZbuffer, 0, totalPixels); }
		catch (Exception e) { }
		//catch (Exception e) { System.out.println("Error: array copy: " + e.toString()); }
		*/
		for (int i = 0; i < totalPixels; i++) {
			transparencyFlag[i] = false;
			transparencyZbuffer[i] = java.lang.Float.MIN_VALUE;
		}
	} // end ClearTransparencyBuffer

} // end class GraphicsDisplay