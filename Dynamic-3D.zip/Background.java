 // Background.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 17, 2003

package d3d;


public class Background {

	boolean created  = false; // if true, then a Background node was in VRML file
	// and thus don't allow Dynamic-3D Creation tool applet parameters to override.
	private float[] skyColorDefault = {0, 0, 0};

	public MFColor skyColor = new MFColor( skyColorDefault );

	public Background() { }

}//end class Background
