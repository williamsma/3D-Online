 // PointSet.java
 // � 2004, 3D-Online, All Rights Reserved 
 // April 28, 2004

package d3d;

public class PointSet extends SFNode {

	//public Color color = null;
	//public Coordinate coord = null;
	public SFNode color = null;
	public SFNode coord = null;

	// constructor
	public PointSet () {
		datatype = VRMLdatatype.PointSet;
	}

} // end PointSet 
