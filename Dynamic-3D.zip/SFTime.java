 // SFTime.java
 // � 2002, 3D-Online, All Rights Reserved 
 // October 30, 2003

package d3d;

public class SFTime {

	/** VRML spec uses "double" a float point value, but Java's "long" is a 64-bit integer */
	long time = 0;

	// constructor
	public SFTime () {
		this.setValue ( 0 );
	}
	public SFTime (long time) {
		this.setValue ( time );
	}

	// setValue
	public void setValue ( long time ) {
		this.time = time;
	}

	// getValue
	public long getValue( ) {
		return this.time;
	}
	/** returns <I>time</I> as a string */
	public String toString( ) {
		String returnString = time +""; // forces the string
		return returnString;
	}

} // end SFTime
