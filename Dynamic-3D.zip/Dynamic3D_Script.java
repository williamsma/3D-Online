 // Dynamic3D_Script.java
 // � 2002, 3D-Online, All Rights Reserved 
 // June 19, 2003

package d3d;


//import Sensor;
//import VRMLdatatype;
//import Dynamic3D;

public class Dynamic3D_Script extends Script {

	// general Dynamic-3D Script variables
	public static final String reverseIndicatorString = "-RVR-ANIM";
	public static final String dynamic3DIndicatorString = "-d3dSCRIPT";
	public static final int not_determined = -1;
	public int scriptType = not_determined;

	// animation variations
	public static final int looping = 0;
	public static final int reverse = 1;
	public static final int singleAnimation = 2;
	public boolean nextAnimation = false; // toggles for the reverse animations
	public long startTime = 0; // copies and passes the time from TouchSensor to TimeSensor

	// rotation variations
	public static final int rotate = 10;
	public static final int materialChange  = 11;

	// color variations
	public Appearance controlAppearance = null;
	public SFNode effectNode  = null; // want Transform, Group or Billboard as we may have multiple Shapes to change


	
	public void Execute_Script() {
		if ( this.scriptType == looping ) {
			this.enabled.setValue( !this.enabled.getValue() );
		}
		else if ( this.scriptType == reverse ) {
			if (nextAnimation) {
				this.enabled.setValue( true );
				nextAnimation = false;
			}
			else {
				this.enabled.setValue( false );
				nextAnimation = true;
			}
		} // reverse animation
		else if ( this.scriptType == singleAnimation ) {
			this.enabled.setValue( true );
		} // single animation
		else if ( this.scriptType == rotate ) {
			this.enabled.setValue( true );
		} // single animation
		else if ( this.scriptType == materialChange ) {

			SFNode currNode = effectNode;
			while ( currNode != null ) {
				while (currNode.datatype != VRMLdatatype.Shape) {
					currNode = currNode.children;
				}
				if (currNode.datatype == VRMLdatatype.Shape) {
					Shape effectShape = (Shape) currNode;
					effectShape.appearance = controlAppearance;
					while ( currNode.next == null ) {
						currNode = currNode.parent;
						if (currNode == effectNode) break;
					}
					if (currNode == effectNode) break;
					else currNode = currNode.next;
				}
			} // end while loop
		} // end materialChange
	} // end Execute_Script

}//end class Dynamic3D_Script
