// AppletParameters.java
// Parameters inside the Applet tag
// � 2003, 3D-Online, All Rights Reserved 
// AppletParameters.java
// March 5, 2003
// Dedicated to Terry Nishimura who passed away in 2002 - first colleague at Xerox

package d3d;

import java.applet.Applet;
import java.util.Date;
import java.util.Calendar;
import java.net.URL;

public class AppletParameters {

	int key = 0;

	private Applet applet = null;
	public float[] backgroundColors = {0, 0, 0};
	public boolean animateBewteenViewpoint = true; // opposite of Viewpoint jump value
	public boolean walkthrough = true; // allow moving viewpoint
	private final float creaseAngleMinimun = .004f; // had to do this for serious round off errors
	public boolean creaseAngleDefault = true;
	public float creaseAngle = creaseAngleMinimun;

	private final int upperCaseOffset = 65;
	private final int lowerCaseOffset = 97;
	// values come from C# registration generation program
	private final int cksumDigit3Offset = upperCaseOffset + 10;
	private final int cksumDigit2Offset = upperCaseOffset + 5;
	private final int cksumDigit1Offset = upperCaseOffset;
	private final int cksumDigit0Offset = upperCaseOffset + 16;
	private final int year1Offset = 100;
	private final int year2Offset = 64;
	private final int lowerCaseZ = lowerCaseOffset + 25;

	// variables from parameters
	int CheckSumParameter = 0;
	int year1Parameter = 0;
	int year2Parameter = 0;
	int monthParameter = 0;
	int dateParameter = 0;
	// variables from host/pc
	int currentYear = 0;
	int currentMonth = 0;
	int currentDate = 0;
	int CheckSumWebSite = 0;
	String domain = null;
	boolean registeredUser = false;

	public AppletParameters (Applet applet_) {
		applet = applet_;
		SetBackgroundColors();

		/******* Crease Angle *******/
		String creaseAngleDefaultString = applet.getParameter("creaseAngleDefault");
		if ( creaseAngleDefaultString != null) {
			try {
				Boolean creaseAngleDefaultBoolean = new Boolean(creaseAngleDefaultString);
				if ( !creaseAngleDefaultBoolean.booleanValue()) {	creaseAngleDefault = false; }
			}
			catch ( Exception e) { }
		} // end animateViewpoint true/false
		String creaseAngleString = applet.getParameter("creaseAngle");
		if ( creaseAngleString != null) {
			try {
				Float creaseAngleFloat = new Float(creaseAngleString);
				creaseAngle = creaseAngleFloat.floatValue();
				if (creaseAngle < creaseAngleMinimun) {
					creaseAngle = creaseAngleMinimun; // had to do this for serious round off errors
				}
			}
			catch ( Exception e) {}
		} // end crease angle value

	} // end Constructors


	public void SetBackgroundColors () {
		String redString = applet.getParameter("backgroundColorR");  // this is the Shout value
		if ( redString != null) {
			try {
				Float red = new Float(redString);
				backgroundColors[0] = red.floatValue();
			}
			catch ( Exception e) {}
		} // end red background
		String greenString = applet.getParameter("backgroundColorG");  // this is the Shout value
		if ( greenString != null) {
			try {
				Float green = new Float(greenString);
				backgroundColors[1] = green.floatValue();
			}
			catch ( Exception e) {}
		} // end green background
		String blueString = applet.getParameter("backgroundColorB");  // this is the Shout value
		if ( blueString != null) {
			try {
				Float blue = new Float(blueString);
				backgroundColors[2] = blue.floatValue();
			}
			catch ( Exception e) {}
		} // end blue background
	} // end SetBackgroundColors



	public String GetVRMLFile () {
		String fileVRMLparameter = applet.getParameter("src");
		if (fileVRMLparameter == null) System.out.println("Error: no 3D graphics file specified");
		return fileVRMLparameter;
	} // GetVRMLFile



	private boolean CheckRegistered() {
		boolean registeredReturn = true;
		String siteParameter = "";
		try { siteParameter = applet.getParameter("website").toLowerCase(); }
		catch ( Exception e) {
			//System.out.println("Missing website parameter information");
		}
		if ( !siteParameter.equals(domain) )  registeredReturn = false;
		if ( CheckSumParameter != CheckSumWebSite )  registeredReturn = false;
		if ( year1Parameter != year2Parameter )  registeredReturn = false;
		if ( year1Parameter < currentYear )  registeredReturn = false;
		else if ( year1Parameter == currentYear ) {
			// years match, check the months
			if ( monthParameter < currentMonth) registeredReturn = false;
			else if ( monthParameter == currentMonth ) {
				if ( dateParameter < currentDate) registeredReturn = false;
			}
		}
		return registeredReturn;
	} // end CheckRegistered



	private boolean GetCurrentWebSiteAndDate() {
		boolean localSite = false;
		Calendar calendar = Calendar.getInstance();
		currentMonth = calendar.get(Calendar.MONTH) + 1; // Java calendar is 0 to 11, C# is 1 to 12
		currentYear = calendar.get(Calendar.YEAR) % 100;
		currentDate = calendar.get(Calendar.DATE);
		URL url = applet.getCodeBase();
		String host = url.getHost();
		// used for test values only
		//host = "www.3D-Online.com";
		//host = "www.3DOnline.com";
		//host = "3D-Online.com";
		if ( host.length() == 0) {
			localSite = true;
		}
		else {
			// get the domain + .com/.net/.mil, etc. and got foreign sites too.
			domain = host.toLowerCase();
			if ( domain.indexOf("www.") == 0 ) {
				// get rid of "www." for any web site
				domain = domain.substring(4, domain.length() );
			}			
			char[] hostCharArray = domain.toCharArray();
			for (int i = 0; i < hostCharArray.length; i++ ) {
				Byte byteValue = new Byte( (byte)hostCharArray[i] );
				CheckSumWebSite += byteValue.intValue();
			}
		}
		return localSite;
	} // end GetCurrentWebSiteAndDate



	private void UnencodeParameters() {
		String registrationParameter = "";
		try {
			registrationParameter = applet.getParameter("registration");
			String version = registrationParameter.substring(0, 4);
			// Get check sum chars
			char[] ckSumChar = new char[4];
			ckSumChar[3] = registrationParameter.charAt(4);
			ckSumChar[2] = registrationParameter.charAt(7);
			ckSumChar[1] = registrationParameter.charAt(10);
			ckSumChar[0] = registrationParameter.charAt(12);
			//System.out.println("      ckSum 3 to 0 = " +  ckSumChar[3] + ", " + ckSumChar[2] + ", " + ckSumChar[1] + ", " + ckSumChar[0] );
			Byte[] ckSumByte = new Byte[4];
			ckSumByte[3] = new Byte( (byte)ckSumChar[3] );
			ckSumByte[2] = new Byte( (byte)ckSumChar[2] );
			ckSumByte[1] = new Byte( (byte)ckSumChar[1] );
			ckSumByte[0] = new Byte( (byte)ckSumChar[0] );
			CheckSumParameter = ( ckSumByte[3].intValue() - cksumDigit3Offset) * 1000 +
									 		( ckSumByte[2].intValue() - cksumDigit2Offset) * 100 +
									 		( ckSumByte[1].intValue() - cksumDigit1Offset) * 10 +
									 		( ckSumByte[0].intValue() - cksumDigit0Offset);
	
			// Get date information
			// two year values
			char[] dateChar = new char[3];
			dateChar[0] = registrationParameter.charAt(5);
			dateChar[1] = registrationParameter.charAt(8);
			dateChar[2] = registrationParameter.charAt(11);
			Byte year1Byte = new Byte( (byte)dateChar[0] );
			Byte year2Byte = new Byte( (byte)dateChar[1] );
			year1Parameter = year1Byte.intValue() - year1Offset;
			year2Parameter = year2Byte.intValue() - year2Offset;
			// month values
			Byte monthByte = new Byte( (byte)dateChar[2] );
			monthParameter = lowerCaseZ - monthByte.intValue();
			// date values
			String date3 = registrationParameter.substring(14, registrationParameter.length());
			Integer dateInt = new Integer(date3);
			dateParameter = dateInt.intValue();
		}
		catch ( Exception e) { 
			//System.out.println("Missing registration parameter information");
		}
	} // end UnencodeParameters



	void SetRegistration () {
		//boolean registered = false;
		UnencodeParameters();
		boolean localSite = GetCurrentWebSiteAndDate();
		if ( localSite ) registeredUser = true;
		else registeredUser = CheckRegistered();
		//return registered;
	} // end GetRegistration



	public void HTMLOverrideParameters (Background background, NavigationInfo navigationInfo) {
		// Parameters that override VRML parameters or adjust Dynamic-3D principles

		if ( !navigationInfo.created ) {
			// not set in NavigationInfo node inside VRML file so applet parameters used
			/******* speed *******/
			String speedString = applet.getParameter("speed");
			if ( speedString != null) {
				try {
					Float speedFloatType = new Float(speedString);
					navigationInfo.speed.f = speedFloatType.floatValue();
				}
				catch ( Exception e) {
					//System.out.println("Error: Applet speed parameter: " + e.toString());
				}
			} // end speed
		
			/******* Headlight *******/
			String headlightOnString = applet.getParameter("headlightOn");
			if ( headlightOnString != null) {
				try {
					Boolean headlightOnBoolean = new Boolean(headlightOnString);
					if ( headlightOnBoolean.booleanValue()) {	navigationInfo.headlight.setValue(true); }
					else navigationInfo.headlight.setValue(false);
				}
				catch ( Exception e) { 
					//System.out.println("Error: Applet's HeadlightOn parameter not a TRUE or FALSE value");
				}
			} // end headlight on
		
			/******* type: WALKTROUGH, EXAMINE, FLY or NONE *******/
			String walkthroughString = applet.getParameter("walkthrough");
			if ( walkthroughString != null) {
				try {
					Boolean walkthroughBoolean = new Boolean(walkthroughString);
					if ( !walkthroughBoolean.booleanValue()) { walkthrough = false; }
				}
				catch ( Exception e) { }
			} // end walkthrough
		} // end navigationInfo paremeters 


		/******* Background Color *******/
		if ( !background.created ) {
			background.skyColor.colors[0][0] = backgroundColors[0];
			background.skyColor.colors[0][1] = backgroundColors[1];
			background.skyColor.colors[0][2] = backgroundColors[2];
		} // end background paremeters 

		/******* Animate Viewpoint *******/
		// Viewpoint's jump value, not exported by Max
		String animateBewteenViewpointString = applet.getParameter("animateVP");
		if ( animateBewteenViewpointString != null) {
			try {
				Boolean animateBetweenViewpointBoolean = new Boolean(animateBewteenViewpointString);
				if ( !animateBetweenViewpointBoolean.booleanValue()) { animateBewteenViewpoint = false; }
			}
			catch ( Exception e) { }
		} // end animateViewpoint true/false

	} // end HTMLOverrideParameters


}  // end AppletParameters
