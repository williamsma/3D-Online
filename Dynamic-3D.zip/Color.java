 // Color.java
 // � 2002, 3D-Online, All Rights Reserved 
 // April 4, 2002

package d3d;


public class Color extends SFNode {

	protected MFColor color = new MFColor();

	public Color() {
		datatype = VRMLdatatype.Color;
	}

}//end class Color
