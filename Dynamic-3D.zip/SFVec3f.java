 // SFVec3f.java
 // � 2003, 3D-Online, All Rights Reserved 
 // October 30, 2003

package d3d;

public class SFVec3f {

	float[] vec3s = new float[3];

	// constructor
	public SFVec3f () {
		this.setValue ( 0, 0, 0);
	}
	public SFVec3f (float x, float y, float z) {
		this.setValue ( x,  y,  z );
	}

	// setValue
	public void setValue (float[] vec3s ) {
		for (int i = 0; i < vec3s.length; i++) { this.vec3s[i] = vec3s[i]; };
	}
	public void setValue (float x, float y, float z ) {
		this.vec3s[0] = x;
		this.vec3s[1] = y;
		this.vec3s[2] = z;
	}

	// getValue
	public float[] getValue( ) {
		return this.vec3s;
	}
	public float getX() {
		return this.vec3s[0];
	}
	public float getY() {
		return this.vec3s[1];
	}
	public float getZ() {
		return this.vec3s[2];
	}
	/** index is a value between 0 thru 2, for the X, Y and Z values respectively */
	public float getValue(int index ) {
		return this.vec3s[index];
	}
	/** returns X, Y and Z separated by space characters */
	public String toString( ) {
		String returnString = vec3s[0] + " " + vec3s[1] + " " + vec3s[2];
		return returnString;
	}

} // end SFVec3f
