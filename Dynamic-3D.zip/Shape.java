 // Shape.java
 // � 2002, 3D-Online, All Rights Reserved 
 // March 31, 2002

package d3d;


public class Shape extends SFNode {

	//public Appearance appearance = null;
	public SFNode appearance = null;
	public SFNode geometry = null;
	Shape nextShape = null; // used to quickly find shapes in the mouse rollovers, interactivity.

	Matrix3x3 rotationMatrix = new Matrix3x3();
	Matrix4x4 matrix4x4 = new Matrix4x4();

	// constructor
	public Shape () {
		datatype = VRMLdatatype.Shape;
	}

} // end class Shape
