 // MathOps.java
 // � 2003, 3D-Online, All Rights Reserved 
 // April 16, 2003

package d3d;

/** Utilities for 3D Graphics Programming Math Operations */
public class MathOps {

	static final int xIndex = 0;
	static final int yIndex = 1;
	static final int zIndex = 2;
	static final int angleIndex = 3;
	static final int quatWidx = 0;
	static final int quatXidx = 1;
	static final int quatYidx = 2;
	static final int quatZidx = 3;
	static final int headingIndex = 0; // heading
	static final int bankingIndex = 1; //roll
	static final int attitueIndex = 2; // pitch



	/** Given two three-dimensional vectors, <I>vector1</I> (v1) and <I>vector2</I> (v2), this returns the
	cross product (cp).<BR>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cp[x] = v1[y] * v2[z] - v1[z] * v2[y];<BR>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cp[y] = v1[z] * v2[x] - v1[x] * v2[z];<BR>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;cp[z] = v1[x] * v2[y] - v1[y] * v2[x];
	*/
	static public float[] CrossProduct (float[] vector1, float[] vector2) {
		float[] crossProduct = new float[3];
		crossProduct[xIndex] =  vector1[yIndex] * vector2[zIndex] - vector1[zIndex] * vector2[yIndex];
		crossProduct[yIndex] =  vector1[zIndex] * vector2[xIndex] - vector1[xIndex] * vector2[zIndex];
		crossProduct[zIndex] =  vector1[xIndex] * vector2[yIndex] - vector1[yIndex] * vector2[xIndex];
		return crossProduct;
	} // end Cross Product



	/** Given two three-dimensional vectors, <I>vector1</I> and <I>vector2</I>, returns the
	dot product (dp)<BR>
	dp = <I>vector1</I>[x] * <I>vector2</I>[x] + <I>vector1</I>[y] * <I>vector2</I>[y] +  <I>vector1</I>[z] * <I>vector2</I>[z]  */
	static public float DotProduct (float[] vector1, float[] vector2) {
		float dotProduct = 0;
		//for (int i = 0; i < 3; i++) {
		for (int i = 0; i < vector1.length; i++) {
			dotProduct += vector1[i] * vector2[i];
		}
		return dotProduct;
	} // end Dot Product



	/** Given a <I>vector</I> of any dimension, returns its length */
	static public float VectorLength (float[] vector) {
		float returnVectorLength = 0;
		for (int i = 0; i < vector.length; i++) {
			//returnVectorLength += (float)Math.pow(vector[i], 2);
			returnVectorLength += (vector[i] * vector[i]); // multiply much fast than a value to 2nd power
		}
		returnVectorLength = (float)Math.sqrt(returnVectorLength);
		return returnVectorLength;
	} // end Vector Length



	/** Given a 3 dimensional <I>vector</I>, returns a normalized vector */
	static public float[] NormalizeVector (float[] vector) {
		float[] normalizedVector = new float[3];
		float normalizeDenominator = (float) Math.sqrt(
			//Math.pow(vector[xIndex], 2) + Math.pow(vector[yIndex], 2) + Math.pow(vector[zIndex], 2) );
			(vector[xIndex]*vector[xIndex]) + (vector[yIndex]*vector[yIndex]) + (vector[zIndex]*vector[zIndex]) );
		for (int i = 0; i < 3; i++) {
			if (normalizeDenominator != 0) {
				normalizedVector[i] = vector[i] / normalizeDenominator;
			}
			else {
				normalizedVector[i] = 0;
			}
		}
		return normalizedVector;
	} // end NormalizeVector



	/** Given a quaternion, returns the euler in hpr order (heading, roll, pitch).<BR>
	 Equations follows <A href="http://www.martinb.com/maths/geometry/rotations/conversions/eulerToMatrix/index.htm">NASA Standard Airplane</A>.<BR>
	*/
	static public float[] QuaternionToEuler (float[] quat) {
		float[] euler = new float[3];
		float sqw = quat[quatWidx]*quat[quatWidx];
		float sqx = quat[quatXidx]*quat[quatXidx];
		float sqy = quat[quatYidx]*quat[quatYidx];
		float sqz = quat[quatZidx]*quat[quatZidx];
		euler[ attitueIndex ] = (float) Math.atan2(
						2.0f * (quat[quatYidx]*quat[quatXidx] + quat[quatZidx]*quat[quatWidx]),
						(sqy - sqx -sqz + sqw));
		euler[ headingIndex ] = (float) Math.atan2(
						2.0f * (quat[quatXidx]*quat[quatZidx] + quat[quatYidx]*quat[quatWidx]),
						(-sqy - sqx + sqz + sqw));
		euler[ bankingIndex ] = (float) Math.asin(
						-2.0f * (quat[quatYidx]*quat[quatZidx] - quat[quatXidx]*quat[quatWidx]));

		return euler;
	} // end QuaternionToEuler



	/** Returns the mutliplication of two quaternions */
	static public float[] MultiplyQuaternions (float[] quat1, float[] quat2) {
		float[] resultQuat = new float[4];
		resultQuat[ quatWidx ] =	quat1[ quatWidx ] * quat2[ quatWidx ] -
											quat1[ quatXidx ] * quat2[ quatXidx ] -
											quat1[ quatYidx ] * quat2[ quatYidx ] -
											quat1[ quatZidx ] * quat2[ quatZidx ];

		resultQuat[ quatXidx ] =	quat1[ quatWidx ] * quat2[ quatXidx ] +
											quat1[ quatXidx ] * quat2[ quatWidx ] +
											quat1[ quatYidx ] * quat2[ quatZidx ] -
											quat1[ quatZidx ] * quat2[ quatYidx ];

		resultQuat[ quatYidx ] =	quat1[ quatWidx ] * quat2[ quatYidx ] +
											quat1[ quatYidx ] * quat2[ quatWidx ] +
											quat1[ quatZidx ] * quat2[ quatXidx ] -
											quat1[ quatXidx ] * quat2[ quatZidx ];

		resultQuat[ quatZidx ] =	quat1[ quatWidx ] * quat2[ quatZidx ] +
											quat1[ quatZidx ] * quat2[ quatWidx ] +
											quat1[ quatXidx ] * quat2[ quatYidx ] -
											quat1[ quatYidx ] * quat2[ quatXidx ];

		return resultQuat;
	} // end MultiplyQuaternions


	/** Given an euler value, returns the quaternion */
	static public float[] EulerToQuaternion (float[] euler) {
		float[] quatHeading	= new float[4];
		float[] quatPitch		= new float[4];
		float[] quatRoll		= new float[4];
		float[] quatHP	= new float[4];
		float[] quatHPR	= new float[4];

		quatHeading[ quatWidx ] = (float) Math.cos(euler[ headingIndex ]/2);
		quatHeading[ quatXidx ] = 0;
		quatHeading[ quatYidx ] = (float) Math.sin(euler[ headingIndex ]/2);
		quatHeading[ quatZidx ] = 0;
		// pitch
		quatPitch[ quatWidx ] = (float) Math.cos(euler[ 1 ]/2);
		quatPitch[ quatXidx ] = (float) Math.sin(euler[ 1 ]/2);
		quatPitch[ quatYidx ] = 0;
		quatPitch[ quatZidx ] = 0;
		// roll
		quatRoll[ quatWidx ] = (float) Math.cos(euler[ 2 ]/2);
		quatRoll[ quatXidx ] = 0;
		quatRoll[ quatYidx ] = 0;
		quatRoll[ quatZidx ] = (float) Math.sin(euler[ 2 ]/2);

		quatHP = MultiplyQuaternions(quatHeading, quatPitch);
		quatHPR = MultiplyQuaternions(quatHP, quatRoll);
		return quatHPR;
	}


	/** Given a quaternion, returns an Axis-Angle value */
	static public float[] QuaternionToAxisAngle (float[] quaternion) {
		float[] axisAngle = new float[4];
	   axisAngle[angleIndex] = (float) (2 * Math.acos( quaternion[quatWidx] ) );
   	float s = (float) (Math.sqrt(1 - quaternion[quatWidx]*quaternion[quatWidx]) );
   	if (Math.abs(s) < 0.001) s = 1;
   	axisAngle[xIndex] = quaternion[quatXidx] / s;
   	axisAngle[yIndex] = quaternion[quatYidx] / s;
   	axisAngle[zIndex] = quaternion[quatZidx] / s;
		return axisAngle;
	}

	// NOTE********* this is also in Matrix4x4 and should be here
	/** Given an Axis-Angle value, returns the equivalent quaternion */
	static public float[] AxisAngleToQuaternion(float[] axisAngle ) {
		float[] quaternion = new float[4];
		float sinAngle = (float) Math.sin(axisAngle[3] / 2);
		quaternion[ MathOps.quatXidx ] = axisAngle[xIndex] * sinAngle;
		quaternion[ MathOps.quatYidx ] = axisAngle[yIndex] * sinAngle;
		quaternion[ MathOps.quatZidx ] = axisAngle[zIndex] * sinAngle;
		quaternion[ MathOps.quatWidx ] = (float) Math.cos(axisAngle[ MathOps.angleIndex ] / 2);
		// Normalize the quaternione
		float denominator = (float) Math.sqrt(
					// multiplication much faster than power by 2
					//Math.pow(quaternion[ MathOps.quatXidx ], 2) + 
					//Math.pow(quaternion[ MathOps.quatYidx ], 2) +
					//Math.pow(quaternion[ MathOps.quatZidx ], 2) +
					//Math.pow(quaternion[ MathOps.quatWidx ], 2)
					( quaternion[ MathOps.quatXidx ] * quaternion[ MathOps.quatXidx ] ) + 
					( quaternion[ MathOps.quatYidx ] * quaternion[ MathOps.quatYidx ] ) +
					( quaternion[ MathOps.quatZidx ] * quaternion[ MathOps.quatZidx ] ) +
					( quaternion[ MathOps.quatWidx ] * quaternion[ MathOps.quatWidx ] )
				);
		quaternion[ MathOps.quatXidx ] /= denominator;
		quaternion[ MathOps.quatYidx ] /= denominator;
		quaternion[ MathOps.quatZidx ] /= denominator;
		quaternion[ MathOps.quatWidx ] /= denominator;
		return quaternion;
	} // end AxisAngleToQuaternion


	// SLERP (t; q0, q1) = [ q0* sin(q*(1-t)) + q1* sin(q*t) ] / sin(q)
	/* not sure we can do SLERP because of so much setup, the two quaternions and angle between before we begin
	private float[] SLERP(float pctTime) {
		float[] returnQuaternion = new float[4];
		if (sinTheta != 0) { // this function isn't called if sinTheta == 0
			float sinTheta_X_PctTime = ((float) Math.sin(sinTheta * pctTime)) / sinTheta;
			float sinTheta_X_OneMinusPctTime = ((float) Math.sin(sinTheta * (1 - pctTime)) )/sinTheta;
			for (int i = 0; i < returnQuaternion.length; i++) {
				returnQuaternion[i] = sourceQuaternion[i] * sinTheta_X_OneMinusPctTime + destQuaternion[i] * sinTheta_X_PctTime;
			}
		}
		return returnQuaternion;
	} // end SLERP
	*/

} // end class MathOps
