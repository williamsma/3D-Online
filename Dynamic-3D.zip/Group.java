// Group.java
// � 2002, 3D-Online, All Rights Reserved 
// March 29, 2002

package d3d;


public class Group extends SFNode {

	/** <I>bboxCenter</I> is set by the Dynamic-3D software and thus this value should not be overwritten. */
	public SFVec3f bboxCenter = new SFVec3f(0, 0, 0);
	/** <I>bboxSize</I> is set by the Dynamic-3D software and thus this value should not be overwritten.  */
	public SFVec3f bboxSize = new SFVec3f(-1, -1, -1);

	Matrix4x4 matrix4x4 = new Matrix4x4();

	// constructor
	public Group () {
		datatype = VRMLdatatype.Group;
	}

} // end Group class
