// Gradients.java
// � 2002, 2003 3D-Online, All Rights Reserved 
// Developed 4Q, 2002

package d3d;


public class Gradients {
	
	final int totalVertices = 3;
	final int redIndex = 0;
	final int greenIndex = 1;
	final int blueIndex = 2;
	final int xIndex = 0;
	final int yIndex = 1;
	final int zIndex = 2;


	public float[] aOneOverZ = new float[totalVertices]; // 1/z for ea. vertex
	public float[] aUOverZ = new float[totalVertices]; // u/z for ea. vertex
	public float[] aVOverZ = new float[totalVertices]; // v/z for ea. vertex

	public float[] aRedOverZ = new float[totalVertices]; // red/z for ea. vertex
	public float[] aGreenOverZ = new float[totalVertices]; // green/z for ea. vertex
	public float[] aBlueOverZ = new float[totalVertices]; // blue/z for ea. vertex

	public float dOneOverZdX; // d(1/z)/dX
	public float dOneOverZdY; // d(1/z)/dY

	public float dUOverZdX; // d(u/z)/dX;
	public float dUOverZdY; // d(u/z)/dY;

	public float dVOverZdX; // d(v/z)/dX;
	public float dVOverZdY; // d(v/z)/dY;

	public float dRedOverZdX; // d(red/z)/dX;
	public float dRedOverZdY; // d(red/z)/dY;

	public float dGreenOverZdX; // d(green/z)/dX;
	public float dGreenOverZdY; // d(green/z)/dY;

	public float dBlueOverZdX; // d(blue/z)/dX;
	public float dBlueOverZdY; // d(blue/z)/dY;

	private int pX0, pY0, pX1, pY1, pX2, pY2;

	// version IV of C.Hecker code
	public int dUdXModifier; // fixed16_16
	public int dVdXModifier; // fixed16_16
	private final int Half = 0x8000;  // fixed16_16
	private final int PosModifier = Half;   // fixed16_16
	private final int NegModifier = Half - 1;   // fixed16_16


	public Gradients() { } // constructor does get called


	private int FloatToFixed28_4(float value) { 
		return ((int) (value * 16));
	} // end FloatToFixed28_4


	private float Fixed28_4ToFloat(int value) { 
		return ( ((float)value) / 16.0f);
	} // end Fixed28_4ToFloat


	private int Fixed28_4Mul(int a, int b) { 
		return ( (a * b) >> 4); //28.4 * 28.4 = 28.8 / 16 = 28.4
	} // end Fixed28_4ToFloat


	public void GradientsPolygon(PolygonClass polygonClass, int width, int height) { 

		pX0 = FloatToFixed28_4( polygonClass.vertex[0].x );
		pY0 = FloatToFixed28_4( polygonClass.vertex[0].y );
		pX1 = FloatToFixed28_4( polygonClass.vertex[1].x );
		pY1 = FloatToFixed28_4( polygonClass.vertex[1].y );
		pX2 = FloatToFixed28_4( polygonClass.vertex[2].x );
		pY2 = FloatToFixed28_4( polygonClass.vertex[2].y );

		int X1Y0 = Fixed28_4Mul( (pX1 - pX2), (pY0 - pY2) );
		int X0Y1 = Fixed28_4Mul( (pX0 - pX2), (pY1 - pY2) );

		float polyVertexY02 = Fixed28_4ToFloat( pY0 - pY2 );
		float polyVertexY12 = Fixed28_4ToFloat( pY1 - pY2 );
		float polyVertexX02 = Fixed28_4ToFloat( pX0 - pX2 );
		float polyVertexX12 = Fixed28_4ToFloat( pX1 - pX2 );

		float OneOverdX = 1.0f /
			Fixed28_4ToFloat( (X1Y0 - X0Y1) );

		float OneOverdY = -OneOverdX;
		float OneOverZ;

		/*  texture map offsetting code
	 	TC' = -C x S x R x C x T x TC
		 		C = Center, S = Scale, R = Rotation, T = Translation, TC = original texture coord, Tc' = transformed texture coord

			    -Center   x   Scale    x    Rotation(&)		 x  Center	 xT ranslation x TextureCoord
		      |1 0 -Cx |   |Sx  0 0 |	  | cos& -sin& 0 |	|1 0 Cx |	| 1 0 Tx |   | TCx |
		TC' = |0 1 -Cy | x | 0 Sy 0 | x | sin&  cos& 0 | x |0 1 Cy | x | 0 1 Ty | x | TCy |
		      |0 0  1  |   | 0  0 1 |	  |  0     0   1 |	|0 0  1 |	| 0 0  1 |   |  1  |

				& = angle of rotation in radians
		*/
		float cosRotate = (float) Math.cos(polygonClass.textureCoordinateRotation);
		float sinRotate = (float) Math.sin(polygonClass.textureCoordinateRotation);
		float textureCoordTransformX =
			 (polygonClass.textureCoordinateTranslationX * polygonClass.textureCoordinateScaleX * cosRotate) +
			-(polygonClass.textureCoordinateTranslationY * polygonClass.textureCoordinateScaleX * sinRotate) +
			 (polygonClass.textureCoordinateCenterX * polygonClass.textureCoordinateScaleX * cosRotate) + 
			-(polygonClass.textureCoordinateCenterY * polygonClass.textureCoordinateScaleX * sinRotate) +
			-polygonClass.textureCoordinateCenterX;
											
		float textureCoordTransformY =
			 (polygonClass.textureCoordinateTranslationX * polygonClass.textureCoordinateScaleY * sinRotate) +
			 (polygonClass.textureCoordinateTranslationY * polygonClass.textureCoordinateScaleY * cosRotate) +
			 (polygonClass.textureCoordinateCenterX * polygonClass.textureCoordinateScaleY * sinRotate) + 
			 (polygonClass.textureCoordinateCenterY * polygonClass.textureCoordinateScaleY * cosRotate) +
			-polygonClass.textureCoordinateCenterY;
											
		float Vmax = 0;
		float maxNegativeU = 0;
		float negativeUoffset = 0;
		float uVal = 0;
		float vVal = 0;
		for (int i = 0; i < totalVertices; i++) {
			vVal = polygonClass.textureCoordinateScaleY * sinRotate * polygonClass.vertex[i].textureCoordUnclipped[xIndex] +
									polygonClass.textureCoordinateScaleY * cosRotate * polygonClass.vertex[i].textureCoordUnclipped[yIndex];
			if (Vmax < vVal) {
				Vmax = vVal;
			}
			uVal = polygonClass.textureCoordinateScaleX * cosRotate * polygonClass.vertex[i].textureCoordUnclipped[xIndex] +
					 -polygonClass.textureCoordinateScaleX * sinRotate * polygonClass.vertex[i].textureCoordUnclipped[yIndex];// +
			if (maxNegativeU > uVal) {
				maxNegativeU = uVal;
			}
		}
		negativeUoffset = (float)Math.ceil( Math.abs(maxNegativeU) + Math.abs(textureCoordTransformX));

		int Vceiling = (int) Math.ceil( Vmax + Math.abs(textureCoordTransformY) );

		float UtextureCoord, VtextureCoord;
		float UtextureCoordCosRotate = polygonClass.textureCoordinateScaleX * cosRotate;
		float UtextureCoordSinRotate = -polygonClass.textureCoordinateScaleX * sinRotate;
		float VtextureCoordCosRotate = polygonClass.textureCoordinateScaleY * cosRotate;
		float VtextureCoordSinRotate = polygonClass.textureCoordinateScaleY * sinRotate;
		polygonClass.tiling = false;
		for (int i = 0; i < totalVertices; i++) {
			OneOverZ = 1.0f / polygonClass.vertex[i].z;
			aOneOverZ[i] = OneOverZ;

			aRedOverZ[i] = polygonClass.vertex[i].color[redIndex] * OneOverZ;
			aGreenOverZ[i] = polygonClass.vertex[i].color[greenIndex] * OneOverZ;
			aBlueOverZ[i] = polygonClass.vertex[i].color[blueIndex] * OneOverZ;
			//if ( polygonClass.imageTexture != null ) {
			if ( polygonClass.texture != null ) {
				/*
				aUOverZ[i] = width * OneOverZ *
								(polygonClass.textureCoordinateScaleX * cosRotate * polygonClass.vertex[i].textureCoord[xIndex] +
								-polygonClass.textureCoordinateScaleX * sinRotate * polygonClass.vertex[i].textureCoord[yIndex] +
								 textureCoordTransformX + negativeUoffset);

				aVOverZ[i] = height * OneOverZ *
									(Vceiling - (
									polygonClass.textureCoordinateScaleY * sinRotate * polygonClass.vertex[i].textureCoord[xIndex] +
									polygonClass.textureCoordinateScaleY * cosRotate * polygonClass.vertex[i].textureCoord[yIndex] +
									textureCoordTransformY));
				*/
				UtextureCoord = 
								(UtextureCoordCosRotate * polygonClass.vertex[i].textureCoord[xIndex] +
								 UtextureCoordSinRotate * polygonClass.vertex[i].textureCoord[yIndex] +
								 textureCoordTransformX + negativeUoffset);
				aUOverZ[i] = width * OneOverZ * UtextureCoord;

				VtextureCoord = 
									(Vceiling - (
									VtextureCoordSinRotate * polygonClass.vertex[i].textureCoord[xIndex] +
									VtextureCoordCosRotate * polygonClass.vertex[i].textureCoord[yIndex] +
									textureCoordTransformY));
				aVOverZ[i] = height * OneOverZ * VtextureCoord;

//System.out.println("UtextureCoord = " + UtextureCoord + ", VtextureCoord = " + VtextureCoord );
				if ( (UtextureCoord > 1) || (UtextureCoord < 0) || (VtextureCoord > 1) || (VtextureCoord < 0) ) {
					polygonClass.tiling = true;
				}
			}
			else { // no texture map
				aUOverZ[i] = 0;
				aVOverZ[i] = 0;
			}
		} // end for loop
//if ( polygonClass.tiling ) System.out.println("   TILING");
//System.out.println();

		dOneOverZdX = OneOverdX * (
			( (aOneOverZ[1] - aOneOverZ[2])* polyVertexY02 ) - 
			( (aOneOverZ[0] - aOneOverZ[2])* polyVertexY12 ) ); 
 
		dOneOverZdY = OneOverdY * (
			( (aOneOverZ[1] - aOneOverZ[2])* polyVertexX02 ) - 
			( (aOneOverZ[0] - aOneOverZ[2])* polyVertexX12 ) ); 

		dUOverZdX = OneOverdX * (
			( (aUOverZ[1] - aUOverZ[2])* polyVertexY02 ) - 
			( (aUOverZ[0] - aUOverZ[2])* polyVertexY12 ) ); 

		dUOverZdY = OneOverdY * (
			( (aUOverZ[1] - aUOverZ[2])* polyVertexX02 ) - 
			( (aUOverZ[0] - aUOverZ[2])* polyVertexX12 ) ); 

		dVOverZdX = OneOverdX * (
			( (aVOverZ[1] - aVOverZ[2])* polyVertexY02 ) - 
			( (aVOverZ[0] - aVOverZ[2])* polyVertexY12 ) ); 
		dVOverZdY = OneOverdY * (
			( (aVOverZ[1] - aVOverZ[2])* polyVertexX02 ) - 
			( (aVOverZ[0] - aVOverZ[2])* polyVertexX12 ) ); 

		dRedOverZdX = OneOverdX * (
			( (aRedOverZ[1] - aRedOverZ[2])* polyVertexY02 ) - 
			( (aRedOverZ[0] - aRedOverZ[2])* polyVertexY12 ) ); 

		dRedOverZdY = OneOverdY * (
			( (aRedOverZ[1] - aRedOverZ[2])* polyVertexX02 ) - 
			( (aRedOverZ[0] - aRedOverZ[2])* polyVertexX12 ) ); 

		dGreenOverZdX = OneOverdX * (
			( (aGreenOverZ[1] - aGreenOverZ[2])* polyVertexY02 ) - 
			( (aGreenOverZ[0] - aGreenOverZ[2])* polyVertexY12 ) ); 

		dGreenOverZdY = OneOverdY * (
			( (aGreenOverZ[1] - aGreenOverZ[2])* polyVertexX02 ) - 
			( (aGreenOverZ[0] - aGreenOverZ[2])* polyVertexX12 ) ); 

		dBlueOverZdX = OneOverdX * (
			( (aBlueOverZ[1] - aBlueOverZ[2])* polyVertexY02 ) - 
			( (aBlueOverZ[0] - aBlueOverZ[2])* polyVertexY12 ) ); 

		dBlueOverZdY = OneOverdY * (
			( (aBlueOverZ[1] - aBlueOverZ[2])* polyVertexX02 ) - 
			( (aBlueOverZ[0] - aBlueOverZ[2])* polyVertexX12 ) ); 


	   /***** verxion IV of C.Hecker code *****/
		// set dUdXModifier
		float dUdXIndicator = dUOverZdX * aOneOverZ[0] - aUOverZ[0] * dOneOverZdX;
		if(dUdXIndicator > 0) {
			dUdXModifier = PosModifier;
		}
		else if(dUdXIndicator < 0) {
			dUdXModifier = NegModifier;
		}
		else {
			// dUdX == 0 commented out by C.Hecker
			float dUdYIndicator = dUOverZdY * aOneOverZ[0] - aUOverZ[0] * dOneOverZdY;
			if(dUdYIndicator >= 0) {
				dUdXModifier = PosModifier;
			}
			else {
				dUdXModifier = NegModifier;
			}
		}

		// set dVdXModifier
		float dVdXIndicator = dVOverZdX * aOneOverZ[0] - aVOverZ[0] * dOneOverZdX;
		if(dVdXIndicator > 0) {
			dVdXModifier = PosModifier;
		}
		else if(dVdXIndicator < 0) {
			dVdXModifier = NegModifier;
		}
		else {
			// dVdX == 0 commented out by C.Hecker
			float dVdYIndicator = dVOverZdY * aOneOverZ[0] - aVOverZ[0] * dOneOverZdY;
			if(dVdYIndicator >= 0) {
				dVdXModifier = PosModifier;
			}
			else {
				dVdXModifier = NegModifier;
			}
		}
		/**** end version IV C. Hecker code *****/
	} // GradientsPolygon

} // end class Gradients