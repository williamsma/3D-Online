/*
LineProp.java
Property of 3D-Online, All Rights Reserved, Copyright, 2003
April 15, 2003
*/

package d3d;


class LineProp {

	 public float xDiff;
	 public float zDiffYDir; // z difference in the y direction
	 public float zDiffXDir; // z difference in the x direction
	 public float xPos;
	 public float yPos;
	 public float zPos;

	public void SetUp (PolygonClass polygon) {
		float width  = (polygon.vertex[1].x - polygon.vertex[0].x) + 1;
		int height = (int) ( Math.ceil(polygon.vertex[1].y) - Math.ceil(polygon.vertex[0].y) ) + 1;
		float depth  = (polygon.vertex[1].z - polygon.vertex[0].z) + 1;

		if ( height != 0) {
			xDiff = width / height;
			zDiffYDir = depth / height;
		}
		else {
			xDiff = width;
			zDiffYDir = depth;
		}
		if (width != 0) {
			 zDiffXDir = depth / width;
		}
		else {
			 zDiffXDir = 0;
		}
		xPos = polygon.vertex[0].x;
		yPos = polygon.vertex[0].y;
		zPos = polygon.vertex[0].z;
	}


	public void Step() {
		xPos += xDiff;
		zPos += zDiffYDir;
	} // end step()

} // end class LineProp