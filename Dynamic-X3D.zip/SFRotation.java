 // SFRotation.java
 // � 2002, 3D-Online, All Rights Reserved
 // October 30, 2003

package d3d;

public class SFRotation {

	float[] rotation = new float[4];

	// constructor
	public SFRotation () {
		this.setValue ( 0, 0, 1, 0);
	}
	public SFRotation (float axisX, float axisY, float axisZ, float angle) {
		this.setValue ( axisX,  axisY, axisZ, angle );
	}

	// setValue
	public void setValue (float[] rotations ) {
		for (int i = 0; i < rotation.length; i++) { this.rotation[i] = rotations[i]; };
	}
	public void setValue (float axisX, float axisY, float axisZ, float angle ) {
		this.rotation[0] = axisX;
		this.rotation[1] = axisY;
		this.rotation[2] = axisZ;
		this.rotation[3] = angle;
	}

	// getValue
	public float getX( ) {
		return this.rotation[0];
	}
	public float getY( ) {
		return this.rotation[1];
	}
	public float getZ( ) {
		return this.rotation[2];
	}
	public float getAngle( ) {
		return this.rotation[3];
	}
	// getValue
	public float[] getValue( ) {
		float[] tempRotation = new float[rotation.length];
		for (int i = 0; i < rotation.length; i++) { tempRotation[i] = this.rotation[i]; };
		return tempRotation;
		//return this.rotation;
	}
	/** index 0 thru 3, retrieves values axisX, axisY, axisZ and angle respectively */
	public float getValue(int index ) {
		return this.rotation[index];
	}
	/** returns four <I>rotation</I> values in the order: <I>axisX</I>, <I>axisY</I>, <I>axisZ</I> and <I>angle</I> separated by space characters */
	public String toString( ) {
		String returnString = rotation[0] + " " + rotation[1] + " " + rotation[2] + " " + rotation[3];
		return returnString;
	}

} // end SFRotation
