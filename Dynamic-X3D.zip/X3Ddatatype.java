 // X3Ddatatype.java
 // � 2002, 3D-Online, All Rights Reserved
 // May 20, 2004

package d3d;

public class X3Ddatatype {

	static final String string_xml				= "xml";
	static final String string_X3D				= "X3D";
	static final String string_head				= "head";
		static final String string_name			= "name";
		static final String string_component	= "component";
		static final String string_meta			= "meta";
			static final String string_content	= "content";
	static final String string_Scene			= "Scene";
	static final String string_fromNode			= "fromNode";
	static final String string_fromField		= "fromField";
	static final String string_toNode			= "toNode";
	static final String string_toField			= "toField";

	static final String string_centerOfRotation		= "centerOfRotation";

	/*
	// used to indicate not a touch Sensor object, otherwise, its a positive number
	static final int NotInteractive = -1;

	public static final int SFNode       = 1;
	static final int ROOT       = 2;

	public static final int Anchor		 = 3;
	public static final int Billboard  = 4;
	static final int children   = 5;
	public static final int Group      = 6;
	public static final int Transform  = 7;
	public static final int Shape      = 8;

	public static final int Viewpoint  = 10;

	public static final int DirectionalLight  = 20;
	public static final int PointLight  = 21;
	public static final int SpotLight  = 22;

	public static final int TimeSensor					= 30;
	public static final int TouchSensor					= 31;
	public static final int PositionInterpolator		= 32;
	public static final int CoordinateInterpolator	= 33;
	public static final int ColorInterpolator			= 34;
	public static final int ScalarInterpolator		= 35;
	public static final int NormalInterpolator		= 36;
	public static final int ROUTE							= 38;
	public static final int OrientationInterpolator	= 39;

	public static final int Appearance			= 40;
	public static final int Material				= 41;
	public static final int ImageTexture		= 42;
	public static final int TextureTransform	= 43;
	public static final int PixelTexture		= 44;

	public static final int IndexedLineSet		= 50;
	public static final int IndexedFaceSet		= 51;
	public static final int Coordinate			= 52;
	public static final int Color					= 53;
	public static final int Normal				= 54;
	public static final int TextureCoordinate	= 55;
	public static final int PointSet				= 56;

	public static final int WorldInfo			= 60;
	public static final int Background		= 61;
	public static final int NavigationInfo	= 62;
	static final int Fog					= 63;

	static final int Script	= 70;



	static final String string_DEF					= "DEF";
	static final String string_USE					= "USE";
	static final String string_ROUTE					= "ROUTE";
	static final String string_IS						= "IS";
	static final String string_TO						= "TO";
	static final String string_TRUE					= "TRUE";
	static final String string_FALSE					= "FALSE";
	static String string_Group							= "Group";
		static String string_bboxCenter				= "bboxCenter";
		static String string_bboxSize					= "bboxSize";
	static String string_Anchor						= "Anchor";
		static String string_description				= "description";
		static String string_parameter				= "parameter";
		static String string_url						= "url";
	static String string_Billboard					= "Billboard";
		static String string_axisOfRotation			= "axisOfRotation";
	static String string_Transform					= "Transform";
		static String string_rotation					= "rotation";
		static String string_scale						= "scale";
		static String string_scaleOrientation		= "scaleOrientation";
		static String string_translation				= "translation";
		static String string_center					= "center";
		static String string_children					= "children";
			static String string_Shape					= "Shape";
			static String string_appearance			= "appearance";
				static String string_Appearance		= "Appearance";
					static String string_material		= "material";
						static String string_Material	= "Material";
							static String string_diffuseColor		= "diffuseColor";
							static String string_emissiveColor		= "emissiveColor";
							static String string_specularColor		= "specularColor";
							static String string_transparency		= "transparency";
							static String string_ambientIntensity	= "ambientIntensity";
							static String string_shininess			= "shininess";
					static String string_texture					= "texture";
						static String string_ImageTexture		= "ImageTexture";
							static String string_repeatS			= "repeatS";
							static String string_repeatT			= "repeatT";
					static String string_textureTransform		= "textureTransform";
						static String string_TextureTransform	= "TextureTransform";
					static String string_PixelTexture			= "PixelTexture";
						static String string_image					= "image";
			static String string_geometry					= "geometry";
				static String string_Box					= "Box";
					static String string_size				= "size";
				static String string_Cone					= "Cone";
					static String string_bottom			= "bottom";
					static String string_bottomRadius	= "bottomRadius";
					static String string_height			= "height";
					static String string_side				= "side";
				static String string_Cylinder				= "Cylinder";
					static String string_radius			= "radius";
					static String string_top				= "top";
				static String string_Sphere				= "Sphere";
				static String string_IndexedLineSet		= "IndexedLineSet";
					static String string_coord				= "coord";
					static String string_Coordinate		= "Coordinate";
						static String string_point			= "point";
					static String string_coordIndex		= "coordIndex";
					static String string_texCoord					= "texCoord";
						static String string_TextureCoordinate	= "TextureCoordinate";
					static String string_texCoordIndex			= "texCoordIndex";
					static String string_color				= "color";
						static String string_Color			= "Color";
					static String string_colorIndex		= "colorIndex";
					static String string_colorPerVertex	= "colorPerVertex";
				static String string_IndexedFaceSet		= "IndexedFaceSet";
					static String string_ccw				= "ccw";
					static String string_convex			= "convex";
					static String string_creaseAngle		= "creaseAngle";
					static String string_solid				= "solid";
					static String string_normalPerVertex= "normalPerVertex";
					static String string_normal			= "normal";
						static String string_Normal		= "Normal";
							static String string_vector	= "vector";
					static String string_normalIndex		= "normalIndex";
				static String string_PointSet				= "PointSet";
	static String string_DirectionalLight		= "DirectionalLight";
		static String string_direction			= "direction";
		static String string_intensity			= "intensity";
		static String string_on						= "on";
	static String string_PointLight				= "PointLight";
		static String string_attenuation			= "attenuation";
		static String string_location				= "location";
	static String string_SpotLight				= "SpotLight";
		static String string_beamWidth			= "beamWidth";
		static String string_cutOffAngle			= "cutOffAngle";
	static String string_Viewpoint						= "Viewpoint";
		static String string_fieldOfView					= "fieldOfView";
		static String string_jump							= "jump";
		static String string_orientation					= "orientation";
		static String string_position						= "position";
	static String string_TouchSensor						= "TouchSensor";
		static String string_enabled						= "enabled";
		static String string_isActive						= "isActive";
		static String string_isOver						= "isOver";
	static String string_TimeSensor						= "TimeSensor";
		static String string_cycleInterval				= "cycleInterval";
		static String string_loop							= "loop";
		static String string_startTime					= "startTime";
		static String string_stopTime						= "stopTime";
		static String string_touchTime					= "touchTime";
	static String string_Interpolator					= "Interpolator";
	static String string_PositionInterpolator			= "PositionInterpolator";
	static String string_CoordinateInterpolator		= "CoordinateInterpolator";
	static String string_ColorInterpolator				= "ColorInterpolator";
	static String string_NormalInterpolator			= "NormalInterpolator";
	static String string_ScalarInterpolator			= "ScalarInterpolator";
	static String string_OrientationInterpolator		= "OrientationInterpolator";
		static String string_key							= "key";
		static String string_keyValue						= "keyValue";
		static String string_fraction						= "fraction"; //event in and out for interpolator
		static String string_value							= "value"; //event in and out for interpolator
	static String string_WorldInfo		= "WorldInfo";
		static String string_title			= "title";
		static String string_info			= "info";
	static String string_Background			= "Background";
		static String string_groundAngle		= "groundAngle";
		static String string_groundColor 	= "groundColor";
		static String string_skyAngle 		= "skyAngle";
		static String string_skyColor			= "skyColor";
	static String string_NavigationInfo			= "NavigationInfo";
		static String string_avatarSize			= "avatarSize";
		static String string_headlight			= "headlight";
		static String string_speed					= "speed";
		static String string_type					= "type";
			static String string_EXAMINE			= "EXAMINE";
			static String string_FLY				= "FLY";
			static String string_NONE				= "NONE";
			static String string_WALK				= "WALK";
		static String string_visibilityLimit	= "visibilityLimit";
	static String string_Fog						= "Fog";
		static String string_fogType				= "fogType";
			static String string_LINEAR			= "LINEAR";
			static String string_EXPONENTIAL		= "EXPONENTIAL";
		static String string_visibilityRange	= "visibilityRange";
*/

	// constructor
	//public X3Ddatatype () {}

} // end class X3Ddatatype
