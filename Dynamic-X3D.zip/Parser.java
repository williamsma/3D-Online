// Parser.java
// � 2002, 3D-Online, All Rights Reserved
// Date: March 30, 2002

package d3d;


import java.io.InputStream;
import java.io.StreamTokenizer;
import java.io.Reader;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.zip.GZIPInputStream;


public class Parser {

	StreamTokenizer st = null;
	int tokenType;


	// constructor
	public Parser() {}


	public StreamTokenizer GetStreamTokenizer (InputStream vrmlInputStream) {

		/* */
		// read compressed VRML/X3D
		GZIPInputStream gZipInputStream = null;
		try {
			gZipInputStream = new GZIPInputStream ( vrmlInputStream );
		}
		catch (Exception e) {
			//System.out.println("Error: Parser.StreamTokenizer: " + e.toString());
		}
		InputStreamReader inputStreamReader = new InputStreamReader( gZipInputStream );
		/* */

		// This line for uncompressed data
		//InputStreamReader inputStreamReader = new InputStreamReader( vrmlInputStream );
		Reader reader = new BufferedReader( inputStreamReader );

		// code to read uncompressed VRML
		st = new StreamTokenizer( reader );
		st.whitespaceChars(32, 44); // space till comma
		st.eolIsSignificant(false);
		st.commentChar('#');
		st.wordChars('_', '_');  // underscore char: used in the ROUTE parsing
		//st.quoteChar('"');  // used for strings in url and description
		st.ordinaryChar('"');  // used for strings in url and description
		st.ordinaryChar('\'');  // used for strings for description in places like Viewpoint node
		st.ordinaryChar('/'); // ADDED FOR X3D /> type ENDINGS
		st.ordinaryChar('!'); // ADDED FOR X3D Comments
		//st.ordinaryChar(':'); // ADDED FOR X3D "xmlns:x3d" in <?xml tag

		return st;
	}

	public int GetToken(StreamTokenizer st) {
		try {
			tokenType = st.nextToken();
		}
		catch (Exception e) {
			//System.out.println("Error: Parser.GetToken: " + e.toString());
		}
		return tokenType;
	}

} // end class Parser
