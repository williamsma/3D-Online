// GraphicEngine.java
// � 2002, 3D-Online, All Rights Reserved
// Date: January 3, 2003
// X3D version

package d3d;

import java.applet.Applet;
import java.awt.Panel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.io.InputStream;
import java.net.URL;
import java.awt.Image;
import java.awt.image.MemoryImageSource;
import java.io.InputStreamReader;
import java.awt.Font;
import java.lang.NullPointerException;



import java.net.URLConnection;
import java.io.FileInputStream;
import java.io.FileReader;

public class GraphicEngine extends Panel {

	LexicalAnalyzerX3D lexicalAnalyzer = null;
	Renderer renderer = null;
	WorldScreenCoordinates coordSystem = null;
	MemoryImageSource sourceA = null;
	MemoryImageSource sourceB = null;
	MemoryImageSource source1 = null;
	MemoryImageSource source2 = null;
	Image image1 = null;
	Image image2 = null;
	Image image = null;
	//Graphics gImage1;
	//Graphics gImage2;
	int totalPixels = 0;
	int width, height;
	URL vrmlFile = null;

	//Node root = new Node();
	Group root = new Group();
	Light lightsRoot = new Light();
	Viewpoint viewpointRoot = new Viewpoint();
	Sensor sensorRoot = new Sensor();
	Interpolator interpolatorRoot = new Interpolator();
	Route routeRoot = new Route();
	Shape shapeRoot = new Shape();
	Picking picking = null;
	PickRay pickRay = new PickRay();

	Background background = new Background();
	NavigationInfo navigationInfo = new NavigationInfo();
	Fog fog = new Fog();

	GraphicsDisplay display = null;
	int topPanelHeight = 0;
	int appHeight = 0;
	AppletParameters appletParameters = null;
	Applet applet;
	Dynamic3D dynamic3D_app = null;
	String textureMapFolder = null;

	// for writing the fps
	Color foregroundColor = null;
	Font fpsFont = new Font("Serif", Font.BOLD, 14);
	Float rendererFPS;
	String fpsString;
	int stringLength;
	int strLen;

	GraphicsEngineController graphicsEngineController = null;
	Thread rendererThread = null;
	Object[] renderControlObjects = new Object[2];
	static final int notifyRender = 0;
	static final int notifyMouseDragged = 1;
	PostParser postParser = null;



	int init(Applet _applet, AppletParameters _appletParameters, int topPanelHeight_, int[] pctComplete ) {


		Dimension panelDim = this.getSize();
		applet = _applet;
		topPanelHeight = topPanelHeight_;
		//appHeight = panelDim.height - topPanelHeight;
		appHeight = panelDim.height;
		coordSystem = new WorldScreenCoordinates( panelDim.width, appHeight );
		width = coordSystem.ScreenCoordMaxX;
		height = coordSystem.ScreenCoordMaxY;
		display = new GraphicsDisplay(coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY);
		//display.Clear();
		totalPixels = coordSystem.ScreenCoordMaxX * coordSystem.ScreenCoordMaxY;
		appletParameters = _appletParameters;

		// key verifies they don't try to sideset starting with the GraphicEngineApplet
		if (appletParameters.key == 11241931) {

			renderControlObjects[notifyRender] = new Object();
			renderControlObjects[notifyMouseDragged] = new Object();

			// Set up constructors
			//lexicalAnalyzer = new LexicalAnalyzer( // old VRML version
			lexicalAnalyzer = new LexicalAnalyzerX3D( // debug version
											applet, root, lightsRoot, viewpointRoot,
											sensorRoot, interpolatorRoot, routeRoot, shapeRoot,
											background, navigationInfo, appletParameters,
											fog);

			//pctComplete[0] += 5;
			//applet.repaint();
			routeRoot.SetLinks(root, sensorRoot, interpolatorRoot, viewpointRoot, lightsRoot);

			// Get the VRML file to render
			//String vrmlFileString = appletParameters.GetVRMLFile();
System.out.println();
System.out.println("applet.getDocumentBase().toString() = " + applet.getDocumentBase().toString());
System.out.println("applet.getCodeBase().toString() = " + applet.getCodeBase().toString());
			String vrmlFileString = appletParameters.GetX3Dfile();
System.out.println("vrmlFileString = " + vrmlFileString);
System.out.println();
			try {
				vrmlFile = new URL (applet.getCodeBase(), vrmlFileString);
	System.out.println("vrmlFile.toString() = " + vrmlFile.toString());
System.out.println();
	char forwardSlash = '/';
	String vrmlFileFullString = vrmlFile.toString();
	int lastSlash = vrmlFileFullString.lastIndexOf(forwardSlash);
	String vrmlFileFullSubstring = vrmlFileFullString.substring(0, lastSlash);
	System.out.println("vrmlFileFullSubstring = " + vrmlFileFullSubstring);
	vrmlFileString = vrmlFileFullString;
				System.out.println("File: " + vrmlFileString);
				textureMapFolder = vrmlFileString.substring(0, (vrmlFileString.indexOf("/") + 1) );
	textureMapFolder = vrmlFileFullSubstring;
				System.out.println();
	System.out.println("textureMapFolder = " + textureMapFolder);
	System.out.println("vrmlFile.getHost() = " + vrmlFile.getHost());
	//System.out.println("vrmlFile.getProtocol() = " + vrmlFile.getProtocol());
	//System.out.println("vrmlFile.getRef() = " + vrmlFile.getRef());
	//System.out.println("vrmlFile.getPort() = " + vrmlFile.getPort());
	System.out.println("vrmlFile.getFile() = " + vrmlFile.getFile());
	System.out.println("vrmlFile.getPath() = " + vrmlFile.getPath());
	System.out.println("vrmlFile.toExternalForm() = " + vrmlFile.toExternalForm());
	//System.out.println("vrmlFile.getQuery() = " + vrmlFile.getQuery());
	//System.out.println("vrmlFile.getUserInfo() = " + vrmlFile.getUserInfo());
	//System.out.println("vrmlFile.getAuthority() = " + vrmlFile.getAuthority());



				InputStream vrmlInputStream = null;
				//FileReader vrmlInputStream = null;
				try {
	System.out.println();
	System.out.println("Inside try");
	System.out.println("   vrmlFile.toString() = " + vrmlFile.toString());
	System.out.println("   GraphicsEngine: before openConnection()");
	//URLConnection urlConnection = vrmlFile.openConnection();
	//System.out.println("   GraphicsEngine: before openStream()");
	//vrmlInputStream = (FileInputStream) urlConnection.getInputStream();
	//System.out.println("   GraphicsEngine: after openStream() 1");
					//vrmlInputStream = (FileReader) vrmlFile.openStream();
					vrmlInputStream = vrmlFile.openStream();

					// check if it's a compressed file
					String fileType = vrmlFileString.substring( (vrmlFileString.length()-3), vrmlFileString.length() );
					boolean gzipFile = true;
					if ( fileType.toLowerCase().equals("x3d") ) gzipFile = false;


					//lexicalAnalyzer.ReadStream(vrmlInputStream, textureMapFolder, true); // true indicates a compressed file
					lexicalAnalyzer.ReadStream(vrmlInputStream, textureMapFolder, gzipFile); // true indicates a compressed file
					appletParameters.HTMLOverrideParameters(background, navigationInfo); // HTML parameters override VRML

					dynamic3D_app = new Dynamic3D( root, sensorRoot, interpolatorRoot, lightsRoot, routeRoot);
					dynamic3D_app.Parser();

					//Create new viewpoint if one is not specified
					if ( viewpointRoot.nextViewpoint == null) {
						Viewpoint defaultViewpoint = new Viewpoint();
						defaultViewpoint.setName("default Viewpoint");
						lexicalAnalyzer.AddChild (root, defaultViewpoint);
						viewpointRoot.nextViewpoint = defaultViewpoint;
					}
					// set each vewipoint's original value
					Viewpoint currentViewpoint = viewpointRoot.nextViewpoint;
					while (currentViewpoint != null) {
						currentViewpoint.orientation_Original.setValue( currentViewpoint.orientation.getValue() );
						currentViewpoint.position_Original.setValue( currentViewpoint.position.getValue() );
						currentViewpoint.fieldOfView_Original.setValue( currentViewpoint.fieldOfView.getValue() );
						currentViewpoint = currentViewpoint.nextViewpoint;
					}
					/*
					root.matrix4x4.setIdentityMatrix();
					int[] bg = {255, 255, 255};
					for (int i = 0; i < 3; i++) {
						bg[i] = Math.min(bg[i], (int)Math.abs(background.skyColor.colors[0][i]*255) );
					}
					display.InitializeBackground( bg );
					*/

					postParser = new PostParser(root, background, display);
					//postParser = new PostParser(root);
					postParser.SceneGraph_CreateNormalsBoundingBox( root );

					// PrintPostParser needed only for debug verion
					PrintPostParser printPostParser = new PrintPostParser(lexicalAnalyzer, root, lightsRoot,
								viewpointRoot, routeRoot, sensorRoot, navigationInfo);

					/* */
					// set up displayd box and images
				   source1 = new MemoryImageSource(coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY, display.buffer1RGB, 0, coordSystem.ScreenCoordMaxX);
				   source2 = new MemoryImageSource(coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY, display.buffer2RGB, 0, coordSystem.ScreenCoordMaxX);
				   source1.setAnimated(true);
				   source2.setAnimated(true);
				   image1 = createImage(source1);
				   image2 = createImage(source2);
					/* */

					//sourceA = new MemoryImageSource( width, height, display.buffer1RGB, 0, width);
					//sourceB = new MemoryImageSource( width, height, display.buffer2RGB, 0, width);
					/*
				   image1 = createImage(coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY);
				   image2 = createImage(coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY);
					//gImage1 = image1.getGraphics();
					//gImage2 = image2.getGraphics();
					*/
					picking = new Picking(coordSystem);
					if (renderer == null) {
						renderer = new Renderer(applet, this, display, coordSystem, root,
													lightsRoot, sensorRoot, routeRoot, shapeRoot,
													//navigationInfo, viewpointRoot, currentViewpoint,
													navigationInfo, viewpointRoot,
													appletParameters, renderControlObjects, picking, pickRay, fog);
						RendererObserver rendererObserver = new RendererObserver( renderer );
						graphicsEngineController = new GraphicsEngineController(this, renderer, rendererObserver);
						rendererObserver.init( graphicsEngineController, renderControlObjects );
						//renderer.addObserver(rendererObserver);
						graphicsEngineController.initialize();
					}

					// give up the input file since it is using a resource
					if (vrmlInputStream != null) {
						vrmlInputStream.close();
						//try { vrmlInputStream.close(); }
						//catch (Exception e) { }
						//catch (Exception e) { System.out.println("Error: GraphicEngine: " + e.toString()); }
					} // end if (vrmlInputStream != null)
				} // end try to get VRML file
				catch (java.io.FileNotFoundException e) { // error getting the VRML file
					/*    Don't comment this out ***************************/
					System.out.println("Error: File '" + vrmlFileString + "' not found");
					return(-1);
				} // end catch file not found error
				catch (Exception e) { // error getting the VRML file
					System.out.println("Error: GraphicEngine : " + e.toString() + " in " + vrmlFileString);
					return(-2);
				} // end catch
			} // end try new URL (getCodeBase(), vrmlFileString);
			catch (Exception e) {
				System.out.println("Error: GraphicEngine: " + e.toString() + ", " + vrmlFileString);
				return(-3);
			}
		} // end got proper key
		else {
			System.out.println("GraphicsEngineApplet mismatch - contact 3D-Online");
			return(-4);
		}
		return 0;
	}  // end init





	/** Adds <I>newNode</I> to the scene graph which must include the <I>parent</I>.&nbsp;&nbsp;
	Nodes that can be added include:<BR>Billboard, Group, Shape, Transform, Viewpoint<BR>DirectionalLight, PointLight and SpotLight */
	public void AddNode(SFNode parent, SFNode newNode){
		// add the newNode to the end of the parent's children linked list
		if ( parent.children == null ) parent.children = newNode;
		else {
			SFNode childList = parent.children;
			while ( childList.next != null ) {
				childList = childList.next;
			}
			childList.next = newNode;
			newNode.prev = childList;
		}
		newNode.parent = parent;
		if (newNode.datatype == VRMLdatatype.Shape) {
			postParser.CreateNormals_BoundingBox ( (Shape)newNode );
		}
		else if ( (newNode.datatype == VRMLdatatype.DirectionalLight) ||  (newNode.datatype == VRMLdatatype.PointLight) || (newNode.datatype == VRMLdatatype.SpotLight) ) {
			Light newLight = (Light) newNode;
			//insert new light into light's linked list
			if (newNode.datatype == VRMLdatatype.DirectionalLight) {
				DirectionalLight directionalLight = (DirectionalLight) newLight;
				directionalLight.directionNormalized = MathOps.NormalizeVector( directionalLight.direction.getValue() );
			}
			else if (newNode.datatype == VRMLdatatype.SpotLight) {
				SpotLight spotLight = (SpotLight) newLight;
				spotLight.directionNormalized = MathOps.NormalizeVector( spotLight.direction.getValue() );
			}
			newLight.nextLight = lightsRoot.nextLight;
			lightsRoot.nextLight = newLight;
		} // end adding light
		else if (newNode.datatype == VRMLdatatype.Viewpoint) {
			// add new viewpoint to end of viewpoint linked list
			Viewpoint newVP = (Viewpoint) newNode;
			Viewpoint currVP = viewpointRoot.nextViewpoint;
			while ( currVP.nextViewpoint != null ) {
				currVP = currVP.nextViewpoint;
			}
			currVP.nextViewpoint = newVP;
		}
	} // end AddNode




	/** Adds <I>newNode</I> with name "nodeName" to the parent in the scene graph, same as above */
	public void AddNode(SFNode parent, SFNode newNode, String nodeName){
		AddNode( parent, newNode);
		SFNode checkNode = lexicalAnalyzer.DEFnameNode.next;
		if (nodeName != null) {
			newNode.setName(nodeName);
			SFNode newNameNode = new SFNode();
			newNameNode.setName(nodeName);
			newNameNode.children = newNode;
			newNameNode.next = checkNode.next;
			checkNode.next = newNameNode;
			//checkNode = newNameNode;
		}
	} // AddNode




	/** <I>DetachNode</I> from the scene graph but return an SFNode so it can be added later.<BR> Does not remove lights or viewpoints<BR>
 To re-attach, call AddNode without a name, since the name prior to detachment still exists.<BR>Since this object is detached from the Scene Graph, it will not render*/
	public SFNode DetachNode(SFNode detachNode){
		SFNode returnNode = detachNode;
		if (
			(detachNode.datatype != VRMLdatatype.DirectionalLight) &&
	  		(detachNode.datatype != VRMLdatatype.PointLight) &&
			(detachNode.datatype != VRMLdatatype.SpotLight)  &&
			(detachNode.datatype != VRMLdatatype.Viewpoint)
		) {
			SFNode parentNode = detachNode.parent;
			if (parentNode.children == detachNode) {
				parentNode.children = detachNode.next;
				detachNode.next.prev = null;
			}
			else {
				SFNode childNode = parentNode.children;
				while ( childNode.next != detachNode ) {
					childNode = childNode.next;
				}
				childNode.next = detachNode.next;
				if (detachNode.next != null) {
					detachNode.next.prev = childNode;
				}
			}
			detachNode.parent = null;
			detachNode.prev = null;
			detachNode.next = null;
		}
		return returnNode;
	} // end DetachNode



	/** <I>DeleteNode</I> from the scene graph.<BR> Does not delete lights or viewpoints<BR>
   Currently does not return memory space. */
	public void DeleteNode(SFNode deleteNode){
		SFNode deletedNode = DetachNode(deleteNode);
		// remove node from namedNodes linked list
		SFNode checkNode = lexicalAnalyzer.DEFnameNode;
		while ( checkNode.next != null ) {
			if ( deleteNode.name.equals(checkNode.next.children.name) ) {
				checkNode.next = deleteNode.next;
			}
			else checkNode = checkNode.next;
		}
	} // end DeleteNode



	/** Loads an URL into the node attachNode. Can load wrl or compressed d3d files  */
	public final void LoadURL(java.lang.String url, SFNode attachNode) {
		try {
			vrmlFile = new URL (applet.getCodeBase(), url);
			System.out.println("Load URL: " + url);
			textureMapFolder = url.substring(0, (url.indexOf("/") + 1) );
			String fileEnding = url.substring( (url.length() - 3), url.length());
			boolean compressed = true;
			if ( fileEnding.equals("x3d") ) compressed = false;
			InputStream vrmlInputStream = null;
			try {
				vrmlInputStream = vrmlFile.openStream();
		   	lexicalAnalyzer.LoadURL(vrmlInputStream, textureMapFolder, compressed, attachNode); // true indicates compressed file
				postParser.SceneGraph_CreateNormalsBoundingBox(attachNode);
			}
			catch (Exception e) { System.out.println("Error: GraphicEngine.LoadURL : " + e.toString() + " in " + url); }
		}
		catch (Exception e) { System.out.println("Error: GraphicEngine.LoadURL: " + e.toString() + ", " + url); }
	} // end LoadURL




	/** returns a reference to the applet class */
	public Applet getApplet(){
		return applet;
	} // end getApplet


	/** Get the Frames Per Second performance, updated once a second */
	public float getFramesPerSecond(){
		return renderer.fps;
	} // end getFramesPerSecond


	/** Given the node's name, function returns a reference to that node */
	public SFNode GetNodeByName(String nodeName){
		SFNode returnNode = null;
		SFNode checkNode = lexicalAnalyzer.DEFnameNode.next;
		while ( checkNode != null ) {
			if ( nodeName.equals(checkNode.children.name) ) {
				returnNode = checkNode.children;
				checkNode = null;
			}
			else checkNode = checkNode.next;
		}
		return returnNode;
	} // end getNodeByName

	/** Allows access to picking */
	public PickRay getPickRay(){
		return pickRay;
	} // end getPickRay

	/* functions accessible by the GraphicsEngineController */
	/** Gets the node at the top of the scene graph */
	public Group getRoot(){
		return root;
	} // end getRoot



	/** returns the current viewpoint. */
	public Viewpoint GetCurrentViewpoint(){
		return renderer.currentViewpoint;
	} // end getCurrentViewpoint

	/** sets the current viewpoint. */
	public void SetViewpoint(Viewpoint newViewpoint){
		renderer.SetupAnimatedViewpoint(newViewpoint);
	} // end getCurrentViewpoint

	/** Set <I>animationBetweenViewpoints</I>.&nbsp; True animated between viewpoints, false jumps between Viewpoints */
	public void SetAnimationBetweenViewpoints(boolean value){
		appletParameters.animateBewteenViewpoint = value;
	}
	/** Get the <I>animationBetweenViewpoints</I> value */
	public boolean GetAnimationBetweenViewpoints(){
		return appletParameters.animateBewteenViewpoint;
	}

	/** If setting the Viewpoint's field-of-view, SetViewFrustum must be called to reset clipping planes and desitnation */
	public void SetViewFrustum(float fieldOfView){
		coordSystem.SetViewFrustum(fieldOfView);
	} // end SetViewFrustum

	/** If coordinates are modified, Normals need to be reset */
	public void ResetNormals(Shape shape){
		postParser.CreateNormals_BoundingBox( shape );
	} // end ModifyNormals

	/** setSize of the applet, only enabled if registered user or used locally */
	public void setSize(int width, int height){
		if ( appletParameters.registeredUser ) {
			setSize(width, height);
		}
	} // end setSize
	/** setSize of the applet, only enabled if registered user or used locally */
	public void setSize(Dimension dim){
		this.setSize(dim.width, dim.height);
	} // end setSize
	void reSize(int width, int height){
		this.setSize(width, height);
	} // end reSize
	void reSize(Dimension dim){
		this.setSize(dim.width, dim.height);
	} // end reSize


	/*
	void start( ) {
		if (renderer != null) {
			try { new Thread(renderer).start(); }
			catch ( Exception e ) { System.out.println("GraphicsEngine: Renderer: " + e ); }
		}
	} // end GraphicsEngine.start
	*/
	void start( ) {
		applet.repaint();
		rendererThread = new Thread(renderer);
		if (renderer != null) {
			try { rendererThread.start(); }
			catch ( Exception e ) { System.out.println("GraphicsEngine: Renderer: " + e ); }
		}
	} // end GraphicsEngine.start



	//void stop() {
	void destroy() {
		graphicsEngineController.finalize();
		// commented out for version 1.4
		//rendererThread.stop();
		// uncommented out for version 1.4
		if (renderer != null); {
		    renderer = null;
		}
	} // end stop()


	/** called by GraphicEngine */
	public void paint(Graphics g) {
		if (renderer.paint) {
			try { // catch any errors

				if (!renderer.renderBuffer1) {
					//source1.newPixels(0, 0, coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY );
					//source1.newPixels(0, 0, width, height );

					source1.newPixels();
					g.drawImage(image1, 0, 0, this);
					//System.out.println("b 1");

					//source = new MemoryImageSource( width, height, display.buffer1RGB, 0, width);
					//image = createImage( source );
					//image = createImage( sourceA );
					//g.drawImage(image, 0, 0, this);
					//g.drawImage( createImage( sourceA ), 0, 0, this);
				}
				else {
					//source2.newPixels(0, 0, coordSystem.ScreenCoordMaxX, coordSystem.ScreenCoordMaxY);
					//source2.newPixels(0, 0, width, height);

					source2.newPixels();
					g.drawImage(image2, 0, 0, this);

					//System.out.println(" b 2");
					//image = createImage(new MemoryImageSource( width, height, display.buffer2RGB, 0, width) );
					//source = new MemoryImageSource( width, height, display.buffer2RGB, 0, width);
					//image = createImage( source );
					//image = createImage( sourceB );
					//g.drawImage(image, 0, 0, this);
					//g.drawImage( createImage( sourceB ), 0, 0, this);
				}

				// Comment this out for the Publish version
				/* */
				// write the fps
				g.setFont(fpsFont);
				// give a color across the color wheel from the background color
				foregroundColor = new Color(
										( (appletParameters.backgroundColors[0] + .5f) % 1),
										( (appletParameters.backgroundColors[1] + .5f) % 1),
										( (appletParameters.backgroundColors[2] + .5f) % 1) );
				g.setColor( foregroundColor );
				rendererFPS = new Float( renderer.fps );
				fpsString = rendererFPS.toString();
				stringLength = fpsString.length();
				strLen = java.lang.Math.min(stringLength, 5);
				g.drawString( ("fps: " + fpsString.substring(0, strLen)), 10, 50);
				/* */


				/*** MUST be turn, then wait cause I get rendering errors *******/
				renderer.turn(); // signal thread waiting in run
				// do nothing for a while
				try {	Thread.currentThread().sleep(5);	}
				//try {	Thread.currentThread().sleep(7);	}
				catch ( InterruptedException e ) { return; }

			}
			catch ( java.lang.NullPointerException e ) {
				// catches error I get when paint shuts down
			}
		}

	} // end paint



	/** called by GraphicEngine */
	public void update(Graphics g){
		paint(g);
	} // end update



} // end GraphicsEngine class
