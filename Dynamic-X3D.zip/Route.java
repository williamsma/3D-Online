 // Route.java
 // � 2002, 3D-Online, All Rights Reserved
 // May 11, 2002

package d3d;


public class Route {

	Route nextRoute = null;
	SFNode fromObject = null;
	SFNode toObject   = null;
	RouteProperties from = null;
	RouteProperties to   = null;

	static private SFNode mainRoot = null;
	static private Sensor mainSensorRoot = null;
	static private Interpolator mainInterpolatorRoot = null;
 	static private Viewpoint mainViewpointRoot = null;
   static private Light mainLightsRoot = null;

	public Route() {} // don't seem to need the Constructor


	private void Write(String string) {
		System.out.print(string);
	}
	private void WriteLine(String string) {
		Write(string);
		System.out.println();
	}


	public boolean MatchRoutePropertyName (SFNode objectNode, String propertyName, RouteProperties property) {
		boolean matchFound = false;
		if ( objectNode.datatype == VRMLdatatype.TimeSensor ) {
			TimeSensor objTimeSensor = (TimeSensor) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.sfFloat = objTimeSensor.fraction_changed;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_enabled) != -1) {
				property.sfBool = objTimeSensor.enabled.value;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_startTime) != -1) {
				property.sfTime = objTimeSensor.startTime.time;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == TimeSensor
		else if ( objectNode.datatype == VRMLdatatype.TouchSensor ) {
			TouchSensor objTouchSensor = (TouchSensor) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_isActive) != -1) {
				property.isActiveProperty = true;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_isOver) != -1) {
				property.isOverProperty = true;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_touchTime) != -1) {
				property.touchTimeProperty = true;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_enabled) != -1) {
				property.sfBool = objTouchSensor.enabled.value;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == TouchSensor
		else if ( objectNode.datatype == VRMLdatatype.PositionInterpolator ) {
			PositionInterpolator objInterpolator = (PositionInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
				property.mfVec3f = objInterpolator.keyValue.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == PositionInterpolator
		else if ( objectNode.datatype == VRMLdatatype.CoordinateInterpolator ) {
			CoordinateInterpolator objInterpolator = (CoordinateInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
				property.mfVec3f = objInterpolator.keyValue.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == CoordinateInterpolator
		else if ( objectNode.datatype == VRMLdatatype.ColorInterpolator ) {
			ColorInterpolator objInterpolator = (ColorInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
				property.mfColor = objInterpolator.keyValue.colors;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == ColorInterpolator
		else if ( objectNode.datatype == VRMLdatatype.OrientationInterpolator ) {
			OrientationInterpolator objInterpolator = (OrientationInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
				property.mfRotation = objInterpolator.keyValue.rotations;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == OrientationInterpolator
		else if ( objectNode.datatype == VRMLdatatype.ScalarInterpolator ) {
			ScalarInterpolator objInterpolator = (ScalarInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
				property.mfFloat = objInterpolator.keyValue.values;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == ScalarInterpolator
		else if ( objectNode.datatype == VRMLdatatype.NormalInterpolator ) {
			NormalInterpolator objInterpolator = (NormalInterpolator) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_fraction) != -1) {
				property.mfFloat = objInterpolator.key.values;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_value) != -1 ) {
// need to redo the Normal definition
				property.mfVec3f = objInterpolator.keyValue.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == NormalInterpolator
		else if (objectNode.datatype == VRMLdatatype.Transform) {
			Transform objTransform = (Transform) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_translation) != -1 ) {
				property.sfVec3f = objTransform.translation.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_rotation) != -1 ) {
				property.sfRotation = objTransform.rotation.rotation;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_scale) != -1 ) {
				property.sfVec3f = objTransform.scale.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == Transform
		else if (objectNode.datatype == VRMLdatatype.Viewpoint) {
			Viewpoint objViewpoint = (Viewpoint) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_position) != -1 ) {
				property.sfVec3f = objViewpoint.position.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_orientation) != -1 ) {
				property.sfRotation = objViewpoint.orientation.rotation;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_fieldOfView) != -1 ) {
				property.sfFloat = objViewpoint.fieldOfView.f;
				property.sfFloatType = property.viewpointFieldOfView;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == Viewpoint
		else if (objectNode.datatype == VRMLdatatype.Material) {
			Material objMaterial = (Material) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_diffuseColor) != -1 ) {
				property.sfColor = objMaterial.diffuseColor.color;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_transparency) != -1 ) {
				property.sfFloat = objMaterial.transparency.f;
				property.sfFloatType = property.materialTransparency;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_ambientIntensity) != -1 ) {
				property.sfFloat = objMaterial.ambientIntensity.f;
				property.sfFloatType = property.ambientIntensity;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_emissiveColor) != -1 ) {
				property.sfColor = objMaterial.emissiveColor.color;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_specularColor) != -1 ) {
				property.sfColor = objMaterial.specularColor.color;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_shininess) != -1 ) {
				property.sfFloat = objMaterial.shininess.f;
				property.sfFloatType = property.materialShininess;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == Material
		else if (
				(objectNode.datatype == VRMLdatatype.DirectionalLight) ||
				(objectNode.datatype == VRMLdatatype.PointLight) ||
				(objectNode.datatype == VRMLdatatype.SpotLight) )
			{
			Light objLight = (Light) objectNode;
			DirectionalLight objDirLight = null;
			PointLight objPtLight = null;
			SpotLight objSpotLight = null;
			if (objectNode.datatype == VRMLdatatype.DirectionalLight) objDirLight = (DirectionalLight) objectNode;
			else if (objectNode.datatype == VRMLdatatype.PointLight) objPtLight = (PointLight) objectNode;
			else if (objectNode.datatype == VRMLdatatype.SpotLight) objSpotLight = (SpotLight) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_direction) != -1 ) {
				if (objDirLight != null) property.sfVec3f = objDirLight.direction.vec3s;
				else  property.sfVec3f = objSpotLight.direction.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_location) != -1 ) {
				if (objPtLight != null) property.sfVec3f = objPtLight.location.vec3s;
				else  property.sfVec3f = objSpotLight.location.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_color) != -1 ) {
				property.sfVec3f = objLight.color.color;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_intensity) != -1 ) {
				property.sfFloat = objLight.intensity.f;
				property.sfFloatType = property.intensity;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_ambientIntensity) != -1 ) {
				property.sfFloat = objLight.ambientIntensity.f;
				property.sfFloatType = property.ambientIntensity;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_on) != -1 ) {
				property.sfBool = objLight.on.value;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_cutOffAngle) != -1 ) {
				property.sfFloat = objSpotLight.cutOffAngle.f;
				property.sfFloatType = property.spotLightCutOffAngle;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_beamWidth) != -1 ) {
				property.sfFloat = objSpotLight.beamWidth.f;
				property.sfFloatType = property.spotLightBeamWidth;
				matchFound = true;
				Write(propertyName + " ");
			}
			else if (propertyName.indexOf(VRMLdatatype.string_radius) != -1 ) {
				if (objectNode.datatype == VRMLdatatype.PointLight) property.sfFloat = objPtLight.radius.f;
				else if (objectNode.datatype == VRMLdatatype.SpotLight) property.sfFloat = objSpotLight.radius.f;
				property.sfFloatType = property.lightRadius;
				matchFound = true;
				Write(propertyName + " ");
			}
		} // end datatype == Light
		else if (objectNode.datatype == VRMLdatatype.Coordinate) {
			Coordinate objCoordinate = (Coordinate) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_point) != -1 ) {
				property.mfVec3f = objCoordinate.point.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		}
		else if (objectNode.datatype == VRMLdatatype.TextureTransform) {
			TextureTransform objTextureTransform = (TextureTransform) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_rotation) != -1 ) {
				property.sfFloat = objTextureTransform.rotation.f;
				property.sfFloatType = property.textureTransformRotation;
				matchFound = true;
				Write(propertyName + " ");
			}
		}
		else if (objectNode.datatype == VRMLdatatype.Normal) {
			Normal objNormal = (Normal) objectNode;
			if (propertyName.indexOf(VRMLdatatype.string_vector) != -1 ) {
				property.mfVec3f = objNormal.vector.vec3s;
				matchFound = true;
				Write(propertyName + " ");
			}
		}
		return matchFound;
	} // end MatchRoutePropertyName


	public SFNode MatchRouteObjectName (String objectName) {
		// check if in node list
		SFNode returnNode = null;
		//Note that Viewpoint is linked inside the mainRoot;
		SFNode checkNode = mainRoot.children;
		while (checkNode != null) {
			if (objectName.equals(checkNode.name)) {
				Write( checkNode.name + "." );
				returnNode = checkNode;
				break;
			}
			// at some point, will need to handle coordinate interpolators
			else if (checkNode.datatype == VRMLdatatype.Shape) {
					Shape shape = (Shape) checkNode;
					if (shape.appearance != null) {
						Appearance appearance = (Appearance) shape.appearance;
						if (objectName.equals(appearance.name) ) {
							returnNode = appearance;
						}
						else {
							if (appearance.material != null) {
								Material material = (Material) appearance.material;
								if (objectName.equals(material.name) ) {
									returnNode = (Material) material;
									Write(returnNode.name + ".");
									returnNode.datatype = material.datatype;
								}
							} // end material != null
							if (appearance.textureTransform != null) {
								TextureTransform textureTransform = (TextureTransform) appearance.textureTransform;
								if (objectName.equals(textureTransform.name) ) {
									returnNode = textureTransform;
									Write(returnNode.name + ".");
									returnNode.datatype = textureTransform.datatype;
								}
							} // end textureTransform != null
						}
					} // end if (shape.appearance != null)
					if (shape.geometry != null) {
						// At some point, will need to handle coordinate interpolators
						if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
							IndexedSet indexedSet = (IndexedSet) shape.geometry;
							if (indexedSet.coord != null) {
								if (objectName.equals(indexedSet.coord.name) ) {
									returnNode = (Coordinate) indexedSet.coord;
									Write(returnNode.name + ".");
									returnNode.datatype = indexedSet.coord.datatype;
								}
							}
							if (returnNode == null) {
								if ( shape.geometry.datatype == VRMLdatatype.IndexedFaceSet ) {
									IndexedFaceSet indexedFaceSet = (IndexedFaceSet) shape.geometry;
									if (indexedFaceSet.normal != null) {
										if (objectName.equals(indexedFaceSet.normal.name) ) {
											returnNode = (Normal) indexedFaceSet.normal;
											Write(returnNode.name + ".");
											returnNode.datatype = indexedFaceSet.normal.datatype;
										}
									}
								}
							}
						} // end geometry = IFS or ILS
					} // end if (shape.geometry != null)
			} // end currentNode == Shape
			//else {
				// Get and check next node
				if (checkNode.children != null) {
					checkNode = checkNode.children;
				}
				else if (checkNode.next == null) {
					checkNode = checkNode.parent;
					// scale back up the later
					while ( (checkNode != mainRoot) && (checkNode.next == null) ) {
						checkNode = checkNode.parent;
					}
					checkNode = checkNode.next;
				} // end matchRoot.next == null, go to parent.next
				else {
					checkNode = checkNode.next;
				}
			//} // end getting the next node
		} // end while loop
		if (returnNode == null) {
			// check if object is a timer or touch sensor
			checkNode = mainSensorRoot.next;
			while (checkNode != null) {
				if (objectName.equals(checkNode.name)) {
					Write( checkNode.name);
					returnNode = checkNode;
				}
				checkNode = checkNode.next;
			}
		}
		if (returnNode == null) {
			// check if object is a interpolator
			checkNode = mainInterpolatorRoot.next;
			while (checkNode != null) {
				if (objectName.equals(checkNode.name)) {
					Write( checkNode.name);
					returnNode = checkNode;
				}
				checkNode = checkNode.next;
			}
		}
		if (returnNode == null) {
			// check if object is a light
			Light currLight  = (Light) mainLightsRoot.nextLight;
			while (currLight != null) {
				if (objectName.equals(currLight.name)) {
					Write( currLight.name);
					returnNode = (SFNode) currLight;
				}
				currLight = (Light) currLight.nextLight;
			}
		}
		return returnNode;
	}  // end MatchRouteObjectName



	public void SetLinks (Group root, Sensor sensorRoot, Interpolator interpolatorRoot,
											Viewpoint viewpointRoot, Light lightsRoot) {
		mainRoot = root;
		mainSensorRoot = sensorRoot;
		mainInterpolatorRoot = interpolatorRoot;
 		mainViewpointRoot = viewpointRoot;
   		mainLightsRoot = lightsRoot;
	} // end SetLinks

}//end class Route
