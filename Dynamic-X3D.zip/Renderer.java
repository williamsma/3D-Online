// Renderer.java
// � 2003, 3D-Online, All Rights Reserved
// Date: February 19, 2003

package d3d;

import java.applet.Applet;
import java.awt.Panel;

// imports related to interactivity
import java.applet.AppletContext;
import java.net.URL;
import java.net.MalformedURLException;
//import java.lang.NullPointerException;
import java.awt.Graphics;
import java.awt.Cursor;

import java.util.Observable;

public class Renderer extends Observable implements Runnable {

	WorldScreenCoordinates coordSystem = null;
	public GraphicsDisplay display = null;
	private FrameGenerator frameGenerator = null;
	private KeyFrameAnimator keyFrameAnimator = null;
	protected NavigationInfo navigationInfo = null;
	public Picking picker = null;
	Shape closestPickedShape = null;

	//clock values;
	private long calendarMilliSeconds = 0;
	private int calendarSeconds = 0; // = currentClock.get(Calendar.SECOND);
	private int prevSecond = -1;
	private long prevMilliSeconds = 0;
	private int frameCounter = 0;
	private long fpsLongTime = 0;
	//public float fps = 0; // need fps to initially be big for first time through
	public float fps = 10000; // need fps to initially be big for first time through
	boolean paint = false; // set true when ready to render the first frame

	public boolean bitbltReady = true; // bit blt is the transfer from memory to screen
	public boolean renderBuffer1 = true; // True: Render buffer 1, draw buffer 2.  False: Render buffer 2, draw buffer 1.
	Applet applet = null;
	//Panel graphicsEnginePanel = null;
	GraphicEngine graphicsEnginePanel = null;
	//Node mainRoot = null;
	Group mainRoot = null;
	Light lightRoot = null;
	Viewpoint viewpointRoot = null;
	Fog fog = null;
	Sensor sensorRoot = null;
	Route routeRoot = null;
	AppletParameters appletParameters = null;

	// Interactivity variables
	InteractivityMouseMotion mouseMotion = null;
	InteractivityMouseClicks mouseClicks = null;
	AppletContext appletContext = null;

	boolean mousePressedEvent	= false;
	boolean mouseMoveEvent		= false;
	boolean mouseOverInteractiveObject = false;

	// animated viewpoint variables
	Viewpoint currentViewpoint = null;
	float[] euler = {0, 0, 0};
	float headingDelta = 0;
	float speed = 0;
	int startX = 0;
	int startY = 0;
	boolean mouseDown_ViewpointMoving = false;
	final long animateFixedViewpointTime = 3000; // milliseconds

	Viewpoint destinationVP = null;
	//float[] destQuaternion = new float[4];
	float[] sourceQuaternion = new float[4];
	float[] sourcePosition = new float[3];
	float sourceFieldOfView;
	boolean currentlyAnimatingViewpoint = false;
	long animatingViewpointStartTime = 0;
	//float[] diffOrientation = new float[4];
	float[] diffQuaternion = new float[4];
	float angleBetweenOrientations = 0;
	float sinTheta = 0; // = Math.sin(angleBetweenOrientations);
	PickRay pickRay = null;

	// Pick variables
	Cursor defaultCursor = null;
	Cursor handCursor = null;
	Cursor moveCursor = null;
	private boolean cursorSetByRenderer = false;
	// used for rotation
	float[] eulerDiff = {0, 0, 0};

	/* 3D Studio Max */
	final float performance3DmodelTool = 1.0f;
	/* Caligari TrueSpace or smaller coords */
	//final float performance3DmodelTool = 20.0f;
	Transform rotatedObject = null;
	boolean xAxisRotation = false;
	boolean yAxisRotation = false;
	boolean zAxisRotation = false;
	TouchSensor mostRecentTouchSensor = null;



	//RendererObservable ro = null;
	//RendererObserver rendererObserver = null;
	Object[] renderControlObjects = null;
	MouseInput mouseInput = new MouseInput();


	//public void Renderer() {}

	//void Init(Applet applet_, GraphicEngine graphicsEnginePanel_, GraphicsDisplay display_, WorldScreenCoordinates coordSystem_,
	public Renderer(Applet applet_, GraphicEngine graphicsEnginePanel_, GraphicsDisplay display_, WorldScreenCoordinates coordSystem_,
						Group mainRoot_, Light lightsRoot_, Sensor sensorRoot_, Route routeRoot_, Shape shapeRoot,
						//NavigationInfo navigationInfo_, Viewpoint viewpointsRoot_, Viewpoint currentViewpoint_,
						NavigationInfo navigationInfo_, Viewpoint viewpointsRoot_,
						AppletParameters appletParameters_, Object[] renderControlObjects, Picking picker_, PickRay pickRay_,
						Fog fog_) {

		this.coordSystem = coordSystem_;
		this.display = display_;
		this.applet = applet_;
		this.graphicsEnginePanel = graphicsEnginePanel_;
		this.mainRoot = mainRoot_;
		this.lightRoot = lightsRoot_;
		this.viewpointRoot = viewpointsRoot_;
		//this.currentViewpoint = currentViewpoint_;
		this.sensorRoot = sensorRoot_;
		this.routeRoot = routeRoot_;
		this.navigationInfo = navigationInfo_;
		this.appletParameters = appletParameters_;
		this.picker = picker_;
		this.pickRay = pickRay_;
		this.fog = fog_;

		defaultCursor = new Cursor(Cursor.DEFAULT_CURSOR);
		handCursor = new Cursor(Cursor.HAND_CURSOR);
		moveCursor = new Cursor(Cursor.MOVE_CURSOR);

		//SetViewpointParameters(viewpointRoot.nextViewpoint);
		//currentViewpoint.parent = viewpointRoot.nextViewpoint.parent;
		currentViewpoint = viewpointRoot.nextViewpoint;
		coordSystem.SetViewFrustum( currentViewpoint.fieldOfView.f );

		frameGenerator = new FrameGenerator(coordSystem, mainRoot, lightRoot, display, navigationInfo,
									picker, pickRay, viewpointRoot, currentViewpoint, fog );
		keyFrameAnimator = new KeyFrameAnimator(routeRoot, sensorRoot, this.graphicsEnginePanel);

		// Add interactivity
		mouseMotion = new InteractivityMouseMotion();
		mouseClicks = new InteractivityMouseClicks();
		appletContext = applet.getAppletContext();

		this.renderControlObjects = renderControlObjects;

	} // end Constructor



	// called by another object telling you that it is your turn
	public synchronized void turn() {
		bitbltReady = true;
		notify(); // signal thread waiting in run
	}



	public void SetViewpointParameters(Viewpoint destinationViewpoint) {
		currentlyAnimatingViewpoint = false;
		currentViewpoint.orientation.setValue( currentViewpoint.orientation_Original.getValue() );
		currentViewpoint.position.setValue( currentViewpoint.position_Original.getValue() );
		currentViewpoint.fieldOfView.setValue( currentViewpoint.fieldOfView_Original.getValue() );

		currentViewpoint = destinationViewpoint;
		//currentViewpoint.orientation.setValue( viewpoint.orientation.rotation );
		//currentViewpoint.position.setValue( viewpoint.position.vec3s );
		//currentViewpoint.fieldOfView.setValue( viewpoint.fieldOfView.f );
		coordSystem.SetViewFrustum( currentViewpoint.fieldOfView.f ); // need to set per frame if fieldOfView is animated
	} // end SetViewpointParameters


	private float[] SLERP(float pctTime, float[] destQuaternion) {
		float[] returnQuaternion = new float[4];
		for (int i = 0; i < 4; i++) { // in case angle is 0
			returnQuaternion[i] = sourceQuaternion[i];
		}
		// SLERP (t; q0, q1) = [ q0* sin(q*(1-t)) + q1* sin(q*t) ] / sin(q)
		if (sinTheta != 0) { // this function isn't called if sinTheta == 0
			float sinTheta_X_PctTime = ((float) Math.sin(sinTheta * pctTime)) / sinTheta;
			float sinTheta_X_OneMinusPctTime = ((float) Math.sin(sinTheta * (1 - pctTime)) )/sinTheta;
			for (int i = 0; i < returnQuaternion.length; i++) {
				returnQuaternion[i] = sourceQuaternion[i] * sinTheta_X_OneMinusPctTime +
											destQuaternion[i] * sinTheta_X_PctTime;
			}
		}
		return returnQuaternion;
	} // end SLERP


	private void UpdateAnimatedViewpoint() {
		// Takes into account the desitnation VP may be animated as we go toward it.
		long currTime = System.currentTimeMillis();
		if ( currTime >= (animateFixedViewpointTime + animatingViewpointStartTime) ) {
			SetViewpointParameters( destinationVP );
		} // end final animation frame
		else {
			float[] currPos = new float[3];
			float pctTime = (float)(currTime - animatingViewpointStartTime) / (float) animateFixedViewpointTime;
			float angleBetweenOrientations;
			float quaternionDotProduct;

			if (currentViewpoint == destinationVP) {
				// computer for SLERP
				quaternionDotProduct = MathOps.DotProduct(sourceQuaternion, MathOps.AxisAngleToQuaternion(destinationVP.orientation_Original.rotation) );
				if ( quaternionDotProduct < 0) {
					for (int i = 0; i < sourceQuaternion.length; i++) { sourceQuaternion[i] = -sourceQuaternion[i]; }
					quaternionDotProduct = MathOps.DotProduct(sourceQuaternion, MathOps.AxisAngleToQuaternion(destinationVP.orientation_Original.rotation) );
				}
				angleBetweenOrientations = (float) Math.acos(quaternionDotProduct);
				sinTheta = (float) Math.sin(angleBetweenOrientations);
				// get orientation, but don't divide by 0 (meaning orientation didn't change
				if (sinTheta != 0) currentViewpoint.orientation.setValue(
						MathOps.QuaternionToAxisAngle( SLERP(pctTime, MathOps.AxisAngleToQuaternion(destinationVP.orientation_Original.rotation)) ) );

				// Field of View and Position
				if ( destinationVP.fieldOfView_Original.f != sourceFieldOfView ) {  // animate fieldOfView
					coordSystem.SetViewFrustum( (((destinationVP.fieldOfView_Original.f - sourceFieldOfView) * pctTime) + sourceFieldOfView) );
				}
				for (int i = 0; i < currPos.length; i++) { currPos[i] =
						( (destinationVP.position_Original.vec3s[i] - sourcePosition[i]) * pctTime) + sourcePosition[i]; }
			}
			else {
				// computer for SLERP
				quaternionDotProduct = MathOps.DotProduct(sourceQuaternion, MathOps.AxisAngleToQuaternion(destinationVP.orientation.rotation) );
				if ( quaternionDotProduct < 0) {
					for (int i = 0; i < sourceQuaternion.length; i++) { sourceQuaternion[i] = -sourceQuaternion[i]; }
					quaternionDotProduct = MathOps.DotProduct(sourceQuaternion, MathOps.AxisAngleToQuaternion(destinationVP.orientation.rotation) );
				}
				angleBetweenOrientations = (float) Math.acos(quaternionDotProduct);
				sinTheta = (float) Math.sin(angleBetweenOrientations);
				// get orientation, but don't divide by 0 (meaning orientation didn't change
				if (sinTheta != 0) currentViewpoint.orientation.setValue(
						MathOps.QuaternionToAxisAngle( SLERP(pctTime, MathOps.AxisAngleToQuaternion(destinationVP.orientation.rotation)) ) );

				// Field of View and Position
				if ( destinationVP.fieldOfView.f != sourceFieldOfView ) {  // animate fieldOfView
					coordSystem.SetViewFrustum( (((destinationVP.fieldOfView.f - sourceFieldOfView) * pctTime) + sourceFieldOfView) );
				}
				for (int i = 0; i < currPos.length; i++) { currPos[i] =
						( (destinationVP.position.vec3s[i] - sourcePosition[i]) * pctTime) + sourcePosition[i]; }
			}
			currentViewpoint.position.setValue( currPos );
		} // end animate to vewipoint
	} // end UpdateAnimatedViewpoint


	void SetupAnimatedViewpoint(Viewpoint nextVP) {
		destinationVP = nextVP;
		// go from currentVP (source) to destinationVP
		if ( !appletParameters.animateBewteenViewpoint ) {
			SetViewpointParameters( destinationVP );
		} // end jump to new viewpoint
		else {
			sourceQuaternion = MathOps.AxisAngleToQuaternion( currentViewpoint.orientation.rotation );
			for (int i = 0; i < 3; i++) { sourcePosition[i] = currentViewpoint.position.vec3s[i]; }
			sourceFieldOfView = currentViewpoint.fieldOfView.f;
			currentlyAnimatingViewpoint = true;
			animatingViewpointStartTime = System.currentTimeMillis();
		}
	} // end SetupAnimatedViewpoint


	public synchronized void run() {
/*
long rendererBeginMillisec = System.currentTimeMillis();
long keyFrameBeginMillisec = 0;
long keyFrameTotalMillisec = 0;
long frameGenBeginMillisec = 0;
long frameGenTotalMillisec = 0;
/* */
/*
long callToPaintBeginMillisec = 0;
long callToPaintTotalMillisec = 0;
long renderWaitBeginMillisec = 0;
long renderWaitTotalMillisec = 0;
long renderWaitCounter = 0;
/* */
//int totalFrames = 1000;
//int totalFrames = 0;
/* */

		/*
		// draw first frame to get things started
		keyFrameAnimator.UpdateAnimations();
		closestPickedShape = frameGenerator.GraphicsPipeline(renderBuffer1, currentViewpoint);
		while (!bitbltReady) { // wait until turn
			try { wait(); } // woken up from turn method
			catch ( InterruptedException ex ) { return; }
		}
		bitbltReady = false;
		renderBuffer1 = !renderBuffer1; // True: Render buffer 1, draw buffer 2.  False: Render buffer 2, draw buffer 1.
		//applet.repaint();
		graphicsEnginePanel.repaint();
		*/


//for (int xxx = 0; xxx < totalFrames; xxx++) {
		while ( true ) {
//keyFrameBeginMillisec = System.currentTimeMillis();
			closestPickedShape = null;
			// for RendererObserver
			setChanged();
			notifyObservers( renderControlObjects[0] );
			keyFrameAnimator.UpdateAnimations();
			if ( currentlyAnimatingViewpoint ) UpdateAnimatedViewpoint();
			// Render scene and check if we picked an object
//keyFrameTotalMillisec += (System.currentTimeMillis() - keyFrameBeginMillisec);


//frameGenBeginMillisec = System.currentTimeMillis();
			closestPickedShape = frameGenerator.GraphicsPipeline(renderBuffer1, currentViewpoint);
			// copy the list used by our GraphicsEngineController
			for (int i = 0; i < pickRay.pickedObjectsAppendList; i++ ) {
				pickRay.object[i] = pickRay.objectAppendList[i];
				pickRay.distance[i] = pickRay.distanceAppendList[i];
			}
			pickRay.pickedObjects = pickRay.pickedObjectsAppendList;
//frameGenTotalMillisec += (System.currentTimeMillis() - frameGenBeginMillisec);

			if ( (closestPickedShape != null) && ( !mouseDown_ViewpointMoving ) ){
				mouseOverInteractiveObject = true;
				if (mousePressedEvent) {
					mousePressedEvent = false;
					if ( closestPickedShape.touchSensor  != null ) {
						// closest picked shape under touch sensor or anchor tag
						if (closestPickedShape.touchSensor.datatype == VRMLdatatype.TouchSensor) {
							TouchSensor currentTouchSensor = (TouchSensor) closestPickedShape.touchSensor;
							currentTouchSensor.isActive = true;
							currentTouchSensor.touchTime = System.currentTimeMillis();
							mostRecentTouchSensor = currentTouchSensor;

							// This may be a rotated object
							SFNode highestNode = closestPickedShape.parent;
							while (highestNode != null ) {
								if ( highestNode.touchSensor == null ) break;
								if ( highestNode.datatype == VRMLdatatype.Transform) {
									if ( highestNode.name != null ) {
										String checkNodeName = highestNode.name;
										checkNodeName = checkNodeName.toLowerCase();
										int rotateStringIndex = checkNodeName.indexOf(Dynamic3D.rotateString);
										if (rotateStringIndex != -1) {
											String rotationKeywords = checkNodeName.substring( rotateStringIndex, checkNodeName.length() );
											if ( rotationKeywords.indexOf("x") != -1 ) xAxisRotation = true;
											if ( rotationKeywords.indexOf("y") != -1 ) yAxisRotation = true;
											if ( rotationKeywords.indexOf("z") != -1 ) zAxisRotation = true;
											if ( (!xAxisRotation) && (!yAxisRotation) && (!zAxisRotation) ) {
												xAxisRotation = true;
												yAxisRotation = true;
											}
											rotatedObject = (Transform) highestNode;
											float[] quaternion = MathOps.AxisAngleToQuaternion( rotatedObject.rotation.getValue() );
											eulerDiff = MathOps.QuaternionToEuler (quaternion);
											break;
										} // end if not rotate
									} // end if name != null
								} // end if Transform
								highestNode = highestNode.parent;
							} // end while highestNode != null
						} // end if TouchSensor
						else if (closestPickedShape.touchSensor.datatype == VRMLdatatype.Anchor) {
							Anchor currentAnchor = (Anchor) closestPickedShape.touchSensor;
							String urlString = currentAnchor.url.get1Value(0);
							if ( urlString.startsWith("#") ) {
								urlString = urlString.substring(1, urlString.length() );
								Viewpoint vp = viewpointRoot.nextViewpoint;
								while (vp != null) {
									if ( urlString.equals(vp.name) ) {
										SetupAnimatedViewpoint(vp);
										vp = null;
									} // end if viewpoint name matches the url string
									else vp = vp.nextViewpoint;
								}  // end while vp != null
							} // end anchor change to new viewpoint
							else { // anchor change to new web page
								try {
									URL url = new URL ( applet.getCodeBase(), currentAnchor.url.get1Value(0) );
									if ( currentAnchor.parameter == null ) appletContext.showDocument(url);
									else appletContext.showDocument(url, currentAnchor.parameter.get1Value(0));
								}
								catch ( MalformedURLException e) {
									System.out.println("Error: Renderer.Anchor: " + e);
								}
							}
						} // end if Anchor tag
					} // end pickedObject under TouchSensor or Anchor tag
				} // end mousePressedEvent
				else if 	(mouseMoveEvent) {
					mouseMoveEvent = false;
					if ( closestPickedShape.touchSensor  != null ) {
						// closest picked shape under touch sensor so set isOver true
						if (closestPickedShape.touchSensor.datatype == VRMLdatatype.TouchSensor) {
							TouchSensor currentTouchSensor = (TouchSensor) closestPickedShape.touchSensor;
							currentTouchSensor.isOver = true;
							currentTouchSensor.touchTime = System.currentTimeMillis();
							mostRecentTouchSensor = currentTouchSensor;

							// check if rotate and change the cursor
							boolean isRotate = false;
							SFNode highestNode = closestPickedShape.parent;
							while (highestNode != null ) {
								if ( highestNode.touchSensor == null ) break;
								if ( highestNode.datatype == VRMLdatatype.Transform) {
									if ( highestNode.name != null ) {
										String checkNodeName = highestNode.name;
										checkNodeName = checkNodeName.toLowerCase();
										if ( checkNodeName.indexOf(Dynamic3D.rotateString) != -1) {
											isRotate = true;
											break;
										} // end if not rotate
									} // end if name != null
								} // end if Transform
								highestNode = highestNode.parent;
							} // end while highestNode != null
							if (isRotate) applet.setCursor(moveCursor);
							else applet.setCursor(handCursor);
							cursorSetByRenderer = true;


						} // end if TouchSensor
						else if (closestPickedShape.touchSensor.datatype == VRMLdatatype.Anchor) {
							applet.setCursor(handCursor);
							cursorSetByRenderer = true;
							Anchor currentAnchor = (Anchor) closestPickedShape.touchSensor;
							if ( currentAnchor.description != null ) {
								if ( currentAnchor.description.s != null ) {
									applet.showStatus( currentAnchor.description.s );
								}
							}
							//try {
							//if (currentAnchor.description != null) applet.showStatus( currentAnchor.description.s );
							//else System.out.println("currentAnchor.description == null");
							//}
							//	catch ( NullPointerException e) {
							//		System.out.println("Error: Renderer.Anchor.ShowStatus: " + e);
							//}
						} // end if Anchor tag
					} // end pickedObject under TouchSensor
				} // end	mouseMoveEvent
 		   } // end closestPickedShape != null
			else if ( (mousePressedEvent) && (appletParameters.walkthrough) ) {
				// viewpoint moved
				float[] cameraQuaternion = new float[4];
				euler[MathOps.headingIndex] += headingDelta / fps; //use six for the moment
				cameraQuaternion = MathOps.EulerToQuaternion( euler );
				currentViewpoint.orientation.setValue( MathOps.QuaternionToAxisAngle( cameraQuaternion ) );
				for (int i = 0; i < 4; i++) {
					currentViewpoint.matrix4x4.quaternion[i] = cameraQuaternion[i];
				}
				currentViewpoint.matrix4x4.convertQuaternionToMatrix();
				float[] cameraMotion = new float[4];
				cameraMotion[MathOps.xIndex] = 0;
				cameraMotion[MathOps.yIndex] = 0;
				cameraMotion[MathOps.zIndex] = (float)(speed / fps);
				cameraMotion[3] = 0; // don't multiply translation row by cameraMotion, just the rotation
				currentViewpoint.matrix4x4.multiply4x4byArray( cameraMotion );
				currentViewpoint.position.vec3s[MathOps.xIndex] += cameraMotion[MathOps.xIndex];
				currentViewpoint.position.vec3s[MathOps.yIndex] += cameraMotion[MathOps.yIndex];
				currentViewpoint.position.vec3s[MathOps.zIndex] += cameraMotion[MathOps.zIndex];
				mouseDown_ViewpointMoving = true;
			}
			else {
				mouseDown_ViewpointMoving = false;
				if (rotatedObject == null ) {
					//try {
						if (cursorSetByRenderer) {
							cursorSetByRenderer = false;
							applet.setCursor(defaultCursor);
						}
						applet.showStatus( "" );
					//}
					//catch ( MalformedURLException e) {
					//	System.out.println("Error: Renderer.Anchor: " + e);
					//}
				}
				mousePressedEvent = false;
				mouseOverInteractiveObject = false;
				if ( mostRecentTouchSensor != null) {
					mostRecentTouchSensor.isActive = false;
					mostRecentTouchSensor.isOver = false;
					mostRecentTouchSensor = null;
				}
			}  // end closestPickedShape == null

//renderWaitBeginMillisec = System.currentTimeMillis();
			while (!bitbltReady) { // wait until turn
				try {wait(1); } // woken up from turn method
				//try {wait(2); } // woken up from turn method
				catch ( InterruptedException e ) { return; }
//renderWaitCounter++;
			}
//renderWaitTotalMillisec += (System.currentTimeMillis() - renderWaitBeginMillisec);

//callToPaintBeginMillisec = System.currentTimeMillis();
			bitbltReady = false;
			renderBuffer1 = !renderBuffer1; // True: Render buffer 1, draw buffer 2.  False: Render buffer 2, draw buffer 1.
			//applet.repaint();
//System.out.println("call repaint");
			paint = true; // set true when ready to render the first frame
			graphicsEnginePanel.repaint();
			//graphicsEnginePanel.repaint(50, 50, 200, 200);

			// frame per second calculator
			calendarMilliSeconds = System.currentTimeMillis();
			calendarSeconds = (int)(calendarMilliSeconds / 1000);
			frameCounter++;
			if ( calendarSeconds != prevSecond ) {
				fpsLongTime = calendarMilliSeconds - prevMilliSeconds;
				fps = (float)((frameCounter * 1000.0f) / fpsLongTime);
				prevSecond = calendarSeconds;
				prevMilliSeconds = System.currentTimeMillis();
				frameCounter = 0;
			}  // end calculating fps
//callToPaintTotalMillisec += (System.currentTimeMillis() - callToPaintBeginMillisec);

		} // end the while rendering loop

//System.out.println("end rendering");

/*
long rendererTotalMillisec = System.currentTimeMillis() - rendererBeginMillisec;
double rendererTotalSec = rendererTotalMillisec / 1000.0f;
System.out.println();
System.out.println("viewpoint position = " + currentViewpoint.position.toString() );
System.out.println("viewpoint orientation = " + currentViewpoint.orientation.toString() );
System.out.println();
System.out.println("rendererTotalSec = " + rendererTotalSec + ", totalFrames = " + totalFrames);
if (totalFrames != 0) System.out.println("frame averages " + (rendererTotalSec / totalFrames) + " seconds");
System.out.println("frame / second " + (totalFrames / rendererTotalSec) );

System.out.println("   keyFrameTotalMillisec = " + (keyFrameTotalMillisec/1000.0f) );
System.out.println("   frameGenTotalMillisec = " + (frameGenTotalMillisec/1000.0f) );
System.out.println("      transformsTotalMillisec = " + (frameGenerator.transformsTotalMillisec/1000.0f) );
System.out.println("         clearBufferTotalMillisec = " + (frameGenerator.clearBufferTotalMillisec/1000.0f) );
System.out.println("         clearZBufferTotalMillisec = " + (frameGenerator.clearZBufferTotalMillisec/1000.0f) );
System.out.println("         transformBillboardTotalMillisec = " + (frameGenerator.transformBillboardTotalMillisec/1000.0f) );
System.out.println("         transformVPTotalMillisec = " + (frameGenerator.transformVPTotalMillisec/1000.0f) );
System.out.println("         transformLightTotalMillisec = " + (frameGenerator.transformLightTotalMillisec/1000.0f) );
System.out.println("      drawSceneGraphTotalMillisec = " + (frameGenerator.drawSceneGraphTotalMillisec/1000.0f) );
System.out.println("         rotateNormalsTotalMillisec = " + (frameGenerator.rotateNormalsTotalMillisec/1000.0f) );
System.out.println("         vertexToCameraTotalMillisec = " + (frameGenerator.vertexToCameraTotalMillisec/1000.0f) );
System.out.println("         frontFacePolyTotalMillisec = " + (frameGenerator.frontFacePolyTotalMillisec/1000.0f) );
System.out.println("            colorsTotalMillisec = " + (frameGenerator.colorsTotalMillisec/1000.0f) );
System.out.println("            lightsTotalMillisec = " + (frameGenerator.lightsTotalMillisec/1000.0f) );
//System.out.println("            headlightTotalMillisec = " + (frameGenerator.headlightTotalMillisec/1000.0f) );
//System.out.println("               headlight0 = " + (frameGenerator.headlight0TotalMillisec/1000.0f) );
//System.out.println("               headlight1 = " + (frameGenerator.headlight1TotalMillisec/1000.0f) );
//System.out.println("               headlight2 = " + (frameGenerator.headlight2TotalMillisec/1000.0f) );
//System.out.println("               headlight3 = " + (frameGenerator.headlight3TotalMillisec/1000.0f) );
//System.out.println("               headlight4 = " + (frameGenerator.headlight4TotalMillisec/1000.0f) );
System.out.println("         clippingTotalMillisec = " + (frameGenerator.clippingTotalMillisec/1000.0f) );
System.out.println("            scannerTotalMillisec = " + (frameGenerator.clipping.scannerTotalMillisec/1000.0f) );
System.out.println("               gradientsTotalMillisec = " + (frameGenerator.scanner.gradientsTotalMillisec/1000.0f) );
System.out.println("               edgeTotalMillisec = " + (frameGenerator.scanner.edgeTotalMillisec/1000.0f) );

System.out.println("               drawScanLineTotalMillisec = " + (frameGenerator.scanner.drawScanLineTotalMillisec/1000.0f) );
System.out.println("                  insideDrawScanLineTotalMillisec = " + (frameGenerator.scanner.insideDrawScanLineTotalMillisec/1000.0f) );
System.out.println("                     drawScanLineSetupTotalMillisec = " + (frameGenerator.scanner.drawScanLineSetupTotalMillisec/1000.0f) );
System.out.println("                     drawScanLineMaterialnoTMtotalMillisec = " + (frameGenerator.scanner.drawScanLineMaterialnoTMtotalMillisec/1000.0f) );
System.out.println("                        drawScanLinePart1totalMillisec = " + (frameGenerator.scanner.drawScanLinePart1totalMillisec/1000.0f) );
System.out.println("                           drawScanLineFloatToFixed16_16TotalMillisec = " + (frameGenerator.scanner.drawScanLineFloatToFixed16_16TotalMillisec/1000.0f) );
System.out.println("                           drawScanLineAffineDivTotalMillisec = " + (frameGenerator.scanner.drawScanLineAffineDivTotalMillisec/1000.0f) );
System.out.println("                           drawScanLinePart1forLoopTotalMillisec = " + (frameGenerator.scanner.drawScanLinePart1forLoopTotalMillisec/1000.0f) );
System.out.println("                              drawScanLinePart1forLoopIfTotalMillisec = " + (frameGenerator.scanner.drawScanLinePart1forLoopIfTotalMillisec/1000.0f) );
System.out.println("                              drawScanLinePart1forLoopPastIfTotalMillisec = " + (frameGenerator.scanner.drawScanLinePart1forLoopPastIfTotalMillisec/1000.0f) );

System.out.println("                        drawScanLinePart2totalMillisec = " + (frameGenerator.scanner.drawScanLinePart2totalMillisec/1000.0f) );
System.out.println("   drawScanLinePart1whileLoopTotalIterations = " + frameGenerator.scanner.drawScanLinePart1whileLoopTotalIterations );
System.out.println("   drawScanLinePart1forLoopTotalIterations = " + frameGenerator.scanner.drawScanLinePart1forLoopTotalIterations );


System.out.println();
System.out.println("   renderWaitTotalMillisec = " + (renderWaitTotalMillisec/1000.0f) );
System.out.println("      renderWaitCounter = " + renderWaitCounter );
System.out.println("   callToPaintTotalMillisec = " + (callToPaintTotalMillisec/1000.0f) );
System.out.println("graphicsEnginePanel:" );
System.out.println("   updateTotalMillisec = " + (graphicsEnginePanel.updateTotalMillisec/1000.0f) );
System.out.println("   paintTotalMillisec = " + (graphicsEnginePanel.updateTotalMillisec/1000.0f) );
/* */

	} // end Renderer.run




	public void addMouseObserver() {
		// Add interactivity
		graphicsEnginePanel.addMouseListener(mouseClicks); // captures mouse clicks
		graphicsEnginePanel.addMouseMotionListener(mouseMotion); // mouse moves and dragging
	}


	public void MouseInputNotification (int mouseClickType, int x, int y)  {
		mouseInput.which = mouseClickType;
		mouseInput.x = x;
		mouseInput.y = y;
		mouseInput.timeStamp = System.currentTimeMillis();
		graphicsEnginePanel.graphicsEngineController.onMouseInput(mouseInput);
	} // MouseInputNotification

	class InteractivityMouseMotion extends java.awt.event.MouseMotionAdapter {

		public InteractivityMouseMotion() {
		} // end Constructor


		public void mouseDragged(java.awt.event.MouseEvent event) {
			Object object = event.getSource();
			//if (object == applet) {
			if (object == graphicsEnginePanel) {
				MouseInputNotification (MouseInput.DRAG, event.getX(), event.getY() );
				if ( rotatedObject != null) {
					float deltaX =  ((float)(event.getX() - startX))/(display.width >> 2);
					float deltaY =  ((float)(event.getY() - startY))/(display.width >> 2);
					float[] newEuler = new float[3];
					if (xAxisRotation) newEuler[1] = eulerDiff[1] + deltaY;
					if (yAxisRotation) newEuler[0] = eulerDiff[0] + deltaX;
					if ( (!yAxisRotation) && (zAxisRotation) ) newEuler[2] = eulerDiff[2] + deltaX;  // X and Z
					if ( (!xAxisRotation) && (yAxisRotation) && (zAxisRotation) ) newEuler[2] = eulerDiff[2] + deltaY;  // Y and Z
					float[] quaternion = MathOps.EulerToQuaternion (newEuler);
					rotatedObject.rotation.setValue( MathOps.QuaternionToAxisAngle( quaternion) );
				}
				else if (!mouseOverInteractiveObject) {
					headingDelta = - ( (event.getX() - startX) * navigationInfo.speed.f) / 400f;
					speed = ((event.getY() - startY) * navigationInfo.speed.f)/ performance3DmodelTool;
   			} // !mouseOverInteractiveObject
			} // applet is an object
		} // end mouseDragged



		public void mouseMoved(java.awt.event.MouseEvent event) {
			Object object = event.getSource();
			//if (object == applet) {
			if (object == graphicsEnginePanel) {
				MouseInputNotification (MouseInput.MOVE, event.getX(), event.getY() );
				picker.SetMousePos( event.getX(), event.getY() );
				mouseMoveEvent = true;
			} // end if (object == applet)
		} // mouseMoved

	} // end class InteractivityMouseMotion



	class InteractivityMouseClicks extends java.awt.event.MouseAdapter {

		Matrix4x4 vpMatrix = new Matrix4x4();

		public InteractivityMouseClicks() {
		}

		public void mousePressed(java.awt.event.MouseEvent event) {
			Object object = event.getSource();
			if (object == graphicsEnginePanel) {
				MouseInputNotification (MouseInput.DOWN, event.getX(), event.getY() );
				// find if we clicked on an interactive object
				startX = event.getX();
				startY = event.getY();
				picker.SetMousePos( startX, startY );
				mousePressedEvent = true;
				vpMatrix.convertAxisAngleToQuaternion( currentViewpoint.orientation.getValue() );
				euler = MathOps.QuaternionToEuler( vpMatrix.quaternion );
			} // if object within applet
		} // end MouseClicked


		public void mouseReleased(java.awt.event.MouseEvent event) {
			Object object = event.getSource();
			//if (object == applet) {
			if (object == graphicsEnginePanel) {
				MouseInputNotification (MouseInput.UP, event.getX(), event.getY());
				headingDelta = 0;
				speed = 0;
				rotatedObject = null;
				xAxisRotation = false;
				yAxisRotation = false;
				zAxisRotation = false;

				mousePressedEvent = false;
//System.out.println("mouse released:");
				if ( mostRecentTouchSensor != null) {
//System.out.println("   mostRecentTouchSensor != null");
					mostRecentTouchSensor.isActive = false;
					//mostRecentTouchSensor = null;
				}
//else System.out.println("   mostRecentTouchSensor must = null");
			}
		} // end mouseReleased

	} // end class InteractivityMouseClicks



}  // end Renderer
