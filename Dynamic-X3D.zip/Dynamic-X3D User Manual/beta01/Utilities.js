<!-- Begin Script
function NewWindow1 (fileName, winName) {
		msgWindow = window.open(fileName, winName, "menubar=yes,scrollbars=yes,resizable=yes,width=320,height=240"  );
}
function NewWindow2 (fileName, winName) {
		msgWindow = window.open(fileName, winName, "menubar=yes,scrollbars=yes,resizable=yes,width=480,height=360"  );
}
function NewWindow3 (fileName, winName) {
		msgWindow = window.open(fileName, winName, "menubar=yes,scrollbars=yes,resizable=yes,width=600,height=450"  );
}


function anchorWindow (fileName) {
		msgWindow = window.open(fileName, "AnchorWindow", "menubar=yes,scrollbars=yes,status=yes,toolbar=yes,location=yes, directories=yes,resizable=yes,width=420,height=360"  );
}
function newWindow (url, winName, w, h) {
	options = "menubar=yes,scrollbars=yes,status=no,resizable=yes,toolbar=no,directories=no,location=no,width=" + w + ",height=" + h;
		msgWindow = window.open(url, winName, options  );
   blur();
}
//  End Script -->
