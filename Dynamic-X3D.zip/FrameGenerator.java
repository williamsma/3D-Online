/****************************
FrameGenerator.java
April 9, 2002
Property of 3D-Online, All Rights Reserved, Copyright, 2002

*****************************/

package d3d;


public class FrameGenerator {



	static final int xIndex = 0;
	static final int yIndex = 1;
	static final int zIndex = 2;
	static final int wIndex = 3;
	static final int redIndex   = 0;
	static final int greenIndex = 1;
	static final int blueIndex = 2;
	static final int endLine = -1;

	GraphicsDisplay display = null;
	Scanner scanner = null;
	ScanLine scanLine = null;

	//Node mainRoot = null;
	Group mainRoot = null;
	SFNode currNode = null; // multi-purpose pointer to a current node
	Light lightRoot = null;
	Viewpoint viewpointRoot = null;
	Viewpoint currViewpoint = null;
	NavigationInfo navigationInfo = null;
	Sensor sensorRoot = null;
	//AppletParameters appletParameters = null;
	PolygonClass polygon = null;
	WorldScreenCoordinates coordSys = null;
	Clipping clipping = null;
	ScanPoint scanPoint = null;
	Fog fog = null;
	private Matrix4x4 finalVPMatrix = null;
	private Matrix3x3	finalVP3x3Matrix = null; // used for just rotations for normals and light directions
	private Viewpoint currentViewpoint = null;
	private int totalTransparencyShapes = 0;

	Picking picking = null;
	PickRay pickRay = null;
	float closestPickDistance = java.lang.Float.NEGATIVE_INFINITY;
	Shape closestPickedInteractiveShape = null;

	// DrawShape variables made global for performance
	float[][] vectorsVertexToCamera = new float[3][3];  // 3 vertices per polygon for the moment
	float[] vertexColor = new float[3];
	float[] diffuseColor = new float[3];
	float[] emissiveColor = new float[3];
	float   ambientIntensity = 0;
	// vars for specular highlights
	float[] halfWayVector = new float[3];
	float[] specularColor = new float[3];
	float   shininess = 0;
	int   shininessInt = 0;
	// vars for point and spot lights
	float NormalDotHalfWayVector = 0;
	float attenuationDistance = 0;
	float attenuationSum = 0;
	float[] vertexToPtLightVector = new float[3]; // used by Point and Spot light
	float dotProductLightVector_VertexNormal = 0;
	float[] computeHeadlightSpecularHighlight = new float[3];

	// power-look-up tables values and code
	final int totalShinyFractions = 101; // .00 thru 1.00
	final int totalShininessValues = 129; // 0 thru 128
	float[][] powerLookUpTable = new float[totalShinyFractions][totalShininessValues];


	private void CreatePowerLookupTable() {
		// creates a look up table so we don't have to compute this all the time
		for (int i = 0; i < totalShinyFractions; i++) { // .00 thru 1.00
			for (int j = 0; j < totalShininessValues; j++) { // 0 thru 128
				powerLookUpTable[i][j] = (float) Math.pow( ((float)i)/100.0f, j );
				if (powerLookUpTable[i][j] < .001f) {
					powerLookUpTable[i][j] = 0;
				}
			}
		}
	} // end CreatePowerLookupTable



	public FrameGenerator(WorldScreenCoordinates coordSystem_, Group mainRoot_,
			Light mainLightsRoot, GraphicsDisplay display_,
			NavigationInfo navigationInfo_, Picking picking_, PickRay pickRay_,
			Viewpoint mainViewpointsRoot, Viewpoint currViewpoint_, Fog fog_) {

		this.mainRoot = mainRoot_;
		this.lightRoot = mainLightsRoot;
		this.viewpointRoot = mainViewpointsRoot;
		this.currViewpoint = currViewpoint_;
		this.currentViewpoint = currViewpoint_;
		this.coordSys = coordSystem_;
		this.display = display_;
		this.navigationInfo = navigationInfo_;
		this.picking = picking_;
		this.pickRay = pickRay_;
		this.fog = fog_;

		scanner = new Scanner(display);
		polygon = new PolygonClass();
		scanLine = new ScanLine(display);
		clipping = new Clipping(coordSys, scanner, display );
		scanPoint = new ScanPoint(coordSys, display);

		finalVPMatrix = new Matrix4x4();
		finalVP3x3Matrix = new Matrix3x3(); // used for just rotations for normals and light directions
		CreatePowerLookupTable();
	} // end FrameGenerator Constructor




	private void TransformViewpoint() {
		currentViewpoint.matrix4x4.setIdentityMatrix();
		currentViewpoint.matrix4x4.convertAxisAngleToQuaternion(currentViewpoint.orientation.getValue());
		currentViewpoint.matrix4x4.convertQuaternionToMatrix();
		currentViewpoint.matrix4x4.setTranslationMatrix(currentViewpoint.position.getValue() );

		Matrix4x4 vpTransformations = new Matrix4x4();
		vpTransformations.setIdentityMatrix();
		vpTransformations.multiplyThisby4x4( currentViewpoint.matrix4x4.values );

		Transform transform = null;
		currNode = currentViewpoint.parent;
		while (currNode != null) {
			if (currNode.datatype == VRMLdatatype.Transform) {
				transform = (Transform) currNode;
				vpTransformations.multiply4x4byThis( transform.matrix4x4.values );
			}
			currNode = currNode.parent;
		}

		// Split the transform into its translation and rotation 3 x3
		Matrix4x4 vpTranslations = new Matrix4x4();
		vpTranslations.setIdentityMatrix();
		for (int i = 0; i < 3; i++) {
			vpTranslations.values[i][3] = -vpTransformations.values[i][3];
			vpTransformations.values[i][3] = 0;
		}
		vpTransformations.InvertMatrix();

		finalVPMatrix.setIdentityMatrix();
		finalVPMatrix.multiplyThisby4x4( vpTransformations.values );
		finalVPMatrix.multiplyThisby4x4( vpTranslations.values );
		finalVP3x3Matrix.Copy4x4To3x3matrix( finalVPMatrix.values ); // used for just rotations for normals and light directions

	} // end TransformViewpoint


	private void TransformLighting() {
		Light currentLight = lightRoot.nextLight;
		SFNode nodeParent = null;
		Transform transform = null;
		while (  currentLight != null) {
			if ( currentLight.on.getValue() ) {
				for (int i = 0; i < 3; i++ ) {
					currentLight.computedColor[i] = currentLight.color.color[i] * currentLight.intensity.f;
				}
				nodeParent = currentLight.parent;
				if ( currentLight.datatype == VRMLdatatype.DirectionalLight) {
					DirectionalLight currentDirLight = (DirectionalLight) currentLight;
					currentDirLight.directionMatrix.setIdentityMatrix();
					while (nodeParent != null) {
						if (nodeParent.datatype == VRMLdatatype.Transform) {
							transform = (Transform) nodeParent;
							// since this is a directional light, we don't need translations.
							currentDirLight.directionMatrix.multiply3x3byThis( transform.rotationMatrix.matrix );
						}
						nodeParent = nodeParent.parent;
					}
					// Rotate for the camera's oreintation
					currentDirLight.directionMatrix.multiply3x3byThis( finalVPMatrix.values );
					currentDirLight.directionNormalized = MathOps.NormalizeVector( currentDirLight.direction.getValue() );
					for (int i = 0; i < currentDirLight.directionNormalized.length; i++) { // copy light, reverse its direction for computation
						currentDirLight.lightDirectionTransformed[i] = -currentDirLight.directionNormalized[i];
					}
					currentDirLight.directionMatrix.multiply3x3byArray( currentDirLight.lightDirectionTransformed );
				} // end if currentLight == DirLight
				else if ( currentLight.datatype == VRMLdatatype.PointLight) {
					PointLight currentPointLight = (PointLight) currentLight;
					currentPointLight.matrix4x4.setIdentityMatrix();
					while (nodeParent != null) {
						if (nodeParent.datatype == VRMLdatatype.Transform) {
							transform = (Transform) nodeParent;
							currentPointLight.matrix4x4.multiply4x4byThis( transform.matrix4x4.values );
						}
						nodeParent = nodeParent.parent;
					}
					// Rotate for the camera's oreintation
					currentPointLight.matrix4x4.multiply4x4byThis( finalVPMatrix.values );
					for (int i = 0; i < currentPointLight.location.vec3s.length; i++) {
						currentPointLight.lightLocationTransformed[i] = currentPointLight.location.vec3s[i];
					}
					currentPointLight.matrix4x4.multiply4x4byArray( currentPointLight.lightLocationTransformed );
 				} // end if Light = PointLight
				else if ( currentLight.datatype == VRMLdatatype.SpotLight) {
					SpotLight currentSpotLight = (SpotLight) currentLight;
					currentSpotLight.matrix4x4.setIdentityMatrix();
					currentSpotLight.directionMatrix.setIdentityMatrix();
					while (nodeParent != null) {
						if (nodeParent.datatype == VRMLdatatype.Transform) {
							transform = (Transform) nodeParent;
							currentSpotLight.matrix4x4.multiply4x4byThis( transform.matrix4x4.values );
							currentSpotLight.directionMatrix.multiply3x3byThis( transform.rotationMatrix.matrix );
						}
						nodeParent = nodeParent.parent;
					}
					// Rotate for the camera's orientation
					currentSpotLight.matrix4x4.multiply4x4byThis( finalVPMatrix.values );
					currentSpotLight.directionMatrix.multiply3x3byThis( finalVPMatrix.values );
					// rotate, translate for spot light location
					for (int i = 0; i < currentSpotLight.location.vec3s.length; i++) {
						currentSpotLight.lightLocationTransformed[i] = currentSpotLight.location.vec3s[i];
					}
					currentSpotLight.directionNormalized = MathOps.NormalizeVector( currentSpotLight.direction.getValue() );
					currentSpotLight.matrix4x4.multiply4x4byArray( currentSpotLight.lightLocationTransformed );
					// rotate for spot light direction vector
					for (int i = 0; i < currentSpotLight.directionNormalized.length; i++) { // copy light, reverse its direction for computation
						currentSpotLight.lightDirectionTransformed[i] = -currentSpotLight.directionNormalized[i];
					}
					currentSpotLight.directionMatrix.multiply3x3byArray( currentSpotLight.lightDirectionTransformed );
 				} // end if Light = SpotLight
			} // end if Light is on
			currentLight = currentLight.nextLight;
		} // end while parsing thru Lights
	} // end TransformLighting



	private void TransformsBillboards_MatrixCalculation() {
		currNode = mainRoot;
		while ( currNode != null ) {

			if (currNode.children != null) {
				currNode = currNode.children;
			}
			else if (currNode.next == null) {
				currNode = currNode.parent;
				while ( (currNode != mainRoot) && (currNode.next == null) ) {
					currNode = currNode.parent;
				}
				currNode = currNode.next;
			}
			else {
				currNode = currNode.next;
			}
			if (currNode != null) {
				if (currNode.datatype == VRMLdatatype.Transform) {
					Transform transform = (Transform) currNode;
					// set up matrix = T x C x R x SR x S x -SR x -C
					//    T = translation; C = Center; R = Rotation; SR = scaleOrientation,

					// translation
					transform.matrix4x4.setIdentityMatrix();
					transform.matrix4x4.setTranslationMatrix(transform.translation.getValue()); // translation

					// center
					Matrix4x4 centerMatrix = new Matrix4x4();
					centerMatrix.setIdentityMatrix();
					centerMatrix.setTranslationMatrix(transform.center.getValue());
					transform.matrix4x4.multiplyThisby4x4(centerMatrix.values); // center
					//transform.matrix4x4.multiplyThisby4x4Optimized(centerMatrix.values); // center

					// rotation
					Matrix4x4 rotationMatrix = new Matrix4x4();
					rotationMatrix.setIdentityMatrix();
					rotationMatrix.convertAxisAngleToQuaternion( transform.rotation.getValue() );
					rotationMatrix.convertQuaternionToMatrix();
					transform.rotationMatrix.Copy4x4To3x3matrix(rotationMatrix.values); // rotation of normals
					transform.matrix4x4.multiplyThisby4x4(rotationMatrix.values); // rotation
					//transform.matrix4x4.multiplyThisby4x4Optimized(rotationMatrix.values); // rotation

					// scaleOrientation
					rotationMatrix.setIdentityMatrix();
					rotationMatrix.convertAxisAngleToQuaternion( transform.scaleOrientation.getValue() );
					rotationMatrix.convertQuaternionToMatrix();
					transform.matrix4x4.multiplyThisby4x4(rotationMatrix.values); // scaleOrientation
					//transform.matrix4x4.multiplyThisby4x4Optimized(rotationMatrix.values); // scaleOrientation

					// Scale
					Matrix4x4 scaleMatrix = new Matrix4x4();
					scaleMatrix.setIdentityMatrix();
					scaleMatrix.setScaleMatrix(transform.scale.getValue());
					transform.matrix4x4.multiplyThisby4x4(scaleMatrix.values); // scale
					//transform.matrix4x4.multiplyThisby4x4Optimized(scaleMatrix.values); // scale

					// -scaleOrientation
					rotationMatrix.setIdentityMatrix();
					float[] negativeAxisAngle = transform.scaleOrientation.getValue();
					negativeAxisAngle[3] = -negativeAxisAngle[3];
					rotationMatrix.convertAxisAngleToQuaternion( negativeAxisAngle );
					rotationMatrix.convertQuaternionToMatrix();
					transform.matrix4x4.multiplyThisby4x4(rotationMatrix.values); // -scaleOrientation
					//transform.matrix4x4.multiplyThisby4x4Optimized(rotationMatrix.values); // -scaleOrientation

					// -center
					for (int j = 0; j < 3; j++) {
						centerMatrix.values[j][3] = -centerMatrix.values[j][3];
					}
					transform.matrix4x4.multiplyThisby4x4(centerMatrix.values); // -center
				} // currNode == Transform
				else if (currNode.datatype == VRMLdatatype.Billboard) {
					Billboard billboard = (Billboard) currNode;
					// billboards are rotated same as the viewpoint
					billboard.matrix4x4.setIdentityMatrix();
					billboard.matrix4x4.convertAxisAngleToQuaternion(currentViewpoint.orientation.getValue());
					billboard.matrix4x4.quaternion[3] = -billboard.matrix4x4.quaternion[3];
					billboard.matrix4x4.convertQuaternionToMatrix();
					billboard.rotationMatrix.Copy4x4To3x3matrix(billboard.matrix4x4.values); // rotation of normals
				} // end Billboard
			} // end currNode != null
		} // end while loop currNode != null
	} // end TransformsBillboards_MatrixCalculation



	private void DrawPointSet(Shape shape, boolean renderBuffer1, int clippingPlanes) { // called by DrawShape
		PointSet pointSet = (PointSet) shape.geometry;
		Coordinate coord = (Coordinate) pointSet.coord;
		Color color = (Color) pointSet.color;
		float[] pointColor = new float[3];
		for (int pointNumber = 0; pointNumber < (coord.point.vec3s.length); pointNumber++) {
			if ( pointSet.color != null ) {
					pointColor = color.color.get1Value(pointNumber);
			}
			else if (shape.appearance != null) {
				Appearance appearance = (Appearance) shape.appearance;
				if (appearance.material != null) {
					Material material = (Material) appearance.material;
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						pointColor[colorIdx] = material.emissiveColor.color[colorIdx];
					}
				}
				else {
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						pointColor[colorIdx] = 0;
					}
				}
			} // end else if shape.color == null
			else {
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					pointColor[colorIdx] = 0;
				}
			}
			scanPoint.pointLocation[xIndex] = coord.transformedPoint[pointNumber][xIndex];
			scanPoint.pointLocation[yIndex] = coord.transformedPoint[pointNumber][yIndex];
			scanPoint.pointLocation[zIndex] = coord.transformedPoint[pointNumber][zIndex];
			for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
				scanPoint.pointColor[colorIdx] = pointColor[colorIdx];
			}
			scanPoint.DrawPoint(renderBuffer1, clippingPlanes);
		} // end for (int pointNumber = 0; pointNumber < totalPoints; pointNumber++)
	} // end DrawPointSet



	private void DrawIndexedLineSet(Shape shape, boolean renderBuffer1, int clippingPlanes) { // called by DrawShape
		IndexedLineSet indexedLineSet = (IndexedLineSet) shape.geometry;
		float[][] pointColor = new float[2][3];
		Coordinate coord = (Coordinate) indexedLineSet.coord;
		Color color = (Color) indexedLineSet.color;
		int lineNumber = -1;
		for (int lineCoord = 0; lineCoord < (indexedLineSet.coordIndex.values.length - 1); lineCoord++) {
			if ( (indexedLineSet.coordIndex.get1Value(lineCoord) != endLine) && (indexedLineSet.coordIndex.get1Value(lineCoord+1) != endLine) ) {
				lineNumber++;
				// use colorIndex values if available, else use emissiveColor, else make it white.
				for (int linePt = 0; linePt < 2; linePt++) {
					for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
						pointColor[linePt][colorIdx] = 1;
					}
				}
				for (int linePt = 0; linePt < 2; linePt++) {
					if ( indexedLineSet.color != null ) {
						if ( indexedLineSet.colorPerVertex.value ) {
							if ( indexedLineSet.colorIndex == null) {
								pointColor[linePt] =
									color.color.get1Value( indexedLineSet.coordIndex.get1Value(lineCoord+linePt) );
							} // end if colorIndex == null
							else { // end if colorIndex != null
								pointColor[linePt] =
										color.color.get1Value( indexedLineSet.colorIndex.get1Value(lineCoord+linePt) );
							} // end if colorIndex != null
						}
						else { // indexedLineSet.colorPerVertex == false
							if ( indexedLineSet.colorIndex == null) {
								pointColor[linePt] = color.color.get1Value( lineNumber );
							} // end if colorIndex == null
							else { // end if colorIndex != null
								pointColor[linePt] =
									color.color.get1Value( indexedLineSet.colorIndex.get1Value(lineNumber) );
							} // end if colorIndex != null
						} // end else if shape.indexedLineSet.colorPerVertex == false
					} // end if shape.color != null
					else { // Spec says use the emissiveColor if specified
						if (shape.appearance != null) {
							Appearance appearance = (Appearance) shape.appearance;
							if (appearance.material != null) {
								Material material = (Material) appearance.material;
								for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
									pointColor[linePt][colorIdx] = material.emissiveColor.color[colorIdx];
								}
							}
						}
					} // end else if shape.color == null
				} // end for lineNumber 0 to 1
				clipping.vertexPts[0][xIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord)][xIndex];
				clipping.vertexPts[0][yIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord)][yIndex];
				clipping.vertexPts[0][zIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord)][zIndex];
				clipping.vertexPts[1][xIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord+1)][xIndex];
				clipping.vertexPts[1][yIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord+1)][yIndex];
				clipping.vertexPts[1][zIndex] =
							coord.transformedPoint[indexedLineSet.coordIndex.get1Value(lineCoord+1)][zIndex];
				for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
					clipping.vertexColor[0][colorIdx] = pointColor[0][colorIdx];
					clipping.vertexColor[1][colorIdx] = pointColor[1][colorIdx];
				}
				clipping.ClipLine(renderBuffer1, clippingPlanes);
			} // Neither pt is a line ending
		} // end for (int lineNumber = 0; lineNumber < shape.indexedLineSet.coordIndex.length; lineNumber++)
	} // end DrawIndexedLineSet



	private void GetSingleVertexToCameraVector(Shape shape, int polygonNumber, int vertexNumber) {
		IndexedSet indexedSet = (IndexedSet) shape.geometry;
		Coordinate coord = (Coordinate) indexedSet.coord;
		vectorsVertexToCamera[vertexNumber] = MathOps.NormalizeVector(
				coord.transformedPoint[indexedSet.coordIndex.values[polygonNumber*4 + vertexNumber]] );
		for (int j = 0; j < 3; j++) {
			vectorsVertexToCamera[vertexNumber][j] = -vectorsVertexToCamera[vertexNumber][j];
		}
	}

	private void GetVertexToCameraVector(Shape shape, int polygonNumber) {
		// gives us normalized vectors from each polygon's vertices back to the camera
		// used for determining backface culling and specular highlights
		// Camera is already transformed to (0,0,0) so, we only need center point
		for (int vertexNumber = 0; vertexNumber < vectorsVertexToCamera.length; vertexNumber++) {
			GetSingleVertexToCameraVector(shape, polygonNumber, vertexNumber );
		}
	} // end GetVertexToCameraVector



	private void DrawIndexedFaceSet(Shape shape, boolean renderBuffer1, int clippingPlanes) { // called by DrawShape
try {
//rotateNormalsBeginMillisec = System.currentTimeMillis();
		IndexedFaceSet indexedFaceSet = (IndexedFaceSet) shape.geometry;
		Coordinate coord = (Coordinate) indexedFaceSet.coord;
		Color color = (Color) indexedFaceSet.color;
		Normal normalVertex = (Normal) indexedFaceSet.normal;
 	   //Coordinate coord = indexedFaceSet.coord;
		//MFInt32 coordIndex = indexedFaceSet.coordIndex;
		for (int polyNormalNumber = 0; polyNormalNumber < indexedFaceSet.normalPolygon.vector.vec3s.length; polyNormalNumber++) {
			// copy the vertex normals and transform (rotate) them
			for (int j = 0; j < 3; j++) {
				indexedFaceSet.normalPolygon.transformedVector[polyNormalNumber][j] = indexedFaceSet.normalPolygon.vector.vec3s[polyNormalNumber][j];
			}
			shape.rotationMatrix.multiply3x3byArray( indexedFaceSet.normalPolygon.transformedVector[polyNormalNumber] );
			//*** since only using rotation matrices, we don't need to normalized the vector
			//shape.indexedFaceSet.normalPolygon.transformedVector[polyNormalNumber] =
			//	MathOps.NormalizeVector( shape.indexedFaceSet.normalPolygon.transformedVector[polyNormalNumber] );
		}  // end transformations of vertex normals


		for (int vertexNormalNumber = 0; vertexNormalNumber < normalVertex.vector.vec3s.length; vertexNormalNumber++) {
			// copy the vertex normals and transform them
			for (int j = 0; j < 3; j++) {
				normalVertex.transformedVector[vertexNormalNumber][j] = normalVertex.vector.vec3s[vertexNormalNumber][j];
			}
			shape.rotationMatrix.multiply3x3byArray( normalVertex.transformedVector[vertexNormalNumber] );
		}  // end covertion from 3D vertices to 2D coordinates

		boolean boundBoxPicked = picking.BoundingBoxPicked( ((Coordinate)indexedFaceSet.coord) );
		// currently only doing 3-vertex polygons
		for (int polygonNumber = 0; polygonNumber < indexedFaceSet.coordIndex.values.length/4; polygonNumber++) {
			// get all the normalized vectors from the camera to each vertex
			GetSingleVertexToCameraVector(shape, polygonNumber, 0 );

			if ( MathOps.DotProduct(vectorsVertexToCamera[0], indexedFaceSet.normalPolygon.transformedVector[polygonNumber]) > 0 ) {
			GetSingleVertexToCameraVector(shape, polygonNumber, 1 );
			GetSingleVertexToCameraVector(shape, polygonNumber, 2 );
				//This polygon is front-facing
				clipping.totalVertices = 3;  // only 3-vertex polygons

				for (int vertexNumber = 0; vertexNumber < 3; vertexNumber++) { //only doing 3-vertex polygons
					// Assign the colors for each vertex, using either the color or material properties of indexedSet
					shininess = 0;
					shininessInt = 0;
					ambientIntensity = 0;
					for (int colorIdx = 0; colorIdx < vertexColor.length; colorIdx++) {
						vertexColor[colorIdx] = 0;
						diffuseColor[colorIdx] = 0;
						//diffuseColor[colorIdx] = .5f;
						emissiveColor[colorIdx] = 0;
						specularColor[colorIdx] = 0;
					}
					if ( (indexedFaceSet.color != null) && (polygon.texture == null) ) {
						if ( indexedFaceSet.colorPerVertex.value ) {
							if ( indexedFaceSet.colorIndex == null) {
								diffuseColor = color.color.get1Value( indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber] );
							} // end if colorIndex == null
							else { // colorIndex != null
								diffuseColor = color.color.get1Value( indexedFaceSet.colorIndex.values[polygonNumber * 4 + vertexNumber] );
							} // end if colorIndex != null
						} // end if colorPerVertex == true
						else { // else colorPerVertex == false
							if ( indexedFaceSet.colorIndex != null) {
								diffuseColor = color.color.get1Value( indexedFaceSet.colorIndex.values[polygonNumber] );
							} // end if colorIndex != null
							else {
								diffuseColor = color.color.get1Value( polygonNumber );
							} // end if colorIndex == null
						}  // end if colorPerVertex == false
					} // end if shape.color != null
					else if (shape.appearance != null) {
						Appearance appearance = (Appearance) shape.appearance;
						if (appearance.material != null) {
							Material material = (Material) appearance.material;
							for (int colorIdx = 0; colorIdx < vertexColor.length; colorIdx++) {
								//if (polygon.imageTexture == null) {
								if (polygon.texture == null) {
									diffuseColor[colorIdx] = material.diffuseColor.color[colorIdx];
								}
								else {
									//diffuseColor[colorIdx] = 0; // matches Cosmo and Shout3D with Texture and Material
									diffuseColor[colorIdx] = 1; // necessary for different color lights
								}
								emissiveColor[colorIdx] = material.emissiveColor.color[colorIdx];
								specularColor[colorIdx] = material.specularColor.color[colorIdx];
							}
							shininess = material.shininess.f * 128;
							//shininessInt = (int)(shape.appearance.material.shininess.f * 128 + .49f); // round off shininess to nearest int between 0 and 128
							shininessInt = (int)(shininess); // round off shininess to nearest int between 0 and 128

							ambientIntensity = material.ambientIntensity.f;
						} // end if shape.appearance.material != null
					} // end if shape.appearance != null

					// Calculate the lights
					int vertex = indexedFaceSet.normalVertexIndex[polygonNumber][vertexNumber];
					Light currentLight = lightRoot.nextLight;
					while ( currentLight != null ) {
						if ( currentLight.on.getValue() ) {
							if ( currentLight.datatype == VRMLdatatype.DirectionalLight) {
								DirectionalLight currentDirLight = (DirectionalLight) currentLight;
								float dotProductLightVector_VertexNormal = MathOps.DotProduct(currentDirLight.lightDirectionTransformed,
																	normalVertex.transformedVector[vertex]);
								if (dotProductLightVector_VertexNormal > 0) { // if dotProduct > 0, then light is directed toward polygon
									for (int k = 0; k < 3; k++) {
										halfWayVector[k] = currentDirLight.lightDirectionTransformed[k] + vectorsVertexToCamera[vertexNumber][k];
									}
									halfWayVector = MathOps.NormalizeVector(halfWayVector);
									NormalDotHalfWayVector = MathOps.DotProduct(normalVertex.transformedVector[vertex], halfWayVector);
									//NormalDotHalfWayVector = (float) Math.pow(NormalDotHalfWayVector, shininess);
									//NormalDotHalfWayVector = powerLookUpTable[(int)(NormalDotHalfWayVector*100)][shininessInt];
									if (NormalDotHalfWayVector > 0) NormalDotHalfWayVector = powerLookUpTable[(int)(NormalDotHalfWayVector*100)][shininessInt];
									else NormalDotHalfWayVector = 0;
									for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
										vertexColor[colorIdx] +=
											//(dotProductLightVertex * diffuseColor[colorIdx] + NormalDotHalfWayVector * specularColor[colorIdx]) *
											(dotProductLightVector_VertexNormal * diffuseColor[colorIdx] + NormalDotHalfWayVector * specularColor[colorIdx]) *
											currentDirLight.computedColor[colorIdx];
											//dotProductLightVertex * diffuseColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.value +
											//NormalDotHalfWayVector * specularColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.value;
											//dotProductLightVertex * diffuseColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.getValue() +
											//NormalDotHalfWayVector * specularColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.getValue();
			//**************** ambient intensity might be added outside this if statement
			//ambientIntensity * diffuseColor[colorIdx] + currentDirLight.ambientIntensity.value;
										//vertexColor[colorIdx] +=
										//	dotProductLightVertex * diffuseColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.getValue() +
										//	NormalDotHalfWayVector * specularColor[colorIdx] * dirLightColor[colorIdx] * currentDirLight.intensity.getValue() +
										//	ambientIntensity * diffuseColor[colorIdx] + currentDirLight.ambientIntensity.value;
									}
								}  // light within 90 degrees of object
							} // if currentLight == DirectionalLight
							else if ( currentLight.datatype == VRMLdatatype.PointLight) {
								PointLight currentPointLight = (PointLight) currentLight;
								// get the vector from the pt light to the vertex
								for (int i = 0; i < 3; i++) {
									vertexToPtLightVector[i] =
	  									currentPointLight.lightLocationTransformed[i] -
										coord.transformedPoint[indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][i];
								}
								float vectorLength = MathOps.VectorLength( vertexToPtLightVector );
								// ck if vertex within pt light's radius
								if ( vectorLength < currentPointLight.radius.f ) {
									vertexToPtLightVector = MathOps.NormalizeVector(vertexToPtLightVector);
									dotProductLightVector_VertexNormal = MathOps.DotProduct(vertexToPtLightVector,
																	normalVertex.transformedVector[vertex]);
									if (dotProductLightVector_VertexNormal > 0) { // if dotProduct > 0, then light is directed toward polygon
										// compute specular highlights
										for (int k = 0; k < 3; k++) {
											halfWayVector[k] = vertexToPtLightVector[k] + vectorsVertexToCamera[vertexNumber][k];
										}
										halfWayVector = MathOps.NormalizeVector(halfWayVector);
										NormalDotHalfWayVector = MathOps.DotProduct( normalVertex.transformedVector[vertex], halfWayVector);
										//NormalDotHalfWayVector = (float) Math.pow(NormalDotHalfWayVector, shininess);
										if (NormalDotHalfWayVector > 0) NormalDotHalfWayVector = powerLookUpTable[(int)(NormalDotHalfWayVector*100)][shininessInt];
										else NormalDotHalfWayVector = 0;
										attenuationDistance = (currentPointLight.radius.f - vectorLength)/currentPointLight.radius.f;
										attenuationSum = currentPointLight.attenuation.vec3s[0] + attenuationDistance *
																	(currentPointLight.attenuation.vec3s[1] + currentPointLight.attenuation.vec3s[2]*attenuationDistance);
										for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
											vertexColor[colorIdx] +=
												(dotProductLightVector_VertexNormal * diffuseColor[colorIdx] + NormalDotHalfWayVector * specularColor[colorIdx]) *
												( currentPointLight.computedColor[colorIdx] * attenuationSum );
										}
									} // end light less than 90 degress angle from vertex
								} // vertex to light < currentPointLight.radius
							} // if currentLight == PointLight
							else if ( currentLight.datatype == VRMLdatatype.SpotLight) {
								SpotLight currentSpotLight = (SpotLight) currentLight;
								// get the vector from the pt light to the vertex
								for (int i = 0; i < 3; i++) {
									vertexToPtLightVector[i] =
	  									currentSpotLight.lightLocationTransformed[i] -
										coord.transformedPoint[indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][i];
								}
								float vectorLength = MathOps.VectorLength( vertexToPtLightVector );
								// ck if vertex within pt light's radius
								if ( vectorLength < currentSpotLight.radius.f ) {
									vertexToPtLightVector = MathOps.NormalizeVector(vertexToPtLightVector);
									dotProductLightVector_VertexNormal = MathOps.DotProduct(vertexToPtLightVector,
																	normalVertex.transformedVector[vertex]);
									if (dotProductLightVector_VertexNormal > 0) { // if dotProduct > 0, then light is directed toward polygon
										// determine angle between spot light direction and vertex to see if its inside beamWidth and cutOffAngle
										float[] lightToVertexVector = new float[3]; // just the reverse direction of vertex to light
										for (int i = 0; i < lightToVertexVector.length; i++) {  // just the reverse direction of vertex to light
											lightToVertexVector[i] = vertexToPtLightVector[i];
										}
										float angleToVertex = (float) Math.acos( MathOps.DotProduct( lightToVertexVector, currentSpotLight.lightDirectionTransformed ) );
 										if ( angleToVertex < currentSpotLight.cutOffAngle.f ) {
 											float cutOffAngleMultiplier = 1;
											if ( angleToVertex > currentSpotLight.beamWidth.f ) {
 												cutOffAngleMultiplier = (angleToVertex - currentSpotLight.cutOffAngle.f)/
																				(currentSpotLight.beamWidth.f - currentSpotLight.cutOffAngle.f);
 										   }
											// compute specular highlights
											for (int k = 0; k < 3; k++) {
												halfWayVector[k] = vertexToPtLightVector[k] + vectorsVertexToCamera[vertexNumber][k];
											}
											halfWayVector = MathOps.NormalizeVector(halfWayVector);
											NormalDotHalfWayVector = MathOps.DotProduct( normalVertex.transformedVector[vertex], halfWayVector);
											//NormalDotHalfWayVector = (float) Math.pow( NormalDotHalfWayVector, shininess );
											if (NormalDotHalfWayVector > 0) NormalDotHalfWayVector = powerLookUpTable[(int)(NormalDotHalfWayVector*100)][shininessInt];
											else NormalDotHalfWayVector = 0;
											attenuationDistance = (currentSpotLight.radius.f - vectorLength)/currentSpotLight.radius.f;
											attenuationSum = currentSpotLight.attenuation.vec3s[0] + attenuationDistance *
																		(currentSpotLight.attenuation.vec3s[1] + currentSpotLight.attenuation.vec3s[2]*attenuationDistance);
											for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
												vertexColor[colorIdx] +=
													(dotProductLightVector_VertexNormal * diffuseColor[colorIdx] + NormalDotHalfWayVector * specularColor[colorIdx]) *
													( currentSpotLight.computedColor[colorIdx] * attenuationSum * cutOffAngleMultiplier);
											}
										} // end angle < cutOffAngle
									} // end light less than 90 degress angle from vertex
								} // vertex to light < currentSpotLight.radius
							} // end if currentLight == SpotLight
						} // if light.on
						currentLight = currentLight.nextLight;
					} // end while currentLight != null

					if ( navigationInfo.headlight.value ) {
						// headlight on: points in same direction as camera (while in camera space)
						//    thus headlight direction is (0, 0, -1), so ignore x and y value.  Light color is white
						for (int k = 0; k < 3; k++) {
							halfWayVector[k] = vectorsVertexToCamera[vertexNumber][k];
						}
						halfWayVector[zIndex] += 1;
						halfWayVector = MathOps.NormalizeVector(halfWayVector);
						NormalDotHalfWayVector =
							MathOps.DotProduct( normalVertex.transformedVector[vertex], halfWayVector );
						if (NormalDotHalfWayVector > 0 ) {
							//NormalDotHalfWayVector = (float) Math.pow(NormalDotHalfWayVector, shininess);
							NormalDotHalfWayVector = powerLookUpTable[(int)(NormalDotHalfWayVector*100)][shininessInt];
							for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
								computeHeadlightSpecularHighlight[colorIdx] = NormalDotHalfWayVector * specularColor[colorIdx];
							}
						}
						for (int colorIdx = 0; colorIdx < 3; colorIdx++) {
							vertexColor[colorIdx] += diffuseColor[colorIdx] *
									normalVertex.transformedVector[vertex][zIndex] +
									computeHeadlightSpecularHighlight[colorIdx];
	//**************** not handling ambientIntesity
									//computeSpecularHightlight[colorIdx] + ambientIntensity * diffuseColor[colorIdx];
						}
					} // end headlight

					// color cannot exceed 1 and emissive color takes over if larger than diffuse color
					for (int colorIdx = 0; colorIdx < vertexColor.length; colorIdx++) {
						vertexColor[colorIdx] = java.lang.Math.min(1, vertexColor[colorIdx]);
						vertexColor[colorIdx] = java.lang.Math.max(emissiveColor[colorIdx], vertexColor[colorIdx]);
						clipping.vertexColor[vertexNumber][colorIdx]  = vertexColor[colorIdx];
					}
					clipping.vertexPts[vertexNumber][xIndex] =
						coord.transformedPoint[indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][xIndex];
					clipping.vertexPts[vertexNumber][yIndex] =
						coord.transformedPoint[indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][yIndex];
					clipping.vertexPts[vertexNumber][zIndex] =
						coord.transformedPoint[indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][zIndex];
					 /**** currently texCoordIndex assumes all polygons are trianbles *******/
					// set the image texture values
					//if (polygon.imageTexture != null) {
					if (polygon.texture != null) {
						TextureCoordinate texCoord = (TextureCoordinate) indexedFaceSet.texCoord;
						if ( indexedFaceSet.texCoordIndex != null ) {
							clipping.vertexTextureCoord[vertexNumber][xIndex] =
									texCoord.point.vec2s[
											indexedFaceSet.texCoordIndex.values[polygonNumber*4 + vertexNumber]][xIndex];
							clipping.vertexTextureCoord[vertexNumber][yIndex] =
									texCoord.point.vec2s[
											indexedFaceSet.texCoordIndex.values[polygonNumber*4 + vertexNumber]][yIndex];
						} // end if indexedFaceSet.texCoordIndex != null
						else {
							clipping.vertexTextureCoord[vertexNumber][xIndex] =
									texCoord.point.vec2s[
											indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][xIndex];
							clipping.vertexTextureCoord[vertexNumber][yIndex] =
									texCoord.point.vec2s[
											indexedFaceSet.coordIndex.values[polygonNumber*4 + vertexNumber]][yIndex];
						}
					} // end if an imageTexture is here.
				} // end for vertexNumber loop of all vertices

				if ( boundBoxPicked ) {
					// bounding box picked so check individual polygons
					for (int vertexNumber = 0; vertexNumber < 3; vertexNumber++) {
						for (int idx = 0; idx < 3; idx++) {
					picking.vertex[vertexNumber][idx] = clipping.vertexPts[vertexNumber][idx];
 						}
 					}
					float pickDistance = picking.PolygonPicked( );
					if ( pickDistance != picking.NoIntersection ) {
						// got a picked object, save it to the list
						pickRay.objectAppendList[pickRay.pickedObjectsAppendList] = shape;
						pickRay.distanceAppendList[pickRay.pickedObjectsAppendList] = pickDistance;
						pickRay.pickedObjectsAppendList++;
					}
					if ( closestPickDistance < pickDistance ) {
						// got a closer object in the foreground
						closestPickDistance = pickDistance;
						// check if this shape IS interactive, either TouchSensor, Anchor or Dynamic-3D object
						if (polygon.objectNumber != VRMLdatatype.NotInteractive) {
							closestPickedInteractiveShape = shape;
						}
						else { // it's a picked object but its not interactive
							closestPickedInteractiveShape = null;
						}
					} // end processing picking closer object
				} // end boundBoxPicked

				// clip and scan this polygon
				clipping.ClipPolygon(polygon, renderBuffer1, clippingPlanes );
			} // end if thus front-facing
		}  // end for polygonNumber = 0 to (Number_Polygons - 1)
}
catch ( java.lang.ArrayIndexOutOfBoundsException e ) {
}
	} // end DrawIndexedFaceSet



	private void TransformCoordinates(Shape shape) {
		Billboard billboard = null;
		Transform transform = null;
		shape.matrix4x4.setIdentityMatrix();
		shape.rotationMatrix.setIdentityMatrix();
		SFNode node = shape.parent;
		while (node != null) {
			//shape.multiply4x4byThis( node.values );
			if (node.datatype == VRMLdatatype.Transform) {
				transform = (Transform) node;
				shape.rotationMatrix.multiply3x3byThis( transform.rotationMatrix.matrix );
				shape.matrix4x4.multiply4x4byThis( transform.matrix4x4.values );
			}
			else if (node.datatype == VRMLdatatype.Billboard) {
				billboard = (Billboard) node;
				shape.rotationMatrix.multiply3x3byThis( billboard.rotationMatrix.matrix );
				shape.matrix4x4.multiply4x4byThis( billboard.matrix4x4.values );
			}
			node = node.parent;
		}
		shape.matrix4x4.multiply4x4byThis( finalVPMatrix.values );
		shape.rotationMatrix.multiply3x3byThis( finalVP3x3Matrix.matrix );

		// multiply all the vertices and save as the transformed points
		//Coordinate coordinate = shape.geometry.coord;
		//IndexedSet geometry = (IndexedSet)shape.geometry;
 	   //Coordinate coordinate = geometry.coord;
		Coordinate coordinate = null;
		if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
			IndexedSet indexedSet = (IndexedSet) shape.geometry;
			coordinate = (Coordinate) indexedSet.coord;
		}
		else if (shape.geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) shape.geometry;
			coordinate = (Coordinate) pointSet.coord;
		}
		for (int pointNumber = 0; pointNumber < coordinate.point.vec3s.length; pointNumber++) {
			coordinate.transformedPoint[pointNumber] = shape.matrix4x4.multiply4x4byArrayOptimized( coordinate.point.vec3s[pointNumber] );
		}
		for (int pointNumber = 0; pointNumber < coordinate.bboxVertices.length; pointNumber++) {
			coordinate.transformBBoxVertices[pointNumber] = shape.matrix4x4.multiply4x4byArrayOptimized( coordinate.bboxVertices[pointNumber] );
		}
		// set up transform bounding box values
		for (int i = 0; i < 3; i++) {
			coordinate.min[i] = java.lang.Float.POSITIVE_INFINITY;
			coordinate.max[i] = java.lang.Float.NEGATIVE_INFINITY;
		}
		for (int i = 0; i < coordinate.transformBBoxVertices.length; i++) {
			for (int j = 0; j < 3; j++) {
				if ( coordinate.max[j] < coordinate.transformBBoxVertices[i][j] ) {
					coordinate.max[j] = coordinate.transformBBoxVertices[i][j];
				}
				if ( coordinate.min[j] > coordinate.transformBBoxVertices[i][j] ) {
					coordinate.min[j] = coordinate.transformBBoxVertices[i][j];
				}
			}
		} // end for i < coord.point.vec3s
	} // end Transform Coordinates



	private void DrawShape(Shape shape, boolean renderBuffer1) {

		TransformCoordinates( shape );
		// Determine clipping of bounding box
		//Coordinate coordinate = shape.geometry.coord;
		Coordinate coordinate = null;
		//IndexedSet geometry = (IndexedSet)shape.geometry;
 	   //coordinate = geometry.coord;
		if ( (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) || (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) ) {
			IndexedSet indexedSet = (IndexedSet) shape.geometry;
			coordinate = (Coordinate) indexedSet.coord;
		}
		else if (shape.geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) shape.geometry;
			coordinate = (Coordinate) pointSet.coord;
		}

		clipping.totalVertices = 4;
		// check the front plane
		for (int vertexNumber = 0; vertexNumber < clipping.totalVertices; vertexNumber++ ) {
			for (int idx = 0; idx < 3; idx++ ) {
				clipping.vertexPts[vertexNumber][idx] = coordinate.transformBBoxVertices[vertexNumber][idx];
			}
		}
		int frontPlane = clipping.ClipBoundingBox();

		// check the back plane
		for (int vertexNumber = 0; vertexNumber < clipping.totalVertices; vertexNumber++ ) {
			for (int idx = 0; idx < 3; idx++ ) {
				clipping.vertexPts[vertexNumber][idx] = coordinate.transformBBoxVertices[vertexNumber + 4][idx];
			}
		}
		int backPlane = clipping.ClipBoundingBox();
		boolean boundingBoxOutOfBounds = false;
		// check if each plane was out of bounds and if it was at least one plane the same
		if ( ( (frontPlane & backPlane & clipping.OutOfBounds) != 0) && ( ( frontPlane & backPlane & clipping.OutOfBoundsMask) != 0) )
			boundingBoxOutOfBounds = true;

		if ( !boundingBoxOutOfBounds ) {
			if ( (frontPlane & clipping.OutOfBounds) != 0) frontPlane = clipping.OutOfBoundsMask;
			if ( (backPlane  & clipping.OutOfBounds) != 0) backPlane  = clipping.OutOfBoundsMask;
			int clippingPlanes = frontPlane | backPlane;
			// not out of bounds
			if (shape.geometry.datatype == VRMLdatatype.IndexedFaceSet) DrawIndexedFaceSet(shape, renderBuffer1, clippingPlanes );
			else if (shape.geometry.datatype == VRMLdatatype.IndexedLineSet) DrawIndexedLineSet(shape, renderBuffer1, clippingPlanes );
			else if (shape.geometry.datatype == VRMLdatatype.PointSet) DrawPointSet(shape, renderBuffer1, clippingPlanes );
		}
	} // end DrawShape



	private void SetPolygonValues(Shape shape) {
		polygon.Reset();
		polygon.objectNumber = currNode.objectNumber;
		if (shape.appearance != null) {
			Appearance appearance = (Appearance) shape.appearance;
			if (appearance.texture != null) {
				//polygon.imageTexture = shape.appearance.texture;
				polygon.texture = appearance.texture;
				if (appearance.texture.datatype == VRMLdatatype.ImageTexture) {
					ImageTexture imageTexture = (ImageTexture) appearance.texture;
					polygon.transparentGIF = imageTexture.transparentGIF;
				}
				else if (appearance.texture.datatype == VRMLdatatype.PixelTexture) {
					PixelTexture pixelTexture = (PixelTexture) appearance.texture;
					polygon.transparentGIF = pixelTexture.image.transparentByte;
				}
			}
			//else {
			//	polygon.imageTexture = null; // set null in the Reset
			//}
			if (appearance.material != null) {
				Material material = (Material) appearance.material;
				polygon.materialAttribute = true;
				polygon.transparencyMaterialValue = material.transparency.f;
			} // end material object
			if (appearance.textureTransform != null) {
				TextureTransform textureTransform = (TextureTransform) appearance.textureTransform;
				polygon.textureCoordinateScaleX = textureTransform.scale.vec2s[0];
				polygon.textureCoordinateScaleY = textureTransform.scale.vec2s[1];
				polygon.textureCoordinateTranslationX = textureTransform.translation.vec2s[0];
				polygon.textureCoordinateTranslationY = textureTransform.translation.vec2s[1];
				polygon.textureCoordinateCenterX = textureTransform.center.vec2s[0];
				polygon.textureCoordinateCenterY = textureTransform.center.vec2s[1];
				polygon.textureCoordinateRotation = textureTransform.rotation.f;
			}
		} // shape.appearance != null
	} // end SetPolygonValues



	private void DrawSceneGraph(boolean renderBuffer1) {
		currNode = mainRoot;

		totalTransparencyShapes = 0;
		while ( currNode != null ) {
			if (currNode.children != null) {
				currNode = currNode.children;
			}
			else if (currNode.next == null) {
				currNode = currNode.parent;
				while ( (currNode != mainRoot) && (currNode.next == null) ) {
					currNode = currNode.parent;
				}
				currNode = currNode.next;
			}
			else {
				currNode = currNode.next;
			}

			if (currNode != null) {
				if (currNode.datatype == VRMLdatatype.Shape) {
					Shape shape = (Shape) currNode;
					SetPolygonValues(shape);
					if ( polygon.transparencyMaterialValue == 0 ) {
						DrawShape(shape, renderBuffer1);
					}
					else { totalTransparencyShapes++; }
				} // end if currNode == Shape
			} // end if currNode != null
		} // end while currNode != null
	} // end DrawSceneGraph



	private void DrawTransparentObjects(boolean renderBuffer1) {
		for (int i = 0; i < totalTransparencyShapes; i++) {
			display.ClearTransparencyBuffer();
			currNode = mainRoot;
			while ( currNode != null ) {
				if (currNode.children != null) {
					currNode = currNode.children;
				}
				else if (currNode.next == null) {
					currNode = currNode.parent;
					while ( (currNode != mainRoot) && (currNode.next == null) ) {
						currNode = currNode.parent;
					}
					currNode = currNode.next;
				}
				else {
					currNode = currNode.next;
				}

				if (currNode != null) {
					if (currNode.datatype == VRMLdatatype.Shape) {
						Shape shape = (Shape) currNode;
						if (shape.appearance != null) {
							Appearance appearance = (Appearance) shape.appearance;
							if (appearance.material != null) {
								Material material = (Material) appearance.material;
								if ( (material.transparency.getValue() != 0) && (material.transparency.getValue() != 1) ){
									SetPolygonValues(shape);
									DrawShape(shape, renderBuffer1);   /***** need to best determine where this should go *******/
								} // end if (transparency != 0) && (transparency != 1)
							} // end if Shape.appearance.material != null
						} // end if Shape.appearance != null
					} // end if currNode == Shape
				} // end if currNode != null
			} // end while currNode != null
			scanner.MoveTransparencyPixelsToBuffer(renderBuffer1);
		} // end for i = # transparent objects
	} // end DrawTransparentObjects





	private void DrawFog(boolean renderBuffer1) {
		// Constants
		//java.lang.Float.NEGATIVE_INFINITY;
		final int redMask   = 0x00ff0000;
		final int greenMask = 0x0000ff00;
		final int blueMask  = 0x000000ff;

		// Variables
		int red, green, blue, pixel;
		float objectContent = 0;
		float fogContent = 1;
		float redFogColor   = fog.color.color[0] * 255;
		float greenFogColor = fog.color.color[1] * 255;
		float blueFogColor  = fog.color.color[2] * 255;

		if (renderBuffer1) {
			if (fog.fogType.s.equals(VRMLdatatype.string_LINEAR)) {
				for (int i = 0; i < display.totalPixels; i++ ) {
					if (display.Zbuffer[i] != java.lang.Float.NEGATIVE_INFINITY) {
						// Z-buffer value != Max_Negative so calculate the fog,
						// and not leave the background color
						if ( -fog.visibilityRange.f >= display.Zbuffer[i]) {
							// object beyond visibilityRange so give it fog color
							display.buffer1RGB[i] = 0xFF000000 |
								((int)redFogColor   << 16) |
								((int)greenFogColor << 8) |
								((int)blueFogColor);
						} // end object beyond visibilityRange so give it fog color
						else  {
							// blend fog and object
							objectContent = (fog.visibilityRange.f + display.Zbuffer[i]) / fog.visibilityRange.f;
							fogContent = 1 - objectContent;
							pixel = display.buffer1RGB[i];
							red   = ( pixel & redMask ) >> 16;
							green = ( pixel & greenMask ) >> 8;
							blue  = ( pixel & blueMask );
							// blend the fog and object
							red   = ((int)((red * objectContent) +
										(redFogColor * fogContent ))
									<< 16);
							green = ((int)((green * objectContent) +
										(greenFogColor * fogContent ))
									<< 8 );
							blue  = ((int)((blue * objectContent) +
										(blueFogColor * fogContent ))
									  ); // shouldn't need blue masking
							display.buffer1RGB[i] = 0xFF000000 | red | green | blue;
						}
					} // end if pixel not background color
				} // end for loop
			} // end LINEAR fog, buffer 1
			else { // fog EXPONENTIAL, buffer 1
				for (int i = 0; i < display.totalPixels; i++ ) {
					if (display.Zbuffer[i] != java.lang.Float.NEGATIVE_INFINITY) {
						// Z-buffer value != Max_Negative so calculate the fog,
						// and not leave the background color
						if ( -fog.visibilityRange.f >= display.Zbuffer[i]) {
							// object beyond visibilityRange so give it fog color
							display.buffer1RGB[i] = 0xFF000000 |
								((int)redFogColor   << 16) |
								((int)greenFogColor << 8) |
								((int)blueFogColor);
						} // end object beyond visibilityRange so give it fog color
						else  {
							// blend fog and object
							objectContent = (fog.visibilityRange.f + display.Zbuffer[i]) / fog.visibilityRange.f;
							objectContent *= objectContent; // Power of 2 for Exponential fog
							fogContent = 1 - objectContent;
							pixel = display.buffer1RGB[i];
							red   = ( pixel & redMask ) >> 16;
							green = ( pixel & greenMask ) >> 8;
							blue  = ( pixel & blueMask );
							// blend the fog and object
							red   = ((int)((red * objectContent) +
										(redFogColor * fogContent ))
									<< 16);
							green = ((int)((green * objectContent) +
										(greenFogColor * fogContent ))
									<< 8 );
							blue  = ((int)((blue * objectContent) +
										(blueFogColor * fogContent ))
									  ); // shouldn't need blue masking
							display.buffer1RGB[i] = 0xFF000000 | red | green | blue;
						}
					} // end if pixel not background color
				} // end for loop

			} // end fog EXPONENTIAL, buffer 1
		} // end renderBuffer1
		else { // renderBuffer2
			if (fog.fogType.s.equals(VRMLdatatype.string_LINEAR)) {
				for (int i = 0; i < display.totalPixels; i++ ) {
					if (display.Zbuffer[i] != java.lang.Float.NEGATIVE_INFINITY) {
						// Z-buffer value != Max_Negative so calculate the fog,
						// and not leave the background color
						if ( -fog.visibilityRange.f >= display.Zbuffer[i]) {
							// object beyond visibilityRange so give it fog color
							display.buffer2RGB[i] = 0xFF000000 |
								((int)redFogColor   << 16) |
								((int)greenFogColor << 8) |
								((int)blueFogColor);
						} // end object beyond visibilityRange so give it fog color
						else  {
							// blend fog and object
							objectContent = (fog.visibilityRange.f + display.Zbuffer[i]) / fog.visibilityRange.f;
							fogContent = 1 - objectContent;
							pixel = display.buffer2RGB[i];
							red   = ( pixel & redMask ) >> 16;
							green = ( pixel & greenMask ) >> 8;
							blue  = ( pixel & blueMask );
							// blend the fog and object
							red   = ((int)((red * objectContent) +
										(redFogColor * fogContent ))
									<< 16);
							green = ((int)((green * objectContent) +
										(greenFogColor * fogContent ))
									<< 8 );
							blue  = ((int)((blue * objectContent) +
										(blueFogColor * fogContent ))
									  ); // shouldn't need blue masking
							display.buffer2RGB[i] = 0xFF000000 | red | green | blue;
						}
					} // end if pixel not background color
				} // end for loop
			} // end LINEAR fog, buffer 2
			else { // fog EXPONENTIAL for buffer 2
				for (int i = 0; i < display.totalPixels; i++ ) {
					if (display.Zbuffer[i] != java.lang.Float.NEGATIVE_INFINITY) {
						// Z-buffer value != Max_Negative so calculate the fog,
						// and not leave the background color
						if ( -fog.visibilityRange.f >= display.Zbuffer[i]) {
							// object beyond visibilityRange so give it fog color
							display.buffer2RGB[i] = 0xFF000000 |
								((int)redFogColor   << 16) |
								((int)greenFogColor << 8) |
								((int)blueFogColor);
						} // end object beyond visibilityRange so give it fog color
						else  {
							// blend fog and object
							objectContent = (fog.visibilityRange.f + display.Zbuffer[i]) / fog.visibilityRange.f;
							objectContent *= objectContent;
							fogContent = 1 - objectContent;
							pixel = display.buffer2RGB[i];
							red   = ( pixel & redMask ) >> 16;
							green = ( pixel & greenMask ) >> 8;
							blue  = ( pixel & blueMask );
							// blend the fog and object
							red   = ((int)((red * objectContent) +
										(redFogColor * fogContent ))
									<< 16);
							green = ((int)((green * objectContent) +
										(greenFogColor * fogContent ))
									<< 8 );
							blue  = ((int)((blue * objectContent) +
										(blueFogColor * fogContent ))
									  ); // shouldn't need blue masking
							display.buffer2RGB[i] = 0xFF000000 | red | green | blue;
						}
					} // end if pixel not background color
				} // end for loop
			} // end fog EXPONENTIAL, buffer 2
		} // end renderBuffer2
	} // end DrawFog




	public Shape GraphicsPipeline(boolean renderBuffer1, Viewpoint currentViewpoint) {
		//Initialize all the buffers
		closestPickDistance = Picking.NoIntersection; // this is the "t" value saving the closest boject
		closestPickedInteractiveShape = null; // this saves the closest Shape
		pickRay.pickedObjectsAppendList = 0; // current number of picked objects
		if (renderBuffer1) display.ClearBuffer1();
		else display.ClearBuffer2();
		display.ClearZbuffer();

		this.currentViewpoint = currentViewpoint;

		TransformsBillboards_MatrixCalculation();
		TransformViewpoint(); // currentViewpoint covert to Matrix and Transforms above it
		TransformLighting(); // Find all Directional Lights and parent Transforms


		// Using lights and transformed normals, now set up polygon parameters and pass off to scanner
		DrawSceneGraph(renderBuffer1);
		if ( totalTransparencyShapes != 0 ) {
			DrawTransparentObjects(renderBuffer1);
		}
		if ( fog.visibilityRange.f != 0 ) {
			DrawFog(renderBuffer1);
		}
		return closestPickedInteractiveShape;
	} // end GraphicsPipeline

}//end class FrameGenerator