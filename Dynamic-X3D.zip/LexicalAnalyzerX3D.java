// LexicalAnalyzerX3D.java
// � 2004, 3D-Online, All Rights Reserved
// Date: May 17, 2004

// X3D version went beta01 July, 2007
// X3D version: beta02, October 14, 2007
// X3D version: beta 03: December 27, 2007
// X3D version: beta 04: February, 2008
// X3D version: beta 05: April 3, 2008
// X3D version: beta 06: April, 2008

package d3d;


import java.io.InputStream;
import java.io.StreamTokenizer;
import java.applet.Applet;
import java.util.Stack;
import java.util.Vector;



public class LexicalAnalyzerX3D {

	final char leftBraceChar    = '{'; // ascii 123
	final char rightBraceChar   = '}'; // ascii 125
	final char leftBracketChar  = '['; // ascii  91
	final char rightBracketChar = ']'; // ascii  93
	final char underscoreChar   = '_'; // ascii  95 (I think)
	final char doubleQuoteChar  = '"'; // ascii  34
	final char leftAngleBracket   = '<'; //ascii  60
	final char rightAngleBracket  = '>'; //ascii  62
	final char equalSign		  = '='; //ascii  61
	final char singleQuote		  = '\''; //ascii  39
	final char backSlash		  = '\\'; //ascii  92
	final char forwardSlash		  = '/'; //ascii  47
	final char questionMark		  = '?'; //ascii  63
	//final char doubleQuote		  = '\"'; //ascii  34
	final char exclimationPoint	  = '!'; //ascii  33
	final char colon			  = ':'; //ascii  58
	final char periodChar			= '.'; // ascii 46

	boolean X3D_head = false; // set true when getting <head> tag, false when getting </head>
	boolean X3D_Scene = false; // set true when getting <Scene> tag
	boolean X3D_X3Dtag = false; // set true when getting <X3D> tag

	SFNode root = null;
	SFNode currentNode = null;

	Transform currentTransform											= null;
	Anchor currentAnchor													= null;
	//Appearance currentAppearance										= null;
	AppletParameters appletParameters								= null;
	Background background												= null;
	Billboard currentBillboard											= null;
	//Color currentColor													= null;
	//ColorInterpolator currentColorInterpolator					= null;
	//Coordinate currentCoordinate										= null;
	//DirectionalLight currentDirectionalLight						= null;
	Fog fog															= null;
	Group currentGroup													= null;
	//Shape currentShape													= null;
	Light currentLight 	                    						= null;
	//Material currentMaterial											= null;
	SFNode /*imageTexture*/ imageTextureRoot							= null;
	//ImageTexture currentImageTexture									= null;
	//ImageTexture currImageTextureLink								= null;
	//IndexedLineSet currentIndexedLineSet							= null;
	//IndexedFaceSet currentIndexedFaceSet							= null;
	Interpolator interpolatorRoot										= null;
	Interpolator interpolatorLink										= null;
	//TextureCoordinate currentTextureCoordinate					= null;
	NavigationInfo navigationInfo										= null;
	//Normal currentNormal													= null;
	//OrientationInterpolator currentOrientationInterpolator	= null;
	//PixelTexture currentPixelTexture									= null;
	//PointLight currentPointLight										= null;
	//PointSet currentPointSet											= null;
	//PositionInterpolator currentPositionInterpolator			= null;
	//CoordinateInterpolator currentCoordinateInterpolator		= null;
	//NormalInterpolator currentNormalInterpolator					= null;
	Route routeRoot														= null;
	Route routeLast														= null;
	//ScalarInterpolator currentScalarInterpolator					= null;
	Sensor sensorRoot														= null;
	Sensor sensorLink														= null;
	//SpotLight currentSpotLight											= null;
	//TextureTransform currentTextureTransform						= null;
	//TimeSensor currentTimeSensor										= null;
	//TouchSensor currentTouchSensor									= null;
	Viewpoint viewpointLink												= null;
	Viewpoint viewpointRoot												= null;
	WorldInfo worldInfo													= null;

	SFNode DEFnameNode						= null; // for a linked list of named nodes for USE/DEF nodes
	SFNode currentDEFnameNode				= null; // for a linked list of named nodes for USE/DEF nodes

	int state = VRMLdatatype.SFNode;
	Applet localApplet = null; // passed to ImageTexture
	Parser parser = null;
	Stack stateStack = null;
	Shape shapeLink = null;

	StreamTokenizer st = null;
	int tokenType;
	String token = null;

	String textureMapFolder = null;
	String imageTextureDEFName = null; // a bit of a cludge but had to split up creation of ImageTexture node and keep name around
	final int floatFileLimit = 15000; // taken from VRML 2.0 Reference Manual book, pg 365, MColor value
	final int intFileLimit = 20000; // from MFInt32 file limit, pg 365 above too
	//float[] tempFloatBuffer = new float[floatFileLimit*3];
	//int[] tempIntBuffer = new int[intFileLimit];
	//int tempBufferIndex = 0;

	/* following are for the debug version */
	final String indentAmt = "   ";
	String indent = "";
	final int maxValsPerLine = 4;
	int valsPerLine = 0; // for list of Coordinate values so line isn't too long
	private void FormatError(String errorMssg) {
		System.out.println("  **Format Error/Warning: " + errorMssg);
	}
	private void Write(char ch) {
		System.out.print(ch);
	}
	private void Write(String string) {
		System.out.print(string);
	}
	private void WriteLine() {
		System.out.println();
	}
	private void WriteLine(char ch) {
		Write(ch);
		WriteLine();
	}
	private void WriteLine(String string) {
		Write(string);
		WriteLine();
	}
	/* end section for debug version */

	public int GetToken() {
		try {
			tokenType = st.nextToken();
		}
		catch (Exception e) {
			FormatError(e.toString());
		}
		return tokenType;
	}


	private void PushStack(int stateValue) {
		Integer stateInteger = new Integer(stateValue);
		stateStack.push( stateInteger );
	}

	private int PopStack() {
		Integer stateInteger = new Integer(stateStack.pop().toString());
		return stateInteger.intValue();
	}



	public Route VerifyRoute () {
		Route newRoute = new Route();
		String objName, propertyName;
		SFNode matchRoot = null;
		boolean propertyFound;

//System.out.println("*");
//System.out.println("LexicalAnalyzer.VerifyRoute end");
//System.out.println("*");
		Write(indent + VRMLdatatype.string_ROUTE + " ");
		// Get the 'fromObject.property' values
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			objName = token.substring(0, token.indexOf('.') );
			matchRoot = newRoute.MatchRouteObjectName(objName);
			if (matchRoot != null) {
				newRoute.fromObject = matchRoot;
				RouteProperties fromProperties = new RouteProperties();
				newRoute.from = fromProperties;

				propertyName = token.substring((token.indexOf('.') + 1), token.length() );
				propertyFound = newRoute.MatchRoutePropertyName (matchRoot, propertyName, newRoute.from);
			}
			else FormatError("'" + objName + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE);
		}
		else FormatError("Missing word in " + VRMLdatatype.string_ROUTE);

		// Get the 'TO' in the ROUTE
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			if (token.equals(VRMLdatatype.string_TO) ) {
				Write(token + " ");
			}
			else FormatError("Missing '" + VRMLdatatype.string_TO + "' in " + VRMLdatatype.string_ROUTE);
		}
		else FormatError("Missing '" + VRMLdatatype.string_TO + "'in " + VRMLdatatype.string_ROUTE);

		// Get the 'toObject.property' values
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			token = st.sval;
			objName = token.substring(0, token.indexOf('.') );
			matchRoot = newRoute.MatchRouteObjectName(objName);
			if (matchRoot != null) {
				newRoute.toObject = matchRoot;
				RouteProperties toProperties = new RouteProperties();
				newRoute.to = toProperties;
				propertyName = token.substring((token.indexOf('.') + 1), token.length() );
				propertyFound = newRoute.MatchRoutePropertyName (matchRoot, propertyName, newRoute.to);
			}
			else FormatError("'" + objName + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE);
		}
		else FormatError("Missing word in " + VRMLdatatype.string_ROUTE);
		WriteLine();
//System.out.println("*");
//System.out.println("LexicalAnalyzer.VerifyRoute end");
//System.out.println("*");

		return newRoute;
	} // end VerifyRoute


	public void CreateRoute () {
		Route newRoute = VerifyRoute();
		if (newRoute != null) {
			// Add to the link list
			routeLast.nextRoute = newRoute;
			routeLast = newRoute;
		}
	} // end CreateRoute

	private boolean CheckBoolean() {
		boolean returnBool = true;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String booleanValue = st.sval;
			booleanValue = booleanValue.toUpperCase();
			if ( booleanValue.equals(VRMLdatatype.string_TRUE) ) returnBool = true;
			//else if ( booleanValue.equals("true") ) returnBool = true;
			else if ( booleanValue.equals(VRMLdatatype.string_FALSE) ) returnBool = false;
			//else if ( booleanValue.equals("false") ) returnBool = false;
			else FormatError("Missing " +  VRMLdatatype.string_TRUE + " or " + VRMLdatatype.string_FALSE + " value ");
		}
		else FormatError("Missing " +  VRMLdatatype.string_TRUE + " or " + VRMLdatatype.string_FALSE + " value ");
		Write(" " + returnBool);
		return returnBool;
	}


	private boolean CheckChar(char validateChar) {
		boolean charCk = false;
		tokenType = GetToken();
		char ch = (char) tokenType;
		if (ch == validateChar) charCk = true;
		Write(ch);
		return charCk;
	}


	private byte[] ParseByteString(String byteString, int bytesPerString) {
		byte[] returnByte = new byte[bytesPerString];
		Write( byteString ); // intValue0 should be "0"
		byteString = byteString.toLowerCase();

		byte[] byteArray = byteString.getBytes();
		// first char is an "x"
		for (int byteNum = 0; byteNum < bytesPerString; byteNum++) {
			int byteValue = 0;
			for (int i = 0; i < 2; i++) {
				Byte aByte = new Byte(byteArray[(byteNum*2) + i + 1]); // first byte is "x"
				int intVal = aByte.intValue();
				if ( intVal <= 57 ) intVal -= 48; // numbers 0 thru 9
				else if (intVal >= 97) intVal -= 87; // letters a thru f
				byteValue = (byteValue << 4) + intVal;
			}
			returnByte[byteNum] = (byte) byteValue;
		}
		return returnByte;
	}

	private byte[] GetByte(int bytesPerString) {
	//private void GetByte() {
		byte[] returnByte = new byte[bytesPerString];
		tokenType = GetToken();
		// handle "0x00, oxFF ..." or "0 255 ..."
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			// either decimal number or Hex number beginning with "0"
			int intValue0 = (int) st.nval;
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_NUMBER) {
				// decimal value, gray 0 - 255, not hex value
				Write( " " + intValue0 );
				st.pushBack();
				returnByte[0] = (byte) intValue0;
			}
			else { // hex begin with 0, either 0xHexHex for gray, 0xRGB (3 values) or 0xRGBA (4 values
				Write(" " + intValue0 ); // intValue0 should be "0"
				returnByte = ParseByteString(st.sval, bytesPerString);
			}
		}
		else { // Hex number beginning with x
			Write(" ");
			returnByte = ParseByteString(st.sval, bytesPerString);
		}
		return returnByte;
	} // end GetByte


	private int GetIntegerNumber() {
		int returnNumber = (int) st.nval;
		Write(" " + returnNumber);
		return returnNumber;
	} // end GetIntegerNumber


	private float GetFloatNumber() {
		// Gets a number and checks for exponential data.
		float returnNumber = (float) st.nval;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String str = st.sval;
  			if (str.length() == 1) {
				//if (str.equals("e")) {
				if ( (str.equals("e")) || (str.equals("E")) ) {
					// positive exponential value
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_NUMBER) {
						int exp = (int) st.nval;
						returnNumber *= Math.pow(10, exp);
					}
					else st.pushBack(); // no exponential value, push value back on stack
				}
				else st.pushBack(); // no exponential value, push value back on stack
			}
			//else if (str.substring(0,2).equals("e-")) {
			else if ( (str.substring(0,2).equals("e-")) || (str.substring(0,2).equals("E-")) ) {
				// have an large negative exponential value, set value to 0
				returnNumber = 0;
			}
			/*
			else if (str.substring(0,2).equals("e+")) {
				// have an large positive exponential value, set value to 0
				System.out.println();
				System.out.println(" the current value is : " + st.sval + ", str = " + str);
				System.out.println();

				returnNumber = 0;
			}
			*/
			else st.pushBack(); // no exponential value, push value back on stack
		}
		else st.pushBack();
		Write(" " + returnNumber);
		return returnNumber;
	} // end GetFloatNumber


	private float[] GetFloatValues(int quantity) {
		float[] returnFloat = new float[quantity];
		for (int i = 0; i < returnFloat.length; i++) {
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_NUMBER) {
				returnFloat[i] = GetFloatNumber();
			}
			else FormatError("Missing numeric values");
		}
		return returnFloat;
	} // end GetFloatValues


	private float GetSingleFloat() {
		float returnFloat = 0;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			returnFloat = GetFloatNumber();
		}
		else FormatError("Missing numeric values");
		return returnFloat;
	} // end GetSingleFloat


	private long GetTimeValue() {
		long returnTime = 0; // long value for time
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_NUMBER) {
			returnTime = (long) st.nval;
			Write(" " + returnTime);
		}
		else FormatError("Missing time value");
		return returnTime;
	} // end GetTimeValue


	public void AddChild (SFNode parentNode, SFNode childNode) {
		childNode.prev = parentNode.childLast;
		childNode.parent = parentNode;
		if (parentNode.childLast != null ) parentNode.childLast.next = childNode;
		if (parentNode.children == null ) parentNode.children = childNode;
		parentNode.childLast = childNode;
	} // end AddChild


	private String GetNodeName () {
		String nodeName = null;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			nodeName = st.sval;
			Write(indent + VRMLdatatype.string_DEF + " " + nodeName + " ");
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
			}
			else FormatError("Name not following " + VRMLdatatype.string_DEF);
		}
		else FormatError("Name '" + token + "' following " + VRMLdatatype.string_DEF + " improper");
		return nodeName;
	} // end GetNodeName


	private void SetNodeName (SFNode node, String name) {
		node.setName(name);
		// Add the node to the linked list
		if (name != null) {
			SFNode newNameNode = new SFNode();
			newNameNode.setName(name);
			newNameNode.children = node;
			currentDEFnameNode.next = newNameNode;
			currentDEFnameNode = newNameNode;
		}
	} // end SetNodeName


	private void GotUSEtoken () {
		SFNode foundNode = null;
		tokenType = GetToken();
		if (tokenType == StreamTokenizer.TT_WORD) {
			String useName = st.sval;
			WriteLine(" " + VRMLdatatype.string_USE + " " + useName + " ");

			SFNode checkNode = DEFnameNode.next;
			while ( checkNode != null ) {
				if ( useName.equals(checkNode.children.name) ) {
					foundNode = checkNode.children;
					switch (state) {
						case VRMLdatatype.Shape:
							/*
							if ( (foundNode.datatype == VRMLdatatype.IndexedFaceSet) ||
									(foundNode.datatype == VRMLdatatype.IndexedLineSet) || (foundNode.datatype == VRMLdatatype.PointSet)) {
								//currentShape.geometry = (IndexedSet)foundNode;
								currentShape.geometry = foundNode;
							}
							if (foundNode.datatype == VRMLdatatype.IndexedFaceSet) {
								//currentShape.indexedFaceSet = (IndexedFaceSet)foundNode;
								currentShape.geometry = (IndexedSet)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.IndexedLineSet) {
								//currentShape.indexedLineSet = (IndexedLineSet)foundNode;
								currentShape.geometry = (IndexedSet)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Appearance) {
								currentShape.appearance = (Appearance)foundNode;
							}
							else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_Shape);
						break; // end case Shape
						case VRMLdatatype.Appearance:
							if (foundNode.datatype == VRMLdatatype.Material) {
								currentAppearance.material = (Material)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.TextureTransform ) {
								currentAppearance.textureTransform = (TextureTransform)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.ImageTexture ) {
								currentAppearance.texture = (ImageTexture)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.PixelTexture ) {
								currentAppearance.texture = (PixelTexture)foundNode;
							}
							else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_Appearance);
						break; // end case Appearance
						case VRMLdatatype.IndexedFaceSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentIndexedFaceSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentIndexedFaceSet.coord = (Coordinate)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.TextureCoordinate) {
								currentIndexedFaceSet.texCoord = (TextureCoordinate)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Normal) {
								currentIndexedFaceSet.normal = (Normal)foundNode;
							}
							else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_IndexedFaceSet);
						break; // end case IndexedFaceSet
						case VRMLdatatype.IndexedLineSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentIndexedLineSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentIndexedLineSet.coord = (Coordinate)foundNode;
							}
							else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_IndexedLineSet);
						break; // end case IndexedLineSet
						case VRMLdatatype.PointSet:
							if (foundNode.datatype == VRMLdatatype.Color) {
								currentPointSet.color = (Color)foundNode;
							}
							else if (foundNode.datatype == VRMLdatatype.Coordinate) {
								currentPointSet.coord = (Coordinate)foundNode;
							}
							else FormatError("No " + useName + ", datatype " + foundNode.datatype + " inside " + VRMLdatatype.string_PointSet);
						break; // end case IndexedLineSet
						*/
						default:
							FormatError("No '" + VRMLdatatype.string_DEF + " " + useName + "' matching '" + VRMLdatatype.string_USE + " " + useName+ "'");
						break; // end default
					} // end switch on state
					checkNode = null; // gets me out of the loop
				}
				else {
					checkNode = checkNode.next;
					if (checkNode == null) FormatError("No '" + VRMLdatatype.string_DEF + " " + useName + "' matching '" + VRMLdatatype.string_USE + " " + useName+ "'");
				}
			}
		}
		else FormatError("'" + token + "' following " + VRMLdatatype.string_USE + " not a word");
	} // end GotUSEtoken




	private SFNode SetUSEtoken (SFNode node, String useName) {
		SFNode foundNode = null;
		SFNode checkNode = DEFnameNode.next;
		boolean searchDone = false;
		while ( !searchDone ) {
			if ( useName.equals(checkNode.children.name) ) {
				foundNode = checkNode.children;
				node = foundNode;
				searchDone = true;
			}
			else {
				checkNode = checkNode.next;
				if (checkNode == null) {
					FormatError("No '" + VRMLdatatype.string_DEF + " " + useName + "' matching '" + VRMLdatatype.string_USE + " " + useName+ "'");
					searchDone = true;
				}
			}
		}
		return foundNode;
	} // end SetUSEtoken





	private void BackgroundNode(){
		background.created  = true; // override applet parameters values, use NavInfo values
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								//SetNodeName (background, token); currently background is not an SFNode class so it doesn't have a name
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word");
						} // end DEF
						else if ( token.equals(VRMLdatatype.string_skyColor) ) background.skyColor.setValue(  GetFloatValues(3)  );
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Background);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Background);
					}
					else FormatError("Missing beginning quote following " + equalSign + " in " + VRMLdatatype.string_Background);				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Background);
			} // end word token inside Background
			else FormatError("Illegal word inside " + VRMLdatatype.string_Background);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Background);
	} //end BackgroundNode




	private void FogNode(){
		//fog = new Fog();
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word");
						} // end DEF
						else if ( token.equals(VRMLdatatype.string_color) ) {
							fog.color.setValue(  GetFloatValues(3)  );
							// leave colors from 0 to 1 in case they are animated
							for (int i = 0; i < 3; i++ ) {
								if ( fog.color.color[i] <= 0 ) fog.color.color[i] = 0;
								else if ( fog.color.color[i] >= 1 ) fog.color.color[i] = 1;
								//else fog.color.color[i] *= 255; // leave colors 0 to 1 in case animated.
							}
						}
						else if ( token.equals(VRMLdatatype.string_visibilityRange) ) {
							fog.visibilityRange.setValue(  GetSingleFloat() );
							if (fog.visibilityRange.f < 0) fog.visibilityRange.f = 0;
						}
						else if ( token.equals(VRMLdatatype.string_fogType) ) {
							boolean matchingDoubleQuote = false;
							tokenType = GetToken();
							while ( (tokenType != singleQuote) && (tokenType != doubleQuoteChar) ) {
								if ( tokenType == doubleQuoteChar) {
									Write(doubleQuoteChar);
									tokenType = GetToken();
									matchingDoubleQuote = true;
								}
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									if ( token.equals(VRMLdatatype.string_LINEAR) ) {
										fog.fogType.setValue( VRMLdatatype.string_LINEAR );
										Write(VRMLdatatype.string_LINEAR);
									}
									else if ( st.sval.equals(VRMLdatatype.string_EXPONENTIAL) ) {
										fog.fogType.setValue( VRMLdatatype.string_EXPONENTIAL );
										Write(VRMLdatatype.string_EXPONENTIAL);
									}
	 								else FormatError(st.sval + "invalid following " + VRMLdatatype.string_fogType + " in " + VRMLdatatype.string_Fog);
								}
								if (matchingDoubleQuote) {
									if ( (tokenType = GetToken()) == doubleQuoteChar) Write(doubleQuoteChar + " ");
									else FormatError("Missing doubleQuote in " + VRMLdatatype.string_NavigationInfo);
									matchingDoubleQuote = false;
								}
								tokenType = GetToken();
							}
							st.pushBack();
						} // end fogType
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Fog);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Fog);
					}
					else FormatError("Missing beginning quote following " + equalSign + " in " + VRMLdatatype.string_Fog);				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Fog);
			} // end word token inside Background
			else FormatError("Illegal word inside " + VRMLdatatype.string_Fog);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Fog);
	} //end FogNode





	private void WorldInfoNode(){
		worldInfo = new WorldInfo();
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								//SetNodeName (background, token); currently background is not an SFNode class so it doesn't have a name
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word");
						} // end DEF
						else if ( token.equals(VRMLdatatype.string_title) ) {
							String title = "";
							boolean firstToken = true;
							//while ( (tokenType = GetToken()) != singleQuote) {
							tokenType = GetToken();
							while ( (tokenType != singleQuote) && (tokenType != doubleQuoteChar) ) {
								if (tokenType == StreamTokenizer.TT_WORD) {
									if (!firstToken) title += " ";
									title += st.sval;
									firstToken = false;
								}
								else if (tokenType == StreamTokenizer.TT_NUMBER) {
									if (!firstToken) title += " ";
									title += st.nval;
									firstToken = false;
								}
								else title += (char) tokenType;
								tokenType = GetToken();
							}
							worldInfo.title.setValue( title );
							Write( title );
							st.pushBack(); // return the singleQuote for consistency
						}
						else if ( token.equals(VRMLdatatype.string_info) ) {
							String info = "";
							boolean firstToken = true;
							tokenType = GetToken();
							while ( (tokenType != singleQuote) && (tokenType != doubleQuoteChar) ) {
								if (tokenType == StreamTokenizer.TT_WORD) {
									if (!firstToken) info += " ";
									info += st.sval;
									firstToken = false;
								}
								else if (tokenType == StreamTokenizer.TT_NUMBER) {
									if (!firstToken) info += " ";
									info += st.nval;
									firstToken = false;
								}
								else info += (char) tokenType;
								tokenType = GetToken();
							}
							worldInfo.info.addValue( info );
							Write( info );
							st.pushBack(); // return the singleQuote for consistency
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_WorldInfo);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_WorldInfo);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_WorldInfo);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_WorldInfo);
			} // end word token inside NavigationInfo
			else FormatError("Illegal word inside " + VRMLdatatype.string_Background);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_WorldInfo);
	} //end WorldInfoNode




	private void NavigationInfoNode(){
		navigationInfo.created  = true; // override applet parameters values, use NavInfo values
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_headlight) ) navigationInfo.headlight.setValue( CheckBoolean() );
						else if ( token.equals(VRMLdatatype.string_speed) ) navigationInfo.speed.setValue( GetSingleFloat() );
						else if ( token.equals(VRMLdatatype.string_avatarSize) ) {
							navigationInfo.avatarSize.setValue(3, GetFloatValues(3) );
							Write("(not currently supported)");
						}
						else if ( token.equals(VRMLdatatype.string_type) ) {
							boolean matchingDoubleQuote = false;
							tokenType = GetToken();
							while ( (tokenType != singleQuote) && (tokenType != doubleQuoteChar) ) {
							//while ( (tokenType = GetToken() ) != singleQuote) {
								if ( tokenType == doubleQuoteChar) {
									Write(doubleQuoteChar);
									tokenType = GetToken();
									matchingDoubleQuote = true;
								}
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									//Write(token);
									if ( token.equals(VRMLdatatype.string_WALK) ) {
										appletParameters.walkthrough = true;
										Write(VRMLdatatype.string_WALK + "; ");
									}
									if ( st.sval.equals(VRMLdatatype.string_EXAMINE) ) {
										appletParameters.walkthrough = true;
										Write(VRMLdatatype.string_EXAMINE + " (sets walkthrough true); ");
									}
									if ( st.sval.equals(VRMLdatatype.string_FLY) ) {
										appletParameters.walkthrough = true;
										Write(VRMLdatatype.string_FLY + " (sets walkthrough true); ");
									}
									if ( st.sval.equals(VRMLdatatype.string_NONE) ) {
										appletParameters.walkthrough = false;
										Write(VRMLdatatype.string_NONE + " (sets walkthrough false); ");
									}
									if ( st.sval.equals(VRMLdatatype.string_ANY) ) {
										Write(VRMLdatatype.string_ANY + " (not supported); ");
									}
									if ( st.sval.equals(VRMLdatatype.string_LOOKAT) ) {
										Write(VRMLdatatype.string_LOOKAT + " (not supported); ");
									}
								}
								//else FormatError(st.sval + " invalid match following " + VRMLdatatype.string_type + " in " + VRMLdatatype.string_NavigationInfo);
								if (matchingDoubleQuote) {
									if ( (tokenType = GetToken()) == doubleQuoteChar) Write(doubleQuoteChar + " ");
									else FormatError("Missing doubleQuote in " + VRMLdatatype.string_NavigationInfo);
									matchingDoubleQuote = false;
								}
								tokenType = GetToken();
							}
							st.pushBack();
						} // end type parameter
						else if ( token.equals(VRMLdatatype.string_visibilityLimit) ) {
							navigationInfo.visibilityLimit.setValue( GetSingleFloat() );
							Write("(not currently supported)");
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_NavigationInfo);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameter in " + VRMLdatatype.string_NavigationInfo);
					} // got single quote
					else FormatError("Missing single quote following " + equalSign + " in " + VRMLdatatype.string_NavigationInfo);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_NavigationInfo);
			} // end word token inside NavigationInfo
			else FormatError("Illegal word inside " + VRMLdatatype.string_NavigationInfo);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_NavigationInfo);
	} //end NavigationInfoNode





	private void TimeSensorNode(TimeSensor timeSensor){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (timeSensor, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word");
						} // end DEF
						else if ( token.equals(VRMLdatatype.string_cycleInterval) ) timeSensor.cycleInterval.setValue( GetSingleFloat() );
						else if ( token.equals(VRMLdatatype.string_loop) ) timeSensor.loop.setValue( CheckBoolean() );
						else if ( token.equals(VRMLdatatype.string_enabled) ) timeSensor.enabled.setValue( CheckBoolean() );
						else if ( token.equals(VRMLdatatype.string_startTime) ) timeSensor.startTime.setValue( GetTimeValue() );
						else if ( token.equals(VRMLdatatype.string_stopTime) ) timeSensor.stopTime.setValue( GetTimeValue() );
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TimeSensor);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_TimeSensor);

					} // end getting the first quote mark
					else FormatError("Missing quote following equal sign in " + VRMLdatatype.string_TimeSensor);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_TimeSensor);
			} // end word token inside TimeSensor
			else FormatError("Illegal word inside " + VRMLdatatype.string_TimeSensor);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_TimeSensor);
	} // end TimeSensorNode




	private void ColorInterpolatorNode(ColorInterpolator colorInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (colorInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_ColorInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							colorInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							colorInterpolator.keyValue = new MFColor(keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ColorInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_ColorInterpolator);
					} // end if a quote after equal sign
					else FormatError("Missing quote following equal sign in " + VRMLdatatype.string_ColorInterpolator);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_ColorInterpolator);
			} // end word token inside ColorInterpolator
			else FormatError("Illegal word inside " + VRMLdatatype.string_ColorInterpolator);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_ColorInterpolator);
	} // end ColorInterpolatorNode




	private void ScalarInterpolatorNode(ScalarInterpolator scalarInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (scalarInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_ScalarInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							scalarInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							scalarInterpolator.keyValue = new MFFloat(keyValues.length, keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ScalarInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_ScalarInterpolator);
					} // end if a beginning quote is found
					else FormatError("Missing quote following equqls sign in " + VRMLdatatype.string_ScalarInterpolator);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_ScalarInterpolator);
			} // end word token inside PositionInterpolator
			else FormatError("Illegal word inside " + VRMLdatatype.string_ScalarInterpolator);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_ScalarInterpolator);
	} // end ScalarInterpolatorNode




	private void PositionInterpolatorNode(PositionInterpolator positionInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote)
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (positionInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_PositionInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							positionInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							positionInterpolator.keyValue = new MFVec3f(keyValues.length, keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PositionInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_PositionInterpolator);
					} // end bgn quote
					else FormatError("Missing quote following equal sign in " + VRMLdatatype.string_PositionInterpolator);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_PositionInterpolator);
			} // end word token inside PositionInterpolator
			else FormatError("Illegal word inside " + VRMLdatatype.string_PositionInterpolator);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_PositionInterpolator);
	} // end PositionInterpolatorNode




	private void NormalInterpolatorNode(NormalInterpolator normalInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (normalInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_NormalInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							normalInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							normalInterpolator.keyValue = new MFVec3f(keyValues.length, keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_NormalInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_NormalInterpolator);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_NormalInterpolator);				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_NormalInterpolator);
			} // end word token inside PositionInterpolator
			else FormatError("Illegal word inside " + VRMLdatatype.string_NormalInterpolator);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_NormalInterpolator);
	} // end NormalInterpolatorNode




	private void CoordinateInterpolatorNode(CoordinateInterpolator coordinateInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (coordinateInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_CoordinateInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							coordinateInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							coordinateInterpolator.keyValue = new MFVec3f(keyValues.length, keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_CoordinateInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_CoordinateInterpolator);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_CoordinateInterpolator);				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_CoordinateInterpolator);
			} // end word token inside PositionInterpolator
			else FormatError("Illegal word inside " + VRMLdatatype.string_CoordinateInterpolator);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_CoordinateInterpolator);
	} // end CoordinateInterpolatorNode




	private void OrientationInterpolatorNode(OrientationInterpolator orientationInterpolator){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				WriteLine(); Write(indent + indentAmt);
				Write(token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (orientationInterpolator, token);
							}
							else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_OrientationInterpolator);
						}
						else if ( token.equals(VRMLdatatype.string_key) ) {
							float[] keys = GetFloatArray();
							orientationInterpolator.key.setValue(keys.length, keys);
						}
						else if ( token.equals(VRMLdatatype.string_keyValue) ) {
							float[] keyValues = GetFloatArray();
							orientationInterpolator.keyValue = new MFRotation(keyValues.length, keyValues);
						}
						else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_OrientationInterpolator);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_OrientationInterpolator);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_OrientationInterpolator);				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_OrientationInterpolator);
			} // end word token inside OrientationInterpolatorNode
			else FormatError("Illegal word inside " + VRMLdatatype.string_OrientationInterpolator);
		} // end while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_OrientationInterpolator);
	} // end OrientationInterpolatorNode




	private DirectionalLight DirectionalLightNode(){
		DirectionalLight dirLight = null;
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(dirLight, token);
								if (foundNode != null) dirLight = (DirectionalLight) foundNode;
							}
						}
						else {
							if (dirLight == null) dirLight = new DirectionalLight();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (dirLight, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_direction) ) {
								dirLight.direction.setValue( GetFloatValues(3) );
								dirLight.directionNormalized = MathOps.NormalizeVector( dirLight.direction.getValue() );
							}
							else if ( token.equals(VRMLdatatype.string_color) ) dirLight.color.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_intensity) ) dirLight.intensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) dirLight.ambientIntensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_on) ) dirLight.on.setValue( CheckBoolean() );
							else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_DirectionalLight);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_DirectionalLight);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_DirectionalLight);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_DirectionalLight);
			} // end word token inside DirectionalLight
			else FormatError("Illegal word inside " + VRMLdatatype.string_DirectionalLight);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_DirectionalLight);
		if (dirLight == null) dirLight = new DirectionalLight();
		return dirLight;
	} //end DirectionalLightNode




	private PointLight PointLightNode(){
		PointLight pointLight = null;
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(pointLight, token);
								if (foundNode != null) pointLight = (PointLight) foundNode;
							}
						}
						else {
							if (pointLight == null) pointLight = new PointLight();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (pointLight, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_location) ) pointLight.location.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_color) ) pointLight.color.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_intensity) ) pointLight.intensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) pointLight.ambientIntensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_on) ) pointLight.on.setValue( CheckBoolean() );
							else if ( token.equals(VRMLdatatype.string_attenuation) ) {
								pointLight.attenuation.setValue( GetFloatValues(3) );
								if (
									(pointLight.attenuation.vec3s[0] == 0) &&
									(pointLight.attenuation.vec3s[1] == 0) &&
									(pointLight.attenuation.vec3s[2] == 0) )
										pointLight.attenuation.vec3s[0] = 1; // VRML rule
							}
							else if ( token.equals(VRMLdatatype.string_radius) ) pointLight.radius.setValue( GetSingleFloat() );
							else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PointLight);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_PointLight);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_PointLight);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_PointLight);
			} // end word token inside PointLight
			else FormatError("Illegal word inside " + VRMLdatatype.string_PointLight);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_PointLight);
		if (pointLight == null) pointLight = new PointLight();
		return pointLight;
	} //end PointLightNode




	private SpotLight SpotLightNode(){
		SpotLight spotLight = null;
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(spotLight, token);
								if (foundNode != null) spotLight = (SpotLight) foundNode;
							}
						}
						else {
							if (spotLight == null) spotLight = new SpotLight();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (spotLight, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_location) ) spotLight.location.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_direction) ) {
								spotLight.direction.setValue( GetFloatValues(3) );
								spotLight.directionNormalized = MathOps.NormalizeVector( spotLight.direction.getValue() );
							}
							else if ( token.equals(VRMLdatatype.string_color) ) spotLight.color.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_intensity) ) spotLight.intensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) spotLight.ambientIntensity.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_on) ) spotLight.on.setValue( CheckBoolean() );
							else if ( token.equals(VRMLdatatype.string_attenuation) ) {
								spotLight.attenuation.setValue( GetFloatValues(3) );
								if (
									(spotLight.attenuation.vec3s[0] == 0) &&
									(spotLight.attenuation.vec3s[1] == 0) &&
									(spotLight.attenuation.vec3s[2] == 0) )
										spotLight.attenuation.vec3s[0] = 1; // VRML rule
							}
							else if ( token.equals(VRMLdatatype.string_radius) ) spotLight.radius.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_beamWidth) ) spotLight.beamWidth.setValue( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_cutOffAngle) ) spotLight.cutOffAngle.setValue( GetSingleFloat() );
							else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_SpotLight);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_SpotLight);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_SpotLight);
				} // got equal sign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_SpotLight);
			} // end word token inside PointLight
			else FormatError("Illegal word inside " + VRMLdatatype.string_SpotLight);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_SpotLight);
		if (spotLight == null) spotLight = new SpotLight();
		return spotLight;
	} //end SpotLightNode




	private void TouchSensorNode(TouchSensor touchSensor){
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_DEF) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SetNodeName (touchSensor, token);
							}
						}
						else if ( token.equals(VRMLdatatype.string_enabled) ) touchSensor.enabled.setValue( CheckBoolean() );
						else FormatError("Invalid token inside " + VRMLdatatype.string_TouchSensor);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_TouchSensor);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_TouchSensor);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_TouchSensor);
			} // tokenType == WORD
			else FormatError("Missing  token following " + VRMLdatatype.string_TouchSensor);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_TouchSensor);
	} // end TouchSensorNode




	private Color ColorNode(SFNode geometry){
		Color returnColor = null;
		if (geometry.datatype == VRMLdatatype.IndexedFaceSet) {
			IndexedFaceSet indexedFaceSet = (IndexedFaceSet) geometry;
			returnColor = (Color) indexedFaceSet.color;
		}
		else if (geometry.datatype == VRMLdatatype.IndexedLineSet) {
			IndexedLineSet indexedLineSet = (IndexedLineSet) geometry;
			returnColor = (Color) indexedLineSet.color;
		}
		else if (geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) geometry;
			returnColor = (Color) pointSet.color;
		}
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnColor, token);
								if (foundNode != null) returnColor = (Color) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Color);
						}
						else {
							if (returnColor == null) returnColor = new Color();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnColor, token);
								}
							}
							else if (token.equals(VRMLdatatype.string_color) ) {
								float[] colorValue = GetFloatArray();
								returnColor.color.setValue(colorValue.length, colorValue);
							}
							else FormatError("Illegal token inside " + VRMLdatatype.string_color);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Color);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Color);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Color);
			} // tokenType == WORD
			else FormatError("Missing  token following " + VRMLdatatype.string_Color);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Color);
		return returnColor;
	} // end ColorNode




	private Coordinate CoordinateNode(SFNode geometry){
		Coordinate returnCoord = null;
		if (geometry.datatype == VRMLdatatype.IndexedFaceSet) {
			IndexedFaceSet indexedFaceSet = (IndexedFaceSet) geometry;
			returnCoord = (Coordinate) indexedFaceSet.coord;
		}
		else if (geometry.datatype == VRMLdatatype.IndexedLineSet) {
			IndexedLineSet indexedLineSet = (IndexedLineSet) geometry;
			returnCoord = (Coordinate) indexedLineSet.coord;
		}
		else if (geometry.datatype == VRMLdatatype.PointSet) {
			PointSet pointSet = (PointSet) geometry;
			returnCoord = (Coordinate) pointSet.coord;
		}
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnCoord, token);
								if (foundNode != null) returnCoord = (Coordinate) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Coordinate);
						}
						else {
							if (returnCoord == null) {
								returnCoord = new Coordinate();
								returnCoord.parent = geometry;
							}
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnCoord, token);
								}
							}
							else if (token.equals(VRMLdatatype.string_point) ) {
								float[] coordinatePoints = GetFloatArray();
								returnCoord.point.setValue(coordinatePoints.length, coordinatePoints);
							}
							else FormatError("Illegal token inside " + VRMLdatatype.string_Coordinate);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Coordinate);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Coordinate);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Coordinate);
			} // tokenType == WORD
			else FormatError("Missing  token following " + VRMLdatatype.string_Coordinate);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Coordinate);
		return returnCoord;
	} // end CoordinateNode




	private Normal NormalNode(SFNode geometry){
		Normal returnNormal = null;
		if (geometry.datatype == VRMLdatatype.IndexedFaceSet) {
			IndexedFaceSet indexedFaceSet = (IndexedFaceSet) geometry;
			returnNormal = (Normal) indexedFaceSet.normal;
		}
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnNormal, token);
								if (foundNode != null) returnNormal = (Normal) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Normal);
						}
						else {
							if (returnNormal == null) returnNormal = new Normal();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnNormal, token);
								}
							}
							else if (token.equals(VRMLdatatype.string_vector) ) {
								float[] vectorValue = GetFloatArray();
								returnNormal.vector.setValue(vectorValue.length, vectorValue);
							}
							else FormatError("Illegal token inside " + VRMLdatatype.string_Normal);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Normal);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Normal);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Normal);
			} // tokenType == WORD
			else FormatError("Missing  token following " + VRMLdatatype.string_Color);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Normal);
		return returnNormal;
	} // end NormalNode




	private TextureCoordinate TexCoordNode(SFNode geometry){
		TextureCoordinate returnTexCoord = null;
		if (geometry.datatype == VRMLdatatype.IndexedFaceSet) {
			IndexedFaceSet indexedFaceSet = (IndexedFaceSet) geometry;
			returnTexCoord = (TextureCoordinate) indexedFaceSet.texCoord;
		}
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnTexCoord, token);
								if (foundNode != null) returnTexCoord = (TextureCoordinate) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_TextureCoordinate);
						}
						else {
							if (returnTexCoord == null) returnTexCoord = new TextureCoordinate();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnTexCoord, token);
								}
							}
							else if (token.equals(VRMLdatatype.string_point) ) {
								float[] texCoordValue = GetFloatArray();
								returnTexCoord.point.setValue(texCoordValue.length, texCoordValue);
							}
							else FormatError("Illegal token inside " + VRMLdatatype.string_TextureCoordinate);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_TextureCoordinate);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_TextureCoordinate);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_TextureCoordinate);
			} // tokenType == WORD
			else FormatError("Missing  token following " + VRMLdatatype.string_Color);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_TextureCoordinate);
		return returnTexCoord;
	} // end TexCoordNode




	private Viewpoint ViewpointNode(){
		Viewpoint returnViewpoint = null;
		while ( (tokenType = GetToken()) != forwardSlash) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnViewpoint, token);
								if (foundNode != null) returnViewpoint = (Viewpoint) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Viewpoint);
						} // end USE word
						else {
							if (returnViewpoint == null) returnViewpoint = new Viewpoint();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnViewpoint, token);
								}
							} // end DEF word
							else if ( token.equals(VRMLdatatype.string_position) ) returnViewpoint.position.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_orientation) ) returnViewpoint.orientation.setValue( GetFloatValues(4) );
							else if ( token.equals(VRMLdatatype.string_fieldOfView) ) returnViewpoint.setFieldOfView( GetSingleFloat() );
							else if ( token.equals(VRMLdatatype.string_jump) ) returnViewpoint.jump.setValue( CheckBoolean() );
							else if ( token.equals(X3Ddatatype.string_centerOfRotation) ) {
								GetFloatValues(3);
								Write("(not currently supported)");
							}
							else if ( token.equals(VRMLdatatype.string_description) ) {
								String description = "";
								boolean firstToken = true;
								while ( (tokenType = GetToken()) != singleQuote) {
									if (!firstToken) description += " ";
									description += st.sval;
									firstToken = false;
								}
								returnViewpoint.description.setValue( description );
								Write( returnViewpoint.description.getValue() );
								st.pushBack(); // return the singleQuote for consistency
							}
							else FormatError("Invalid token inside " + VRMLdatatype.string_Viewpoint);
						} // end !USE word
					} // beginning quote
					else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Transform);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
					else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Transform);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Viewpoint);
			} // tokenType == WORD
			else FormatError("Missing token following in " + VRMLdatatype.string_Viewpoint);
		} // end while != rightAngleBracket
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Viewpoint);
		if (returnViewpoint == null) returnViewpoint = new Viewpoint(); // no USE nor attrbutes but legit Viewpoint
		return returnViewpoint;
	} // end ViewpointNode




	private Transform TransformNode(){
		Transform returnTransform = null;
		while ( (tokenType = GetToken()) != rightAngleBracket) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnTransform, token);
								if (foundNode != null) returnTransform = (Transform) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Transform);
						}
						else {
							if (returnTransform == null) returnTransform = new Transform();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnTransform, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_translation) ) returnTransform.translation.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_rotation) ) returnTransform.rotation.setValue( GetFloatValues(4) );
							else if ( token.equals(VRMLdatatype.string_center) ) returnTransform.center.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_scale) ) returnTransform.scale.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_scaleOrientation) ) returnTransform.scaleOrientation.setValue( GetFloatValues(4) );
							else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
								returnTransform.bboxSize.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
								returnTransform.bboxCenter.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else FormatError("Invalid token inside " + VRMLdatatype.string_Transform);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Transform);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Transform);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Transform);
			} // tokenType == WORD
			else FormatError("Missing token following in " + VRMLdatatype.string_Transform);
		} // end while != rightAngleBracket
		WriteLine(rightAngleBracket);
		indent += indentAmt;
		if (returnTransform == null) returnTransform = new Transform(); // no USE nor attrbutes but legit Transform
		return returnTransform;
	} // end TransformNode




	private Anchor AnchorNode(){
		Anchor returnAnchor = null;
		//while ( (tokenType = GetToken()) != forwardSlash) {
		while ( (tokenType = GetToken()) != rightAngleBracket) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnAnchor, token);
								if (foundNode != null) returnAnchor = (Anchor) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Anchor);
						} // end "USE"
						else { // got some value for Anchor object
							if (returnAnchor == null) returnAnchor = new Anchor();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnAnchor, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_description) ) {
								String description = "";
								boolean firstToken = true;
								while ( (tokenType = GetToken()) != doubleQuoteChar) {
									//if (tokenType == doubleQuoteChar) description += doubleQuoteChar;
									//else {
										if (!firstToken) description += " ";
										description += st.sval;
									//}
									firstToken = false;
								}
								//returnAnchor.description.setValue( description );
								returnAnchor.description = new SFString( description );
								Write( returnAnchor.description.getValue() );
								st.pushBack(); // return the quote for consistency
							}
							else if ( token.equals(VRMLdatatype.string_url) ) {
								String[] url = new String[1];
								url[0] = "";
								while ( (tokenType = GetToken()) != doubleQuoteChar) {
									if ( tokenType == StreamTokenizer.TT_WORD) url[0] += st.sval;
									else if ( tokenType == StreamTokenizer.TT_NUMBER) {
										int intNum = (int) st.nval;
										if (intNum == st.nval) {
											if (intNum == 0) url[0] += "."; // this is a real cludge, but I don't want to rewrite the GetFloat/GetToken code
											else url[0] += intNum;
										}
										else url[0] += st.nval;
									}
									else  url[0] += (char)( (byte)tokenType );
								}
								Write(url[0]);
								st.pushBack();
								returnAnchor.url = new MFString( 1, url );
							} // end if url node
							else if ( token.equals(VRMLdatatype.string_parameter) ) {
								String[] parameter = new String[1];
								parameter[0] = "";
								while ( (tokenType = GetToken()) != doubleQuoteChar) {
									if ( tokenType == StreamTokenizer.TT_WORD) parameter[0] += st.sval;
									else if ( tokenType == StreamTokenizer.TT_NUMBER) {
										int intNum = (int) st.nval;
										if (intNum == st.nval) {
											if (intNum == 0) parameter[0] += "."; // this is a real cludge, but I don't want to rewrite the GetFloat/GetToken code
											else parameter[0] += intNum;
										}
										else parameter[0] += st.nval;
									}
									else  parameter[0] += (char)( (byte)tokenType );
								}
								/*boolean insideAngleBracket = false;
								boolean insideDoubleQuote = false;
								tokenType = GetToken();
								if ( tokenType == StreamTokenizer.TT_WORD) parameter[0] += st.sval;
								else if ( tokenType == StreamTokenizer.TT_NUMBER) {
									int intNum = (int) st.nval;
									if (intNum == st.nval) {
										if (intNum == 0) parameter[0] += "."; // this is a real cludge, but I don't want to rewrite the GetFloat/GetToken code
										else parameter[0] += intNum;
									}
									else parameter[0] += st.nval;
								}
								else FormatError("Illegal value following quote in url in " + VRMLdatatype.string_Anchor);
								*/
								/*
								//while ( (tokenType = GetToken()) != singleQuote) {
								tokenType = GetToken();
								while ( (tokenType != singleQuote) || (tokenType != doubleQuoteChar) ) {
									if ( tokenType == StreamTokenizer.TT_WORD) {
										parameter[0] += st.sval;
									}
									else if ( tokenType == StreamTokenizer.TT_NUMBER) {
										int intNum = (int) st.nval;
										if (intNum == st.nval) {
											if (intNum == 0) parameter[0] += "."; // this is a real cludge, but I don't want to rewrite the GetFloat/GetToken code
											else parameter[0] += intNum;
										}
										else parameter[0] += st.nval;
									}
									else {
										//Write( (char)tokenType );
										Write( (char)( (byte)tokenType ) );
										if (tokenType == leftAngleBracket) {
											insideAngleBracket = true;
											Write(leftAngleBracket);
										}
										else if (tokenType == rightAngleBracket) {
											insideAngleBracket = false;
											Write(rightAngleBracket);
										}
										else if (tokenType == doubleQuoteChar) {
											if (insideDoubleQuote) {
												insideDoubleQuote = false;
											}
											else {
												parameter[0] = "";
												insideDoubleQuote = true;
											}
										}
										else parameter[0] += (char) tokenType;
									}
									tokenType = GetToken();
								} // end while loop
								*/
								Write(parameter[0]);
								st.pushBack();
								//Write(singleQuote);
								//Write( (char)( (byte)tokenType ) );
								returnAnchor.parameter = new MFString( 1, parameter );
							} // end if parameter node
							else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
								returnAnchor.bboxSize.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
								returnAnchor.bboxCenter.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else FormatError("Invalid token inside " + VRMLdatatype.string_Anchor);
						} // end parsing a value for the Anchor object.
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						//else FormatError("Missing '" + singleQuote + "' following parameters in " + VRMLdatatype.string_Anchor);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Anchor);
					} // end getting a beginning double/single quote
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Anchor);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Anchor);
			} // tokenType == WORD
			else FormatError("Wrong token '" + (char)( (byte)tokenType ) + "' following in " + VRMLdatatype.string_Anchor);
		} // end while != rightAngleBracket
		//Write(forwardSlash);
		WriteLine(rightAngleBracket);
		//if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		//else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Anchor);
		indent += indentAmt;
		if (returnAnchor == null) returnAnchor = new Anchor(); // no USE nor attrbutes but legit Anchor
		return returnAnchor;
	} // end AnchorNode




	private Group GroupNode(){
		Group returnGroup = null;
		while ( (tokenType = GetToken()) != rightAngleBracket) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnGroup, token);
								if (foundNode != null) returnGroup = (Group) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Coordinate);
						}
						else {
							if (returnGroup == null) returnGroup = new Group();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnGroup, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
								returnGroup.bboxSize.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
								returnGroup.bboxCenter.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else FormatError("Invalid token inside " + VRMLdatatype.string_Group);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Group);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Group);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Group);
			} // tokenType == WORD
			//else FormatError("Missing  token following in " + VRMLdatatype.string_Group);
		} // end while != rightAngleBracket
		WriteLine(rightAngleBracket);
		indent += indentAmt;
		if (returnGroup == null) returnGroup = new Group(); // no USE nor attributes
		return returnGroup;
	} // end GroupNode




	private Billboard BillboardNode(){
		Billboard returnGroup = null;
		while ( (tokenType = GetToken()) != rightAngleBracket) {
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(returnGroup, token);
								if (foundNode != null) returnGroup = (Billboard) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Coordinate);
						}
						else {
							if (returnGroup == null) returnGroup = new Billboard();
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (returnGroup, token);
								}
							}
							else if ( token.equals(VRMLdatatype.string_axisOfRotation) ) returnGroup.axisOfRotation.setValue( GetFloatValues(3) );
							else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
								returnGroup.bboxSize.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
								returnGroup.bboxCenter.setValue( GetFloatValues(3) );
								Write("(not currently supported) ");
							}
							else FormatError("Invalid token inside " + VRMLdatatype.string_Billboard);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Billboard);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Billboard);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Billboard);
			} // tokenType == WORD
			//else FormatError("Missing  token following in " + VRMLdatatype.string_Billboard);
		} // end while != rightAngleBracket
		WriteLine(rightAngleBracket);
		indent += indentAmt;
		if (returnGroup == null) returnGroup = new Billboard(); // no USE nor attributes
		return returnGroup;
	} // end BillboardNode




	private void ROUTEnode(){
		SFNode fromNode = null;
		SFNode toNode	= null;
		boolean fromPropertyFound = false;
		boolean toPropertyFound = false;
		Route newRoute = new Route();
		String fromField = null;
		String toField = null;
		while ( (tokenType = GetToken()) != forwardSlash) {
			if ( tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) {
					//	Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(X3Ddatatype.string_fromNode) ) {
							if ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token + " ");
								fromNode = newRoute.MatchRouteObjectName(token);
								if (fromNode != null) {
									newRoute.fromObject = fromNode;
									RouteProperties fromProperties = new RouteProperties();
									newRoute.from = fromProperties;
								}
								else FormatError("'" + token + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE + " " + X3Ddatatype.string_fromNode);
							}
							else FormatError("Missing word token in " + VRMLdatatype.string_ROUTE);
						}
						else if ( token.equals(X3Ddatatype.string_fromField) ) {
							if ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
								token = st.sval;
								fromField = token;
								Write(fromField + " ");
								// VRML version that didn't work with X3D-edit
								//fromPropertyFound = newRoute.MatchRoutePropertyName (fromNode, token, newRoute.from);
								//if (fromPropertyFound) fromNode = newRoute.MatchRouteObjectName(token);
								//else FormatError("fromField '" + token + "' not found in " + VRMLdatatype.string_ROUTE);
							}
							else FormatError("Missing word token in " + VRMLdatatype.string_ROUTE);
						}
						else if ( token.equals(X3Ddatatype.string_toNode) ) {
							if ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token + " ");
								toNode = newRoute.MatchRouteObjectName(token);
								if (toNode != null) {
									newRoute.toObject = toNode;
									// Get the fromField
									RouteProperties toProperties = new RouteProperties();
									newRoute.to = toProperties;
								}
								else FormatError("'" + token + "' not a pre-defined Node in " + VRMLdatatype.string_ROUTE + " " + X3Ddatatype.string_toNode);
							}
							else FormatError("Missing word token in " + VRMLdatatype.string_ROUTE);
						}
						else if ( token.equals(X3Ddatatype.string_toField) ) {
							if ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
								token = st.sval;
								toField = token;
								Write(toField + " ");
								// VRML version that didn't work with X3D-edit
								//toPropertyFound = newRoute.MatchRoutePropertyName (toNode, token, newRoute.to);
								//if (toPropertyFound) toNode = newRoute.MatchRouteObjectName(token);
								//else FormatError("toField '" + token + "' not found in " + VRMLdatatype.string_ROUTE);
							}
							else FormatError("Missing word token in " + VRMLdatatype.string_ROUTE);
						}
						else FormatError("Missing token '" + X3Ddatatype.string_fromNode + "' in " + VRMLdatatype.string_ROUTE);
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_ROUTE);
					} // end receiving a single or double quote
					else FormatError("Missing quote after equal sing in " + VRMLdatatype.string_ROUTE);
				} // end if token = equalSign
				else FormatError("Missing '" + equalSign + "' in " + VRMLdatatype.string_ROUTE);
			} // end if token = WORD
			else FormatError("Missing word token in " + VRMLdatatype.string_ROUTE);
		} // while not forwardSlash
		Write(forwardSlash);
		if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
		else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_ROUTE);

		// New code from VRML version to handle x3D-edit creation of ROUTE's in different order
//System.out.println("fromNode = " + fromNode.name + ", fromField = " + fromField );
		fromPropertyFound = newRoute.MatchRoutePropertyName (fromNode, fromField, newRoute.from);
		if (fromPropertyFound) fromNode = newRoute.MatchRouteObjectName(token);
		else FormatError("fromField '" + token + "' not found in " + VRMLdatatype.string_ROUTE);

//System.out.println("toNode = " + toNode.name + ", toField = " + toField );
		toPropertyFound = newRoute.MatchRoutePropertyName (toNode, toField, newRoute.to);
		if (toPropertyFound) toNode = newRoute.MatchRouteObjectName(token);
		else FormatError("toField '" + token + "' not found in " + VRMLdatatype.string_ROUTE);
		if ( (fromPropertyFound) && (toPropertyFound) ) {
//System.out.println("BOTH FOUND");
			routeLast.nextRoute = newRoute;
			routeLast = newRoute;
		}
	} // end ROUTEnode




	private int[] GetIntegerArray(){
		int[] returnIntArray = null;
		Vector intVector = new Vector();
		int intNumber = 0;
		/*
		// old version that didn't handle carriage-return line-feed characters, particularly from X3D-edit
		while ( (tokenType = GetToken()) == StreamTokenizer.TT_NUMBER) {
			intNumber = GetIntegerNumber();
			//if (intNumber != -1) intVector.addElement( (Object) new Integer ( intNumber ) );
			intVector.addElement( (Object) new Integer ( intNumber ) );
		}
		*/
		// New version that handles carriage-return line-feed characters, particularly from X3D-edit
		boolean done = false;
		while ( !done ) {
			tokenType = GetToken();
			if ( tokenType == StreamTokenizer.TT_NUMBER ) {
				intNumber = GetIntegerNumber();
				//if (floatNumber != -1) floatVector.addElement( (Object) new Float ( floatNumber ) );
				intVector.addElement( (Object) new Integer ( intNumber ) );
			}
			else if (tokenType == '&') { // check for carriage return-line feed from X3D-edit
				while ( (tokenType = GetToken()) != ';' ) { }
				WriteLine();
				Write(indent + indentAmt );
			}
			else done = true;
		}
		st.pushBack(); // return the last token
		Integer il;
		returnIntArray = new int[intVector.size()];
		for (int i = 0; i < returnIntArray.length; i++) {
			il = new Integer( intVector.elementAt(i).toString() );
			returnIntArray[i] = il.intValue();
		}
		return returnIntArray;
	} // end GetIntegerArray




	private float[] GetFloatArray(){
		float[] returnFloatArray = null;
		Vector floatVector = new Vector();
		float floatNumber;
		/*
		// old version that didn't handle carriage-return line-feed characters, particularly from X3D-edit
		while ( (tokenType = GetToken()) == StreamTokenizer.TT_NUMBER) {
			floatNumber = GetFloatNumber();
			//if (floatNumber != -1) floatVector.addElement( (Object) new Float ( floatNumber ) );
			floatVector.addElement( (Object) new Float ( floatNumber ) );
		}
		*/
		// New version that handles carriage-return line-feed characters, particularly from X3D-edit
		boolean done = false;
		while ( !done ) {
			tokenType = GetToken();
			if ( tokenType == StreamTokenizer.TT_NUMBER ) {
				floatNumber = GetFloatNumber();
				//if (floatNumber != -1) floatVector.addElement( (Object) new Float ( floatNumber ) );
				floatVector.addElement( (Object) new Float ( floatNumber ) );
			}
			else if (tokenType == '&') { // check for carriage return-line feed from X3D-edit
				while ( (tokenType = GetToken()) != ';' ) { }
				WriteLine();
				Write(indent + indentAmt );
			}
			else done = true;
		}
		st.pushBack(); // return the last token
		Float fl;
		returnFloatArray = new float[floatVector.size()];
		for (int i = 0; i < returnFloatArray.length; i++) {
			fl = new Float( floatVector.elementAt(i).toString() );
			returnFloatArray[i] = fl.floatValue();
		}
		return returnFloatArray;
	} // end GetFloatArray




	private void IndexedLineSetNode(Shape shape, IndexedLineSet indexedLineSet){
		boolean indexedLineSetDone = false;
		while ( !indexedLineSetDone ){
			//if ((tokenType = GetToken()) == leftAngleBracket){
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(" " + token);
					if ( (tokenType = GetToken()) == equalSign) {
						Write(equalSign);
						//if ( (tokenType = GetToken()) == singleQuote) {
						//	Write(singleQuote)
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
							Write( (char)( (byte)tokenType ) );
						/* */
							if ( token.equals(VRMLdatatype.string_USE) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SFNode foundNode = SetUSEtoken(indexedLineSet, token);
									if (foundNode != null) {
										//remove(indexedLineSet); /*** should remove the indexedLineSet if not needed */
										shape.geometry = (IndexedLineSet) foundNode;
									}
									else FormatError("No " + VRMLdatatype.string_IndexedLineSet + " DEFINED as '" + token + "'");
									// should now end the USE with a "/>  (a quote, forward slash and right angle
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										tokenType = GetToken();
										if ( tokenType == forwardSlash ) {
											Write( (char)( (byte)tokenType ) );
											tokenType = GetToken();
											if ( tokenType == rightAngleBracket ) {
												WriteLine( (char)( (byte)tokenType ) );
											}
											else FormatError("Missing '" + rightAngleBracket + "' at end of " + VRMLdatatype.string_IndexedLineSet);
										}
										else FormatError("Missing '" + forwardSlash + "' near end of " + VRMLdatatype.string_IndexedLineSet);
									}
									else FormatError("Missing ending quote in " + VRMLdatatype.string_IndexedLineSet);
								}
								else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_IndexedLineSet);
								if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
								state = PopStack();
								indexedLineSetDone = true;
							} // end of 'USE' parsing
							else { // have a defined IndexedLineSet, not a 'USE' one.
						/* */

								if ( token.equals(VRMLdatatype.string_coordIndex) ) indexedLineSet.coordIndex = new MFInt32( GetIntegerArray() );
								/* */
								else if ( token.equals(VRMLdatatype.string_DEF) ) {
									tokenType = GetToken();
									if (tokenType == StreamTokenizer.TT_WORD) {
										token = st.sval;
										Write(token);
										SetNodeName (indexedLineSet, token);
									}
								}
								/* */
								else if ( token.equals(VRMLdatatype.string_colorIndex) ) indexedLineSet.colorIndex = new MFInt32( GetIntegerArray() );
								else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) indexedLineSet.colorPerVertex.setValue( CheckBoolean() );
								else FormatError("Unexpected token '" + token + "' in " + VRMLdatatype.string_IndexedLineSet);
								//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
								tokenType = GetToken();
								if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
								else FormatError("Missing quote after token in " + VRMLdatatype.string_IndexedLineSet);
						/* */
							} // a non-USE indexedFaceSet
						/* */
						}
						else FormatError("Missing beginning quote before token in " + VRMLdatatype.string_IndexedLineSet);
					}
					else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_IndexedLineSet);
				} // end got a WORD token after <
				else if (tokenType == rightAngleBracket) {
					WriteLine(rightAngleBracket);
				} // end if rightAngleBracket
				else if (tokenType == leftAngleBracket) {
					//while ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(indent + leftAngleBracket + token);
						if (token.equals(VRMLdatatype.string_Coordinate) ) indexedLineSet.coord = CoordinateNode(indexedLineSet);
						else if (token.equals(VRMLdatatype.string_Color) ) indexedLineSet.color = ColorNode(indexedLineSet);
						else FormatError("Unexpected token '" + token + "' in " + VRMLdatatype.string_IndexedLineSet);
					} // end if word
					else if (tokenType == forwardSlash) {
						if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
						Write(indent + leftAngleBracket + forwardSlash);
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_IndexedLineSet) ) Write(VRMLdatatype.string_IndexedLineSet);
							else FormatError("Expecting '" + VRMLdatatype.string_IndexedLineSet + "' instead of " + token);
						}
						else FormatError("Expecting word token inside " + VRMLdatatype.string_IndexedLineSet);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' in " + VRMLdatatype.string_IndexedLineSet);
						indexedLineSetDone = true;
					} // end forwardSlash
					else FormatError("Missing token in " + VRMLdatatype.string_IndexedLineSet);
				} // end leftAngleBracket
				else if (tokenType == forwardSlash) {
					if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
					Write(indent + leftAngleBracket + forwardSlash);
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(token);
						if ( token.equals(VRMLdatatype.string_IndexedLineSet) ) {
							state = PopStack();
							indexedLineSetDone = true;
						} // end getting ending IndexedLineSet node
						else FormatError("Expecting '" + VRMLdatatype.string_IndexedLineSet + "'");
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_IndexedLineSet);
					} // end getting Word token after </
					else FormatError("Missing word '" + VRMLdatatype.string_IndexedLineSet + "'");
				} // end if forward slash for ending IndexedLineSet
			//} // end if we begin with leftAngleBracket
			//else FormatError("Missing '" + leftAngleBracket + "' inside " + VRMLdatatype.string_IndexedLineSet);
		} // end while indexedFaceSetDone == false
	} // end IndexedLineSetNode




	/************** need to do normalIndex ************************/
	/******* ASSUMES FOR THE MOMENT THAT WE GET ONLY TRIANGLES **********/
	private void IndexedFaceSetNode(Shape shape, IndexedFaceSet indexedFaceSet){
		boolean indexedFaceSetDone = false;
		while ( !indexedFaceSetDone ){
			//if ((tokenType = GetToken()) == leftAngleBracket){
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(" " + token);
					if ( (tokenType = GetToken()) == equalSign) {
						Write(equalSign)
						;
						//if ( (tokenType = GetToken()) == singleQuote) {
						//	Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
							Write( (char)( (byte)tokenType ) );
						/* */
							if ( token.equals(VRMLdatatype.string_USE) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SFNode foundNode = SetUSEtoken(indexedFaceSet, token);
									if (foundNode != null) {
										//indexedFaceSet = (IndexedFaceSet) foundNode;
										//remove(indexedFaceSet); /*** should remove the indexedFaceSet if not needed */
										shape.geometry = (IndexedFaceSet) foundNode;
									}
									else FormatError("No " + VRMLdatatype.string_IndexedFaceSet + " DEFINED as '" + token + "'");
									// should now end the USE with a "/>  (a quote, forward slash and right angle
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										tokenType = GetToken();
										if ( tokenType == forwardSlash ) {
											Write( (char)( (byte)tokenType ) );
											tokenType = GetToken();
											if ( tokenType == rightAngleBracket ) {
												WriteLine( (char)( (byte)tokenType ) );
											}
											else FormatError("Missing '" + rightAngleBracket + "' at end of " + VRMLdatatype.string_IndexedFaceSet);
										}
										else FormatError("Missing '" + forwardSlash + "' near end of " + VRMLdatatype.string_IndexedFaceSet);
									}
									else FormatError("Missing ending quote in " + VRMLdatatype.string_IndexedFaceSet);
								}
								else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_IndexedFaceSet);
								if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
								state = PopStack();
								indexedFaceSetDone = true;
							} // end of 'USE' parsing
							else { // have a defined IndexedFaceSet, not a 'USE' one.
						/* */
								if ( token.equals(VRMLdatatype.string_coordIndex) ) indexedFaceSet.coordIndex = new MFInt32( GetIntegerArray() );
								/* */
								else if ( token.equals(VRMLdatatype.string_DEF) ) {
									tokenType = GetToken();
									if (tokenType == StreamTokenizer.TT_WORD) {
										token = st.sval;
										Write(token);
										SetNodeName (indexedFaceSet, token);
									}
								}
								/* */
								else if ( token.equals(VRMLdatatype.string_colorIndex) ) indexedFaceSet.colorIndex = new MFInt32( GetIntegerArray() );
								else if ( token.equals(VRMLdatatype.string_texCoordIndex) ) indexedFaceSet.texCoordIndex = new MFInt32( GetIntegerArray() );
								//else if ( token.equals(VRMLdatatype.string_normalIndex) ) indexedFaceSet.normalPolygonIndex = new MFInt32( GetIntegerArray() );
								else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) indexedFaceSet.colorPerVertex.setValue( CheckBoolean() );
								else if ( token.equals(VRMLdatatype.string_normalPerVertex) ) indexedFaceSet.normalPerVertex.setValue( CheckBoolean() );
								else if ( token.equals(VRMLdatatype.string_ccw) ) {
									indexedFaceSet.ccw.setValue( CheckBoolean() );
									Write(" (not implemented: ccw TRUE only)");
								}
								else if ( token.equals(VRMLdatatype.string_solid) ) {
									indexedFaceSet.solid.setValue( CheckBoolean() );
									Write(" (not implemented)");
								}
								else if ( token.equals(VRMLdatatype.string_convex) ) {
									indexedFaceSet.convex.setValue( CheckBoolean() );
									Write(" (not implemented)");
								}
								else if ( token.equals(VRMLdatatype.string_creaseAngle) ) {
									float creaseAngle = GetSingleFloat();
									if ( !appletParameters.creaseAngleDefault ) indexedFaceSet.creaseAngle.setValue( creaseAngle );
									else  Write(" - using default of " + appletParameters.creaseAngle);
									WriteLine();
								}
								else FormatError("Unexpected token '" + token + "' in " + VRMLdatatype.string_IndexedFaceSet);
								//end quote
								//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
								tokenType = GetToken();
								if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
								else FormatError("Missing ending quote in " + VRMLdatatype.string_IndexedFaceSet);
						/* */
							} // a non-USE indexedFaceSet
						/* */
						} // end if beginning quote found
						else FormatError("Missing beginning quote in " + VRMLdatatype.string_IndexedFaceSet);
					}
					else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_IndexedFaceSet);
				} // end got a WORD token after <
				else if (tokenType == rightAngleBracket) {
					WriteLine(rightAngleBracket);
				} // end if rightAngleBracket
				else if (tokenType == leftAngleBracket) {
					//while ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(indent + leftAngleBracket + token);
						if (token.equals(VRMLdatatype.string_Coordinate) ) indexedFaceSet.coord = CoordinateNode(indexedFaceSet);
						else if (token.equals(VRMLdatatype.string_Color) ) indexedFaceSet.color = ColorNode(indexedFaceSet);
						else if (token.equals(VRMLdatatype.string_Normal) ) indexedFaceSet.normal = NormalNode(indexedFaceSet);
						else if (token.equals(VRMLdatatype.string_TextureCoordinate) )  indexedFaceSet.texCoord = TexCoordNode(indexedFaceSet);
						else FormatError("Unexpected token '" + token + "' in " + VRMLdatatype.string_IndexedFaceSet);
					} // end if word
					else if (tokenType == forwardSlash) {
						if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
						Write(indent + leftAngleBracket + forwardSlash);
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_IndexedFaceSet) ) Write(VRMLdatatype.string_IndexedFaceSet);
							else FormatError("Expecting '" + VRMLdatatype.string_IndexedFaceSet + "' instead of " + token);
						}
						else FormatError("Expecting word token inside " + VRMLdatatype.string_IndexedFaceSet);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' in " + VRMLdatatype.string_IndexedFaceSet);
						indexedFaceSetDone = true;
					} // end forwardSlash
					else FormatError("Missing token in " + VRMLdatatype.string_IndexedFaceSet);
				} // end leftAngleBracket
				else if (tokenType == forwardSlash) {
					if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
					Write(indent + leftAngleBracket + forwardSlash);
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(token);
						if ( token.equals(VRMLdatatype.string_IndexedFaceSet) ) {
							state = PopStack();
							indexedFaceSetDone = true;
						} // end getting ending IndexedFaceSet node
						else FormatError("Expecting '" + VRMLdatatype.string_IndexedFaceSet + "'");
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_IndexedFaceSet);
					} // end getting Word token after </
					else FormatError("Missing word '" + VRMLdatatype.string_IndexedFaceSet + "'");
				} // end if forward slash for ending IndexedFaceSet
			//} // end if we begin with leftAngleBracket
			//else FormatError("Missing '" + leftAngleBracket + "' inside " + VRMLdatatype.string_IndexedFaceSet);
		} // end while indexedFaceSetDone == false
	} // end IndexedFaceSetNode




	private void PointSetNode(Shape shape, PointSet pointSet){
		boolean pointSetDone = false;
		while ( !pointSetDone ){
			tokenType = GetToken();
			if (tokenType == rightAngleBracket) {
				WriteLine(rightAngleBracket);
			} // end if rightAngleBracket
			else if (tokenType == leftAngleBracket) {
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(indent + leftAngleBracket + token);
					if (token.equals(VRMLdatatype.string_Coordinate) ) pointSet.coord = CoordinateNode(pointSet);
					else if (token.equals(VRMLdatatype.string_Color) ) pointSet.color = ColorNode(pointSet);
				} // end if word
				else if (tokenType == forwardSlash) {
					if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
					Write(indent + leftAngleBracket + forwardSlash);
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						if (token.equals(VRMLdatatype.string_PointSet) ) Write(VRMLdatatype.string_PointSet);
						else FormatError("Expecting '" + VRMLdatatype.string_PointSet + "' instead of " + token);
					}
					else FormatError("Expecting word token inside " + VRMLdatatype.string_PointSet);
					if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
					else FormatError("Missing '" + rightAngleBracket + "' in " + VRMLdatatype.string_PointSet);
					pointSetDone = true;
				} // end forwardSlash
				else FormatError("Missing token in " + VRMLdatatype.string_PointSet);
			} // end leftAngleBracket
			else FormatError("Missing '" + leftAngleBracket + "' inside " + VRMLdatatype.string_PointSet);
		} // end while pointSetDone == false
	} // end PointSetNode




	//private void AppearanceNode(Appearance appearance){
	private Appearance AppearanceNode(Shape shape) {
		Appearance appearance = null;
		boolean appearanceDone = false;
		while ( !appearanceDone ){
			tokenType = GetToken();
			if (tokenType == StreamTokenizer.TT_WORD) {
				token = st.sval;
				Write(" " + token);
				if ( (tokenType = GetToken()) == equalSign) {
					Write(equalSign);
					//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
					tokenType = GetToken();
					if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
						Write( (char)( (byte)tokenType ) );
						if ( token.equals(VRMLdatatype.string_USE) ) {
							tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(token);
								SFNode foundNode = SetUSEtoken(appearance, token);
								if (foundNode != null) appearance = (Appearance) foundNode;
							}
							else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Appearance);
						}
						else {
							if (appearance == null) {
								appearance = new Appearance();
								indent += indentAmt;
							}
							if ( token.equals(VRMLdatatype.string_DEF) ) {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(token);
									SetNodeName (appearance, token);
								}
							}
							else FormatError("Illegal token inside " + VRMLdatatype.string_Appearance);
						}
						//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
						tokenType = GetToken();
						if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
						else FormatError("Missing quote following parameters in " + VRMLdatatype.string_Appearance);
					}
					else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Appearance);
				} // end if property followed by equalSign
				else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Appearance);
			} // got a word token
			else if (tokenType == rightAngleBracket) {
				WriteLine(rightAngleBracket);
				//indent += indentAmt;
				//appearanceDone = true;
			}
			else if (tokenType == forwardSlash) {
				Write( forwardSlash );
				if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
				else FormatError("Missing '" + rightAngleBracket + "' in " + VRMLdatatype.string_Appearance + "'");
				appearanceDone = true;
			}
			else if (tokenType == leftAngleBracket){
				if (appearance == null) {
					appearance = new Appearance();
					indent += indentAmt;
				}
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(indent + leftAngleBracket + token);
					if ( token.equals(VRMLdatatype.string_Material) ) {
						Material material = null;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_USE) ) {
											tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												Write(token);
												SFNode foundNode = SetUSEtoken(material, token);
												if (foundNode != null) material = (Material) foundNode;
											}
											else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_Material);
										}
										else {
											if (material == null) material = new Material();
											if ( token.equals(VRMLdatatype.string_DEF) ) {
												tokenType = GetToken();
												if (tokenType == StreamTokenizer.TT_WORD) {
													token = st.sval;
													Write(token);
													SetNodeName (material, token);
												}
												else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_Material);
											}
											else if ( token.equals(VRMLdatatype.string_diffuseColor) ) material.diffuseColor.setValue( GetFloatValues(3) );
											else if ( token.equals(VRMLdatatype.string_emissiveColor) ) material.emissiveColor.setValue( GetFloatValues(3) );
											else if ( token.equals(VRMLdatatype.string_specularColor) ) material.specularColor.setValue( GetFloatValues(3) );
											else if ( token.equals(VRMLdatatype.string_transparency) ) material.transparency.setValue( GetSingleFloat() );
											else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) material.ambientIntensity.setValue( GetSingleFloat() );
											else if ( token.equals(VRMLdatatype.string_shininess) ) material.shininess.setValue( GetSingleFloat() );
											else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Material);
										}
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_Material);
									} // got first single quote
									else FormatError("Missing quote following " + token + " in " + VRMLdatatype.string_Material);
								} // got equal sign
								else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_Material);
							} // word token inside Material
							else FormatError("Illegal word inside " + VRMLdatatype.string_Material);
						} // while not forwardSlash

						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Material);
						if (material == null) material = new Material();
						appearance.material = material;
					} // end Material


					else if ( token.equals(VRMLdatatype.string_ImageTexture) ) {
						ImageTexture imageTexture = null;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
										//Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_USE) ) {
											tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												Write(token);
												SFNode foundNode = SetUSEtoken(imageTexture, token);
												if (foundNode != null) imageTexture = (ImageTexture) foundNode;
											}
											else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_ImageTexture);
										}
										else {
											// moved below for X3D implementation
											//if (imageTexture == null) imageTexture = new ImageTexture();

											if ( token.equals(VRMLdatatype.string_url) ) {
												//boolean insideAngleBracket = false;
												//boolean insideDoubleQuote = false;
												String[] url = new String[1];
												url[0] = "";
												tokenType = GetToken();
												/*
											//	while ( (tokenType = GetToken()) != singleQuote) {
													if ( tokenType == StreamTokenizer.TT_WORD) url[0] += st.sval;
													else if ( tokenType == StreamTokenizer.TT_NUMBER) {
														int intNum = (int) st.nval;
														if (intNum == st.nval) {
															if (intNum == 0) url[0] += "."; // this is a real cludge, but I don't want to rewrite the GetFloat/GetToken code
															else url[0] += intNum;
														}
														else url[0] += st.nval;
													}
													else {
														//Write( (char)tokenType );
														if (tokenType == leftAngleBracket) insideAngleBracket = true;
														else if (tokenType == rightAngleBracket) insideAngleBracket = false;
														else if (tokenType == doubleQuoteChar) {
															if (insideDoubleQuote) {
																insideDoubleQuote = false;
															}
															else {
																url[0] = "";
																insideDoubleQuote = true;
															}
														}
														else url[0] += (char) tokenType;
													}
													//if (!insideAngleBracket) url += " ";
											//	}
											*/
												url[0] += st.sval;
												Write(url[0]);
												//st.pushBack();
												//Write(singleQuote);
												// check if this image was previously downloaded, and if so, point to it
												// otherwise, request it be downloaded
												SFNode currNodeLink	= imageTextureRoot.next;
												while (currNodeLink != null) {
													ImageTexture currImageTextureLink = (ImageTexture) currNodeLink;
													if ( currImageTextureLink.url.get1Value(0).equals(url[0]) ) {
														//currentAppearance.texture = currImageTextureLink;
														// added for X3D implementation
														imageTexture = currImageTextureLink;
														break;
													}
													currNodeLink = currNodeLink.next;
												}
												if ( currNodeLink == null) {
													// add new Image Texture
													// moved from above for X3D implementation
													if (imageTexture == null) imageTexture = new ImageTexture();
													//ImageTexture currentImageTexture	= new ImageTexture();
													//SetNodeName(imageTexture, imageTextureDEFName); // new var used to save nodeName
													imageTexture.url = new MFString( 1, url );
													imageTexture.retrieveImage(localApplet, 1);
													// insert new ImageTexture into linked list
													imageTexture.next = imageTextureRoot.next;
													imageTextureRoot.next = imageTexture;
												}
											} // end if url node
										} // end not USE value
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_ImageTexture);
									} // got first single quote
									else FormatError("Missing quote  following " + token + " in " + VRMLdatatype.string_ImageTexture);
								} // got equal sign
								else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_ImageTexture);
							} // word token inside Material
							else FormatError("Illegal word inside " + VRMLdatatype.string_ImageTexture);
						} // while not forwardSlash

						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_ImageTexture);
						if (imageTexture == null) imageTexture = new ImageTexture();
						appearance.texture = imageTexture;
					} // end ImageTexture



					else if ( token.equals(VRMLdatatype.string_TextureTransform) ) {
						TextureTransform textureTransform = null;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
									//	Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_USE) ) {
											tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												Write(token);
												SFNode foundNode = SetUSEtoken(textureTransform, token);
												if (foundNode != null) textureTransform = (TextureTransform) foundNode;
											}
											else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word in " + VRMLdatatype.string_TextureTransform);
										}
										else {
											if (textureTransform == null) textureTransform = new TextureTransform();
											if ( token.equals(VRMLdatatype.string_DEF) ) {
												tokenType = GetToken();
												if (tokenType == StreamTokenizer.TT_WORD) {
													token = st.sval;
													Write(token);
													SetNodeName (textureTransform, token);
												}
												else FormatError(VRMLdatatype.string_DEF + " = '" + token + "' not a word in " + VRMLdatatype.string_TextureTransform);
											}
											else if ( token.equals(VRMLdatatype.string_scale) ) textureTransform.scale.setValue( GetFloatValues(2) );
											else if ( token.equals(VRMLdatatype.string_center) ) textureTransform.center.setValue( GetFloatValues(2) );
											else if ( token.equals(VRMLdatatype.string_rotation) ) textureTransform.rotation.setValue( GetSingleFloat() );
											else if ( token.equals(VRMLdatatype.string_translation) ) textureTransform.translation.setValue( GetFloatValues(2) );
											else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TextureTransform);
										} // end not USE value
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										//else FormatError("Missing '" + singleQuote + "' following " + equalSign + " in " + VRMLdatatype.string_TextureTransform);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing quote following parameters in " + VRMLdatatype.string_TextureTransform);
									} // got first single quote
									else FormatError("Missing quote '" + token + "=' in " + VRMLdatatype.string_TextureTransform);
								} // got equal sign
								else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_TextureTransform);
							} // word token inside Material
							else FormatError("Illegal word inside " + VRMLdatatype.string_TextureTransform);
						} // while not forwardSlash

						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_TextureTransform);
						if (textureTransform == null) textureTransform = new TextureTransform();
						appearance.textureTransform = textureTransform;
					} // end TextureTransform


					else if ( token.equals(VRMLdatatype.string_PixelTexture) ) {
						PixelTexture pixelTexture = new PixelTexture();
						appearance.texture = pixelTexture;
						while ( (tokenType = GetToken()) != forwardSlash) {
							//tokenType = GetToken();
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_image) ) {
											if ( (tokenType = GetToken()) == StreamTokenizer.TT_NUMBER) pixelTexture.image.width = GetIntegerNumber();
											else FormatError("Missing width value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);
											if ( (tokenType = GetToken()) == StreamTokenizer.TT_NUMBER) pixelTexture.image.height = GetIntegerNumber();
											else FormatError("Missing height value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);
											if ( (tokenType = GetToken()) == StreamTokenizer.TT_NUMBER) pixelTexture.image.components = GetIntegerNumber();
											else FormatError("Missing components value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);
											pixelTexture.image.pixels = new byte[pixelTexture.image.width * pixelTexture.image.height * pixelTexture.image.components];
											int widthIndex = pixelTexture.image.width - 1;
											int heightIndex = pixelTexture.image.height - 1;
											for (int i = 0; i < pixelTexture.image.width; i++) {
												for (int j = 0; j < pixelTexture.image.height; j++) {
													byte[] returnBytes = GetByte(pixelTexture.image.components);
													for (int byteNum = 0; byteNum < returnBytes.length; byteNum++) {
														pixelTexture.image.pixels[
															(i + ((heightIndex-j)*pixelTexture.image.height))*pixelTexture.image.components + byteNum] =
															returnBytes[byteNum];
													}
												}
											}
											pixelTexture.image.SetRGBA();
										} // end if token == image
										else if ( token.equals(VRMLdatatype.string_repeatS) ) {
											pixelTexture.repeatS.setValue( CheckBoolean() );
											Write("; " + VRMLdatatype.string_repeatS + " not currently supported ");
										}
										else if ( token.equals(VRMLdatatype.string_repeatT) ) {
											pixelTexture.repeatT.setValue( CheckBoolean() );
											Write("; " + VRMLdatatype.string_repeatT + " not currently supported ");
										}
										else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PixelTexture);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing quote following parameters in " + VRMLdatatype.string_PixelTexture);
									}
									else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_PixelTexture);
								} // got equal sign
								else FormatError("Missing '" + equalSign + "' following " + token + " in " + VRMLdatatype.string_PixelTexture);
							} // word token inside PixelTexture
							else FormatError("Missing word token in " + VRMLdatatype.string_PixelTexture);
						} // end while loop
						if ( tokenType == forwardSlash) Write(forwardSlash);
						else FormatError("Missing '" + forwardSlash + "' in " + VRMLdatatype.string_PixelTexture);
						//else FormatError("Illegal word inside " + VRMLdatatype.string_PixelTexture);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' in " + VRMLdatatype.string_PixelTexture);
					} // end PixelTexture


					else FormatError("Missing ' inside " + VRMLdatatype.string_Appearance);
				} // end if forward slash for ending Appearance
				else if (tokenType == forwardSlash) {
					if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
					Write(indent + leftAngleBracket + forwardSlash);
					if ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(token);
						if ( token.equals(VRMLdatatype.string_Appearance) ) {
							if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
							else  FormatError("Missing '" + rightAngleBracket + "' after '" + leftAngleBracket + forwardSlash + VRMLdatatype.string_Appearance + "'");
							appearanceDone = true;
						}
						else FormatError("Missing '" + VRMLdatatype.string_Appearance + "' after '" + leftAngleBracket + forwardSlash + "'");
					}
					else FormatError("Missing '" + rightAngleBracket + "' after '" + forwardSlash + "' in " + VRMLdatatype.string_Appearance);
				} // end if forward slash for ending Appearance
			} // end if we begin with leftAngleBracket
			else FormatError("Missing '" + leftAngleBracket + "' inside " + VRMLdatatype.string_Appearance);
		} // end while appearanceDone == false
		return appearance;
	} //end AppearanceNode




	private void ShapeNode(Shape shape){
		boolean shapeDone = false;
		while ( !shapeDone ){
			//if ( (tokenType = GetToken()) == leftAngleBracket) {
			tokenType = GetToken();
			if ( tokenType == leftAngleBracket) {
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					Write(indent + leftAngleBracket);
					token = st.sval;
					Write(token);
					if ( token.equals(VRMLdatatype.string_Box) ) {
						float[] size = Box.size;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
									//	Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_size) ) size = GetFloatValues(Box.size.length);
										else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Box);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing Quote following parameter inside '" + VRMLdatatype.string_Box);
									}
									else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Box);
								} // end if equal sign follows token
								else FormatError("Missing '" + equalSign + "' following '" + token + "' inside '" + VRMLdatatype.string_Box);
							} // got word following Box node
							else FormatError("Missing property following " + VRMLdatatype.string_Box);
						} // end while not forwardSlash
						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Box);
						Box box	= new Box(size);
						//SetNodeName(box, nodeName);
						shape.geometry = box;
					} // end if Box node
					else if ( token.equals(VRMLdatatype.string_Sphere) ) {
						float radius = Sphere.radius;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
									//	Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_radius) ) radius = GetSingleFloat();
										else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Sphere);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing Quote following parameter inside '" + VRMLdatatype.string_Sphere);
									}
									else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Sphere);
								} // end if equal sign follows token
								else FormatError("Missing '" + equalSign + "' following '" + token + "' inside '" + VRMLdatatype.string_Sphere);
							} // got a word following Sphere node
							else FormatError("Missing property following " + VRMLdatatype.string_Sphere);
						} // end while not forwardSlash
						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Sphere);
						Sphere sphere	= new Sphere(radius);
						//SetNodeName(sphere, nodeName);
						shape.geometry = sphere;
					} // end if Sphere node
					else if ( token.equals(VRMLdatatype.string_Cylinder) ) {
						boolean bottom = Cylinder.bottom;
						float height = Cylinder.height;
						float radius = Cylinder.radius;
						boolean side   = Cylinder.side;
						boolean top   = Cylinder.top;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
										//Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_bottom) ) bottom = CheckBoolean();
										else if ( token.equals(VRMLdatatype.string_height) ) height = GetSingleFloat();
										else if ( token.equals(VRMLdatatype.string_radius) ) radius = GetSingleFloat();
										else if ( token.equals(VRMLdatatype.string_side) ) side = CheckBoolean();
										else if ( token.equals(VRMLdatatype.string_top) ) top = CheckBoolean();
										else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cylinder);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing Quote following parameter inside '" + VRMLdatatype.string_Cylinder);
									}
									else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Cylinder);
								} // end if equal sign follows token
								else FormatError("Missing '" + equalSign + "' following '" + token + "' inside '" + VRMLdatatype.string_Cylinder);
							} // got a word following Sphere node
							else FormatError("Missing property following " + VRMLdatatype.string_Sphere);
						} // end while not forwardSlash
						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Cylinder);
						Cylinder cylinder	= new Cylinder(bottom, height, radius, side, top);
						//SetNodeName(sphere, nodeName);
						shape.geometry = cylinder;
					} // end if Cylinder node
					else if ( token.equals(VRMLdatatype.string_Cone) ) {
						boolean bottom = Cone.bottom;
						float bottomRadius = Cone.bottomRadius;
						float height = Cone.height;
						boolean side   = Cone.side;
						while ( (tokenType = GetToken()) != forwardSlash) {
							if (tokenType == StreamTokenizer.TT_WORD) {
								token = st.sval;
								Write(" " + token);
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									//if ( (tokenType = GetToken()) == singleQuote) {
									//	Write(singleQuote);
									tokenType = GetToken();
									if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
										Write( (char)( (byte)tokenType ) );
										if ( token.equals(VRMLdatatype.string_bottom) ) bottom = CheckBoolean();
										else if ( token.equals(VRMLdatatype.string_bottomRadius) ) bottomRadius = GetSingleFloat();
										else if ( token.equals(VRMLdatatype.string_height) ) height = GetSingleFloat();
										else if ( token.equals(VRMLdatatype.string_side) ) side = CheckBoolean();
										else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cone);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
										else FormatError("Missing Quote following parameter inside '" + VRMLdatatype.string_Cone);
									}
									else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Cone);
								} // end if equal sign follows token
								else FormatError("Missing '" + equalSign + "' following '" + token + "' inside '" + VRMLdatatype.string_Cone);
							} // got a word following Sphere node
							else FormatError("Missing property following " + VRMLdatatype.string_Cone);
						} // end while not forwardSlash
						Write(forwardSlash);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Cone);
						Cone cone = new Cone(bottom, bottomRadius, height, side);
						//SetNodeName(sphere, nodeName);
						shape.geometry = cone;
					} // end if Cone node
					else if ( token.equals(VRMLdatatype.string_IndexedFaceSet) ) {
						PushStack( state );
						state = VRMLdatatype.IndexedFaceSet;
						IndexedFaceSet indexedFaceSet = new IndexedFaceSet();
						/*****************************/
						// Added to Dyn-X3D beta 05 to fix animated coordinates
						indexedFaceSet.parent = shape;

						/*****************************/
						shape.geometry = indexedFaceSet;
						indent += indentAmt;
						if ( appletParameters.creaseAngleDefault ) {
							indexedFaceSet.creaseAngle.setValue( appletParameters.creaseAngle );
						}
						IndexedFaceSetNode( shape, indexedFaceSet );
					} // end if token = IndexedFaceSet
					else if ( token.equals(VRMLdatatype.string_IndexedLineSet) ) {
						PushStack( state );
						state = VRMLdatatype.IndexedLineSet;
						IndexedLineSet indexedLineSet = new IndexedLineSet();
						shape.geometry = indexedLineSet;
						indent += indentAmt;
						IndexedLineSetNode( shape, indexedLineSet );
					} // end if token = IndexedFaceSet
					else if ( token.equals(VRMLdatatype.string_PointSet) ) {
						PushStack( state );
						state = VRMLdatatype.PointSet;
						PointSet pointSet = new PointSet();
						shape.geometry = pointSet;
						indent += indentAmt;
						PointSetNode( shape, pointSet );
					} // end if token = IndexedFaceSet
					else if ( token.equals(VRMLdatatype.string_Appearance) ) {
						PushStack( state );
						state = VRMLdatatype.Appearance;
						shape.appearance = AppearanceNode( shape );
					} // end if token = Appearance
					else FormatError("Illegal token '" + token + "' inside " + VRMLdatatype.string_Shape);
				} // tokenType == WORD
				else if (tokenType == forwardSlash) {
					if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
					Write(indent + leftAngleBracket + forwardSlash);
					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(token);
						if ( token.equals(VRMLdatatype.string_Shape) ) {
							state = PopStack();
							shapeDone = true;
						} // end getting ending Appearance node
						else FormatError("Expecting '" + VRMLdatatype.string_Shape + "'");
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' for " + VRMLdatatype.string_Shape);
					} // end getting Word token after </
					else FormatError("Missing word '" + VRMLdatatype.string_Shape + "'");
				} // end if forward slash for ending Shape
				else FormatError("Missing  token or forwardSlash following in " + VRMLdatatype.string_Shape);
			} // end if leftAngleBracker
			else FormatError("Missing '" + leftAngleBracket + "' inside " + VRMLdatatype.string_Shape);
		} // end while shapeDone != false
	} //end ShapeNode




	private int HeadParser() {
		tokenType = GetToken();
		if (tokenType == leftAngleBracket) {
			tokenType = GetToken();
			if (tokenType == forwardSlash) {
				if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
				Write(indent + leftAngleBracket + forwardSlash);
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(token);
					if ( token.equals(X3Ddatatype.string_head) ) X3D_head = false;
					else FormatError("Expecting '" + X3Ddatatype.string_head + "' after '" + leftAngleBracket + "'");
					if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
					else FormatError("Missing '" + rightAngleBracket + "' for " + token);
				}
 				else FormatError("Missing token word after '" + leftAngleBracket + forwardSlash + "'");
        	}
			else if (tokenType == exclimationPoint) {
				// comments
				//Write(indent + leftAngleBracket + " --comments-- ");
				/*
					while ( (tokenType = GetToken()) != rightAngleBracket ) {
						if (tokenType == equalSign) Write(equalSign);
						else if (tokenType == singleQuote) Write(singleQuote);
						else if (tokenType == doubleQuoteChar) Write(doubleQuoteChar);
						else if (tokenType == colon) Write(colon);
						else if (tokenType == periodChar) Write(periodChar);
						else if (tokenType == questionMark) Write(questionMark);
						else if (tokenType == underscoreChar) Write(underscoreChar);
						else if (tokenType == '-') Write('-');
						else if (tokenType == '#') Write('#');
						else if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							Write(token + " ");
						}
						else if ( tokenType == StreamTokenizer.TT_NUMBER) {
							int intNum = (int) st.nval;
							if (intNum == st.nval) Write(""+intNum);
							else Write(""+st.nval);
						}
						else Write( (char)( (byte)tokenType ) );
					}
					*/
				while ( (tokenType = GetToken()) != rightAngleBracket) {}
				//WriteLine("--" + rightAngleBracket);
			}
			else if (tokenType == StreamTokenizer.TT_WORD) {
				Write(indent + leftAngleBracket);
				token = st.sval;
				Write(token);
				if ( token.equals(X3Ddatatype.string_meta) ) {
					Write(" ");
					while ( (tokenType = GetToken()) != rightAngleBracket ) {
						if (tokenType == equalSign) Write(equalSign);
						else if (tokenType == singleQuote) Write(singleQuote);
						else if (tokenType == doubleQuoteChar) Write(doubleQuoteChar);
						else if (tokenType == colon) Write(colon);
						else if (tokenType == periodChar) Write(periodChar);
						else if (tokenType == questionMark) Write(questionMark);
						else if (tokenType == underscoreChar) Write(underscoreChar);
						else if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							Write(token + " ");
						}
						else if ( tokenType == StreamTokenizer.TT_NUMBER) {
							int intNum = (int) st.nval;
							if (intNum == st.nval) Write(""+intNum);
							else Write(""+st.nval);
						}
						else Write( (char)( (byte)tokenType ) );
					}
					WriteLine(rightAngleBracket);

/*

					tokenType = GetToken();
					if (tokenType == StreamTokenizer.TT_WORD) {
						token = st.sval;
						Write(" " + token);
						if ( (token.equals(X3Ddatatype.string_name)) || (token.equals(X3Ddatatype.string_content))) {
							if ( (tokenType = GetToken()) == equalSign) {
								Write(equalSign);
								//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
								tokenType = GetToken();
								if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
									Write( (char)( (byte)tokenType ) );
									tokenType = GetToken();
									if (tokenType == StreamTokenizer.TT_WORD) {
										token = st.sval;
										Write(token);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
											tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												Write(" " + token);
												if ( token.equals(X3Ddatatype.string_content) ) {
													if ( (tokenType = GetToken()) == equalSign) {
														Write(equalSign);
														if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
														boolean insideAngleBracket = false;
														while ( (tokenType = GetToken()) != singleQuote) {
															if ( tokenType == periodChar) Write(periodChar);
															else if ( tokenType == StreamTokenizer.TT_WORD) Write(st.sval);
															else if ( tokenType == StreamTokenizer.TT_NUMBER) {
																int intNum = (int) st.nval;
																if (intNum == st.nval) Write(""+intNum);
																else Write(""+st.nval);
															}
															else {
																Write( (char)tokenType );
																if (tokenType == leftAngleBracket) insideAngleBracket = true;
																else if (tokenType == rightAngleBracket) insideAngleBracket = false;
															}
															if (!insideAngleBracket) Write(" ");
														} // end while token != singlequote
														Write(singleQuote);
														if ( (tokenType = GetToken()) == forwardSlash) Write(forwardSlash);
														else FormatError("Missing '" + forwardSlash + "' inside " + X3Ddatatype.string_meta);
														if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
														else FormatError("Missing '" + rightAngleBracket + "' inside " + X3Ddatatype.string_meta);
													}
													else FormatError("Missing '" + equalSign + "' following " + X3Ddatatype.string_content + " in " + X3Ddatatype.string_meta);
												}
 												else FormatError("Missing '" + X3Ddatatype.string_content + "' in " + X3Ddatatype.string_meta);
											}
 											else FormatError("Missing token word after in " + X3Ddatatype.string_meta);
										}
										else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Cylinder);
									}
									else FormatError("Missing token word after '" + equalSign + "' in " + X3Ddatatype.string_meta);
								}
								else FormatError("Missing Quote following '" + equalSign + "' inside '" + VRMLdatatype.string_Cylinder);
							}
							else FormatError("Missing '" + equalSign + "' following " + X3Ddatatype.string_name + " in " + X3Ddatatype.string_meta);
						}
 						else FormatError("Missing '" + X3Ddatatype.string_name + "' or '" + X3Ddatatype.string_content +  "'in " + X3Ddatatype.string_meta);
					}
 					else FormatError("Missing token word after '" + leftAngleBracket + forwardSlash + "'");
 					*/
				} // end if "meta"
				else if ( token.equals(X3Ddatatype.string_component) ) {
					while ( (tokenType = GetToken()) != forwardSlash) {
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							Write(token);
							if ( token.equals(X3Ddatatype.string_name) ) {
								if ( (tokenType = GetToken()) == equalSign) {
									Write(equalSign);
									if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
									tokenType = GetToken();
									if (tokenType == StreamTokenizer.TT_WORD) {
										token = st.sval;
										Write(token);
									}
 									else FormatError("Missing token word after in " + X3Ddatatype.string_component);
								}
								else FormatError("Missing '" + equalSign + "' following " + X3Ddatatype.string_name + " in " + X3Ddatatype.string_component);
							}
 							else FormatError("Missing '" + X3Ddatatype.string_name + "' in " + X3Ddatatype.string_component);
						}
 						else FormatError("Missing token word after '" + leftAngleBracket + forwardSlash + "'");
					}
					Write(forwardSlash);
					if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
					else FormatError("Missing '" + rightAngleBracket + "' inside " + X3Ddatatype.string_meta);
				}
			} // end if word following leftAngleBracket
			/*
			else if (tokenType == exclimationPoint) {
				// comments
				while ( (tokenType = GetToken()) != rightAngleBracket) {}
			}
			*/
			else FormatError("Missing '" + forwardSlash + "' or token word after " + leftAngleBracket);
		} // end if leftAngleBracker
		return tokenType;
	} // HeadParser




	private int X3DParser() {
		// parses once an <X3D> tag is seen, looking for <head>, <Scene> or </x3d>
		String nodeName = null;
		tokenType = GetToken();
		if (tokenType == leftAngleBracket) {
			tokenType = GetToken();
			if (tokenType == forwardSlash) {
				if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
				Write(indent + leftAngleBracket + forwardSlash);
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(token);
					if ( token.equals(X3Ddatatype.string_X3D )  ) { X3D_X3Dtag = false;} // got </x3d> tag
					else FormatError("Expecting X3D Headers");
					if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
					else FormatError("Missing '" + rightAngleBracket + "' for " + token);

				} // end getting Word token after </
				else FormatError("Missing word in X3D Header");
         	}
			else if (tokenType == StreamTokenizer.TT_WORD) {
				Write(indent + leftAngleBracket);
				token = st.sval;
				Write(token);
				if ( token.equals(X3Ddatatype.string_X3D) ) {
					indent += indentAmt;
					while ( (tokenType = GetToken()) != rightAngleBracket) {
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							Write(" " + token);
						}
						if (tokenType == StreamTokenizer.TT_NUMBER) {
							double number = st.nval;
							Write(" " + number);
						}
						else if ( tokenType == equalSign) Write(equalSign);
					}
					WriteLine(rightAngleBracket);
				}
				else if ( token.equals(X3Ddatatype.string_head) ) {
					if ( (tokenType = GetToken()) == rightAngleBracket) {
						WriteLine(rightAngleBracket);
						indent += indentAmt;
						X3D_head = true; // set true, got the <head> tag, reset false when getting </head>
					}
					else FormatError("Missing '" + rightAngleBracket + "' in " + X3Ddatatype.string_head);
				}
				else if ( token.equals(X3Ddatatype.string_Scene) ) {
					if ( (tokenType = GetToken()) == rightAngleBracket) {
						WriteLine(rightAngleBracket);
						indent += indentAmt;
						X3D_Scene = true; // set true, got the <Scene> tag
					}
					else FormatError("Missing '" + rightAngleBracket + "' in " + X3Ddatatype.string_Scene);
				}
				else FormatError("Missing 'X3D', 'head' or 'Scene' word after '" + leftAngleBracket + "'");
			} // end word after leftAngleBracket
			else if (tokenType == exclimationPoint) {
				// comments
				while ( (tokenType = GetToken()) != rightAngleBracket) {}
			}
			else FormatError("Missing token word after '" + leftAngleBracket + "'");
		} // end beginning with leftAngleBracket
		//else FormatError("Missing '" + leftAngleBracket + "'");
		return tokenType;
	} // X3DParser




	/* read the initial <?xml ... > tag */
	private int X3DfileParser() {
		String nodeName = null;
		tokenType = GetToken();
		if (tokenType == leftAngleBracket) {
			tokenType = GetToken();
			if (tokenType == questionMark) {
				Write(indent + leftAngleBracket + questionMark);
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					if ( token.equals(X3Ddatatype.string_xml) ) {
						Write(X3Ddatatype.string_xml);
						while ( (tokenType = GetToken()) != questionMark) {
						} // end while not questionMark
						Write(questionMark);
						if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
						else FormatError("Missing '" + rightAngleBracket + "' in xml tag");
					} // got word which should be "xml"
					else FormatError("Missing '" + X3Ddatatype.string_xml + "' token following <?");
				} // got word which should be "xml"
				else FormatError("Missing word token following <?");
			} // end if <?xml ... ?>
			else if (tokenType == StreamTokenizer.TT_WORD) {
				Write(leftAngleBracket);
				token = st.sval;
				Write(token);
				if ( token.equals(X3Ddatatype.string_X3D) ) {
					// Got the <X3D> tag
					indent += indentAmt;
					while ( (tokenType = GetToken()) != rightAngleBracket) {
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							Write(" " + token);
							while ( (tokenType = GetToken()) == colon) {
								Write(colon);
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_WORD) Write(st.sval);
							}
							if ( tokenType == equalSign) {
								Write(equalSign);
								if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
								tokenType = GetToken();
								//if ( tokenType == StreamTokenizer.TT_WORD) Write(st.sval);
								if ( tokenType == StreamTokenizer.TT_WORD) Write(st.sval);
								else if ( tokenType == StreamTokenizer.TT_NUMBER) {
									//int intNum = (int) st.nval;
									//if (intNum == st.nval) Write(""+intNum);
									//else Write(""+st.nval);
									Write(""+st.nval);
								}
								//else Write( (char)tokenType );
								else if ( tokenType == leftAngleBracket) {
									Write(leftAngleBracket);
									while ( (tokenType = GetToken()) != rightAngleBracket) {
										if ( tokenType == StreamTokenizer.TT_WORD) Write(st.sval);
										else if ( tokenType == StreamTokenizer.TT_NUMBER) {
											int intNum = (int) st.nval;
											if (intNum == st.nval) Write(""+intNum);
											else Write(""+st.nval);
										}
										else Write( (char)tokenType );
									}
									Write(rightAngleBracket);
								}
								else FormatError("Illegal tokenType '" + tokenType + "' following '" + equalSign + "' in <?xml");
								//Write(singleQuote);
								if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
							}
						}
						else if (tokenType == StreamTokenizer.TT_NUMBER) {
							double number = st.nval;
							Write(" " + number);
						}
						else if (tokenType == forwardSlash) {
							Write(forwardSlash);
						}
						else FormatError("Illegal tokenType '" + tokenType + "' following <?xml");
						//WriteLine();
					}
					WriteLine(rightAngleBracket);
					X3D_X3Dtag = true;
				}
				else {
					// may have gotten a <!DOCTYPE...> tag
					while ( (tokenType = GetToken()) != rightAngleBracket) {}
					WriteLine(rightAngleBracket);
				}
			} // end word after leftAngleBracket
			else {
				Write(leftAngleBracket);
				while ( (tokenType = GetToken()) != rightAngleBracket) {}
				WriteLine(rightAngleBracket);
			}
		} // end beginning with leftAngleBracket
		else if (tokenType != StreamTokenizer.TT_EOF) FormatError("Missing '" + leftAngleBracket + "'"); // need to check for EOL
		return tokenType;
	} // X3DfileParser




	private int NodeParser() {
		String nodeName = null;
		tokenType = GetToken();
		if (tokenType == leftAngleBracket) {
			tokenType = GetToken();
			if (tokenType == forwardSlash) {
				if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
				Write(indent + leftAngleBracket + forwardSlash);
				tokenType = GetToken();
				if (tokenType == StreamTokenizer.TT_WORD) {
					token = st.sval;
					Write(token);
					if ( token.equals(VRMLdatatype.string_Transform) ) {
						currentNode = currentTransform.parent;
						currentTransform = null;
						if ( currentNode.datatype == VRMLdatatype.Transform) currentTransform = (Transform) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Anchor) currentAnchor = (Anchor) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Group) currentGroup = (Group) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Billboard) currentBillboard = (Billboard) currentNode;
					} // end getting ending Transform node
					else if ( token.equals(VRMLdatatype.string_Anchor) ) {
						currentNode = currentAnchor.parent;
						currentGroup = null;
						if ( currentNode.datatype == VRMLdatatype.Transform) currentTransform = (Transform) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Anchor) currentAnchor = (Anchor) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Group) currentGroup = (Group) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Billboard) currentBillboard = (Billboard) currentNode;
					} // end getting ending Anchor node
					else if ( token.equals(VRMLdatatype.string_Group) ) {
						currentNode = currentGroup.parent;
						currentGroup = null;
						if ( currentNode.datatype == VRMLdatatype.Transform) currentTransform = (Transform) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Anchor) currentAnchor = (Anchor) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Group) currentGroup = (Group) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Billboard) currentBillboard = (Billboard) currentNode;
					} // end getting ending Group node
					else if ( token.equals(VRMLdatatype.string_Billboard) ) {
						currentNode = currentBillboard.parent;
						currentBillboard = null;
						if ( currentNode.datatype == VRMLdatatype.Transform) currentTransform = (Transform) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Anchor) currentAnchor = (Anchor) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Group) currentGroup = (Group) currentNode;
						else if (currentNode.datatype == VRMLdatatype.Billboard) currentBillboard = (Billboard) currentNode;
					} // end getting ending Billboard node
					else if ( token.equals(X3Ddatatype.string_Scene) ) { X3D_Scene = false;}
					else FormatError("Illegal token '" + token + "'");
					if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
					else FormatError("Missing '" + rightAngleBracket + "' for " + token);

				} // end getting Word token after </
				else FormatError("Missing proper word after '</' ");
         	} // end forward slash
			else if (tokenType == StreamTokenizer.TT_WORD) {
				Write(indent + leftAngleBracket);
				token = st.sval;
				Write(token);
				//switch (state) {
					/********* Node, children *********/
					//case VRMLdatatype.SFNode:
					//case VRMLdatatype.Transform:
						if ( token.equals(VRMLdatatype.string_Transform) ) {
							PushStack( state );
							state = VRMLdatatype.Transform;
							currentTransform = TransformNode();
							if (currentTransform != null) {
								AddChild (currentNode, currentTransform);
								currentNode = currentTransform;
							}
						} // end Transform
						else if ( token.equals(VRMLdatatype.string_Viewpoint) ) {
							PushStack( state );
							state = VRMLdatatype.Viewpoint;
							Viewpoint viewpoint = ViewpointNode();
							if (viewpoint != null) {
								AddChild (currentNode, viewpoint);
								viewpointLink.nextViewpoint = viewpoint;
								viewpointLink = viewpoint;
							}
						} // end Viewpoint
						else if ( token.equals(VRMLdatatype.string_Group) ) {
							PushStack( state );
							state = VRMLdatatype.Group;
							currentGroup = GroupNode();
							if (currentGroup != null) {
								AddChild (currentNode, currentGroup);
								currentNode = currentGroup;
							}
						} // end Group
						else if ( token.equals(VRMLdatatype.string_Billboard) ) {
							PushStack( state );
							state = VRMLdatatype.Billboard;
							currentBillboard = BillboardNode();
							if (currentBillboard != null) {
								AddChild (currentNode, currentBillboard);
								currentNode = currentBillboard;
							}
						} // end Billboard
						else if ( token.equals(VRMLdatatype.string_DirectionalLight) ) {
							PushStack( state );
							state = VRMLdatatype.DirectionalLight;
							DirectionalLight dirLight = DirectionalLightNode();
							if (dirLight != null) {
								AddChild (currentNode, dirLight);
								currentLight.nextLight = dirLight;
								currentLight = dirLight;
							}
						} // end DirectionalLight
						else if ( token.equals(VRMLdatatype.string_PointLight) ) {
							PushStack( state );
							state = VRMLdatatype.PointLight;
							PointLight pointLight = PointLightNode();
							if (pointLight != null) {
								AddChild (currentNode, pointLight);
								currentLight.nextLight = pointLight;
								currentLight = pointLight;
							}
						} // end PointLight
						else if ( token.equals(VRMLdatatype.string_SpotLight) ) {
							PushStack( state );
							state = VRMLdatatype.SpotLight;
							SpotLight spotLight = SpotLightNode();
							if (spotLight != null) {
								AddChild (currentNode, spotLight);
								currentLight.nextLight = spotLight;
								currentLight = spotLight;
							}
						} // end SpotLight
						else if ( token.equals(VRMLdatatype.string_ColorInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.ColorInterpolator;
							ColorInterpolator colorInterpolator = new ColorInterpolator();
							interpolatorLink.next = colorInterpolator;
							colorInterpolator.prev = interpolatorLink;
							interpolatorLink = colorInterpolator;
							ColorInterpolatorNode( colorInterpolator );
						} // end ColorInterpolator
						else if ( token.equals(VRMLdatatype.string_PositionInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.PositionInterpolator;
							PositionInterpolator positionInterpolator = new PositionInterpolator();
							interpolatorLink.next = positionInterpolator;
							positionInterpolator.prev = interpolatorLink;
							interpolatorLink = positionInterpolator;
							PositionInterpolatorNode( positionInterpolator );
						} // end PositionInterpolator
						else if ( token.equals(VRMLdatatype.string_OrientationInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.OrientationInterpolator;
							OrientationInterpolator orientationInterpolator = new OrientationInterpolator();
							interpolatorLink.next = orientationInterpolator;
							orientationInterpolator.prev = interpolatorLink;
							interpolatorLink = orientationInterpolator;
							OrientationInterpolatorNode( orientationInterpolator );
						} // end OrientationInterpolator
						else if ( token.equals(VRMLdatatype.string_CoordinateInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.CoordinateInterpolator;
							CoordinateInterpolator coordinateInterpolator = new CoordinateInterpolator();
							interpolatorLink.next = coordinateInterpolator;
							coordinateInterpolator.prev = interpolatorLink;
							interpolatorLink = coordinateInterpolator;
							CoordinateInterpolatorNode( coordinateInterpolator );
						} // end CoordinateInterpolator
						else if ( token.equals(VRMLdatatype.string_ScalarInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.ScalarInterpolator;
							ScalarInterpolator scalarInterpolator = new ScalarInterpolator();
							interpolatorLink.next = scalarInterpolator;
							scalarInterpolator.prev = interpolatorLink;
							interpolatorLink = scalarInterpolator;
							ScalarInterpolatorNode( scalarInterpolator );
						} // end ScalarInterpolator
						else if ( token.equals(VRMLdatatype.string_NormalInterpolator) ) {
							PushStack( state );
							state = VRMLdatatype.NormalInterpolator;
							NormalInterpolator normalInterpolator = new NormalInterpolator();
							interpolatorLink.next = normalInterpolator;
							normalInterpolator.prev = interpolatorLink;
							interpolatorLink = normalInterpolator;
							NormalInterpolatorNode( normalInterpolator );
						} // end NormalInterpolator
						else if ( token.equals(VRMLdatatype.string_TouchSensor) ) {
							PushStack( state );
							state = VRMLdatatype.TouchSensor;
							TouchSensor touchSensor = new TouchSensor();
							sensorLink.next = touchSensor;
							touchSensor.prev = sensorLink;
							sensorLink = touchSensor;
							currentNode.touchSensor = touchSensor;
							TouchSensorNode( touchSensor );
						} // end TouchSensor
						else if ( token.equals(VRMLdatatype.string_TimeSensor) ) {
							PushStack( state );
							state = VRMLdatatype.TimeSensor;
							TimeSensor timeSensor = new TimeSensor();
							sensorLink.next = timeSensor;
							timeSensor.prev = sensorLink;
							sensorLink = timeSensor;
							TimeSensorNode(timeSensor);
						} // end TimeSensor
						else if ( token.equals(VRMLdatatype.string_Anchor) ) {
							PushStack( state );
							state = VRMLdatatype.Anchor;
							currentAnchor = AnchorNode();
							if (currentAnchor != null) {
								AddChild (currentNode, currentAnchor);
								currentNode = currentAnchor;
							}
						} // end Anchor
						else if ( token.equals(VRMLdatatype.string_ROUTE) ) {
							PushStack( state );
							state = VRMLdatatype.ROUTE;
							ROUTEnode();
						} // end ROUTE
						else if ( token.equals(VRMLdatatype.string_Shape) ) {
							PushStack( state );
							state = VRMLdatatype.Shape;
							Shape shape = new Shape();
							AddChild (currentNode, shape);  // Node in case Shape is alone or attached to Transform, Group, Billboard, etc.
							shapeLink.nextShape = shape; // used to quickly find shapes in the mouse rollovers, interactivity.
							shapeLink = shape;
							//while ( (tokenType = GetToken()) != rightAngleBracket) {
							while ( (tokenType = GetToken()) == StreamTokenizer.TT_WORD) {
								//if (tokenType == StreamTokenizer.TT_WORD) {
									token = st.sval;
									Write(" " + token);
									if ( (tokenType = GetToken()) == equalSign) {
										Write(equalSign);
										//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
										tokenType = GetToken();
										if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) {
											Write( (char)( (byte)tokenType ) );
											if ( token.equals(VRMLdatatype.string_USE) ) {
												tokenType = GetToken();
												if (tokenType == StreamTokenizer.TT_WORD) {
													token = st.sval;
													Write(token);
													SFNode foundNode = SetUSEtoken(shape, token);
													if (foundNode != null) {
														Shape foundShape = (Shape) foundNode;
														shape.appearance = foundShape.appearance;
														shape.geometry = foundShape.geometry;
													}
												}
												else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word");
											}
											else if ( token.equals(VRMLdatatype.string_DEF) ) {
												tokenType = GetToken();
												if (tokenType == StreamTokenizer.TT_WORD) {
													token = st.sval;
													Write(token);
													SetNodeName (shape, token);
												}
												else FormatError(VRMLdatatype.string_USE + " = '" + token + "' not a legit word");
											}
											else FormatError("illegal/unsupported node '" + token + "' after " + VRMLdatatype.string_USE + " or " + VRMLdatatype.string_DEF);
											//if ( (tokenType = GetToken()) == singleQuote) Write(singleQuote);
											tokenType = GetToken();
											if ( (tokenType == singleQuote) || (tokenType == doubleQuoteChar) ) Write( (char)( (byte)tokenType ) );
											else FormatError("Missing quote following parameters in " + VRMLdatatype.string_USE + " or " + VRMLdatatype.string_DEF);
										}
										else FormatError("Missing quote following " + equalSign + " in " + VRMLdatatype.string_USE + " or " + VRMLdatatype.string_DEF);
									} // got equal sign
									else FormatError("Missing '" + equalSign + "' following " + token + " after " + VRMLdatatype.string_USE + " or " + VRMLdatatype.string_DEF);
								//}
							}
							if (tokenType == forwardSlash) {
								Write(forwardSlash);
								if ( (tokenType = GetToken()) == rightAngleBracket) WriteLine(rightAngleBracket);
								else FormatError("Missing " + rightAngleBracket + " in " + VRMLdatatype.string_Shape);
							}
							else if ( tokenType == rightAngleBracket) {
								WriteLine(rightAngleBracket);
								indent += indentAmt;
								ShapeNode(shape);
							}
							else FormatError("Missing " + rightAngleBracket + " in " + VRMLdatatype.string_Shape);
						} // else if token = Shape
						else if ( token.equals(VRMLdatatype.string_NavigationInfo) ) {
							PushStack( state );
							state = VRMLdatatype.NavigationInfo;
							NavigationInfoNode();
						} // end NavigationInfo
						else if ( token.equals(VRMLdatatype.string_WorldInfo) ) {
							PushStack( state );
							state = VRMLdatatype.WorldInfo;
							WorldInfoNode();
						} // end NavigationInfo
						else if ( token.equals(VRMLdatatype.string_Background) ) {
							PushStack( state );
							state = VRMLdatatype.Background;
							BackgroundNode();
						} // end Background
						else if ( token.equals(VRMLdatatype.string_Fog) ) {
							PushStack( state );
							state = VRMLdatatype.Fog;
							FogNode();
						} // end Background
						else  FormatError("unknown word token " + token);
					//break;
					//default:
					//break;
				//} // end switch statement
			} // end if WORD follows leftAngleBracket
			else if (tokenType == exclimationPoint) {
				// comments
				while ( (tokenType = GetToken()) != rightAngleBracket) {}
			}
			else {
				// comments
				FormatError("Unknown token '" + tokenType + "' after <");
			}
		} // end if leftAngleBrack
		else {
		if (tokenType == StreamTokenizer.TT_WORD) {
System.out.println();
System.out.println("Old VRML parser");
System.out.println();
			token = st.sval;
			nodeName = null;

			if (token.equals(VRMLdatatype.string_DEF) ) {
				nodeName = GetNodeName();
			}

			switch (state) {

				/********* Node, children *********/
				/*
				case VRMLdatatype.SFNode:
				case VRMLdatatype.children:
					if ( token.equals(VRMLdatatype.string_Transform) ) {
						//if (nodeName == null) {
						//	Write(indent);
						//}
						Write(VRMLdatatype.string_Transform + " "); indent += indentAmt;
						//if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Transform;
							currentTransform = new Transform();
							SetNodeName (currentTransform, nodeName);
							AddChild (currentNode, currentTransform);
							currentNode = currentTransform;
							//WriteLine();
						//}
						//else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Transform);
					} // else if token = Transform

					else if ( token.equals(VRMLdatatype.string_Shape) ) {
						if (nodeName == null) {
							Write(indent);
						}
						Write(VRMLdatatype.string_Shape); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Shape;
							currentShape = new Shape();
							SetNodeName (currentShape, nodeName);
							AddChild (currentNode, currentShape);  // Node in case Shape is alone or attached to Transform, Group, Billboard, etc.
							shapeLink.nextShape = currentShape; // used to quickly find shapes in the mouse rollovers, interactivity.
							shapeLink = currentShape;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Shape);
					} // else if token = Shape

					else if ( token.equals(VRMLdatatype.string_Viewpoint) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_Viewpoint + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Viewpoint;
							currentViewpoint = new Viewpoint();
							SetNodeName (currentViewpoint, nodeName);
							AddChild (currentNode, currentViewpoint);
							viewpointLink.nextViewpoint = currentViewpoint;
							viewpointLink = currentViewpoint;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Viewpoint);
					} // else if token = Viewpoint
					else if ( token.equals(VRMLdatatype.string_DirectionalLight) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_DirectionalLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.DirectionalLight;
							currentDirectionalLight = new DirectionalLight();
							SetNodeName (currentDirectionalLight, nodeName);
							AddChild (currentNode, currentDirectionalLight);
							currentLight.nextLight = currentDirectionalLight;
							currentLight = currentDirectionalLight;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_DirectionalLight);
					} // else if token = DirectionalLight

					else if ( token.equals(VRMLdatatype.string_PointLight) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_PointLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.PointLight;
							currentPointLight = new PointLight();
							SetNodeName (currentPointLight, nodeName);
							AddChild (currentNode, currentPointLight);
							currentLight.nextLight = currentPointLight;
							currentLight = currentPointLight;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PointLight);
					} // else if token = PointLight

					else if ( token.equals(VRMLdatatype.string_SpotLight) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_SpotLight + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.SpotLight;
							currentSpotLight = new SpotLight();
							SetNodeName (currentSpotLight, nodeName);
							AddChild (currentNode, currentSpotLight);
							currentLight.nextLight = currentSpotLight;
							currentLight = currentSpotLight;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_SpotLight);
					} // else if token = SpotLight

					else if ( token.equals(VRMLdatatype.string_TimeSensor) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_TimeSensor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.TimeSensor;
							currentTimeSensor = new TimeSensor();
							SetNodeName (currentTimeSensor, nodeName);
							sensorLink.next = currentTimeSensor;
							currentTimeSensor.prev = sensorLink;
							sensorLink = currentTimeSensor;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TimeSensor);
					} // else if token = TimeSensor
					else if ( token.equals(VRMLdatatype.string_OrientationInterpolator) ) {
						Write(VRMLdatatype.string_OrientationInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.OrientationInterpolator;
							currentOrientationInterpolator = new OrientationInterpolator();
							SetNodeName(currentOrientationInterpolator, nodeName);
							interpolatorLink.next = currentOrientationInterpolator;
							currentOrientationInterpolator.prev = interpolatorLink;
							interpolatorLink = currentOrientationInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_OrientationInterpolator);
					} // else if token = OrientationInterpolator
					else if ( token.equals(VRMLdatatype.string_PositionInterpolator) ) {
						Write(VRMLdatatype.string_PositionInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.PositionInterpolator;
							currentPositionInterpolator = new PositionInterpolator();
							SetNodeName(currentPositionInterpolator, nodeName);
							interpolatorLink.next = currentPositionInterpolator;
							currentPositionInterpolator.prev = interpolatorLink;
							interpolatorLink = currentPositionInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PositionInterpolator);
					} // else if token = PositionInterpolator

					else if ( token.equals(VRMLdatatype.string_CoordinateInterpolator) ) {
						Write(VRMLdatatype.string_CoordinateInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.CoordinateInterpolator;
							currentCoordinateInterpolator = new CoordinateInterpolator();
							SetNodeName(currentCoordinateInterpolator, nodeName);
							interpolatorLink.next = currentCoordinateInterpolator;
							currentCoordinateInterpolator.prev = interpolatorLink;
							interpolatorLink = currentCoordinateInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_CoordinateInterpolator);
					} // else if token = CoordinateInterpolator
					else if ( token.equals(VRMLdatatype.string_ColorInterpolator) ) {
						Write(VRMLdatatype.string_ColorInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.ColorInterpolator;
							currentColorInterpolator = new ColorInterpolator();
							SetNodeName(currentColorInterpolator, nodeName);
							interpolatorLink.next = currentColorInterpolator;
							currentColorInterpolator.prev = interpolatorLink;
							interpolatorLink = currentColorInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ColorInterpolator);
					} // else if token = ColorInterpolator

					else if ( token.equals(VRMLdatatype.string_ScalarInterpolator) ) {
						Write(VRMLdatatype.string_ScalarInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.ScalarInterpolator;
							currentScalarInterpolator = new ScalarInterpolator();
							SetNodeName(currentScalarInterpolator, nodeName);
							interpolatorLink.next = currentScalarInterpolator;
							currentScalarInterpolator.prev = interpolatorLink;
							interpolatorLink = currentScalarInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ScalarInterpolator);
					} // else if token = ScalarInterpolator

					else if ( token.equals(VRMLdatatype.string_NormalInterpolator) ) {
						Write(VRMLdatatype.string_NormalInterpolator + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.NormalInterpolator;
							currentNormalInterpolator = new NormalInterpolator();
							SetNodeName(currentNormalInterpolator, nodeName);
							interpolatorLink.next = currentNormalInterpolator;
							currentNormalInterpolator.prev = interpolatorLink;
							interpolatorLink = currentNormalInterpolator;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_NormalInterpolator);
					} // else if token = NormalInterpolator


					else if ( token.equals(VRMLdatatype.string_ROUTE) ) {
						CreateRoute();
					} // else if token = ROUTE

					else if ( token.equals(VRMLdatatype.string_TouchSensor) ) {
						if (nodeName == null) Write(indent);
						Write (VRMLdatatype.string_TouchSensor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.TouchSensor;
							currentTouchSensor = new TouchSensor();
							SetNodeName(currentTouchSensor, nodeName);
							sensorLink.next = currentTouchSensor;
							currentTouchSensor.prev = sensorLink;
							sensorLink = currentTouchSensor;
							currentNode.touchSensor = currentTouchSensor;
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TouchSensor);
					} // else if token = TouchSensor

					else if ( token.equals(VRMLdatatype.string_Anchor) ) {
						Write(VRMLdatatype.string_Anchor + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Anchor;
							currentAnchor = new Anchor();
							SetNodeName(currentAnchor, nodeName);
							currentAnchor.matrix4x4.setIdentityMatrix(); //set just as a precaution
							AddChild (currentNode, currentAnchor);
							currentNode = currentAnchor;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Anchor);
					} // else if token = Anchor

					if ( token.equals(VRMLdatatype.string_Billboard) ) {
					//else if ( token.equals(VRMLdatatype.string_Billboard) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_Billboard + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Billboard;
							currentBillboard = new Billboard();
							//currentBillboard.matrix4x4.setIdentityMatrix();  // set in FrameGen
							SetNodeName(currentBillboard, nodeName);
							AddChild (currentNode, currentBillboard);
							currentNode = currentBillboard;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Billboard);
					} // else if token = Billboard

					else if ( token.equals(VRMLdatatype.string_Group) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_Group + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Group;
							currentGroup = new Group();
							currentGroup.matrix4x4.setIdentityMatrix(); //set here as a pre-caution
							SetNodeName(currentGroup, nodeName);
							AddChild (currentNode, currentGroup);
							currentNode = currentGroup;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Group);
					} // else if token = Group

					else if ( token.equals(VRMLdatatype.string_Background) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_Background + " "); indent += indentAmt;
						background.created  = true; // override applet parameters values, use NavInfo values
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.Background;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Background);
					} // else if token = Background
					else if ( token.equals(VRMLdatatype.string_NavigationInfo) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_NavigationInfo + " "); indent += indentAmt;
						navigationInfo.created  = true; // override applet parameters values, use NavInfo values
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.NavigationInfo;
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_NavigationInfo);
					} // else if token = NavigationInfo
					else if ( token.equals(VRMLdatatype.string_WorldInfo) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_WorldInfo + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							PushStack( state );
							state = VRMLdatatype.WorldInfo;
							worldInfo = new WorldInfo();
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_WorldInfo);
					} // else if token = WorldInfo

					else if ( token.equals(VRMLdatatype.string_Fog) ) {
						if (nodeName == null) Write(indent);
						Write(VRMLdatatype.string_Fog + " "); indent += indentAmt;
						if ( CheckChar(leftBraceChar) ) {
							Write(indent + "; not currently supported ");
							PushStack( state );
							state = VRMLdatatype.Fog;
							currentFog = new Fog();
							//SetNodeName(currentFog, nodeName);
							WriteLine();
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Fog);
					} // else if token = Fog

					else FormatError("node: '" + token + "' misplaced, not currently implemented or illegal.");
				break; // end case Node or children
				*/



				/********* TimeSensor *********/
				/*
				case VRMLdatatype.TimeSensor:
					if ( token.equals(VRMLdatatype.string_cycleInterval) ) {
						Write(indent + VRMLdatatype.string_cycleInterval);
						currentTimeSensor.cycleInterval.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_loop) ) {
						Write(indent + VRMLdatatype.string_loop);
						currentTimeSensor.loop.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_enabled) ) {
						Write(indent + VRMLdatatype.string_enabled);
						currentTimeSensor.enabled.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_startTime) ) {
						Write(indent + VRMLdatatype.string_startTime);
						currentTimeSensor.startTime.setValue( GetTimeValue() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_stopTime) ) {
						Write(indent + VRMLdatatype.string_stopTime);
						currentTimeSensor.stopTime.setValue( GetTimeValue() );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TimeSensor);
				break; // end case TimeSensor
				*/


				/********* TouchSensor *********/
				/*
				case VRMLdatatype.TouchSensor:
					if ( token.equals(VRMLdatatype.string_enabled) ) {
						Write(indent + VRMLdatatype.string_enabled);
						currentTouchSensor.enabled.setValue( CheckBoolean() );
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TouchSensor);
				break; // end case TouchSensor
				*/


				/********* Viewpoint *********/
				/*
				case VRMLdatatype.Viewpoint:
					if ( token.equals(VRMLdatatype.string_position) ) {
						Write(indent + VRMLdatatype.string_position);
						currentViewpoint.position.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_orientation) ) {
						Write(indent + VRMLdatatype.string_orientation);
						currentViewpoint.orientation.setValue( GetFloatValues(4) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_fieldOfView) ) {
						Write(indent + VRMLdatatype.string_fieldOfView);
						currentViewpoint.setFieldOfView( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_jump) ) {
						Write(indent + VRMLdatatype.string_jump);
						currentViewpoint.jump.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_description) ) {
						Write(indent + VRMLdatatype.string_description + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							token = st.sval;
							currentViewpoint.description.setValue( token );
							WriteLine(doubleQuoteChar + token + doubleQuoteChar);
						}
						else FormatError(" in " + VRMLdatatype.string_Viewpoint + " " + VRMLdatatype.string_description + " node");
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Viewpoint);
				break; // end case Viewpoint
				*/

				/********* DirectionalLight *********/
				/*
				case VRMLdatatype.DirectionalLight:
					if ( token.equals(VRMLdatatype.string_direction) ) {
						Write(indent + VRMLdatatype.string_direction);
						currentDirectionalLight.direction.setValue( GetFloatValues(3) );
						currentDirectionalLight.directionNormalized = MathOps.NormalizeVector( currentDirectionalLight.direction.getValue() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color);
						currentDirectionalLight.color.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) {
						Write(indent + VRMLdatatype.string_intensity);
						currentDirectionalLight.intensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) {
						Write(indent + VRMLdatatype.string_ambientIntensity);
						currentDirectionalLight.ambientIntensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) {
						Write(indent + VRMLdatatype.string_on);
						currentDirectionalLight.on.setValue( CheckBoolean() );
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_DirectionalLight);
				break; // end case DirectionalLight
				*/



				/********* PointLight *********/
				/*
				case VRMLdatatype.PointLight:
					if ( token.equals(VRMLdatatype.string_location) ) {
						Write(indent + VRMLdatatype.string_location);
						currentPointLight.location.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_attenuation) ) {
						Write(indent + VRMLdatatype.string_attenuation);
						currentPointLight.attenuation.setValue( GetFloatValues(3) );
						if (
							(currentPointLight.attenuation.vec3s[0] == 0) &&
							(currentPointLight.attenuation.vec3s[1] == 0) &&
							(currentPointLight.attenuation.vec3s[2] == 0) )
								currentPointLight.attenuation.vec3s[0] = 1; // VRML rule
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color);
						currentPointLight.color.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) {
						Write(indent + VRMLdatatype.string_intensity);
						currentPointLight.intensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) {
						Write(indent + VRMLdatatype.string_ambientIntensity);
						currentPointLight.ambientIntensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) {
						Write(indent + VRMLdatatype.string_on);
						currentPointLight.on.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_radius) ) {
						Write(indent + VRMLdatatype.string_radius);
						currentPointLight.radius.setValue( GetSingleFloat() );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PointLight);
				break; // end case PointLight
				*/



				/********* SpotLight *********/
				/*
				case VRMLdatatype.SpotLight:
					if ( token.equals(VRMLdatatype.string_location) ) {
						Write(indent + VRMLdatatype.string_location);
						currentSpotLight.location.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_direction) ) {
						Write(indent + VRMLdatatype.string_direction);
						currentSpotLight.direction.setValue( GetFloatValues(3) );
						currentSpotLight.directionNormalized = MathOps.NormalizeVector( currentSpotLight.direction.getValue() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_attenuation) ) {
						Write(indent + VRMLdatatype.string_attenuation);
						currentSpotLight.attenuation.setValue( GetFloatValues(3) );
						if (
							(currentSpotLight.attenuation.vec3s[0] == 0) &&
							(currentSpotLight.attenuation.vec3s[1] == 0) &&
							(currentSpotLight.attenuation.vec3s[2] == 0) )
								currentSpotLight.attenuation.vec3s[0] = 1; // VRML rule
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color);
						currentSpotLight.color.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_intensity) ) {
						Write(indent + VRMLdatatype.string_intensity);
						currentSpotLight.intensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) {
						Write(indent + VRMLdatatype.string_ambientIntensity);
						currentSpotLight.ambientIntensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_on) ) {
						Write(indent + VRMLdatatype.string_on);
						currentSpotLight.on.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_radius) ) {
						Write(indent + VRMLdatatype.string_radius);
						currentSpotLight.radius.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_beamWidth) ) {
						Write(indent + VRMLdatatype.string_beamWidth);
						currentSpotLight.beamWidth.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_cutOffAngle) ) {
						Write(indent + VRMLdatatype.string_cutOffAngle);
						currentSpotLight.cutOffAngle.setValue( GetSingleFloat() );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_SpotLight);
				break; // end case SpotLight
				*/



				/********* Transform *********/
				/*
				case VRMLdatatype.Transform:
					if ( token.equals(VRMLdatatype.string_children) ) {
						Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Transform);
					}
					else
					if ( token.equals(VRMLdatatype.string_translation) ) {
						Write(indent + VRMLdatatype.string_translation);
						currentTransform.translation.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_rotation) ) {
						Write(indent + VRMLdatatype.string_rotation);
						currentTransform.rotation.setValue( GetFloatValues(4) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_center) ) {
						Write(indent + VRMLdatatype.string_center);
						currentTransform.center.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scale) ) {
						Write(indent + VRMLdatatype.string_scale);
						currentTransform.scale.setValue( GetFloatValues(3) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scaleOrientation) ) {
						Write(indent + VRMLdatatype.string_scaleOrientation);
						currentTransform.scaleOrientation.setValue( GetFloatValues(4) );
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
						Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentTransform.bboxCenter.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
						Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentTransform.bboxSize.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						//WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ROUTE) ) {
						CreateRoute();
					} // else if token = ROUTE
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Transform);
				break; // end case Transform
				*/



				/********* Shape *********/
				/*
				case VRMLdatatype.Shape:
					if ( token.equals(VRMLdatatype.string_appearance) ) {
						Write(indent + VRMLdatatype.string_appearance  + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Appearance) ) {
									Write(VRMLdatatype.string_Appearance  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Appearance;
										currentAppearance	= new Appearance();
										SetNodeName(currentAppearance, nodeName);
										currentShape.appearance = currentAppearance;
										WriteLine();
									}
									else FormatError("Missing '{' following " + VRMLdatatype.string_Appearance);
								} // end if token == Appearance
								else FormatError("Missing '" + VRMLdatatype.string_Appearance + "' following " + VRMLdatatype.string_appearance);
							} // end if token != USE
						} // end if token == word
						else FormatError("Missing word token following " + VRMLdatatype.string_appearance);
					} // end Shape.appearance

					else if ( token.equals(VRMLdatatype.string_geometry) ) {
						Write(indent + VRMLdatatype.string_geometry   + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								Write( token + " ");
								if ( token.equals(VRMLdatatype.string_IndexedFaceSet) ) {
									if ( CheckChar(leftBraceChar) ) {
										indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.IndexedFaceSet;
										currentIndexedFaceSet = new IndexedFaceSet();
										if ( appletParameters.creaseAngleDefault ) {
											currentIndexedFaceSet.creaseAngle.setValue( appletParameters.creaseAngle );
										}
										SetNodeName(currentIndexedFaceSet, nodeName);
										//currentShape.indexedFaceSet = currentIndexedFaceSet;
										currentShape.geometry = currentIndexedFaceSet;
										//currentIndexedFaceSet.normal = new Normal(); // done here cause some IFS have a normal and others may not
										//Normal normal = (Normal) currentIndexedFaceSet.normal;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_IndexedFaceSet);
								} // end geometry.IndexedFaceSet

								else if ( token.equals(VRMLdatatype.string_IndexedLineSet) ) {
									if ( CheckChar(leftBraceChar) ) {
										indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.IndexedLineSet;
										currentIndexedLineSet	= new IndexedLineSet();
										SetNodeName(currentIndexedLineSet, nodeName);
										currentShape.geometry = currentIndexedLineSet;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_IndexedLineSet);
								} // end geometry.IndexedLineSet

								else if ( token.equals(VRMLdatatype.string_PointSet) ) {
									if ( CheckChar(leftBraceChar) ) {
										indent += indentAmt;
										PushStack( state );
										state = VRMLdatatype.PointSet;
										currentPointSet	= new PointSet();
										SetNodeName(currentPointSet, nodeName);
										currentShape.geometry = currentPointSet;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PointSet);
								} // end geometry.PointSet
								else if ( token.equals(VRMLdatatype.string_Box) ) {
									float[] size = Box.size;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_size) ) { size = GetFloatValues(Box.size.length); }
												else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Box);
												tokenType = GetToken();
											}
											else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Box);
										} while (tokenType != rightBraceChar);
										WriteLine(rightBraceChar);
										Box box	= new Box(size);
										SetNodeName(box, nodeName);
										currentShape.geometry = box;
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Box);
								} // end Box
								else if ( token.equals(VRMLdatatype.string_Cone) ) {
									boolean bottom = Cone.bottom;
									float bottomRadius = Cone.bottomRadius;
									float height = Cone.height;
									boolean side   = Cone.side;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_bottom) ) { bottom = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_bottomRadius) ) { bottomRadius = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_height) ) { height = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_side) ) { side = CheckBoolean(); }
												else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cone);
												tokenType = GetToken();
											}
											else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Cone);
										} while (tokenType != rightBraceChar);
										WriteLine(rightBraceChar);
										Cone cone = new Cone(bottom, bottomRadius, height, side);
										SetNodeName(cone, nodeName);
										currentShape.geometry = cone;
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Cone);
								} // end Cone

								else if ( token.equals(VRMLdatatype.string_Cylinder) ) {
									boolean bottom = Cylinder.bottom;
									float height = Cylinder.height;
									float radius = Cylinder.radius;
									boolean side   = Cylinder.side;
									boolean top   = Cylinder.top;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_bottom) ) { bottom = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_height) ) { height = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_radius) ) { radius = GetSingleFloat(); }
												else if ( token.equals(VRMLdatatype.string_side) ) { side = CheckBoolean(); }
												else if ( token.equals(VRMLdatatype.string_top) ) { top = CheckBoolean(); }
												else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Cylinder);
												tokenType = GetToken();
											}
											else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Cylinder);
										} while (tokenType != rightBraceChar);
										WriteLine(rightBraceChar);
										Cylinder cylinder	= new Cylinder(bottom, height, radius, side, top);
										SetNodeName(cylinder, nodeName);
										currentShape.geometry = cylinder;
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Cylinder);
								} // end Cylinder
								else if ( token.equals(VRMLdatatype.string_Sphere) ) {
									float radius = Cylinder.radius;
									if ( CheckChar(leftBraceChar) ) {
										tokenType = GetToken();
										do {
											//tokenType = GetToken();
											if (tokenType == StreamTokenizer.TT_WORD) {
												token = st.sval;
												if ( token.equals(VRMLdatatype.string_radius) ) { radius = GetSingleFloat(); }
												else FormatError("Illegal '" + token + "' inside " + VRMLdatatype.string_Sphere);
												tokenType = GetToken();
											}
											else if (tokenType != rightBraceChar) FormatError("Missing word inside " + VRMLdatatype.string_Sphere);
										} while (tokenType != rightBraceChar);
										WriteLine(rightBraceChar);
										Sphere sphere	= new Sphere(radius);
										SetNodeName(sphere, nodeName);
										currentShape.geometry = sphere;
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Sphere);
								} // end geometry.Sphere
								else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_geometry);
							} // end word != USE
						} // end if word token follows geometry
						else FormatError("word must follow " + VRMLdatatype.string_geometry);
					} // end Shape.geometry
				break; // end case Shape
				*/



				/********* Appearance *********/
				/*
				case VRMLdatatype.Appearance:

					if ( token.equals(VRMLdatatype.string_material) ) {
						Write( indent + VRMLdatatype.string_material  + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Material) ) {
									Write(VRMLdatatype.string_Material  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Material;
										currentMaterial = new Material();
										SetNodeName(currentMaterial, nodeName);
										currentAppearance.material = currentMaterial;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Material);
								} // end if token == material
								else FormatError("Missing '" + VRMLdatatype.string_Material + "' following " + VRMLdatatype.string_material);
							} // end token != USE
						} // end if token == word
						else FormatError("Missing word token following " + VRMLdatatype.string_material);
					} // end if Appearance.material
					else if ( token.equals(VRMLdatatype.string_texture) ) {
						Write(indent + VRMLdatatype.string_texture + " " );
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								imageTextureDEFName = null; // save this name when I actually load the ImageName
								if (token.equals(VRMLdatatype.string_DEF) ) {
									//nodeName = GetNodeName();
									imageTextureDEFName = GetNodeName();
								}
								if ( token.equals(VRMLdatatype.string_ImageTexture) ) {
									Write(VRMLdatatype.string_ImageTexture  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.ImageTexture;
										//currentImageTexture	= new ImageTexture(localApplet);
										//SetNodeName(currentImageTexture, nodeName);
										//currentAppearance.texture = currentImageTexture;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_ImageTexture);
								}
								else if ( token.equals(VRMLdatatype.string_PixelTexture) ) {
									Write(VRMLdatatype.string_PixelTexture  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.PixelTexture;
										currentPixelTexture	= new PixelTexture();
										SetNodeName(currentPixelTexture, nodeName);
										//currentAppearance.texture = currentPixelTexture;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_PixelTexture);
								}
								else FormatError("Missing texture type following " + VRMLdatatype.string_texture);
							} // end token != USE
						}  // end if token == word
						else FormatError("Missing word token following " + VRMLdatatype.string_texture);
					} // end Appearance.texture
					else if ( token.equals(VRMLdatatype.string_textureTransform) ) {
						Write(indent + VRMLdatatype.string_textureTransform + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_TextureTransform) ) {
									Write(VRMLdatatype.string_TextureTransform  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.TextureTransform;
										currentTextureTransform	= new TextureTransform();
										SetNodeName(currentTextureTransform, nodeName);
										//currentAppearance.textureTransform = currentTextureTransform;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TextureTransform);
								} // end if token == material
								else FormatError("Missing '" + VRMLdatatype.string_Material + "' following " + VRMLdatatype.string_textureTransform);
							} // end token != USE
						} // end if token == word
						else FormatError("Missing word token following " + VRMLdatatype.string_textureTransform);
					} //end Appearance.textureTransform
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Appearance);
				break; // end case Appearance
				*/



				/********* Material *********/
				/*
				case VRMLdatatype.Material:
					if ( token.equals(VRMLdatatype.string_diffuseColor) ) {
						Write(indent + VRMLdatatype.string_diffuseColor + " ");
						currentMaterial.diffuseColor.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_emissiveColor) ) {
						Write(indent + VRMLdatatype.string_emissiveColor );
						currentMaterial.emissiveColor.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_specularColor) ) {
						Write(indent + VRMLdatatype.string_specularColor );
						currentMaterial.specularColor.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_transparency) ) {
						Write(indent + VRMLdatatype.string_transparency );
						currentMaterial.transparency.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_ambientIntensity) ) {
						Write(indent + VRMLdatatype.string_ambientIntensity );
						currentMaterial.ambientIntensity.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_shininess) ) {
						Write(indent + VRMLdatatype.string_shininess );
						currentMaterial.shininess.setValue( GetSingleFloat() );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Material);
				break; // end case Material
				*/



				/********* TextureTransform *********/
				/*
				case VRMLdatatype.TextureTransform:
					if ( token.equals(VRMLdatatype.string_center) ) {
						Write(indent + VRMLdatatype.string_center);
						currentTextureTransform.center.setValue( GetFloatValues(2) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_rotation) ) {
						Write(indent + VRMLdatatype.string_rotation);
						currentTextureTransform.rotation.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_scale) ) {
						Write(indent + VRMLdatatype.string_scale);
						currentTextureTransform.scale.setValue( GetFloatValues(2) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_translation) ) {
						Write(indent + VRMLdatatype.string_translation);
						currentTextureTransform.translation.setValue( GetFloatValues(2) );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TextureTransform);
				break; // end case TextureTransform
				*/



				/********* IndexedLineSet *********/
				/*
				case VRMLdatatype.IndexedLineSet:
					if ( token.equals(VRMLdatatype.string_coord) ) {
						Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) {
									Write(VRMLdatatype.string_Coordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentIndexedLineSet.coord = currentCoordinate;
										currentCoordinate.parent = currentShape; // this is a cludge so interpolated coordinates can call ResetNormals(shape)
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end IndexedLineSet.coord

					else if ( token.equals(VRMLdatatype.string_coordIndex) ) {
						Write(indent + VRMLdatatype.string_coordIndex );
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentIndexedLineSet.coordIndex = new MFInt32();
							if (tempIntBuffer[tempBufferIndex-1] != -1) { // insure we end with -1
								tempIntBuffer[tempBufferIndex] = -1;
								tempBufferIndex++;
							}
							currentIndexedLineSet.coordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_coordIndex);
					} // end IndexedLineSet.coordIndex

					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) {
									Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentIndexedLineSet.color = currentColor;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // else if token == Color
								else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end else if token != USE
						} // end if token == world
						else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end IndexedLineSet.color

					else if ( token.equals(VRMLdatatype.string_colorIndex) ) {
						Write(indent + VRMLdatatype.string_colorIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentIndexedLineSet.colorIndex = new MFInt32();
							currentIndexedLineSet.colorIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_colorIndex);
					} // end currentIndexedLineSet.colorIndex

					else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) {
						Write(indent + VRMLdatatype.string_colorPerVertex + " ");
						currentIndexedLineSet.colorPerVertex.setValue( CheckBoolean() );
					} // end currentIndexedLineSet.colorPerVertex
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_IndexedLineSet);
				break; // end case IndexedLineSet
				*/



				/********* IndexedFaceSet *********/
				/*
				case VRMLdatatype.IndexedFaceSet:
					if ( token.equals(VRMLdatatype.string_coord) ) {
						Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) {
									Write(VRMLdatatype.string_Coordinate  + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentIndexedFaceSet.coord = currentCoordinate;
										currentCoordinate.parent = currentShape; // this is a cludge so interpolated coordinates can call ResetNormals(shape)
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end IndexedFaceSet.coord

					else if ( token.equals(VRMLdatatype.string_coordIndex) ) {
						Write(indent + VRMLdatatype.string_coordIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							valsPerLine = 0;
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									Write(",");
									if (tempIntBuffer[tempBufferIndex] == -1) valsPerLine++;
									if (valsPerLine > maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentIndexedFaceSet.coordIndex = new MFInt32();
							if (tempIntBuffer[tempBufferIndex-1] != -1) { // insure we end with -1
								tempIntBuffer[tempBufferIndex] = -1;
								tempBufferIndex++;
							}
							currentIndexedFaceSet.coordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_coordIndex);
					}  // end IndexedFaceSet.coordIndex

					// Need to Rewrite Normal
					else if ( token.equals(VRMLdatatype.string_normal) ) {
						Write(indent + VRMLdatatype.string_normal + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_DEF) ) {
								nodeName = GetNodeName();
							}
							if ( token.equals(VRMLdatatype.string_Normal) ) {
								Write(VRMLdatatype.string_Normal  + " "); indent += indentAmt;
								if ( CheckChar(leftBraceChar) ) {
									PushStack( state );
									state = VRMLdatatype.Normal;
									currentIndexedFaceSet.normal = new Normal(); // done here cause some IFS have a normal and others may not
									SetNodeName (currentIndexedFaceSet.normal, nodeName);
									WriteLine();
								}
								else FormatError("Missing '{' following " + VRMLdatatype.string_Normal);
							}
							else FormatError("Missing '" + VRMLdatatype.string_Normal + "' following " + VRMLdatatype.string_normal);
						}
						else FormatError("Non-word token following " + VRMLdatatype.string_normal);
					} // end IndexedFaceSet.normal

					else if ( token.equals(VRMLdatatype.string_normalIndex) ) {
						Write(indent + VRMLdatatype.string_normalIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									currentIndexedFaceSet.normalIndexStream.addElement( (Object) new Integer ( GetIntegerNumber() ) );
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							Integer il = new Integer( currentIndexedFaceSet.normalIndexStream.elementAt(currentIndexedFaceSet.normalIndexStream.size()-1).toString() );
							if (il.intValue() != -1) { // insure we end with -1
								currentIndexedFaceSet.normalIndexStream.addElement( (Object) new Integer ( -1 ) );
							}
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_normalIndex);
					} // end IndexedFaceSet.normalIndex

					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) {
									Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentIndexedFaceSet.color = currentColor;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // if token == Color
								else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end if !USE
						} // end if a word
						else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end IndexedFaceSet.color

					else if ( token.equals(VRMLdatatype.string_colorIndex) ) {
						Write(indent + VRMLdatatype.string_colorIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									Write(",");
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentIndexedFaceSet.colorIndex = new MFInt32();
							currentIndexedFaceSet.colorIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_colorIndex);
					} // end IndexedFaceSet.colorIndex

					else if ( token.equals(VRMLdatatype.string_texCoord) ) {
						Write(indent + VRMLdatatype.string_texCoord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_TextureCoordinate) ) {
									Write(VRMLdatatype.string_TextureCoordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.TextureCoordinate;
										currentTextureCoordinate = new TextureCoordinate();
										SetNodeName (currentTextureCoordinate, nodeName);
										currentIndexedFaceSet.texCoord = currentTextureCoordinate;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_TextureCoordinate);
								}
								else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_texCoord);
							} // end word != USE
						} // end got a word
						else FormatError("Non-word token following " + VRMLdatatype.string_texCoord);
					} // end IndexedFaceSet.texCoord

					else if ( token.equals(VRMLdatatype.string_texCoordIndex) ) {
						Write(indent + VRMLdatatype.string_texCoordIndex  + " ");
						if ( CheckChar(leftBracketChar) ) {
							valsPerLine = 0;
							tempBufferIndex = 0;
							do {
								tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempIntBuffer[tempBufferIndex] = GetIntegerNumber();
									//Write(",");
									if (tempIntBuffer[tempBufferIndex] == -1) {
										Write(",");
										valsPerLine++;
									}
									if (valsPerLine > maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									tempBufferIndex++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentIndexedFaceSet.texCoordIndex = new MFInt32( );
							currentIndexedFaceSet.texCoordIndex.setValue(tempBufferIndex, tempIntBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_texCoordIndex);
					}  // end IndexedFaceSet.texCoordIndex

					else if ( token.equals(VRMLdatatype.string_colorPerVertex) ) {
						Write(indent + VRMLdatatype.string_colorPerVertex + " ");
						currentIndexedFaceSet.colorPerVertex.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_normalPerVertex) ) {
						Write(indent + VRMLdatatype.string_normalPerVertex + " ");
						currentIndexedFaceSet.normalPerVertex.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_ccw) ) {
						Write(indent + VRMLdatatype.string_ccw  + " ");
						currentIndexedFaceSet.ccw.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_solid) ) {
						Write(indent + VRMLdatatype.string_solid  + " ");
						currentIndexedFaceSet.solid.setValue( CheckBoolean() );
					}
					else if ( token.equals(VRMLdatatype.string_creaseAngle) ) {
						Write(indent + VRMLdatatype.string_creaseAngle );
						float creaseAngle = GetSingleFloat();
						if ( appletParameters.creaseAngleDefault ) {
							Write(" - using default of " + appletParameters.creaseAngle);
						}
						else currentIndexedFaceSet.creaseAngle.setValue( creaseAngle );
						//currentIndexedFaceSet.creaseAngle.setValue( GetSingleFloat() );
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_IndexedFaceSet);
				break; // end case IndexedFaceSet
				*/



				/********* PointSet *********/
				/*
				case VRMLdatatype.PointSet:
					if ( token.equals(VRMLdatatype.string_coord) ) {
						Write(indent + VRMLdatatype.string_coord + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Coordinate) ) {
									Write(VRMLdatatype.string_Coordinate + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Coordinate;
										currentCoordinate	= new Coordinate();
										SetNodeName (currentCoordinate, nodeName);
										currentPointSet.coord = currentCoordinate;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Coordinate);
								} // end if token == Coordinate
								else FormatError("Missing '" + VRMLdatatype.string_Coordinate + "' following " + VRMLdatatype.string_coord);
							} // end if token != USE
						} // end if token == WORD
						else FormatError("Non-word token following " + VRMLdatatype.string_coord);
					} // end PointSet.coord

					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color + " ");
						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_WORD) {
							token = st.sval;
							if (token.equals(VRMLdatatype.string_USE) ) { GotUSEtoken(); }
							else {
								if (token.equals(VRMLdatatype.string_DEF) ) { nodeName = GetNodeName(); }
								if ( token.equals(VRMLdatatype.string_Color) ) {
									Write(VRMLdatatype.string_Color + " "); indent += indentAmt;
									if ( CheckChar(leftBraceChar) ) {
										PushStack( state );
										state = VRMLdatatype.Color;
										currentColor = new Color();
										SetNodeName (currentColor, nodeName);
										currentPointSet.color = currentColor;
										WriteLine();
									}
									else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_Color);
								} // else if token == Color
								else FormatError("Missing '" + VRMLdatatype.string_Color + "' following " + VRMLdatatype.string_color);
							} // end else if token != USE
						} // end if token == world
						else FormatError("Non-word token following " + VRMLdatatype.string_color);
					} // end PointSet.color

					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PointSet);
				break; // end case PointSet
				*/


				/********* Coordinate *********/
				/*
				case VRMLdatatype.Coordinate:
					if ( token.equals(VRMLdatatype.string_point) ) {
						Write(indent + VRMLdatatype.string_point + " ");
						if ( CheckChar(leftBracketChar) ) {
							valsPerLine = 0;
							tempBufferIndex = 0;
							// had to get this before do while loop cause tokenType set in GetFloatNumber
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									Write(",");
									if (valsPerLine >= maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentCoordinate.point.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_point);
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Coordinate);
				break; // end case Coordinate
				*/


				/********* Normal *********/
				/*
				case VRMLdatatype.Normal:
					if ( token.equals(VRMLdatatype.string_vector) ) {
						Write(indent + VRMLdatatype.string_vector + " ");
						if ( CheckChar(leftBracketChar) ) {
							float[] newVector = new float[3];
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									currentIndexedFaceSet.normalStream.addElement( (Object) new Float ( GetFloatNumber() ) );
									Write(" ");
								}
								tokenType = GetToken();
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							Normal normal = (Normal) currentIndexedFaceSet.normal;
							normal.vector.vec3s = new float[currentIndexedFaceSet.normalStream.size()/3][3]; // makes vec3s not null for ROUTE properties
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_vector);
					} // end if 'vector'not following Normal
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Normal);
				break; // end case Normal
				*/


				/********* Color *********/
				/*
				case VRMLdatatype.Color:
					if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									Write(",");
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentColor.color.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBraceChar + "' following " + VRMLdatatype.string_color);
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Color);
				break; // end case Color
				*/


				/********* PositionInterpolator, ColorInterpolator, CoordinateInterpolator, NormalInterpolator *********/
				/*
				case VRMLdatatype.PositionInterpolator:
				case VRMLdatatype.ColorInterpolator:
				case VRMLdatatype.CoordinateInterpolator:
				case VRMLdatatype.NormalInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) {
						Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									Write(",");
									if (valsPerLine >= maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							if (state == VRMLdatatype.PositionInterpolator) {
								currentPositionInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.ColorInterpolator) {
								currentColorInterpolator.keyValue = new MFColor(tempBufferIndex, tempFloatBuffer);
							}
							//else if (state == VRMLdatatype.CoordinateInterpolator) {
								currentCoordinateInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
							//else if (state == VRMLdatatype.NormalInterpolator) {
							if (state == VRMLdatatype.NormalInterpolator) {
								currentNormalInterpolator.keyValue = new MFVec3f(tempBufferIndex, tempFloatBuffer);
							}
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) {
						Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									Write(",");
									if ( valsPerLine > (maxValsPerLine*2) ) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							if (state == VRMLdatatype.PositionInterpolator) {
								currentPositionInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							else if (state == VRMLdatatype.ColorInterpolator) {
								currentColorInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							//else if (state == VRMLdatatype.CoordinateInterpolator) {
							if (state == VRMLdatatype.CoordinateInterpolator) {
								currentCoordinateInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
							//else if (state == VRMLdatatype.NormalInterpolator) {
							if (state == VRMLdatatype.NormalInterpolator) {
								currentNormalInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
							}
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key);
					} // end if key
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Interpolator);
				break; // end case ColorInterpolator, PositionInterpolator
				*/

				/********* OrientationInterpolator - for Transform.rotation and Viewpoint.orientation *********/
				/*
				case VRMLdatatype.OrientationInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) {
						Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;

									Write(",");
									if (valsPerLine >= maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentOrientationInterpolator.keyValue = new MFRotation(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue + " inside " + VRMLdatatype.string_OrientationInterpolator);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) {
						Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									Write(",");
									if ( valsPerLine > (maxValsPerLine*2) ) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentOrientationInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key + " inside " + VRMLdatatype.string_OrientationInterpolator);
					} // end if key
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_OrientationInterpolator);
				break; // end case OrientationInterpolator
				*/

				/********* ScalarInterpolator, used for MFFloats typically *********/
				/*
				case VRMLdatatype.ScalarInterpolator:
					if ( token.equals(VRMLdatatype.string_keyValue) ) {
						Write(indent + VRMLdatatype.string_keyValue + " ");
						if ( CheckChar(leftBracketChar) ) {
							tempBufferIndex = 0;
							valsPerLine = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;

									Write(",");
									if ( valsPerLine > (maxValsPerLine*2) ) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentScalarInterpolator.keyValue = new MFFloat(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_keyValue + " inside " + VRMLdatatype.string_ScalarInterpolator);
					} // end if keyValue

					else if ( token.equals(VRMLdatatype.string_key) ) {
						Write(indent + VRMLdatatype.string_key  + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							tempBufferIndex = 0;
							valsPerLine = 0;
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									Write(",");
									if ( valsPerLine > (maxValsPerLine*2) ) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentScalarInterpolator.key.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_key + " inside " + VRMLdatatype.string_ScalarInterpolator);
					} // end if key
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ScalarInterpolator);
				break; // end case ScalarInterpolator
				*/



				/********* ImageTexture *********/
				/*
				case VRMLdatatype.ImageTexture:
					if ( token.equals(VRMLdatatype.string_url) ) {
						Write(indent + VRMLdatatype.string_url + " ");
						String[] urlString = new String[1];
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							token = st.sval;
							urlString[0] = textureMapFolder + token;
							//urlString[0] = urlString[0].toLowerCase();
						}
						else FormatError("Missing doublequote following " + VRMLdatatype.string_url + " in " + VRMLdatatype.string_ImageTexture);
						// check for a repeated image
						SFNode currNodeLink	= imageTextureRoot.next;
						while (currNodeLink != null) {
							ImageTexture currImageTextureLink = (ImageTexture) currNodeLink;
							if ( currImageTextureLink.url.get1Value(0).equals(urlString[0]) ) {
								//currentAppearance.texture = currImageTextureLink;
								break;
							}
							currNodeLink = currNodeLink.next;
						}
						if ( currNodeLink == null) {
							// add new Image Texture
							//ImageTexture currentImageTexture	= new ImageTexture(localApplet);
							ImageTexture currentImageTexture	= new ImageTexture();
							SetNodeName(currentImageTexture, imageTextureDEFName); // new var used to save nodeName
							//currentAppearance.texture = currentImageTexture;
							currentImageTexture.url = new MFString( 1, urlString );
							//currentImageTexture.retrieveImage( );
							currentImageTexture.retrieveImage(localApplet, 1);
							// insert new ImageTexture into linked list
							currentImageTexture.next = imageTextureRoot.next;
							imageTextureRoot.next = currentImageTexture;
						}
						WriteLine(doubleQuoteChar + token + doubleQuoteChar);
					} // end getting url
					else if ( token.equals(VRMLdatatype.string_repeatS) ) {
						Write(indent + VRMLdatatype.string_repeatS );
						//currentImageTexture.repeatS.setValue( CheckBoolean() ); // valied currentImageTexture may not be avail
						CheckBoolean();
						WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatS + " not currently supported ");
					}
					else if ( token.equals(VRMLdatatype.string_repeatT) ) {
						Write(indent + VRMLdatatype.string_repeatT );
						//currentImageTexture.repeatT.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						CheckBoolean();
						WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatT + " not currently supported ");
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_ImageTexture);
				break; // end case ImageTexture
				*/



				/********* PixelTexture *********/
				/*
				case VRMLdatatype.PixelTexture:
					if ( token.equals(VRMLdatatype.string_image) ) {
						Write(indent + VRMLdatatype.string_image + " ");

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.width  = GetIntegerNumber();
						else FormatError("Missing width value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.height = GetIntegerNumber();
						else FormatError("Missing height value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						tokenType = GetToken();
						if (tokenType == StreamTokenizer.TT_NUMBER) currentPixelTexture.image.components = GetIntegerNumber();
						else FormatError("Missing components value following " + VRMLdatatype.string_image + " in " + VRMLdatatype.string_PixelTexture);

						currentPixelTexture.image.pixels = new byte[currentPixelTexture.image.width * currentPixelTexture.image.height * currentPixelTexture.image.components];
						// flip the pixel texture according to spec.
						int widthIndex = currentPixelTexture.image.width - 1;
						int heightIndex = currentPixelTexture.image.height - 1;
						for (int i = 0; i < currentPixelTexture.image.width; i++) {
							for (int j = 0; j < currentPixelTexture.image.height; j++) {
								byte[] returnBytes = GetByte(currentPixelTexture.image.components);
								for (int byteNum = 0; byteNum < returnBytes.length; byteNum++) {
									//currentPixelTexture.image.pixels[(currentPixelTexture.image.height*(widthIndex - i))+j+byteNum] = returnBytes[byteNum];
									currentPixelTexture.image.pixels[
										(i + ((heightIndex-j)*currentPixelTexture.image.height))*currentPixelTexture.image.components + byteNum] =
										returnBytes[byteNum];
								}
							}
						}
						currentPixelTexture.image.SetRGBA();
						WriteLine();
					} // end getting image
					else if ( token.equals(VRMLdatatype.string_repeatS) ) {
						Write(indent + VRMLdatatype.string_repeatS );
						currentPixelTexture.repeatS.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatS + " not currently supported ");
					}
					else if ( token.equals(VRMLdatatype.string_repeatT) ) {
						Write(indent + VRMLdatatype.string_repeatT );
						currentPixelTexture.repeatT.setValue( CheckBoolean() );  // valied currentImageTexture may not be avail
						WriteLine(indent + indentAmt + "; " + VRMLdatatype.string_repeatT + " not currently supported ");
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_PixelTexture);
				break; // end case PixelTexture
				*/



				/********* TextureCoordinate *********/
				/*
				case VRMLdatatype.TextureCoordinate:
					if ( token.equals(VRMLdatatype.string_point) ) {
						Write(indent + VRMLdatatype.string_point + " ");
						if ( CheckChar(leftBracketChar) ) {
							valsPerLine = 0;
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								//tokenType = GetToken();
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tokenType = GetToken();
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									Write(",");
									if (valsPerLine >= maxValsPerLine) {
										WriteLine();
 										valsPerLine = 0;
										Write(indent + indentAmt);
								   }
									else valsPerLine++;
									tempBufferIndex++;
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							WriteLine(rightBracketChar);
							currentTextureCoordinate.point.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_point);
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_TextureCoordinate);
				break; // end case TextureCoordinate
				*/



				/********* Anchor *********/
				/*
				case VRMLdatatype.Anchor:
					if ( token.equals(VRMLdatatype.string_children) ) {
						Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar +"' following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Anchor);
					} // end if children
					else if ( token.equals(VRMLdatatype.string_description) ) {
						Write(indent + VRMLdatatype.string_description + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							//token = st.sval;
							currentAnchor.description = new SFString( st.sval );
							WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						else FormatError("Missing doublequote following " + VRMLdatatype.string_description + " in " + VRMLdatatype.string_Anchor);
					} // end if description
					else if ( token.equals(VRMLdatatype.string_parameter) ) {
						Write(indent + VRMLdatatype.string_parameter + " ");
						tokenType = GetToken();
						boolean bracket = false;
						if ( tokenType == leftBracketChar ) {
							tokenType = GetToken();
							bracket = true;
							Write(leftBracketChar);
						}
						if ( tokenType == doubleQuoteChar ){
							//token = st.sval;
							String[] parameterString = {st.sval };
							currentAnchor.parameter = new MFString(1, parameterString );
							Write(doubleQuoteChar + parameterString[0] + doubleQuoteChar);
						}
						else FormatError("Missing double quote/left bracket following " + VRMLdatatype.string_parameter + " in " + VRMLdatatype.string_Anchor);
						if ( bracket ) {
							tokenType = GetToken();
							Write(rightBracketChar);
						}
						WriteLine();
					} // end if parameter
					else if ( token.equals(VRMLdatatype.string_url) ) {
						Write(indent + VRMLdatatype.string_url + " ");
						tokenType = GetToken();
						boolean bracket = false;
						if ( tokenType == leftBracketChar ) {
							tokenType = GetToken();
							bracket = true;
							Write(leftBracketChar);
						}
						if ( tokenType == doubleQuoteChar ){
							//token = st.sval;
							String[] urlString = {st.sval };
							currentAnchor.url = new MFString(1, urlString );
							Write(doubleQuoteChar + urlString[0] + doubleQuoteChar);
						}
						else FormatError("Missing double quote following " + VRMLdatatype.string_url + " in " + VRMLdatatype.string_Anchor);
						if ( bracket ) {
							tokenType = GetToken();
							Write(rightBracketChar);
						}
						WriteLine();
					} // end if url
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
						Write(indent + VRMLdatatype.string_bboxCenter + " ");
						//currentAnchor.setBboxCenter( GetFloatValues(3) );
						currentAnchor.bboxCenter.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
						Write(indent + VRMLdatatype.string_bboxSize + " ");
						//currentAnchor.setBboxSize( GetFloatValues(3) );
						currentAnchor.bboxSize.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Anchor);
				break; // end case Anchor
				*/


				/********* Billboard *********/
				/*
				case VRMLdatatype.Billboard:
					if ( token.equals(VRMLdatatype.string_children) ) {
						Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Billboard);
					}
					else if ( token.equals(VRMLdatatype.string_axisOfRotation) ) {
						Write(indent + VRMLdatatype.string_axisOfRotation);
						currentBillboard.axisOfRotation.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
						Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentBillboard.bboxCenter.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
						Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentBillboard.bboxSize.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Billboard);
				break; // end case Billboard
				*/



				/********* Group *********/
				/*
				case VRMLdatatype.Group:
					if ( token.equals(VRMLdatatype.string_children) ) {
						Write(indent + VRMLdatatype.string_children  + " "); indent += indentAmt;
						if ( CheckChar(leftBracketChar) ) {
							PushStack( state );
							state = VRMLdatatype.children;
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar +"' (left bracket) following '" + VRMLdatatype.string_children + "' inside " + VRMLdatatype.string_Group);
					}
					else if ( token.equals(VRMLdatatype.string_bboxCenter) ) {
						Write(indent + VRMLdatatype.string_bboxCenter + " ");
						currentGroup.bboxCenter.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_bboxSize) ) {
						Write(indent + VRMLdatatype.string_bboxSize + " ");
						currentGroup.bboxSize.setValue( GetFloatValues(3) );
						Write("; not currently supported ");
						WriteLine();
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Group);
				break; // end case Group
				*/


				/********* WorldInfo *********/
				/*
				case VRMLdatatype.WorldInfo:
					if ( token.equals(VRMLdatatype.string_title) ) {
						Write(indent + VRMLdatatype.string_title + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							worldInfo.title.setValue( st.sval );
							WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						else FormatError("Missing doublequote following " + VRMLdatatype.string_title + " in " + VRMLdatatype.string_WorldInfo);
					}
					else if ( token.equals(VRMLdatatype.string_info) ) {
						Write(indent + VRMLdatatype.string_info + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							WriteLine(leftBracketChar);
							tokenType = GetToken();
							while (tokenType != rightBracketChar) {
								worldInfo.info.addValue( st.sval );
								WriteLine(indent + indentAmt + doubleQuoteChar + st.sval + doubleQuoteChar);
								tokenType = GetToken();
							}
							WriteLine(indent + rightBracketChar);
						}
						else if (tokenType == doubleQuoteChar) {
							// no brackets but a single string
							worldInfo.info.addValue( st.sval );
							WriteLine(doubleQuoteChar + st.sval + doubleQuoteChar);
						}
						else FormatError("Missing character following " + VRMLdatatype.string_info + " in " + VRMLdatatype.string_WorldInfo);
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_WorldInfo);
				break; // end case WorldInfo
				*/


				/********* Background *********/
				/*
				case VRMLdatatype.Background:
					if ( token.equals(VRMLdatatype.string_skyColor) ) {
						Write(indent + VRMLdatatype.string_skyColor + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							Write(leftBracketChar);
							tempBufferIndex = 0;
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[tempBufferIndex] = GetFloatNumber();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									tempFloatBuffer[tempBufferIndex] = GetSingleFloat();
									tempBufferIndex++;
									Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							Write(rightBracketChar);
							background.skyColor.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else {
							//background.setSkyColor( GetFloatValues(3) );
							tempFloatBuffer[0] = GetFloatNumber();
							tempFloatBuffer[1] = GetSingleFloat();
							tempFloatBuffer[2] = GetSingleFloat();
							background.skyColor.setValue( 3, tempFloatBuffer );
						}
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_groundColor) ) {
						Write(indent + VRMLdatatype.string_groundColor + " ");
						tokenType = GetToken();
						if ( tokenType == leftBracketChar ) {
							Write(leftBracketChar);
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									tempFloatBuffer[0] = GetSingleFloat();
									tempFloatBuffer[0] = GetSingleFloat();
									Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							Write(rightBracketChar);
							Write("; not currently supported ");
							//background.groundColor.setValue(tempBufferIndex, tempFloatBuffer);
						}
						else {
							tempFloatBuffer[0] = GetFloatNumber();
							tempFloatBuffer[1] = GetSingleFloat();
							tempFloatBuffer[2] = GetSingleFloat();
							Write("; not currently supported ");
							//background.groundColor.setValue( 3, tempFloatBuffer );
						}
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_skyAngle) ) {
						Write(indent + VRMLdatatype.string_skyAngle + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							Write(rightBracketChar);
							Write("; not currently supported");
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_skyAngle + " in " + VRMLdatatype.string_Background);
 				   }
					else if ( token.equals(VRMLdatatype.string_groundAngle) ) {
						Write(indent + VRMLdatatype.string_groundAngle + " ");
						if ( CheckChar(leftBracketChar) ) {
							tokenType = GetToken();
							do {
								if (tokenType == StreamTokenizer.TT_NUMBER) {
									tempFloatBuffer[0] = GetFloatNumber();
									Write(",");
									tokenType = GetToken();
								}
							} while (tokenType != rightBracketChar);
							Write(rightBracketChar);
							Write("; not currently supported ");
							WriteLine();
						}
						else FormatError("Missing '" + leftBracketChar + "' following " + VRMLdatatype.string_skyAngle + " in " + VRMLdatatype.string_Background);
 				   }
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Background);
				break; // end case Background
				*/


				/********* Fog *********/
				/*
				case VRMLdatatype.Fog:
					if ( token.equals(VRMLdatatype.string_visibilityRange) ) {
						Write(indent + VRMLdatatype.string_visibilityRange);
						currentFog.visibilityRange.setValue( GetSingleFloat() );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_color) ) {
						Write(indent + VRMLdatatype.string_color);
						currentFog.color.setValue( GetFloatValues(3) );
						WriteLine();
					}
					else if ( token.equals(VRMLdatatype.string_fogType) ) {
						Write(indent + VRMLdatatype.string_fogType + " ");
						tokenType = GetToken();
						if (tokenType == doubleQuoteChar) {
							if ( st.sval.equals(VRMLdatatype.string_LINEAR) ) {
								Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								currentFog.fogType.setValue( VRMLdatatype.string_LINEAR );
								WriteLine();
							}
							else if ( st.sval.equals(VRMLdatatype.string_EXPONENTIAL) ) {
								Write(doubleQuoteChar + st.sval + doubleQuoteChar);
								currentFog.fogType.setValue( VRMLdatatype.string_EXPONENTIAL );
								WriteLine();
							}
	 						else FormatError(st.sval + "invalid following " + VRMLdatatype.string_fogType + " in " + VRMLdatatype.string_Fog);
						}
 						else FormatError("Missing " + doubleQuoteChar + " following " + VRMLdatatype.string_fogType + " in " + VRMLdatatype.string_Fog);
					}
					else FormatError("illegal/unsupported node '" + token + "' inside " + VRMLdatatype.string_Fog);
				break; // end case Fog
				*/



				/********* default *********/
				default:
					FormatError("node '" + token + "' misplaced, not currently implemented or illegal");
				break; // end default
			} // end switch on state
		} // end if (tokenType == StreamTokenizer.TT_WORD)


		//else if ( tokenType == rightBraceChar) { // '}'
		//	if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
		//	WriteLine(indent + rightBraceChar);
		else if ( tokenType == rightBraceChar) { // '}'
			if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
			WriteLine(indent + rightAngleBracket);
			switch (state) {
				/*
				case VRMLdatatype.Appearance:
					currentAppearance = null;
					state =  PopStack();
				break;
				case VRMLdatatype.Material:
					currentMaterial = null;
					state =  PopStack();
				break;
				case VRMLdatatype.Shape:
					currentShape = null;
					state = PopStack();
				break;
				case VRMLdatatype.Transform:
					state = PopStack();
					currentNode = currentTransform.parent;
					if ( currentNode.datatype == VRMLdatatype.Transform) {
						currentTransform = (Transform) currentNode;
					}
					else { currentTransform = null; }
				break;
				case VRMLdatatype.Viewpoint:
					currentViewpoint = null;
					state = PopStack();
				break;
				case VRMLdatatype.Coordinate:
					currentCoordinate = null;
					state = PopStack();
				break;
				case VRMLdatatype.IndexedFaceSet:
					currentIndexedFaceSet = null;
					state = PopStack();
				break;
				case VRMLdatatype.IndexedLineSet:
					currentIndexedLineSet = null;
					state =  PopStack();
				break;
				case VRMLdatatype.PointSet:
					currentPointSet = null;
					state =  PopStack();
				break;
				case VRMLdatatype.TextureTransform:
					currentTextureTransform = null;
					state =  PopStack();
				break;
				case VRMLdatatype.TextureCoordinate:
					currentTextureCoordinate = null;
					state = PopStack();
				break;
				case VRMLdatatype.ImageTexture:
					//currentImageTexture = null;
					state = PopStack();
				break;
				case VRMLdatatype.PixelTexture:
					currentPixelTexture = null;
					state = PopStack();
				break;
				case VRMLdatatype.Color:
					currentColor = null;
					state = PopStack();
				break;
				case VRMLdatatype.TimeSensor:
					currentTimeSensor = null;
					state = PopStack();
				break;
				case VRMLdatatype.TouchSensor:
					currentTouchSensor = null;
					state = PopStack();
				break;
				case VRMLdatatype.DirectionalLight:
					currentDirectionalLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.PointLight:
					currentPointLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.SpotLight:
					currentSpotLight = null;
					state = PopStack();
				break;
				case VRMLdatatype.ColorInterpolator:
					currentColorInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.PositionInterpolator:
					currentPositionInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.CoordinateInterpolator:
					currentCoordinateInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.OrientationInterpolator:
					currentOrientationInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.ScalarInterpolator:
					currentScalarInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.NormalInterpolator:
					currentNormalInterpolator = null;
					state = PopStack();
				break;
				case VRMLdatatype.Anchor:
					state = PopStack();
					currentNode = currentAnchor.parent;
					if ( currentNode.datatype == VRMLdatatype.Anchor) {
						currentAnchor = (Anchor) currentNode;
					}
					else { currentAnchor = null; }
				break;
				case VRMLdatatype.Billboard:
					state = PopStack();
					currentNode = currentBillboard.parent;
					if ( currentNode.datatype == VRMLdatatype.Billboard) {
						currentBillboard = (Billboard) currentNode;
					}
					else { currentBillboard = null; }
				break;
				case VRMLdatatype.Group:
					state = PopStack();
					currentNode = currentGroup.parent;
					if ( currentNode.datatype == VRMLdatatype.Group) {
						currentGroup = (Group) currentNode;
					}
					else { currentGroup = null; }
				break;
				case VRMLdatatype.SFNode:
				case VRMLdatatype.ROOT:
					FormatError("'" + rightBraceChar + "' for unspecified Node.");
				break;
				//case VRMLdatatype.Background:
				case VRMLdatatype.Fog:
				//case VRMLdatatype.NavigationInfo:
				case VRMLdatatype.WorldInfo:
					state = PopStack();
				break;
				case VRMLdatatype.Normal:
					//currentNormal = null;
					state = PopStack();
				break;
				case VRMLdatatype.NavigationInfo:
					state = PopStack();
				break;
				case VRMLdatatype.WorldInfo:
					state = PopStack();
				break;
				*/
				default:
					FormatError("'" + rightBraceChar + "' for undefined node.");
				break;
			} // end switch on state for '}'
		} // end if ( tokenType == rightBraceChar)

		else if ( tokenType == rightBracketChar) { // ']'
			if (indent.length() >= indentAmt.length() ) indent = indent.substring(0, (indent.length() - indentAmt.length()) );
			WriteLine(indent + rightBracketChar);
			switch (state) {
				case VRMLdatatype.children:
					state = PopStack();
				break;
				default:
					FormatError("'" + rightBracketChar + "' (right bracket) for undefined node.");
				break;
			} // end switch on state
		} // else if token == right Brace

		else if (tokenType == StreamTokenizer.TT_NUMBER) {
			FormatError("unexpected number: " + GetFloatNumber() );
		}
		} // end if (tokenType != StreamTokenizer.TT_WORD)
		return tokenType;
	} // end NodeParser function


	public void ReadStream(InputStream vrmlInputStream, String _textureMapFolder, boolean compressedFile) {
		this.textureMapFolder = _textureMapFolder;
		st = parser.GetStreamTokenizer (vrmlInputStream, compressedFile);
		do {
			if (X3D_head) tokenType = HeadParser();
			else if (X3D_Scene) tokenType = NodeParser();
			else if (X3D_X3Dtag) tokenType = X3DParser();
			else tokenType = X3DfileParser();
		} while (tokenType != StreamTokenizer.TT_EOF);
	} // end ReadStream


	/* called by GraphicEngine LoadURL public comment*/
	public void LoadURL(InputStream vrmlInputStream, String _textureMapFolder, boolean compressedFile, SFNode attachNode) {
		currentNode = attachNode;
		ReadStream(vrmlInputStream, _textureMapFolder, compressedFile);
	} // end LoadURL


	public LexicalAnalyzerX3D(Applet applet,
				//Node mainRoot, Light mainLightsRoot,
				Group mainRoot, Light mainLightsRoot,
				Viewpoint mainViewpointRoot, Sensor mainSensorRoot,
				Interpolator mainInterpolatorRoot, Route mainRouteRoot, Shape shapeRoot,
				Background background_, NavigationInfo navigationInfo_,
				AppletParameters appletParameters_, Fog fog_) {

		stateStack  = new Stack();
		parser = new Parser();

		localApplet = applet;

		mainRoot.setName("ROOT");
 		root = mainRoot;
		currentNode = mainRoot;

		mainLightsRoot.setName("LIGHTSroot");
		currentLight = mainLightsRoot;

		mainViewpointRoot.setName("VIEWPOINTroot");
		viewpointRoot = mainViewpointRoot;
		viewpointLink = mainViewpointRoot;

		mainSensorRoot.setName("SENSORroot");
		sensorRoot = mainSensorRoot;
		sensorLink = mainSensorRoot;

		mainInterpolatorRoot.setName("INTERPOLATORroot");
		interpolatorRoot = mainInterpolatorRoot;
		interpolatorLink = mainInterpolatorRoot;

		routeRoot = mainRouteRoot;
		routeLast = mainRouteRoot;
		shapeLink = shapeRoot;

		imageTextureRoot = new SFNode();

		background		= background_;
		navigationInfo	= navigationInfo_;

		DEFnameNode = new SFNode(); // for a linked list of named nodes for USE/DEF nodes
		//DEFnameNode.setName("DEFnameNodeRoot");
		currentDEFnameNode = DEFnameNode; // for a linked list of named nodes for USE/DEF nodes

		fog = fog_;

		appletParameters = appletParameters_;

	} // LexicalAnalyzer Constructor

} // end class Lexical Analyser
