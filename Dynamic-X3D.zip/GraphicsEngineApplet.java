// GraphicsEngineApplet.java.java
// � 2002, 3D-Online, All Rights Reserved
// Date: June 7, 2003
// modified July 5, 2007 for X3D

package d3d;


import java.applet.Applet;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Font;



public class GraphicsEngineApplet extends Applet implements Runnable {
	Dimension screenDim = null;
	boolean doneInit = false;
	int xOffset, yOffset;
	final int xLength = 110;
	final int yLength = 100;
	int[] pctComplete = new int[1];
	AppletParameters appletParameters = null;
	Color backgroundColor = null;
	Color foregroundColor = null;
	Color progressBarColor = null;
	Color watermarkColor = null;
	String watermarkString = "Dynamic-X3D by 3D-Online";

	GraphicEngine graphicsEngine = null;
	Thread graphicEngineThread = null;


	public void init() {
		System.out.println("Copyright (c) 2008 3D-Online");
		System.out.println("Dynamic-X3D, version beta 06");
		screenDim = this.getSize();
		xOffset = (screenDim.width  - xLength) >> 1;
		yOffset = (screenDim.height - yLength) >> 1;
	}


	public void start() {
		appletParameters = new AppletParameters( this );
		appletParameters.key = 5620965;
		appletParameters.SetRegistration();
//appletParameters.registeredUser = false;

		float[] background = {appletParameters.backgroundColors[0], appletParameters.backgroundColors[1], appletParameters.backgroundColors[2]};
		backgroundColor = new Color( background[0], background[1], background[2] );
		foregroundColor = new Color(
								( (background[0] + .5f) % 1), ( (background[1] + .5f) % 1), ( (background[2] + .5f) % 1) );
		progressBarColor = new Color(
								( (background[0] + .5f) % 1), ( (background[1] + .1f) % 1), ( (background[2] + .1f) % 1) );
		for (int i = 0; i < 3; i++) {
			if (background[i] > .2f) background[i] -= .2f;
			else background[i] += .25f;
		}
		watermarkColor = new Color( background[0], background[1], background[2] );
		pctComplete[0] = 10;

		//new Thread(this).start();
		graphicEngineThread = new Thread(this);
		graphicEngineThread.start();
		repaint();
	} // end Dyn3DEngine.start


	public void run() {
		GraphicsEngineInit graphicsEngineInit = new GraphicsEngineInit(this, pctComplete, appletParameters);
		//graphicsEngineInit = new GraphicsEngineInit(this, pctComplete, appletParameters);
		graphicsEngine = graphicsEngineInit.GetGraphicEngine();
		repaint();
	}

	public void paint(Graphics g) {
		if (!doneInit) {
			this.setBackground( backgroundColor );
			g.setColor( foregroundColor );
			g.setFont(new Font("Serif", Font.BOLD, 22));
			g.drawString("3D-Online", (xOffset + 5), yOffset );
			g.setFont(new Font("Serif", Font.BOLD, 16));
			g.drawString("Loading . . .", (xOffset + 20), (yOffset + 25) );
			g.setColor( foregroundColor );
			g.drawRect( xOffset, (yOffset + 35), 110, 20);
			g.setColor( progressBarColor );
			g.fillRect( (xOffset + 5), (yOffset + 40), pctComplete[0], 10);
			if ( pctComplete[0] == 100) doneInit = true;
		}
		if (doneInit) {
			this.setBackground( backgroundColor );
			g.clearRect(xOffset, (yOffset-40), (xOffset+200), (yOffset+100) );
			if ( !appletParameters.registeredUser ) {
				g.setColor( watermarkColor );
				g.setFont(new Font("Serif", Font.BOLD, 24));
				int xLeft = 5;
				int xRight = xLeft + 320;
				int y = 60;
				final int yOffset = 55;
				while (y < 470) {
					g.drawString(watermarkString, xLeft, y );
					g.drawString(watermarkString, xRight, y );
					y += yOffset;
				}
			}
		}
	}

	public void update(Graphics g){
		paint(g);
	} // end update


	//public void stop() {
	//	super.stop();
	//} // end stop
	public void destroy() {
		graphicsEngine.destroy();
		graphicEngineThread.stop();
		super.destroy();
	} // end destroy

	public SFNode GetNodeByName(String nodeName){
		SFNode returnNode = graphicsEngine.GetNodeByName(nodeName);
		return returnNode;
	} // end getRoot

	/** returns the current viewpoint. */
	public Viewpoint GetCurrentViewpoint(){
		return graphicsEngine.GetCurrentViewpoint();
	} // end getCurrentViewpoint

	/** Sets the viewpoint to the <I>newViewpoint</I> in the List.<BR>If any Viewpoints are contained within a Transform(s), all the Viewpoints should be contained inside the same Transform(s) */
	public void SetCurrentViewpoint(Viewpoint newViewpoint){
		graphicsEngine.SetViewpoint(newViewpoint);
	} // end SetCurrentViewpoint

	/** Set <I>animationBetweenViewpoints</I>.&nbsp; True animated between viewpoints, false jumps between Viewpoints */
	public void SetAnimationBetweenViewpoints(boolean value){
		graphicsEngine.SetAnimationBetweenViewpoints(value);
	}
	/** Get the <I>animationBetweenViewpoints</I> value */
	public boolean GetAnimationBetweenViewpoints(){
		return graphicsEngine.GetAnimationBetweenViewpoints();
	}

	/** If setting the Viewpoint's field-of-view, SetViewFrustum must be called to reset clipping planes and desitnation */
	public void SetViewFrustum(float fieldOfView){
		graphicsEngine.SetViewFrustum(fieldOfView);
	} // end GetFirstViewpointInList


} // end class GraphicsEngineApplet
