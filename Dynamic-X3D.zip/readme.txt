Dynamic-X3D builds upon Dynamic-3D using many of the same files, except that the parser now reads X3D instead of VRML.

LexicalAnalyzerX3D.java is the debug version of the code giving verbose messages.  LexicalAnalyzerX3DNDB.java is the non-debug version of the code and gives very few messages.  It must be renamed to "LexicalAnalyzerX3D.java" for the Publish version.

Also, GraphicsEngineApplet.java is the Publish version.  GraphicsEngineAppletDebug.java is the Preview version with verbose error messages.